// Read publication formatting as inert text. Never insert publisher markup into the UI.
export function publicationText(value) {
  const template = document.createElement('template');
  template.innerHTML = String(value || '');
  template.content.querySelectorAll('script,style').forEach(node => node.remove());
  return template.content.textContent || '';
}

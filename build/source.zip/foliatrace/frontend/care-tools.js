// Task tools use saved source versions; editable drafts never become evidence.
const STATUS = {PASS:'Text signal found', PARTIAL:'Needs reading', UNKNOWN:'Not established', FAIL:'Scope conflict'};
const SOURCE = {PERSON_REPORTED:'Person or caregiver', PACKAGING_REPORTED:'Packaging, reported by recorder', PROFESSIONAL_NOTE:'Professional note'};

export function clarificationPanel({record,item,api,el,onSave}) {
  const panel=el('section',undefined,'clarification-panel');
  const history=(record.packet.clarification_history||[]).filter(n=>n.item_id===item.reported.item_id);
  const latest=new Map(history.map(n=>[n.field,n]));
  const answered=item.clarification_questions.filter(q=>latest.get(q.field)?.status==='ANSWER_RECORDED').length;
  panel.append(el('h4','Make the next conversation easier'),el('p',answered+' of '+item.clarification_questions.length+' questions have a recorded answer. Original reported details stay unchanged.','hint'));
  for(const task of item.clarification_questions){
    const note=latest.get(task.field),row=el('details',undefined,'clarification-task');
    row.append(el('summary',(note?.status==='ANSWER_RECORDED'?'Answer recorded · ':note?'Ask pharmacist · ':'To clarify · ')+task.question));
    if(note){row.append(el('p',note.note,'clarification-answer'),el('p',(SOURCE[note.source]||note.source)+' · '+note.recorded_by+' · '+new Date(note.created_at).toLocaleString(),'hint'));}
    if(record.origin==='LOCAL_CONSULTATION_PREPARATION'){
      const form=el('form');
      const field=(title,name,type='input')=>{const label=el('label',title),input=el(type);input.name=name;label.append(input);form.append(label);return input;};
      const status=field('What happens next?','status','select');
      for(const [value,text] of [['ANSWER_RECORDED','Record an answer, with its source'],['ASK_PROFESSIONAL','Keep a question for the pharmacist']]){const o=el('option',text);o.value=value;status.append(o);}
      status.value=note?.status||'ASK_PROFESSIONAL';
      const text=field('Answer or question to bring','note','textarea');text.rows=3;text.required=true;text.minLength=5;text.maxLength=2000;text.value=note?.note||'';
      const source=field('Where did this information come from?','source','select');
      for(const [value,label] of Object.entries(SOURCE)){const o=el('option',label);o.value=value;source.append(o);}source.value=note?.source||'PERSON_REPORTED';
      const by=field('Recorded by (a role is enough)','recorded_by');by.required=true;by.maxLength=80;by.value=note?.recorded_by||'Patient or caregiver';
      const save=el('button','Save note as a new snapshot','quiet');save.type='submit';const feedback=el('p','','hint');feedback.setAttribute('role','status');form.append(save,feedback);
      form.onsubmit=async event=>{event.preventDefault();save.disabled=true;try{await onSave({item_id:item.reported.item_id,field:task.field,status:status.value,note:text.value,source:source.value,recorded_by:by.value},record);}
        catch(error){feedback.textContent='Not saved: '+error.message+'. Your note is kept here.';}finally{save.disabled=false;}};
      row.append(form);
    }
    panel.append(row);
  }
  if(history.length){const audit=el('details');audit.append(el('summary','Earlier clarification notes ('+history.length+')'));for(const n of history)audit.append(el('p',n.field+' · '+n.note),el('p',(SOURCE[n.source]||n.source)+' · '+n.recorded_by+' · '+n.created_at,'hint'));panel.append(audit);}
  return panel;
}

export function sharePanel({record,api,el}) {
  const panel=el('details',undefined,'selected-sharing');panel.append(el('summary','Choose what to share with your pharmacist'));
  panel.append(el('p','Nothing is selected automatically. Preview the exact information before downloading. Omitted information does not mean “none”.','hint'));
  const form=el('form'),products=el('fieldset');products.append(el('legend','1 · Select products'));
  const checkbox=(parent,label,name,value)=>{const wrap=el('label',undefined,'share-choice'),input=el('input');input.type='checkbox';input.name=name;if(value)input.value=value;wrap.append(input,el('span',label));parent.append(wrap);return input;};
  for(const item of record.packet.products)checkbox(products,item.reported.name,'item_ids',item.reported.item_id);
  form.append(products);const extra=el('fieldset');extra.append(el('legend','2 · Add only what you want included'));
  for(const [name,title] of [['include_medicines','Other medicines and their reported status'],['include_allergies','Allergies / previous reactions and their reported status'],['include_questions','Your additional questions and missing-context prompts'],['include_clarifications','Recorded clarification answers and their sources'],['include_reading','Attached professional reading decisions and reasons']])checkbox(extra,title,name);
  form.append(extra);
  const preview=el('button','Preview selected handoff');preview.type='submit';preview.disabled=true;
  const message=el('p','Select at least one product.','hint');message.setAttribute('role','status');
  const output=el('div',undefined,'share-preview');output.hidden=true;
  const downloads=el('div',undefined,'share-downloads');downloads.hidden=true;let generation=0,urls=[];
  const invalidate=()=>{generation++;for(const u of urls)URL.revokeObjectURL(u);urls=[];output.replaceChildren();output.hidden=true;downloads.replaceChildren();downloads.hidden=true;preview.disabled=!form.querySelector('[name="item_ids"]:checked');message.textContent=preview.disabled?'Select at least one product.':'Selection changed. Generate a fresh preview before sharing.';};
  form.addEventListener('change',invalidate);
  form.onsubmit=async event=>{event.preventDefault();const at=++generation,data=new FormData(form),selection={item_ids:data.getAll('item_ids')};for(const input of form.querySelectorAll('input[type="checkbox"]'))if(input.name!=='item_ids')selection[input.name]=input.checked;preview.disabled=true;message.textContent='Preparing only your selected information…';
    try{const result=await api('/api/consultations/'+record.id+'/share-preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(selection)});if(at!==generation)return;
      const p=result.projection;output.replaceChildren(el('h3','Your sharing preview'),el('p',p.sharing_scope,'hint'),el('p',p.scope,'hint'));
      for(const [key,title] of [['other_medicines','Other medicines'],['allergies','Allergies / previous reactions']])if(p[key])output.append(el('h4',title),el('p',p[key].status),el('p',p[key].details||'No details recorded'));
      if('questions' in p){output.append(el('h4','Questions to discuss'),el('p',p.questions||'No additional question recorded'));for(const q of p.next_questions||[])output.append(el('p',q));}
      for(const row of p.products){const card=el('article',undefined,'share-preview-product');card.append(el('h4',row.name),el('p',row.use),el('p','Brand: '+(row.brand||'Not provided')));
        for(const [key,value] of Object.entries(row.actual_use))card.append(el('p',key.replaceAll('_',' ')+': '+value));
        card.append(el('p','Stated form: '+row.stated_preparation),el('p','Reported reason: '+row.reported_reason));
        if(row.label){card.append(el('p','NIH label '+row.label.id+' · bottle match not established'));for(const ing of row.ingredients)card.append(el('p',(ing.nested?'Within blend: ':'')+ing.name+': '+(ing.amounts.join('; ')||'Individual amount not provided')),el('p',ing.forms),el('p',ing.notes));const other=row.other_ingredients||{};card.append(el('p','Other declared ingredients: '+(other.text||(other.ingredients||[]).map(i=>i.name).join('; ')||'Not provided')));}
        else card.append(el('p',row.source_text||'No original wording recorded'));
        const questions=el('ul');for(const q of row.clarifications)questions.append(el('li',q));card.append(questions);
        for(const note of row.clarification_notes||[])card.append(el('p',note.field+' · '+note.note),el('p',(SOURCE[note.source]||note.source)+' · '+note.recorded_by+' · '+note.created_at,'hint'));
        for(const r of row.reviews||[]){card.append(el('h4','Professional reading · not product approval'),el('p',r.question),el('p',r.coverage_note,'hint'),el('p',r.unreviewed_records+' candidate/study records have no recorded human decision.'));if(!r.decisions.length)card.append(el('p','No human reading decision recorded.'));for(const d of r.decisions)card.append(el('p',d.title),el('p',d.decision+': '+d.reason),el('p','Recorded by: '+d.reviewer));}output.append(card);
      }
      const omitted=[['include_medicines','other medicines'],['include_allergies','allergies'],['include_questions','additional questions'],['include_clarifications','clarification notes'],['include_reading','professional readings']].filter(([key])=>!selection[key]).map(([,name])=>name);
      message.textContent=p.products.length+' selected product(s). Excluded: '+(omitted.join(', ')||'no optional sections')+'. This file contains health information.';
      output.hidden=false;downloads.replaceChildren();for(const [text,type,content,filename] of [['Open selected handoff to print','text/html',result.html,'foliatrace-selected-handoff.html'],['Download selected data','application/json',JSON.stringify(p,null,2),'foliatrace-selected-handoff.json']]){const a=el('a',text,'button-link');const u=URL.createObjectURL(new Blob([content],{type}));urls.push(u);a.href=u;if(type==='text/html'){a.target='_blank';a.rel='noopener noreferrer';}else a.download=filename;downloads.append(a);}downloads.hidden=false;
    }catch(error){if(at===generation)message.textContent='Preview unavailable: '+error.message+'. Nothing has been shared.';}finally{if(at===generation)preview.disabled=false;}
  };
  form.append(preview,message);panel.append(form,output,downloads);return panel;
}

export function bridgePanel({context,record,row,api,el,link}) {
  const panel=el('section',undefined,'product-study-bridge');
  const button=el('button','Compare this study with the saved product','quiet');button.type='button';
  const content=el('div');panel.append(button,content);
  button.onclick=async()=>{button.disabled=true;content.replaceChildren(el('p','Checking the exact product and study versions…','hint'));
    try{const params=new URLSearchParams({review_id:record.id,item_id:context.item_id,record_id:row.id});if(context.ingredient_key)params.set('ingredient_key',context.ingredient_key);
      const result=await api('/api/consultations/'+context.consultation_id+'/study-bridge?'+params);
      content.replaceChildren(el('h4',result.product_name+' ↔ '+result.candidate),el('p',result.scope,'hint'));
      if(result.source_label)content.append(link('Selected NIH label '+result.source_label.id+' ↗',result.source_label.url));
      const scroll=el('div',undefined,'bridge-scroll');scroll.tabIndex=0;scroll.setAttribute('role','region');scroll.setAttribute('aria-label','Product and study comparison; scroll horizontally if needed');
      const table=el('table',undefined,'bridge-table'),caption=el('caption','What is known on each side');table.append(caption);const head=el('thead'),tr=el('tr');for(const title of ['Check','Saved product / report','Question and study source']){const th=el('th',title);th.scope='col';tr.append(th);}head.append(tr);table.append(head);const body=el('tbody');
      for(const d of result.dimensions){
        const tr=el('tr'),title=el('th',d.label);title.scope='row';
        const product=el('td',d.product),study=el('td');
        const requirement={human:'Human participants',any:'No specific requirement',single_plant:'This plant alone',controlled:'A comparison group',placebo:'A placebo comparison'}[d.question_requirement]||String(d.question_requirement).replaceAll('_',' ');
        study.append(el('span',STATUS[d.status]||d.status,'bridge-status '+d.status.toLowerCase()),el('p','Requested: '+requirement));
        const why=el('details',undefined,'bridge-reason');why.open=d.status==='FAIL';
        why.append(el('summary','Reason and source'),el('p',d.detail));
        if(d.caution&&d.caution!==d.detail)why.append(el('p',d.caution,'hint'));
        for(const span of d.spans){why.append(el('blockquote',span.text));if(span.url)why.append(link('Inspect source ↗',span.url));}
        study.append(why);tr.append(title,product,study);body.append(tr);
      }
      table.append(body);scroll.append(table);content.append(scroll);button.textContent='Product comparison loaded';
    }catch(error){content.replaceChildren(el('p','Comparison unavailable: '+error.message+'. No product match has been inferred.','error'));button.disabled=false;}
  };
  return panel;
}

import {initHandoffs} from './handoff.js';
import {initConsultation} from './consultation.js';
import {initQuestionReview} from './question-review.js';
import {publicationText} from './publication-text.js';
const $ = (s) => document.querySelector(s);
let data,
  health,
  passages = [],
  custom = false,
  selected = null,
  graphFocus = null,
  recorded = false,
  analysisSerial = 0,
  requestedSourceName = null;
let readingResumeActive=false,restoringReading=false;
const RESUME_READING_KEY='foliatrace.resume.v1';
const identityComparisons=new Map();
const statementReadingTargets=new Map();
const studyComparisons=new Map();

// Plain-language meaning of every machine state shown to a reader.
const STATUS = {
  RESOLVED_MODERN_NAME: ["ok", "Matches a modern scientific name", "A modern checklist accepts this name. That still does not prove what the historical author meant."],
  PROVISIONAL: ["warn", "One candidate, via a common name", "Only one species in this snapshot carries this name. Species outside the snapshot may share it."],
  AMBIGUOUS: ["bad", "Ambiguous: several species", "Several species share this name. Evidence is kept separate for each candidate."],
  GENUS_ONLY: ["warn", "Genus only", "The name points to a whole genus. Each species in the snapshot is a separate branch."],
  OPEN_WORLD_AMBIGUOUS: ["warn", "Other regional species share this name", "The snapshot holds one species, but GBIF lists other species of this genus with the same common name and records in Great Britain."],
  UNRESOLVED: ["neutral", "Not resolved", "No candidate found. That is not evidence that the plant is unknown."],
};
const RATING = { STRONG: ["ok", "Strong fit"], MODERATE: ["warn", "Moderate fit"], WEAK: ["neutral", "Weak fit"], NOT_ASSESSABLE: ["neutral", "Not assessable"] };
const MATRIX_STATUS = { MATCH: ["ok", "fits"], PARTIAL: ["warn", "partly fits"], CONFLICT: ["bad", "conflicts"] };
const RESEARCH_STATE = {
  HUMAN_FINDINGS_FAVOURABLE: ["ok", "Human studies report benefit"],
  HUMAN_FINDINGS_EARLY: ["warn", "Early human findings, too few to rely on"],
  HUMAN_FINDINGS_MIXED: ["warn", "Human findings mixed or inconclusive"],
  HUMAN_NO_BENEFIT_REPORTED: ["bad", "Human studies report no benefit"],
  HUMAN_STUDIED_RESULT_UNCLEAR: ["neutral", "Studied in humans, result unclear"],
  PRECLINICAL_ONLY: ["warn", "Laboratory studies only"],
  SPECIES_NAMED_NO_TESTED_RESULT: ["neutral", "Mentioned, not the study subject"],
  COMMON_NAME_ONLY: ["neutral", "Common name only; species unclear"],
  NO_STUDY_RETRIEVED: ["neutral", "No study retrieved"],
};
const REASONS = {
  OPEN_WORLD_CHECK_NOT_AVAILABLE: "Regional name-collision check unavailable for this taxon",
  EXACT_ACCEPTED_NAME: "Exact accepted scientific name",
  EXACT_SYNONYM: "Exact scientific synonym",
  EXACT_INPUT_SYNONYM_MATCH: "Exact scientific synonym",
  EXACT_SYNONYM_HOMONYM: "Same wording is another species' accepted name (homonym)",
  NAMED_IN_SOURCE_FIRST_SENTENCE: "The source names this species in the next sentence",
  OPENING_SOURCE_COMMON_NAME: "The opening botanical subject uses a specific common name for this candidate",
  EXACT_VERNACULAR: "Exact common-name match",
  RECORDED_LOCAL_NAME: "Local name in a published list",
  EXACT_HISTORICAL_LEXICON: "Listed for this historical name",
  GBIF_EXACT_COMMON_NAME: "GBIF lists this common name",
  GBIF_GENUS_MEMBER: "A species of the named genus",
  GBIF_EXACT_SCIENTIFIC_NAME: "Exact GBIF scientific name",
  FUZZY_NAME: "Spelling-tolerant name match",
  ABBREVIATED_GENUS: "Abbreviated genus with matching epithet",
  GENUS_VERNACULAR_ONLY: "Common name used for the whole genus",
  GENUS_CONTEXT_ONLY: "Genus name only",
  OPEN_WORLD_CONGENERS_IN_REGION: "Other species of this genus share the name",
  RANGE_MATCH: "Recorded in the source region",
  RANGE_CONFLICT_REQUIRES_REVIEW: "Not recorded in the source region",
  NO_VERIFIED_RANGE_IN_SNAPSHOT: "No verified range in snapshot",
};
const SENSITIVITY = {
  CONCLUSION_CHANGES_WITH_IDENTITY: ["Evidence availability and its limits depend on which plant this is.", false],
  EVIDENCE_SET_CHANGES_WITH_IDENTITY: ["Different candidates reach different papers.", false],
  STABLE_ACROSS_CANDIDATES: ["Every candidate leads to the same evidence.", true],
  SINGLE_CANDIDATE_IN_SNAPSHOT: ["One candidate in this snapshot.", true],
  OPEN_WORLD_ALTERNATIVES_NOT_RETRIEVED: ["Other species share this name; their evidence was not retrieved.", false],
  NO_CANDIDATE: ["No candidate in this snapshot.", true],
};
const BRANCH_STATE = {
  NO_EVIDENCE_IN_SNAPSHOT: "No evidence in snapshot",
  COMMON_NAME_ONLY_EVIDENCE: "Only papers that use the common name",
  SPECIES_SPECIFIC_BUT_INSUFFICIENT: "Species named, but cannot answer the question",
  SPECIES_SPECIFIC_FINDINGS: "Species-specific findings",
  COMPARABILITY_NOT_ASSESSED: "Saved before screening existed; re-run to screen",
};
const BLOCKING = {
  identity: "species not established",
  population: "population not human or not stated",
  design: "design cannot test efficacy",
  comparator: "comparator missing or not established",
  outcome: "no result for the condition",
  preparation: "preparation differs or is not established",
  intervention: "isolated compound, not the plant",
  NONE: "every automated check passed",
  NONE_UNRESOLVED: "no check failed, some unresolved",
  NOT_ASSESSED_LEGACY_RECORD: "not screened (saved before checks existed)",
};
// No blocking check is not the same as passing: partial or unknown checks stay visible.
function blockingKey(e) {
  const c = e.comparability;
  if (!c) return "NOT_ASSESSED_LEGACY_RECORD";
  if (c.first_blocking_check) return c.first_blocking_check;
  return (c.checks || []).some((x) => x.status !== "PASS") ? "NONE_UNRESOLVED" : "NONE";
}
const CHECK_LABEL = { identity: "Species", population: "Population", design: "Design", comparator: "Comparator", outcome: "Outcome", preparation: "Preparation", intervention: "Intervention" };
const CASES = [
  ["CAMOMILE.", "Camomile", "compare possible plant identities"],
  ["MINT.", "Mint", "evidence changes with identity"],
  ["SAGE.", "Sage · 1897", "follow leaf tea into a controlled study", {collection:true,sourceStudy:{paperId:'PMC13203699',name:'Salvia officinalis'}}],
  ["FEVERFEW OR FEATHERFEW.", "Feverfew", "follow its recorded preparations"],
  ["THYME.", "Thyme", "see why the species matters"],
  ["FEVERFEW.", "Feverfew · 1897", "untangle changes of plant in the source"],
];

function el(tag, text, cls) {
  const e = document.createElement(tag);
  if (text !== undefined && text !== null) e.textContent = String(text);
  if (cls) e.className = cls;
  return e;
}
function link(text, url) {
  const a = el("a", text);
  try {
    const u = new URL(url, location.origin);
    if (["https:", "http:"].includes(u.protocol)) {
      a.href = u.href;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
    }
  } catch {}
  return a;
}
function pill(text, tone = "neutral") {
  return el("span", text, "pill " + tone);
}
function human(value) {
  return String(value ?? "").replaceAll("_", " ").toLowerCase();
}
function currentLiterature(name) {
  return link('Find current papers ↗', 'https://pubmed.ncbi.nlm.nih.gov/?term='+encodeURIComponent('"'+name+'"'));
}
function option(value, label) {
  const o = el("option", label);
  o.value = value;
  return o;
}
function status(text, error = false) {
  $("#status").textContent = text;
  $("#status").className = error ? "error" : "";
  if (error) $("#status").hidden = false;
}
async function api(path, options) {
  const r = await fetch(path, options);
  if (!r.ok) {
    const e = await r.json().catch(() => ({ detail: "Request failed" }));
    throw new Error(typeof e.detail === "string" ? e.detail : JSON.stringify(e.detail));
  }
  return r.json();
}
let benchmarkRequest;
function benchmarks() {
  if (!benchmarkRequest) benchmarkRequest = api('/api/benchmarks').catch(error => { benchmarkRequest = null; throw error; });
  return benchmarkRequest;
}
// Europe PMC titles keep inline markup such as <i>Genus species</i>; strip it for display only.
function cleanTitle(t) {
  return publicationText(t);
}
function plural(n, word) {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}
function relationTone(r) {
  return r === "SUPPORTS" ? "ok" : r === "CONTRADICTS" || r === "MIXED" ? "bad" : "neutral";
}
function group() {
  return data?.identity_counterfactuals.find((g) => g.key === selected);
}
function taxonName(id) {
  for (const g of data.identity_counterfactuals) for (const b of g.branches) if (b.taxon_id === id) return b.name;
  return id;
}

/* ---------- Views and tabs ---------- */
let researchReady=false,researchLoading=null;
async function ensureResearch(){
  if(researchReady)return;
  if(!researchLoading)researchLoading=(async()=>{
    passages=await api('/api/passages');
    for(const id of ['compare-a','compare-b'])$('#'+id).replaceChildren(...passages.map(p=>option(p.id,`${p.collection||'Culpeper 1850'} · ${p.title}`)));
    $('#compare-a').value=passages.find(p=>p.title==='CAMOMILE.'&&!p.collection)?.id||passages[0]?.id;
    $('#compare-b').value=passages.find(p=>p.collection&&/CHAMOM|CAMOM/.test(p.title))?.id||passages[1]?.id;
    $('#passage').replaceChildren();
    for(const label of [...new Set(passages.map(p=>p.collection||'Culpeper 1850'))]){const group=el('optgroup');group.label=label;group.append(...passages.filter(p=>(p.collection||'Culpeper 1850')===label).map(p=>option(p.id,p.title)));$('#passage').append(group);}
    renderCases();renderResearchTrails();researchReady=true;
  })().catch(error=>{researchLoading=null;throw error;});
  return researchLoading;
}
function showView(name,questionInitial=null) {
  if(!['consultation','question'].includes(name)&&!researchReady)return ensureResearch().then(()=>showView(name,questionInitial)).catch(error=>status('Could not load the research library: '+error.message,true));
  rememberReading();
  for (const b of document.querySelectorAll(".view-tab")) {
    if (b.dataset.view === name) b.setAttribute("aria-current", "page");
    else b.removeAttribute("aria-current");
  }
  for (const v of ["workspace", "map", "graph", "evaluation", "chemistry", "library", "handoffs", "consultation", "question"]) $("#view-" + v).hidden = v !== name;
  history.replaceState(null,'','#'+name);
  const tools=$('.research-tools');if(tools){tools.hidden=!location.pathname.startsWith('/research');tools.open=!['consultation','question'].includes(name);}
  if(health)$('#literature-availability').hidden=name==='consultation'||health.abstracts_available>=health.papers;
  $(".source-bar").hidden = name !== "workspace";
  $("#status").hidden = name !== "workspace";
  if(!restoringReading&&data&&['workspace','graph'].includes(name))readingResumeActive=true;
  if (name === "graph" && data) renderGraph();
  if (name === "chemistry") return loadChemistry();
  if (name === "map") return loadEvidenceMap();
  if (name === "library") loadLibrary();
  if (name === 'handoffs') return handoffs.open();
  if (name === 'consultation') return consultation.open();
  if (name === 'question') return questionReview.open(questionInitial);
  if (name === 'evaluation') return loadMetrics();
}

let librarySnapshot, libraryLimit = 6, rankedLibrary = null, librarySearchText = '', libraryFocus = null, librarySearchSerial = 0, libraryScrollY = 0;
let librarySaved = new Set(), librarySavedOnly = false, libraryVisibleRows = [], libraryNotes = {};
let libraryBeforeSaved = null;
let sourceFocusOrigin = 'library';
let sourceEvidenceFocus = null;
let libraryReadingEntries = new Map(), libraryReadingMigrations = new Set();
function savedReading(){
  if(recorded)return null;
  try{const saved=JSON.parse(localStorage.getItem(RESUME_READING_KEY)||'null');return saved?.version===1&&/^[a-f0-9]{24}$/.test(saved.runId)?saved:null;}catch{return null;}
}
function updateResumeControl(){const control=$('#resume-reading');if(control)control.hidden=recorded||!savedReading();}
function rememberReading(){
  if(recorded||restoringReading||!readingResumeActive||!data?.run_id||($('#view-workspace').hidden&&$('#view-graph').hidden))return;
  const focused=libraryFocus?.source_id===data.source.id?libraryFocus.statement:null;
  const previous=savedReading(),activeView=$('#view-workspace').hidden?$('#view-graph'):$('#view-workspace'),bounds=activeView.getBoundingClientRect();
  const filters=Object.fromEntries(['branch','study-type','relation','year'].map(id=>[id,$('#'+id).value]));
  const tab=$('[role="tab"][aria-selected="true"]')?.id||'tab-identity';
  const keepPosition=!(bounds.top<window.innerHeight-80&&bounds.bottom>80)&&previous?.runId===data.run_id&&previous.name===selected&&previous.tab===tab&&previous.width===window.innerWidth&&JSON.stringify(previous.filters)===JSON.stringify(filters);
  const saved={version:1,runId:data.run_id,name:selected,tab,filters,
    identityPair:identityComparisons.get(data.run_id+'::'+selected)||null,
    statementTarget:statementReadingTargets.get(data.run_id+'::'+selected)??'',
    studyComparison:studyComparisons.get(studyComparisonScope())||[],
    scrollY:keepPosition?previous.scrollY:window.scrollY,width:window.innerWidth,sourceScroll:$('#original').scrollTop,
    sourceFocus:focused?{start:focused.start,end:focused.end}:null,
    evidenceFocus:sourceFocusOrigin==='evidence'?sourceEvidenceFocus:null,
    papers:[...$('#evidence').querySelectorAll('.evidence-item')].map(card=>({paper:card.dataset.paper,taxon:card.dataset.taxon,condition:card.dataset.condition,hidden:card.hidden,source:!!card.querySelector(':scope > .study-source-comparison')?.open,context:!!card.querySelector(':scope > .study-context')?.open,topics:!!card.querySelector(':scope > .linked-conditions')?.open})),
    trialReadings:[...$('#evidence').querySelectorAll('.trial-readings')].map(panel=>({id:panel.dataset.readingSet,open:panel.open,contexts:[...panel.querySelectorAll('.trial-reading-context[open]')].map(context=>context.closest('.trial-reading-card').dataset.pmid)}))};
  try{localStorage.setItem(RESUME_READING_KEY,JSON.stringify(saved));updateResumeControl();}catch{}
}
async function resumeReading(saved,{navigate=true,position=true}={}){
  invalidatePendingAnalysis();
  const serial=analysisSerial;
  status('Reopening your saved analysis…');
  const result=await api('/api/analyses/'+saved.runId);
  if(serial!==analysisSerial)return null;
  restoringReading=true;
  try{
    data=result;data.researcher_reviews||=[];requestedSourceName=data.configuration.requested_name||null;
    const passage=passages.find(p=>p.id===data.source.id);custom=!passage;
    $('#passage').value=passage?.id||'';$('#input').value=data.input;
    if(custom)$('#custom-input').open=true;
    if([...$('#analysis-ranking').options].some(o=>o.value===data.configuration.retrieval))$('#analysis-ranking').value=data.configuration.retrieval;
    libraryFocus=null;sourceEvidenceFocus=null;sourceFocusOrigin='resume';
    const chars=Array.from(data.input),focus=saved.sourceFocus;
    if(focus&&Number.isInteger(focus.start)&&Number.isInteger(focus.end)&&focus.start>=0&&focus.end>focus.start&&focus.end<=chars.length){
      libraryFocus={source_id:data.source.id,statement:{start:focus.start,end:focus.end,text:chars.slice(focus.start,focus.end).join('')}};
      const target=saved.evidenceFocus;
      if(target&&data.evidence.some(e=>e.paper.id===target.paperId&&e.taxon_id===target.taxonId)&&data.identity_counterfactuals.some(g=>g.key===target.nameKey)){sourceEvidenceFocus=target;sourceFocusOrigin='evidence';}
    }
    const resumeName=data.identity_counterfactuals.find(g=>g.key===saved.name);
    if(resumeName&&(saved.statementTarget===''||data.historical_claims.some(claim=>claim.id===saved.statementTarget&&resumeName.claim_ids.includes(claim.id))))statementReadingTargets.set(identityPairKey(resumeName),saved.statementTarget);
    if(resumeName&&Array.isArray(saved.identityPair)&&saved.identityPair.length===2&&saved.identityPair[0]!==saved.identityPair[1]&&saved.identityPair.every(id=>resumeName.branches.some(branch=>branch.taxon_id===id)))identityComparisons.set(identityPairKey(resumeName),saved.identityPair);
    render();if(resumeName)selectName(saved.name);
    if(resumeName&&Array.isArray(saved.studyComparison)){
      const pool=studyComparisonPool();studyComparisons.set(studyComparisonScope(),[...new Set(saved.studyComparison)].filter(key=>pool.has(key)).slice(0,3));
    }
    for(const [id,value] of Object.entries(saved.filters||{}))if(['branch','study-type','relation','year'].includes(id)){
      const control=$('#'+id);if(control.tagName!=='SELECT'||[...control.options].some(o=>o.value===value))control.value=value;
    }
    renderEvidence();
    for(const item of Array.isArray(saved.papers)?saved.papers:[]){
      const card=[...$('#evidence').querySelectorAll('.evidence-item')].find(card=>card.dataset.paper===item.paper&&card.dataset.taxon===item.taxon&&card.dataset.condition===item.condition);
      if(!card)continue;card.hidden=item.hidden===true;
      for(const [selector,key] of [['.study-source-comparison','source'],['.study-context','context'],['.linked-conditions','topics']]){const panel=card.querySelector(':scope > '+selector);if(panel)panel.open=item[key]===true;}
    }
    for(const section of $('#evidence').querySelectorAll('.branch-group')){
      const more=section.querySelector(':scope > .more'),remaining=section.querySelectorAll(':scope > .evidence-item[hidden]').length;
      if(more){if(remaining)more.textContent='Read '+remaining+' more publications';else more.remove();}
    }
    for(const item of Array.isArray(saved.trialReadings)?saved.trialReadings:[]){
      const panel=[...$('#evidence').querySelectorAll('.trial-readings')].find(panel=>panel.dataset.readingSet===item.id);if(!panel)continue;panel.open=item.open===true;
      for(const context of panel.querySelectorAll('.trial-reading-context'))context.open=Array.isArray(item.contexts)&&item.contexts.includes(context.closest('.trial-reading-card').dataset.pmid);
    }
    showTab(['tab-identity','tab-evidence','tab-review'].includes(saved.tab)?saved.tab:'tab-identity');
    if(navigate)showView('workspace');
    readingResumeActive=true;updateResumeControl();
    status('Resumed your saved analysis and reading context. Analyze again when you want results from the current data.');
    if(position)requestAnimationFrame(()=>requestAnimationFrame(()=>{if($('#view-workspace').hidden&&$('#view-graph').hidden)return;if(Number.isFinite(saved.sourceScroll))$('#original').scrollTop=Math.max(0,saved.sourceScroll);if(saved.width===window.innerWidth&&Number.isFinite(saved.scrollY))window.scrollTo({top:Math.max(0,saved.scrollY),behavior:'auto'});else focusNameInspector();}));
    return true;
  }finally{restoringReading=false;}
}
window.addEventListener('pagehide',rememberReading);
let rememberReadingTimer;
function scheduleRememberReading(){clearTimeout(rememberReadingTimer);rememberReadingTimer=setTimeout(rememberReading,250);}
window.addEventListener('scroll',scheduleRememberReading,{passive:true});
document.addEventListener('toggle',scheduleRememberReading,true);
$('#resume-reading').addEventListener('click',async()=>{const saved=savedReading();if(!saved)return;const control=$('#resume-reading');control.disabled=true;try{await resumeReading(saved);}catch(error){status('Could not reopen that saved reading: '+error.message,true);}finally{control.disabled=false;}});
const READING_STORE = 'foliatrace.reading.v2';
const libraryComparison = new Map();
const libraryExpanded = new Set();
const ROLE_LABEL = {THERAPEUTIC_USE_RECORDED:'Recorded use', ADVERSE_EFFECT_RECORDED:'Possible harmful effect', CONTEXT_ONLY_OR_UNCLEAR:'Context or unclear'};
function statementRoleLabel(record){
  const role=record.statement_role,scope=record.scope??record.relation_scope;
  if(scope==='PARAGRAPH_CONTEXT_UNCERTAIN_RELATION'&&['THERAPEUTIC_USE_RECORDED','ADVERSE_EFFECT_RECORDED'].includes(role))return 'Statement · subject unresolved';
  if(scope==='MULTI_PLANT_CLAUSE_UNCERTAIN_RELATION'&&['THERAPEUTIC_USE_RECORDED','ADVERSE_EFFECT_RECORDED'].includes(role))return 'Statement · plant attribution unresolved';
  return ROLE_LABEL[role]||'Statement';
}
function sourceLabel(value) { return value.replace(/\[\d+\]\s*/g,'').replace(/\.$/,'').trim(); }
function readingKey(row){return JSON.stringify([row.source_id,row.collection,row.date,row.url,row.statement.start,row.statement.end,row.statement.text]);}
function persistLibraryReading(record){
  for(const row of record?[record]:librarySnapshot.records){
    const key=readingKey(row),saved=librarySaved.has(row.id),note=libraryNotes[row.id]||'';
    if(saved||note)libraryReadingEntries.set(key,{key,saved,note});else libraryReadingEntries.delete(key);
  }
  localStorage.setItem(READING_STORE,JSON.stringify({version:2,entries:[...libraryReadingEntries.values()],migrated_snapshots:[...libraryReadingMigrations]}));
}
function restoreLibraryReading(){
  try{
    const stored=JSON.parse(localStorage.getItem(READING_STORE)||'{}');
    if(stored.version===2&&Array.isArray(stored.entries)){
      libraryReadingEntries=new Map(stored.entries.filter(e=>typeof e.key==='string'&&typeof e.note==='string').map(e=>[e.key,{key:e.key,saved:e.saved===true,note:e.note}]));
      libraryReadingMigrations=new Set((stored.migrated_snapshots||[]).filter(s=>typeof s==='string'));
    }
  }catch{}
  const rows=new Map(librarySnapshot.records.map(row=>[row.id,row]));
  for(const migration of [{snapshot_sha256:librarySnapshot.snapshot_sha256,id_map:null},...(librarySnapshot.reading_migrations||[])]){
    if(libraryReadingMigrations.has(migration.snapshot_sha256))continue;
    try{
      const saved=JSON.parse(localStorage.getItem('foliatrace.saved.'+migration.snapshot_sha256)||'[]');
      const notes=JSON.parse(localStorage.getItem('foliatrace.notes.'+migration.snapshot_sha256)||'{}');
      const savedIds=new Set(Array.isArray(saved)?saved:[]),noteMap=notes&&typeof notes==='object'&&!Array.isArray(notes)?notes:{};
      for(const oldId of new Set([...savedIds,...Object.keys(noteMap)])){
        const row=rows.get(migration.id_map?migration.id_map[oldId]:oldId);if(!row)continue;
        const key=readingKey(row);if(libraryReadingEntries.has(key))continue;
        libraryReadingEntries.set(key,{key,saved:savedIds.has(oldId),note:typeof noteMap[oldId]==='string'?noteMap[oldId]:''});
      }
      libraryReadingMigrations.add(migration.snapshot_sha256);
    }catch{}
  }
  librarySaved=new Set();libraryNotes={};
  for(const row of librarySnapshot.records){const entry=libraryReadingEntries.get(readingKey(row));if(entry?.saved)librarySaved.add(row.id);if(entry?.note)libraryNotes[row.id]=entry.note;}
}
function storeLibrarySaved() {
  try{persistLibraryReading();}catch{$('#knowledge-search-status').textContent='Browser storage is unavailable. Export Reading notes to keep this reading list.';}
  updateSavedControl();
}
function updateSavedControl(){
  $('#library-saved').textContent=librarySavedOnly?'← Back to results':'Saved statements'+(librarySaved.size?' ('+librarySaved.size+')':'');
  $('#library-saved').setAttribute('aria-pressed',String(librarySavedOnly));
}
async function openLibraryRecord(row, origin = 'library') {
  sourceFocusOrigin = origin;
  libraryFocus = row;
  if (origin === 'library') libraryScrollY = window.scrollY;
  choosePassage(row.source_id); showView('workspace'); await analyze();
  if(data?.source.id!==row.source_id)return;
  const claim = data?.source.id === row.source_id && data.historical_claims.find(c=>c.support.start === row.statement.start);
  const target = claim && data.identity_counterfactuals.find(g=>g.claim_ids.includes(claim.id));
  if(target){statementReadingTargets.set(identityPairKey(target),claim.id);selectName(target.key);}
  $('#source-focus')?.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function saveStatementButton(row) {
  const button = el('button', librarySaved.has(row.id) ? 'Saved ✓' : 'Save statement', 'quiet');
  button.setAttribute('aria-pressed', String(librarySaved.has(row.id)));
  button.addEventListener('click', () => {
    librarySaved.has(row.id) ? librarySaved.delete(row.id) : librarySaved.add(row.id);
    storeLibrarySaved();
    button.textContent = librarySaved.has(row.id) ? 'Saved ✓' : 'Save statement';
    button.setAttribute('aria-pressed', String(librarySaved.has(row.id)));
    if (librarySavedOnly) loadLibrary();
  });
  return button;
}
function libraryAttribution(row) {
  const block=el('div',undefined,'statement-attribution');
  const label=row.scope==='PARAGRAPH_CONTEXT_UNCERTAIN_RELATION'?'Chapter index (subject unresolved): ':row.scope==='SOURCE_SECTION_HEADING'?'Chapter plant: ':'Plant wording: ';
  block.append(el('p',label+[...new Set(row.names.map(n=>n.text))].join(', '),'hint'));
  const note=statementQualifier({relation_scope:row.scope,negated:row.negated});
  if(note)block.append(el('p',note,'hint'));
  return block;
}
function readingNoteEditor(row) {
  const label=el('label','Your research note','reading-note'),input=el('textarea');
  input.rows=3;input.maxLength=4000;input.value=libraryNotes[row.id]||'';
  input.placeholder='Your interpretation, a question, or a citation to follow up…';
  const state=el('span','Stored in this browser; included in Reading notes.','hint');state.setAttribute('aria-live','polite');
  input.addEventListener('input',()=>{
    const value=input.value.trim();if(value)libraryNotes[row.id]=value;else delete libraryNotes[row.id];
    try{persistLibraryReading(row);state.textContent='Saved in this browser; included in Reading notes.';}
    catch{state.textContent='Browser storage is unavailable. Export Reading notes or a backup to keep this note.';}
  });
  label.append(input,state);return label;
}
function readingBackup() {
  // Include every saved statement and note, independently of the current filters.
  try{persistLibraryReading();}catch{} // In-memory notes can still be downloaded when storage is full.
  return {schema:'foliatrace.reading-backup',version:1,exported_at:new Date().toISOString(),entries:[...libraryReadingEntries.values()]};
}
function parseReadingBackup(value) {
  if(value?.schema!=='foliatrace.reading-backup'||value.version!==1||!Array.isArray(value.entries)||value.entries.length>20000)throw new Error('Choose a FoliaTrace reading backup JSON file.');
  const entries=new Map();
  for(const entry of value.entries){
    if(!entry||typeof entry.key!=='string'||typeof entry.saved!=='boolean'||typeof entry.note!=='string'||entry.note.length>4000)throw new Error('The backup contains an invalid reading entry. No notes were imported.');
    let anchor;try{anchor=JSON.parse(entry.key);}catch{throw new Error('The backup contains an invalid source anchor. No notes were imported.');}
    if(!Array.isArray(anchor)||anchor.length!==7||typeof anchor[0]!=='string'||typeof anchor[6]!=='string'||!Number.isInteger(anchor[4])||!Number.isInteger(anchor[5])||anchor[4]<0||anchor[5]<=anchor[4]||anchor[5]-anchor[4]!==Array.from(anchor[6]).length||anchor.slice(1,4).some(field=>field!==null&&!['string','number'].includes(typeof field)))throw new Error('The backup contains an invalid source anchor. No notes were imported.');
    const key=JSON.stringify(anchor),previous=entries.get(key);
    if(previous&&(previous.note!==entry.note||previous.saved!==entry.saved))throw new Error('The backup contains conflicting copies of one entry. No notes were imported.');
    entries.set(key,{key,saved:entry.saved,note:entry.note});
  }
  return [...entries.values()];
}
function restoreReadingBackup(value) {
  const incoming=parseReadingBackup(value),merged=new Map(libraryReadingEntries);
  let conflicts=0;
  for(const entry of incoming){
    const previous=merged.get(entry.key),conflict=!!(previous?.note&&entry.note&&previous.note!==entry.note);
    if(conflict)conflicts++;
    merged.set(entry.key,{...entry,saved:entry.saved||previous?.saved===true,note:previous?.note||entry.note});
  }
  // Commit only after the whole file is validated and storage succeeds.
  localStorage.setItem(READING_STORE,JSON.stringify({version:2,entries:[...merged.values()],migrated_snapshots:[...libraryReadingMigrations]}));
  libraryReadingEntries=merged;
  restoreLibraryReading();
  const active=new Set(librarySnapshot.records.map(readingKey)),matched=incoming.filter(entry=>active.has(entry.key)).length;
  return {entries:incoming.length,matched,unavailable:incoming.length-matched,conflicts};
}
function openSourceStudyReading(sourceStudy){
  const branch=data.identity_counterfactuals.flatMap(name=>name.branches).find(branch=>branch.name===sourceStudy.name);
  const study=branch&&data.evidence.find(e=>e.taxon_id===branch.taxon_id&&e.paper.id===sourceStudy.paperId&&e.historical_contexts?.some(context=>context.route.some(route=>/gargl/i.test(route.text))));
  const name=study&&data.identity_counterfactuals.find(name=>name.branches.some(branch=>branch.evidence_ids.includes(study.id)));
  if(!study||!name)return false;
  const context=study.historical_contexts.find(context=>context.route.some(route=>/gargl/i.test(route.text)));
  statementReadingTargets.set(identityPairKey(name),context.claim_id);selectName(name.key);openBranchPublication(study.taxon_id,study.paper.id);rememberReading();return true;
}
function renderResearchTrails() {
  const box=$('#research-trails');box.replaceChildren();
  const trails=[
    {title:'One name. Which plant?',source:'CAMOMILE.',collection:false,copy:'Choose two possible identities and read the changed publications. Then compare a historical swelling / joint-pain statement with a modern mouthwash study: the shared topic does not make the indications equivalent.',tab:'tab-identity',action:'Explore Camomile identities',indicationStudy:{paperId:'PMC13203699',taxonId:'gbif:8370958'}},
    {title:'Does the study answer the source?',source:'MINT.',collection:false,copy:'Read a Mint statement beside a combined-oil trial, or compare three placebo-controlled peppermint-oil trials. Inspect how formulation and primary endpoints change the question.',tab:'tab-evidence',action:'Read Mint trial',readingSet:'reading-set:peppermint-ibs-trials'},
    {title:'What carries forward into a modern study?',source:'SAGE.',collection:true,copy:'Fernie records Sage leaf tea with honey as a gargle. Read the Sage arm of a modern controlled mouthwash trial: inspect its aqueous preparation, measured outcomes and reported findings, alongside what the old statement leaves unspecified.',tab:'tab-evidence',action:'Follow Sage tea into the study',sourceStudy:{paperId:'PMC13203699',name:'Salvia officinalis'}},
    {title:'What does a molecule assay show?',view:'chemistry',copy:'Follow parthenolide’s reported assays and publication mentions. See the molecular target and original document, with the limits of what an assay can establish.',action:'Inspect parthenolide assays'},
  ];
  for(const trail of trails){
    const passage=passages.find(p=>p.title===trail.source&&Boolean(p.collection)===trail.collection);if(!passage&&!trail.view)continue;
    const card=el('article',undefined,'research-trail');card.append(el('h4',trail.title),el('p',trail.copy));
    const go=el('button',trail.action+' →','text-action');
    const openTrail=async(mode='study')=>{
      if(trail.view==='chemistry'){await showView('chemistry');const compound=chemistrySnapshot?.mappings.find(c=>/parthenolide/i.test(c.name));if(compound){$('#chemical-compound').value=String(compound.cid);await loadChemistry();}$('#view-chemistry').scrollIntoView({behavior:'smooth',block:'start'});return;}
      libraryFocus=null;choosePassage(passage.id);showView('workspace');await analyze();
      if(data?.source.id===passage.id){
        if(trail.sourceStudy){
          if(openSourceStudyReading(trail.sourceStudy))return;
          status('No active source-statement link to this study is available in this analysis. Inspect the current source records instead.',true);
        }
        if(mode==='indication'&&trail.indicationStudy){
          const study=data.evidence.find(e=>e.paper.id===trail.indicationStudy.paperId&&e.taxon_id===trail.indicationStudy.taxonId);
          const name=study&&data.identity_counterfactuals.find(g=>g.branches.some(b=>b.evidence_ids.includes(study.id)));
          if(study&&name){const statement=study.historical_contexts?.find(context=>context.preparation?.length)||study.historical_contexts?.[0];statementReadingTargets.set(identityPairKey(name),statement?.claim_id||'');selectName(name.key);openBranchPublication(study.taxon_id,study.paper.id);return;}
          status('This source analysis has no active matching study; inspect the available publications instead.',true);
        }
        if(mode==='trials'&&trail.readingSet){openTrialReadingSet(trail.readingSet);return;}
        if(trail.tab==='tab-evidence'){
          const study=data.evidence.find(e=>e.paper.methods_contexts?.length);
          const name=study&&data.identity_counterfactuals.find(g=>g.branches.some(b=>b.evidence_ids.includes(study.id)));
          if(study&&name){selectName(name.key);openBranchPublication(study.taxon_id,study.paper.id);return;}
        }
        showTab(trail.tab,true);$('#'+$('#'+trail.tab).getAttribute('aria-controls')).scrollIntoView({behavior:'smooth',block:'start'});
      }
    };
    go.addEventListener('click',()=>openTrail());card.append(go);
    if(trail.indicationStudy){const indication=el('button','Compare historical and study indications →','text-action');indication.addEventListener('click',()=>openTrail('indication'));card.append(indication);}
    if(trail.readingSet){const compare=el('button','Compare controlled Mint trials →','text-action');compare.addEventListener('click',()=>openTrail('trials'));card.append(compare);}
    box.append(card);
  }
}
function cancelLibrarySearch() {
  librarySearchSerial++;
  $('#knowledge-search').disabled = false;
  $('#knowledge-search').textContent = 'Search knowledge';
  $('#knowledge-search-status').textContent = '';
}
function applyLibraryFilters() {
  libraryLimit = 6;
  if ($('#library-query').value.trim()) searchLibrary();
  else { rankedLibrary = null; librarySearchText = ''; loadLibrary(); }
}
function renderLibraryComparison() {
  const tray=$('#library-comparison'); tray.hidden=!libraryComparison.size; tray.replaceChildren();
  if(!libraryComparison.size)return;
  const text=el('div'); text.append(el('strong',libraryComparison.size===2?'Ready to compare':'Choose one more chapter'),el('p',[...libraryComparison.values()].map(r=>sourceLabel(r.source_title)).join(' + '),'hint'));
  const go=el('button','Compare sources'); go.disabled=libraryComparison.size!==2;
  go.addEventListener('click',()=>{const ids=[...libraryComparison.keys()];$('#compare-a').value=ids[0];$('#compare-b').value=ids[1];showView('workspace');$('#comparison-box').open=true;$('#compare-run').click();$('#comparison-box').scrollIntoView({behavior:'smooth',block:'start'});});
  const clear=el('button','Clear','quiet');clear.addEventListener('click',()=>{libraryComparison.clear();loadLibrary();});tray.append(text,go,clear);
}
async function loadLibrary() {
  const box=$('#library-records');
  try {
    if(!librarySnapshot){
      librarySnapshot=await api('/api/research/corpus');
      $('#library-collection').append(...Object.keys(librarySnapshot.collections).map(s=>option(s,s)));
      $('#library-condition').append(...Object.keys(librarySnapshot.conditions).sort().map(s=>option(s,human(s.replace('condition:','')))));
      restoreLibraryReading();
      $('#library-summary').replaceChildren(...[[Object.values(librarySnapshot.collections).reduce((a,b)=>a+b,0),'historical chapters'],[Object.keys(librarySnapshot.collections).length,'books to explore'],[librarySnapshot.records.length,'source statements']].map(([value,label])=>{const s=el('div',undefined,'library-stat');s.append(el('strong',String(value)),el('span',label));return s;}));
      storeLibrarySaved();
    }
    const collection=$('#library-collection').value,condition=$('#library-condition').value,role=$('#library-role').value,query=librarySearchText.toLowerCase();
    const rows=(rankedLibrary||librarySnapshot.records).filter(r=>(!librarySavedOnly||librarySaved.has(r.id))&&(!role||r.statement_role===role)&&(!collection||r.collection===collection)&&(!condition||r.conditions.some(c=>c.id===condition))&&(rankedLibrary||!query||[r.statement.text,r.source_title,...r.names.map(n=>n.text)].join(' ').toLowerCase().includes(query)));
    libraryVisibleRows=rows;
    const groups=new Map();for(const r of rows){if(!groups.has(r.source_id))groups.set(r.source_id,[]);groups.get(r.source_id).push(r);}
    let chapters=[...groups.values()];
    if(!rankedLibrary&&!collection){const books=[...new Set(chapters.map(g=>g[0].collection))].map(book=>chapters.filter(g=>g[0].collection===book));chapters=[];for(let i=0;books.some(b=>i<b.length);i++)for(const book of books)if(book[i])chapters.push(book[i]);}
    $('#library-count').textContent=plural(rows.length,'statement')+' in '+plural(chapters.length,'chapter')+(librarySavedOnly?' · your reading list':'');
    box.replaceChildren();
    if(!chapters.length){const empty=el('div',undefined,'library-empty');empty.append(el('h3',librarySavedOnly?'Your reading list starts here.':'No statements match these filters.'),el('p',librarySavedOnly?'Save a statement while you browse to collect it here.':'Try another topic, include both books, or search by meaning.'));const reset=el('button','Browse recorded uses','quiet');reset.addEventListener('click',resetLibrary);empty.append(reset);box.append(empty);}
    for(const group of chapters.slice(0,libraryLimit)){
      const r=group[0],card=el('article',undefined,'knowledge-card'),head=el('div',undefined,'knowledge-card-head');
      const title=el('div');title.append(el('p',r.collection,'kicker historical'),el('h3',sourceLabel(r.source_title)));
      head.append(title,pill(statementRoleLabel(r),r.statement_role==='ADVERSE_EFFECT_RECORDED'?'bad':'neutral'));card.append(head);
      const topics=el('div',undefined,'knowledge-topics');for(const term of [...new Map(group.flatMap(row=>row.conditions).map(c=>[c.id,c])).values()].slice(0,4)){const topic=el('button',term.label,'topic-chip');topic.addEventListener('click',()=>{$('#library-condition').value=term.id;applyLibraryFilters();});topics.append(topic);}card.append(topics);
      const quote=el('blockquote',r.statement.text);card.append(quote);
      if(r.statement.text.length>240){const full=el('button','Show full statement','text-action');full.setAttribute('aria-expanded','false');full.addEventListener('click',()=>{const on=quote.classList.toggle('full-quote');full.textContent=on?'Show shorter preview':'Show full statement';full.setAttribute('aria-expanded',String(on));});card.append(full);}
      card.append(libraryAttribution(r));
      const preparations=[...new Set(group.flatMap(row=>row.preparations.map(p=>p.text.toLowerCase())))].slice(0,4);
      if(preparations.length)card.append(el('p',(group.length>1?'Preparations across matching statements: ':'Preparation wording: ')+preparations.join(' · '),'hint'));
      if(group.length>1){const more=el('details',undefined,'knowledge-more');more.open=libraryExpanded.has(r.source_id);more.addEventListener('toggle',()=>{more.open?libraryExpanded.add(r.source_id):libraryExpanded.delete(r.source_id);});more.append(el('summary',(group.length-1)+' more matching statement'+(group.length>2?'s':'')));for(const row of group.slice(1)){const item=el('div',undefined,'knowledge-extra');item.append(pill(statementRoleLabel(row),row.statement_role==='ADVERSE_EFFECT_RECORDED'?'bad':'neutral'),el('blockquote',row.statement.text),libraryAttribution(row));const actions=el('div',undefined,'knowledge-actions');const open=el('button','Read in context','text-action');open.addEventListener('click',()=>openLibraryRecord(row));if(passages.some(p=>p.id===row.source_id))actions.append(open);actions.append(saveStatementButton(row));item.append(actions);if(librarySavedOnly||libraryNotes[row.id])item.append(readingNoteEditor(row));more.append(item);}card.append(more);}
      const actions=el('div',undefined,'knowledge-actions');
      if(passages.some(p=>p.id===r.source_id)){const open=el('button','Read in workspace →');open.addEventListener('click',()=>openLibraryRecord(r));actions.append(open);}else actions.append(link('Read original source ↗',r.url));
      actions.append(saveStatementButton(r));card.append(actions);
      if(librarySavedOnly||libraryNotes[r.id])card.append(readingNoteEditor(r));
      const foot=el('div',undefined,'knowledge-card-foot');foot.append(link('Original book ↗',r.url));
      if(passages.some(p=>p.id===r.source_id)){const compare=el('label',undefined,'compare-choice'),check=el('input');check.type='checkbox';check.checked=libraryComparison.has(r.source_id);check.disabled=libraryComparison.size>=2&&!check.checked;check.addEventListener('change',()=>{check.checked?libraryComparison.set(r.source_id,r):libraryComparison.delete(r.source_id);loadLibrary();});compare.append(check,document.createTextNode('Compare chapter'));foot.append(compare);}card.append(foot);box.append(card);
    }
    $('#library-more').hidden=chapters.length<=libraryLimit;renderLibraryComparison();
  }catch(error){box.replaceChildren(el('p',error.message,'error'));}
}
function resetLibrary(){cancelLibrarySearch();librarySavedOnly=false;libraryBeforeSaved=null;updateSavedControl();librarySearchText='';rankedLibrary=null;libraryLimit=6;$('#library-query').value='';$('#library-collection').value='';$('#library-condition').value='';$('#library-role').value='THERAPEUTIC_USE_RECORDED';loadLibrary();}
for(const id of ['library-collection','library-condition','library-role'])$('#'+id).addEventListener('change',applyLibraryFilters);
$('#knowledge-method').addEventListener('change',()=>{if($('#library-query').value.trim())searchLibrary();});
$('#library-query').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();$('#knowledge-search').click();}});
$('#library-query').addEventListener('input',()=>{cancelLibrarySearch();if(!$('#library-query').value.trim()){librarySearchText='';rankedLibrary=null;libraryLimit=6;loadLibrary();}else $('#knowledge-search-status').textContent='Press Enter to search the source statements.';});
$('#library-more').addEventListener('click',()=>{libraryLimit+=6;loadLibrary();});
$('#library-saved').addEventListener('click',async()=>{
  let returnScroll=null;
  if(!librarySavedOnly){
    libraryBeforeSaved={query:$('#library-query').value,text:librarySearchText,ranked:rankedLibrary,limit:libraryLimit,scroll:window.scrollY,status:$('#knowledge-search-status').textContent,fields:Object.fromEntries(['library-role','library-collection','library-condition','knowledge-method'].map(id=>[id,$('#'+id).value]))};
    cancelLibrarySearch();librarySavedOnly=true;rankedLibrary=null;librarySearchText='';$('#library-query').value='';libraryLimit=6;
    for(const id of ['library-role','library-collection','library-condition'])$('#'+id).value='';
    $('#knowledge-search-status').textContent='Your saved statements. Filters apply to this reading list.';
  }else{
    cancelLibrarySearch();librarySavedOnly=false;
    if(libraryBeforeSaved){
      const previous=libraryBeforeSaved;$('#library-query').value=previous.query;librarySearchText=previous.text;rankedLibrary=previous.ranked;libraryLimit=previous.limit;
      for(const [id,value] of Object.entries(previous.fields))$('#'+id).value=value;
      $('#knowledge-search-status').textContent=previous.status;returnScroll=previous.scroll;
    }
    libraryBeforeSaved=null;
  }
  updateSavedControl();await loadLibrary();
  requestAnimationFrame(()=>{if(returnScroll!==null)window.scrollTo({top:returnScroll,behavior:'auto'});else $('.library-results-bar').scrollIntoView({block:'start',behavior:'smooth'});});
});
for(const [label,query] of [['Sleep','What was recorded for sleeplessness?'],['Headaches','Preparations used to relieve headache'],['Wounds','Leaves or decoctions applied to wounds'],['Digestion','Plants recorded for indigestion']]){const b=el('button',label,'topic-chip');b.addEventListener('click',()=>{$('#library-query').value=recorded?label.toLowerCase():query;$('#knowledge-search').click();});$('#library-examples').append(b);}
async function searchLibrary(){
  const button=$('#knowledge-search'),status=$('#knowledge-search-status'),query=$('#library-query').value.trim(),serial=++librarySearchSerial;
  if(!query){resetLibrary();return;}librarySearchText=query;libraryLimit=6;
  if(recorded){rankedLibrary=null;loadLibrary();status.textContent='Searching wording in the recorded library.';return;}
  button.disabled=true;button.textContent='Searching…';status.textContent='Finding relevant passages across the historical books…';
  try{const result=await api('/api/research/knowledge-search?'+new URLSearchParams({q:query,method:$('#knowledge-method').value,limit:'40',collection:$('#library-collection').value,condition:$('#library-condition').value,role:$('#library-role').value}));if(serial!==librarySearchSerial)return;rankedLibrary=result.results.map(x=>x.record);status.textContent='Best matching source statements for “'+query+'”. Open a chapter to inspect its context.';await loadLibrary();}catch(error){if(serial===librarySearchSerial)status.textContent=error.message;}finally{if(serial===librarySearchSerial){button.disabled=false;button.textContent='Search knowledge';}}
}
$('#knowledge-search').addEventListener('click',searchLibrary);
$('#library-export-results').addEventListener('click',()=>{
  const csvValue=value=>{let text=String(value??'');if(/^[=+@-]/.test(text.trimStart()))text="'"+text;return '"'+text.replaceAll('"','""')+'"';};
  const rows=[['source_id','book','chapter','year','statement','statement_type','plant_wording','preparations','attribution_scope','negation_flag','researcher_note','source_url','licence'],...libraryVisibleRows.map(r=>[r.source_id,r.collection,r.source_title,r.date,r.statement.text,r.statement_role,r.names.map(n=>n.text).join('; '),r.preparations.map(p=>p.text).join('; '),r.scope,r.negated,libraryNotes[r.id]||'',r.url,r.licence])];
  offerExport(rows.map(r=>r.map(csvValue).join(',')).join('\r\n'),'foliatrace-selected-statements.csv','text/csv;charset=utf-8','Selected historical statements (CSV)');
});

$('#library-export-notes').addEventListener('click',()=>{
  const lines=['# FoliaTrace reading notes','',librarySavedOnly?'Saved historical statements.':'Historical statements from the current search and filters.','These are historical records, not treatment recommendations.',''];
  for(const r of libraryVisibleRows){
    lines.push('## '+sourceLabel(r.source_title),'',r.collection+' · '+r.date+' · '+statementRoleLabel(r),'',...r.statement.text.split('\n').map(line=>'> '+line),'','Plant wording: '+r.names.map(n=>n.text).join(', '),'Preparations mentioned: '+(r.preparations.map(p=>p.text).join(', ')||'not stated'),statementQualifier({relation_scope:r.scope,negated:r.negated}),'Source: '+r.url,'Rights: '+r.licence,'Original span: '+r.statement.start+'–'+r.statement.end,'');
    if(libraryNotes[r.id])lines.push('### Researcher note (not source text)','',libraryNotes[r.id],'');
  }
  offerExport(lines.join('\n'),'foliatrace-reading-notes.md','text/markdown;charset=utf-8','Reading notes');
});
$('#library-backup').addEventListener('click',async()=>{
  const message=$('#library-backup-status');
  try{if(!librarySnapshot)await loadLibrary();if(!librarySnapshot)throw new Error('The library is not available. Try again when it has loaded.');
    const backup=readingBackup();offerExport(JSON.stringify(backup,null,2),'foliatrace-reading-backup.json','application/json','Saved reading backup');
    message.textContent=`Backup ready to download: ${backup.entries.length} entries, including entries outside the current filters.`;
  }catch(error){message.textContent=error.message;}
});
$('#library-restore').addEventListener('change',async event=>{
  const file=event.target.files[0],message=$('#library-backup-status');if(!file)return;
  try{if(file.size>50000000)throw new Error('Reading backups must be smaller than 50 MB.');
    if(!librarySnapshot)await loadLibrary();if(!librarySnapshot)throw new Error('The library is not available. Try again when it has loaded.');
    const result=restoreReadingBackup(JSON.parse(await file.text()));
    message.textContent=`Restored ${result.matched} matching entries. ${result.unavailable} entries belong to sources unavailable in this library; they remain in your backup data. ${result.conflicts} note conflicts: existing notes were kept; the incoming notes remain in your original backup file.`;
    updateSavedControl();await loadLibrary();
  }catch(error){message.textContent=`Could not restore: ${error.message}`;}
  finally{event.target.value='';}
});

let chemistrySnapshot;
async function loadChemistry() {
  const box = $("#chemical-records");
  try {
    if (!chemistrySnapshot) {
      chemistrySnapshot = await api('/api/research/chemistry');
      const choices = chemistrySnapshot.mappings || [];
      $("#chemical-compound").replaceChildren(...choices.map((c) => option(String(c.cid), `${c.name} · ${c.chembl_id}`)));
    }
    const cid = Number($("#chemical-compound").value), snapshot = chemistrySnapshot;
    box.replaceChildren();
    const mapping = snapshot.mappings.find((m) => m.cid === cid);
    if (!mapping) { box.append(el("p", "No verified chemical mappings installed.", "empty")); return; }
    box.append(el("p", `Exact InChIKey join: ${mapping.inchi_key} · ${snapshot.release.chembl_db_version} · ${snapshot.licence}`, "hint"));
    const rows = snapshot.records.filter((r) => r.cid === cid);
    box.append(el("h3", `${rows.length} reported assay measurements`));
    for (const r of rows) {
      const item = el("details", undefined, "reading-record");
      item.append(el("summary", `${r.target.pref_name} · ${r.standard_type} ${r.standard_relation} ${r.standard_value} ${r.standard_units}`), el("p", `${r.target.organism} · ${human(r.target.target_type)} · assay ${r.assay_id}`), el("blockquote", r.assay_description), link("ChEMBL measurement ↗", r.url), document.createTextNode(" · "), link("Original document record ↗", 'https://www.ebi.ac.uk/chembl/explore/document/' + r.document_id), el("p", `${r.licence} · ${r.scope}`, "hint"));
      box.append(item);
    }
    box.append(el("h3", "Publications in this snapshot mentioning the compound"));
    const papers = snapshot.publications[String(cid)] || [];
    if (!papers.length) box.append(el("p", "No publication co-mention in the bundled abstracts.", "empty"));
    for (const p of papers) {
      const item = el("details", undefined, "reading-record");
      item.append(el("summary", cleanTitle(p.title)), el("blockquote", p.supporting_text), link(p.paper_id + ' ↗', p.url), el("p", `${p.licence} · ${p.scope}`, "hint"));
      box.append(item);
    }
    box.append(el("p", `${snapshot.selection} ${snapshot.attribution}`, "hint"));
    if (snapshot.failures.length) box.append(el("p", `${snapshot.failures.length} compound mappings unavailable; they were not guessed.`, "hint"));
  } catch (error) { box.replaceChildren(el("p", error.message, "error")); }
}

$("#chemical-compound").addEventListener('change', loadChemistry);
$("#verify-name-form").addEventListener('submit', async (event) => {
  event.preventDefault();
  const box = $("#name-check-result"), button = $("#verify-name-form button");
  button.disabled = true;
  try {
    const response = await api('/api/taxonomy/verify-scientific?' + new URLSearchParams({name: $("#verify-scientific-name").value.trim()}));
    box.replaceChildren(el("p", response.scope, "hint"));
    if (!response.results.length) box.append(el("p", "No scientific-name match returned.", "empty"));
    for (const c of response.results) box.append(link(`${c.currentCanonicalSimple || c.matchedName} · ${c.dataSourceTitleShort}`, c.outlink), el("p", `${c.taxonomicStatus || 'status not supplied'} · ${response.match_type || 'match type not supplied'}`, "hint"));
  } catch (error) { box.replaceChildren(el("p", error.message, "error")); }
  finally { button.disabled = false; }
});
function statementQualifier(claim) {
  const notes = [];
  if (claim.relation_scope === 'MULTI_PLANT_CLAUSE_UNCERTAIN_RELATION') notes.push('Several plants are named; the use is not assigned to a single species.');
  if (claim.relation_scope === 'PARAGRAPH_CONTEXT_UNCERTAIN_RELATION') notes.push('A nearby sentence names another plant, so the subject of this sentence is uncertain. Literature is shown for the plant of this chapter; check the source before applying it.');
  if (claim.relation_scope === 'SOURCE_SECTION_HEADING') notes.push('Plant inferred from the chapter heading, not named in this sentence.');
  if (claim.relation_scope === 'PRECEDING_SENTENCE_SUBJECT') notes.push('Plant carried over from the previous sentence.');
  if (claim.relation_scope === 'PRECEDING_NAME_LIST') notes.push('Plant taken from the list of names that opens this entry.');
  if (claim.practice === 'RITUAL_OR_AMULET') notes.push('Reports an amulet or ritual practice.');
  if (claim.practice === 'VETERINARY') notes.push('Reports use on animals.');
  if (claim.practice === 'HOMOEOPATHIC') notes.push('Reports a homoeopathic claim.');
  if (claim.practice === 'NON_PLANT_REMEDY') notes.push('The remedy here is not a plant, so no plant literature is linked.');
  if (claim.negated) notes.push('Contains negation; read the original wording.');
  return notes.join(' ');
}
function comparisonTopics(result) {
  const topics = new Map();
  for (const [index, item] of result.sources.entries()) {
    for (const claim of item.claims.filter(c => c.statement_role === 'THERAPEUTIC_USE_RECORDED')) {
      for (const term of new Map(claim.conditions.map(c=>[c.id,c])).values()) {
        if (!topics.has(term.id)) topics.set(term.id, {id:term.id,label:term.label || human(term.id.replace('condition:','')),claims:result.sources.map(()=>[])});
        topics.get(term.id).claims[index].push(claim);
      }
    }
  }
  return [...topics.values()].sort((a,b) => b.claims.filter(c=>c.length).length-a.claims.filter(c=>c.length).length || a.label.localeCompare(b.label));
}
function offerExport(text,filename,type,title){
  const dialog=el('dialog',undefined,'export-preview'),head=el('div',undefined,'export-preview-head'),close=el('button','Close','quiet');
  const heading=el('h2',title);heading.id='export-preview-title';dialog.setAttribute('aria-labelledby',heading.id);
  close.type='button';close.addEventListener('click',()=>dialog.close());head.append(heading,close);
  const content=el('textarea');content.readOnly=true;content.value=text.replace(/^\uFEFF/,'');content.setAttribute('aria-label',title+' export text');
  const actions=el('div',undefined,'row'),download=el('button','Download file'),copy=el('button','Copy text','quiet'),message=el('p',undefined,'hint');
  message.setAttribute('role','status');
  download.type='button';download.addEventListener('click',()=>{
    const payload=type.startsWith('text/csv')&&!text.startsWith('\uFEFF')?'\uFEFF'+text:text;
    const url=URL.createObjectURL(new Blob([payload],{type})),anchor=el('a');anchor.href=url;anchor.download=filename;anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    message.textContent='Download requested. You can also copy the text below.';
  });
  copy.type='button';copy.addEventListener('click',async()=>{
    try{await navigator.clipboard.writeText(content.value);message.textContent='Copied to clipboard.';}
    catch{content.focus();content.select();message.textContent='Select the text and copy it to keep this export.';}
  });
  actions.append(download,copy);dialog.append(head,el('p','Review the source references and your notes before saving or sharing.','hint'),content,actions,message);
  dialog.addEventListener('close',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
}
function downloadNote(text, filename) {
  offerExport(text,filename,'text/markdown;charset=utf-8','Source comparison notes');
}
function exportComparison(result, topics) {
  const lines=['# FoliaTrace source comparison','','Topic links are extracted reading aids. Shared terms do not prove the same historical plant identity or an effective treatment.'];
  for(const item of result.sources)lines.push('', '## '+sourceLabel(item.source.title),item.source.context || '',String(item.source.date || 'Date unknown'),item.source.url,'Rights: '+item.source.licence);
  for(const topic of topics){
    lines.push('','## '+topic.label);
    result.sources.forEach((item,index)=>{
      lines.push('','### '+sourceLabel(item.source.title));
      if(!topic.claims[index].length)lines.push('No recorded-use statement extracted for this topic in this chapter. This does not establish absence.');
      for(const claim of topic.claims[index])lines.push('',...claim.support.text.split('\n').map(line=>'> '+line),'Preparations: '+(claim.preparation.map(p=>p.text).join(', ')||'not stated'),statementQualifier(claim),'Source span: '+claim.support.start+'–'+claim.support.end);
    });
  }
  lines.push('','## Candidate identities','These are conditional research links.');
  for(const item of result.sources)for(const name of item.names)lines.push(sourceLabel(item.source.title)+' — '+name.label+': '+(name.branches.map(b=>b.name).join('; ')||'unresolved')+' ('+(STATUS[name.status]?.[1]||human(name.status))+')');
  for(const item of result.sources){const other=item.claims.filter(c=>c.statement_role!=='THERAPEUTIC_USE_RECORDED'||!c.conditions.length);if(other.length){lines.push('','## Additional context — '+sourceLabel(item.source.title));for(const claim of other)lines.push('',statementRoleLabel(claim),...claim.support.text.split('\n').map(line=>'> '+line),statementQualifier(claim),'Source span: '+claim.support.start+'–'+claim.support.end);}}
  downloadNote(lines.join('\n'),'foliatrace-source-comparison.md');
}
function comparisonQuotation(item,claim) {
  const fragment=el('div',undefined,'comparison-quotation');
  fragment.append(el('blockquote',claim.support.text));
  const facts=[['Parts',claim.part],['Preparations',claim.preparation]].map(([label,values])=>label+': '+(values.map(v=>v.text).join(', ')||'not stated'));
  fragment.append(el('p',facts.join(' · '),'hint'));
  const qualifier=statementQualifier(claim);if(qualifier)fragment.append(el('p',qualifier,'hint'));
  const open=el('button','Read in original context →','text-action');
  open.addEventListener('click',()=>openLibraryRecord({source_id:item.source.id,statement:claim.support},'comparison'));
  fragment.append(open);return fragment;
}
function renderComparison(result,box) {
  const topics=comparisonTopics(result),shared=topics.filter(t=>t.claims.every(c=>c.length));
  box.replaceChildren(el('h3','What do these sources record?'));
  const intro=el('p',`${shared.length} shared topic${shared.length===1?'':'s'} · ${topics.length-shared.length} topic${topics.length-shared.length===1?'':'s'} extracted in only one chapter.`, 'comparison-intro');
  box.append(intro,el('p','A blank match means no use was extracted here. Read each quotation to see which plant, preparation and wording it actually concerns.','hint'));
  const actions=el('div',undefined,'row comparison-actions'),exportButton=el('button','Download comparison notes','quiet');
  exportButton.addEventListener('click',()=>exportComparison(result,topics));actions.append(exportButton);box.append(actions);
  const wrap=el('div',undefined,'table-wrap comparison-matrix'),table=el('table'),caption=el('caption','Recorded uses by topic; expand a cell to read its source quotations.');table.append(caption);
  const thead=el('thead'),head=el('tr'),topicHead=el('th','Topic');topicHead.scope='col';head.append(topicHead);
  for(const item of result.sources){const th=el('th');th.scope='col';th.append(el('strong',sourceLabel(item.source.title)),el('p',[item.source.context,item.source.date].filter(Boolean).join(' · '),'hint'),link('Original book ↗',item.source.url));head.append(th);}thead.append(head);table.append(thead);
  const tbody=el('tbody'),rows=[];
  for(const topic of topics){
    const row=el('tr'),label=el('th');label.scope='row';label.append(el('span',topic.label),pill(topic.claims.every(c=>c.length)?'Both chapters':'One chapter'));row.append(label);
    result.sources.forEach((item,index)=>{
      const cell=el('td'),claims=topic.claims[index];
      if(!claims.length)cell.append(el('p','No recorded use extracted','comparison-absence'));
      else {
        const details=el('details'),summary=el('summary',plural(claims.length,'statement'));
        const preparations=[...new Set(claims.flatMap(c=>c.preparation.map(p=>p.text.toLowerCase())))];
        if(preparations.length)summary.append(el('span',preparations.join(', '),'comparison-preparations'));
        details.append(summary);for(const claim of claims)details.append(comparisonQuotation(item,claim));cell.append(details);
      }
      row.append(cell);
    });
    rows.push({row,shared:topic.claims.every(c=>c.length)});tbody.append(row);
  }
  table.append(tbody);wrap.append(table);
  if(topics.length){const toggle=el('button','Show shared topics only','quiet');toggle.disabled=!shared.length;toggle.setAttribute('aria-pressed','false');toggle.addEventListener('click',()=>{const on=toggle.getAttribute('aria-pressed')!=='true';toggle.setAttribute('aria-pressed',String(on));toggle.textContent=on?'Show all topics':'Show shared topics only';for(const item of rows)item.row.hidden=on&&!item.shared;});actions.prepend(toggle);box.append(wrap);}
  else box.append(el('p','No therapeutic-use topic was extracted in these chapters. Their context statements remain available below.','hint'));
  const identities=el('details',undefined,'comparison-context');identities.append(el('summary','Which plant identities could connect these chapters?'));
  const linked=result.candidate_links.filter(c=>result.shared_candidate_ids.includes(c.id));
  identities.append(el('p',linked.length?'Shared candidates: '+linked.map(c=>c.name).join('; ')+'.':'No shared candidate in this snapshot.','hint'));
  for(const item of result.sources){identities.append(el('h4',sourceLabel(item.source.title)));for(const name of item.names)identities.append(el('p',name.label+': '+(name.branches.map(b=>b.name).join('; ')||'unresolved')),el('p',STATUS[name.status]?.[1]||human(name.status),'hint'));}
  identities.append(el('p','These candidates are hypotheses, not a verified historical identity match.','hint'));box.append(identities);
  const additional=el('details',undefined,'comparison-context');additional.append(el('summary','Harmful effects, other context and unclassified uses'));
  for(const item of result.sources){
    const other=item.claims.filter(c=>c.statement_role!=='THERAPEUTIC_USE_RECORDED'||!c.conditions.length);
    additional.append(el('h4',sourceLabel(item.source.title)));
    if(!other.length)additional.append(el('p','No additional statements extracted.','hint'));
    for(const claim of other){additional.append(pill(statementRoleLabel(claim),claim.statement_role==='ADVERSE_EFFECT_RECORDED'?'bad':'neutral'),comparisonQuotation(item,claim));}
  }
  box.append(additional);
}
$('#compare-run').addEventListener('click',async()=>{
  const button=$('#compare-run'),box=$('#comparison-result'),ids=[$('#compare-a').value,$('#compare-b').value];
  if(ids[0]===ids[1]){box.replaceChildren(el('p','Choose two different chapters to compare.','hint'));return;}
  button.disabled=true;box.replaceChildren(el('p','Reading the two source records…','hint'));
  try{const result=await api('/api/research/compare-sources',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({passage_ids:ids})});renderComparison(result,box);}
  catch(error){box.replaceChildren(el('p',error.message,'error'));}
  finally{button.disabled=false;}
});
function showTab(id, focus = false) {
  for (const t of document.querySelectorAll('[role="tab"]')) {
    const on = t.id === id;
    t.setAttribute("aria-selected", String(on));
    t.tabIndex = on ? 0 : -1;
    $("#" + t.getAttribute("aria-controls")).hidden = !on;
    if (on && focus) t.focus();
  }
}

/* ---------- Source ---------- */
function mentionGroup(mentionId) {
  return data.identity_counterfactuals.find((g) => g.mention_ids.includes(mentionId));
}
function renderSource() {
  const requested=data.configuration.requested_name;
  $('#source-name-input').value=requested||'';
  $('#source-name-reset').hidden=!requested;
  $('#source-name-state').textContent=requested?'Researcher-selected wording: “'+requested+'”. Exact source occurrences are marked; botanical identity remains a separate question.':'';
  if(requested)$('#inspect-source-name').open=true;
  $("#source-title").textContent = data.source.title || "Untitled text";
  const meta = $("#source-meta");
  meta.replaceChildren();
  const parts = [data.source.context, data.source.date ? `Edition ${data.source.date}` : "Edition date not established", human(data.source.licence)];
  meta.append(document.createTextNode(parts.filter(Boolean).join(" · ") + " "));
  if (data.source.url) meta.append(link("Source ↗", data.source.url));
  const box = $("#original");
  let focus = $('#source-focus');
  if(!focus){focus=el('aside',undefined,'source-focus');focus.id='source-focus';box.before(focus);}
  focus.replaceChildren();focus.hidden=!libraryFocus||libraryFocus.source_id!==data.source.id;
  if(!focus.hidden){
    focus.append(el('p','The statement you opened','kicker historical'),el('blockquote',libraryFocus.statement.text));
    const back=el('button',sourceFocusOrigin==='map'?'← Back to the research map':sourceFocusOrigin==='comparison'?'← Back to your comparison':sourceFocusOrigin==='evidence'?'← Back to this study':sourceFocusOrigin==='resume'?'← Back to reading overview':'← Back to your results','quiet');
    back.addEventListener('click',()=>{
      if(sourceFocusOrigin==='evidence'&&sourceEvidenceFocus){
        const target=sourceEvidenceFocus;selectName(target.nameKey);openBranchPublication(target.taxonId,target.paperId);
      }else if(sourceFocusOrigin==='map'){
        showView('map');requestAnimationFrame(()=>window.scrollTo({top:mapScrollY,behavior:'auto'}));
      }else if(sourceFocusOrigin==='resume'){
        focusNameInspector();
      }else if(sourceFocusOrigin==='comparison'){
        showView('workspace');$('#comparison-box').open=true;$('#comparison-result').scrollIntoView({behavior:'smooth',block:'start'});
      }else{showView('library');requestAnimationFrame(()=>window.scrollTo({top:libraryScrollY,behavior:'auto'}));}
    });
    const close=el('button','Clear statement focus','text-action');close.addEventListener('click',()=>{libraryFocus=null;renderSource();});
    const actions=el('div',undefined,'row');actions.append(back);
    if(sourceFocusOrigin!=='evidence'){
      const inspect=el('button','Inspect name & studies','quiet');inspect.type='button';
      inspect.addEventListener('click',()=>{showTab('tab-identity');focusNameInspector();});actions.append(inspect);
    }
    actions.append(close);focus.append(actions);
  }
  box.replaceChildren();
  const chars = Array.from(data.input);
  const activeSpan=!focus.hidden?libraryFocus.statement:null;
  function appendOriginalText(start,end) {
    if(!activeSpan||end<=activeSpan.start||start>=activeSpan.end){box.append(document.createTextNode(chars.slice(start,end).join('')));return;}
    const from=Math.max(start,activeSpan.start),to=Math.min(end,activeSpan.end);
    box.append(document.createTextNode(chars.slice(start,from).join('')),el('mark',chars.slice(from,to).join(''),'statement-highlight'),document.createTextNode(chars.slice(to,end).join('')));
  }
  let last = 0;
  for (const m of data.mentions) {
    if (m.start < last) continue;
    appendOriginalText(last,m.start);
    const g = mentionGroup(m.id);
    const b = el("button", chars.slice(m.start, m.end).join(""), "mention" + (g && g.key === selected ? " active" : ""));
    b.type = "button";
    b.dataset.group = g?.key || "";
    b.setAttribute("aria-label", `${m.text}: inspect this name`);
    b.addEventListener("click", () => {if(g){selectName(g.key);focusNameInspector();}});
    if(activeSpan&&m.start<activeSpan.end&&m.end>activeSpan.start)b.classList.add('statement-highlight');
    box.append(b);
    last = m.end;
  }
  appendOriginalText(last,chars.length);
  if(activeSpan)requestAnimationFrame(()=>{const mark=box.querySelector('.statement-highlight');if(mark)box.scrollTop+=mark.getBoundingClientRect().top-box.getBoundingClientRect().top-32;});
}
function renderClaims() {
  const g = group();
  const claims = data.historical_claims.filter((c) => !g || g.claim_ids.includes(c.id));
  $("#claims-summary").textContent = g ? `Source statements linked to “${g.label}” (${claims.length})` : `Source statements (${claims.length})`;
  const box = $("#claims");
  box.replaceChildren();
  if (!claims.length) box.append(el("p", "No plant–use statement extracted for this name. Fields absent from the text stay unknown.", "hint"));
  for (const c of claims) {
    const row = el("div", undefined, "claim");
    row.append(pill(c.statement_role?statementRoleLabel(c):human('LEGACY_ROLE_NOT_SCREENED'), c.statement_role === 'ADVERSE_EFFECT_RECORDED' ? 'bad' : 'neutral'));
    const facts = el("div", undefined, "facts");
    const fact = (label, values) => {
      const s = el("span");
      s.append(el("b", label + ": "), document.createTextNode(values.length ? [...new Set(values)].join(", ") : "not stated"));
      facts.append(s);
    };
    fact("Condition terms", c.conditions.map((x) => x.original));
    fact("Part", c.part.map((x) => x.text));
    fact("Preparation", c.preparation.map((x) => x.text));
    row.append(el("blockquote", c.support.text), facts);
    const qualifier=statementQualifier(c);if(qualifier)row.append(el('p',qualifier,'hint'));
    if(g){const focus=el('button','Research this statement →','text-action');focus.type='button';focus.addEventListener('click',()=>{
      statementReadingTargets.set(identityPairKey(g),c.id);
      for(const id of ['branch','study-type','relation','year'])$('#'+id).value='';
      renderEvidence();showTab('tab-evidence',true);$('.statement-reading').scrollIntoView({block:'start',behavior:'smooth'});rememberReading();
    });row.append(focus);}
    box.append(row);
  }
}

/* ---------- Names ---------- */
function renderNames() {
  const box = $("#names");
  box.replaceChildren();
  const groups = data.identity_counterfactuals;
  if (!groups.length) box.append(el("p", "No plant name recognised in this text. Try the Latin name, or enter the wording under “Inspect a name the extractor missed”.", "empty"));
  for (const g of groups) {
    const b = el("button", g.label, "chip");
    b.type = "button";
    b.dataset.key = g.key;
    b.setAttribute("aria-pressed", String(g.key === selected));
    b.append(el("span", `×${g.occurrences.length} · ${STATUS[g.status]?.[1] ?? human(g.status)}`, "count"));
    b.addEventListener("click", () => selectName(g.key));
    box.append(b);
  }
  const unlisted = data.local_names_not_in_any_list || [];
  if (unlisted.length) box.append(el("p", `Not in any open name list, so left unidentified: ${unlisted.slice(0, 8).join(", ")}${unlisted.length > 8 ? ` and ${unlisted.length - 8} more` : ""}.`, "hint"));
}
function selectName(key) {
  selected = key;
  for (const b of document.querySelectorAll("#names .chip")) b.setAttribute("aria-pressed", String(b.dataset.key === key));
  for (const b of document.querySelectorAll("#original .mention")) b.classList.toggle("active", b.dataset.group === key);
  renderInspector();
  renderClaims();
}
function focusNameInspector(){
  const heading=$('#name-title');heading.tabIndex=-1;heading.focus({preventScroll:true});
  $('.inspector-pane').scrollIntoView({behavior:'smooth',block:'start'});
}
const DIRECTION = { SUPPORTS: ["ok", "Reports benefit"], CONTRADICTS: ["bad", "Reports no benefit"], MIXED: ["warn", "Mixed result"], INSUFFICIENT: ["neutral", "Inconclusive"], NO_RESULT_STATEMENT: ["neutral", "No result sentence read"] };
function designName(types) {
  const set = new Set(types || []);
  return set.has("META_ANALYSIS") ? "Meta-analysis" : set.has("SYSTEMATIC_REVIEW") ? "Systematic review" : set.has("CLINICAL_TRIAL") ? "Clinical trial" : set.has("OBSERVATIONAL_HUMAN") ? "Observational study" : set.has("REVIEW") ? "Review" : "Study";
}
function resultCounts(r) {
  return [r.favourable ? `${r.favourable} favourable` : "", r.no_benefit ? `${r.no_benefit} no benefit` : "", r.mixed ? `${r.mixed} mixed or inconclusive` : ""].filter(Boolean).join(" · ");
}
function assessmentBasis(r) {
  const basis = r.assessment_basis;
  if (!basis) return null;
  const box = el('details', undefined, 'assessment-basis');
  box.append(el('summary', 'Why this summary?'));
  const stated = (basis.records || []).filter(s => s.direction && s.direction !== 'NO_RESULT_STATEMENT');
  const explanations = {
    CURRENT_SYNTHESES: `${stated.length} retrieved reviews with an attributable result inform this summary. Conflicting or uncertain review findings remain mixed. Reviews can share trials.`,
    INDIVIDUAL_PLANT_STUDIES: `${r.isolated_plant_studies ?? r.human_studies} human studies examine this plant without another named plant ingredient. Observational findings and small trial sets remain preliminary.`,
    COMBINATION_ONLY: 'The human studies test combinations. Their results do not isolate this plant.',
    PRECLINICAL_ONLY: 'The available attributable results are from laboratory or animal studies.',
    NO_ELIGIBLE_HUMAN_RESULT: 'No attributable human result was found in the retrieved records.'
  };
  box.append(el('p', explanations[basis.kind] || human(basis.kind), 'hint'));
  if (r.human_studies > r.isolated_plant_studies && basis.kind !== 'COMBINATION_ONLY') box.append(el('p', `${r.human_studies - r.isolated_plant_studies} combination studies remain available below, but do not decide the isolated-plant summary.`, 'hint'));
  for (const s of basis.records || []) {
    const [tone, label] = DIRECTION[s.direction] || DIRECTION.NO_RESULT_STATEMENT;
    const line = el('p', undefined, 'digest-meta');
    line.append(pill(label, tone), document.createTextNode(` ${s.year || 'Year unknown'} · `), link(cleanTitle(s.title), s.url));
    box.append(line);
  }
  if (stated.length) box.append(el('p', 'Compare the preparations, populations and measured outcomes in the studies. This summary is not a pooled effect estimate or a risk-of-bias assessment.', 'hint'));
  return box;
}
function studyList(r) {
  const box = el("details", undefined, "study-list");
  const shown = r.studies?.length || 0;
  box.append(el("summary", `Read ${shown === r.human_studies ? plural(shown, "study").replace("studys", "studies") : `${shown} of ${r.human_studies} studies`}`));
  const basis = assessmentBasis(r);
  if (basis) box.append(basis);
  for (const s of r.studies || []) {
    const [tone, label] = DIRECTION[s.direction] || DIRECTION.NO_RESULT_STATEMENT;
    const row = el("div", undefined, "study-row");
    const head = el("p");
    head.append(pill(label, tone), el("span", ` ${designName(s.design)}${s.year ? " · " + s.year : ""}${s.combination ? " · with other ingredients" : ""}${s.identity === "SCIENTIFIC_NAME" ? "" : " · species taken from the common name"} `, "digest-meta"), link(cleanTitle(s.title).slice(0, 110) + (s.title.length > 110 ? "…" : "") + " ↗", s.url));
    row.append(head);
    if (s.finding_statements?.length) {
      for (const statement of s.finding_statements) {
        row.append(el('p', human(statement.direction), 'quote-label'), el('blockquote', statement.supporting_text));
      }
    } else if (s.finding) row.append(el("blockquote", s.finding));
    box.append(row);
  }
  return box;
}
function renderResearchSummary(g) {
  const box = $("#research-summary");
  box.replaceChildren();
  if (!g || !g.branches.length) return;
  const ids = new Set(g.branches.map((b) => b.taxon_id)), rows = (data.research_digest || []).filter((r) => ids.has(r.taxon_id) && g.conditions.includes(r.condition_id));
  const matrix = data.resolutions.find((r) => g.mention_ids.includes(r.mention_id))?.identity_matrix;
  const leading = matrix?.candidates.find((c) => c.taxon_id === matrix.leading);
  const identity = leading ? `Best fit so far: ${leading.name} (${(RATING[leading.rating] || [])[1]?.toLowerCase()}). ` : g.branches.length > 1 ? "The candidates are not separated by the source wording. " : `Candidate: ${g.branches[0].name}. `;
  const withHuman = rows.filter((r) => r.human_studies).length, topics = new Set(rows.map((r) => r.topic));
  box.append(el("p", identity + (rows.length ? `${plural(topics.size, "recorded topic")} reached modern literature, ${withHuman} with human studies.` : "No study retrieved for its recorded uses."), "summary-line"));
  const listed = data.resolutions.find((r) => g.mention_ids.includes(r.mention_id) && r.list_agreement?.names_agreeing > 1)?.list_agreement;
  if (listed) box.append(el("p", `${listed.names_agreeing} of the ${listed.names_listed} names the author lists point to this plant in published name lists. A list of names is evidence for reading, not an identification.`, "hint"));
  const record = data.resolutions.flatMap((r) => (g.mention_ids.includes(r.mention_id) ? r.candidates : [])).find((c) => c.name_record)?.name_record;
  if (record) box.append(el("p", `Name recorded by ${record.source === "Duke" ? "Dr. Duke (USDA)" : record.source}: ${record.printed}${record.where ? ", " + record.where : ""}.`, "hint"));
  if (!rows.length) {
    const known = g.branches.map((b) => data.plant_literature?.[b.taxon_id]).find((row) => row?.publications);
    if (known) {
      const note = el("p", `On other topics: ${plural(known.publications, "publication")} name ${known.name}, ${known.human_studies} human. `, "hint");
      for (const row of known.leading.slice(0, 2)) { note.append(link(cleanTitle(row.title).slice(0, 70) + "… ↗", row.url), document.createTextNode(" ")); }
      box.append(note);
    }
  }
  if (rows.length) {
    const list = el("ul", undefined, "digest");
    for (const r of rows.slice(0, Math.min(8, Math.max(4, withHuman)))) {
      const [tone, label] = RESEARCH_STATE[r.state] || ["neutral", human(r.state)];
      const li = el("li"), counts = resultCounts(r);
      li.append(pill(label, tone), el("span", ` ${r.topic}`, "digest-topic"), el("span", ` · ${r.taxon}${r.human_studies ? " · " + plural(r.human_studies, "human study").replace("studys", "studies") : ""}${counts ? " · " + counts : ""}${r.combination_only ? " · only tested with other ingredients" : ""}`, "digest-meta"));
      if (r.independent_use) li.append(el("span", ` · reported elsewhere: ${independentLine(r.independent_use)}`, "digest-meta"));
      if (r.recorded_poisonous) li.append(document.createTextNode(" "), pill("Recorded as poisonous", "bad"));
      if (r.regulatory) li.append(el("span", ` · ${regulatoryLine(r.regulatory)}`, "digest-meta"));
      if (r.studies?.length) li.append(studyList(r));
      else {
        const basis = assessmentBasis(r);
        if (basis) li.append(basis);
        if (r.best_study) { li.append(document.createTextNode(" ")); li.append(link((r.best_study.year || "") + " study ↗", r.best_study.url)); }
      }
      list.append(li);
    }
    box.append(list);
  }
}
function renderIdentityMatrix(g) {
  const box = $("#identity-matrix");
  box.replaceChildren();
  const matrix = g && data.resolutions.find((r) => g.mention_ids.includes(r.mention_id))?.identity_matrix;
  if (!matrix?.candidates.length) return;
  const section = el("section", undefined, "identity-matrix");
  section.append(el("h3", "Which candidate fits what the author wrote?"), el("p", matrix.candidates.length > 1 ? (matrix.separation === "CLEAR" ? "The source wording separates these candidates. Read the rows behind the rating." : "The source wording does not clearly separate these candidates.") : "One candidate, checked against the source wording.", "hint"));
  if(matrix.reading_order)section.append(el('p',matrix.reading_order,'hint'));
  for (const c of matrix.candidates) {
    const card = el("details", undefined, "matrix-candidate");
    card.open = c.taxon_id === matrix.leading || matrix.candidates.length === 1;
    const head = el("summary"), [tone, label] = RATING[c.rating] || ["neutral", c.rating];
    head.append(el("i", c.name), document.createTextNode(" "), pill(label, tone), el("span", ` score ${c.score}`, "digest-meta"));
    card.append(head);
    if (!c.rows.length) card.append(el("p", "The source gives no comparable description for this candidate.", "hint"));
    for (const row of c.rows) {
      const [rowTone, word] = MATRIX_STATUS[row.status] || ["neutral", human(row.status)];
      const item = el("div", undefined, "matrix-row");
      item.append(el("strong", row.feature + " "), pill(`${word} ${row.points > 0 ? "+" : ""}${row.points}`, rowTone));
      if (row.values?.length) item.append(el("span", " " + row.values.join(" / "), "digest-meta"));
      if (row.historical) item.append(el("blockquote", row.historical.text));
      if (row.modern?.text) item.append(el("p", row.modern.text, "hint"));
      card.append(item);
    }
    if (c.description_source) { const note = el("p", undefined, "hint"); note.append(document.createTextNode("Modern description: "), link(c.description_source.title + " ↗", c.description_source.url), document.createTextNode(" · " + c.description_source.licence)); card.append(note); }
    section.append(card);
  }
  section.append(el("p", "Scoring adapted from Lardos et al. 2023: +2 fits, −2 conflicts, Strong 5 or more, Moderate 3–4, Weak 2 or less. It ranks hypotheses for reading; it does not identify the plant.", "hint"));
  box.append(section);
}
function renderInspector() {
  const g = group();
  $("#name-title").textContent = g ? `“${g.label}”` : "No name selected";
  const line = $("#name-status");
  line.replaceChildren();
  if (g) {
    const [tone, label, explain] = STATUS[g.status] || ["neutral", human(g.status), ""];
    line.append(pill(label, tone), document.createTextNode(explain));
    if(data.mentions.some(m=>g.mention_ids.includes(m.id)&&m.method==='RESEARCHER_SELECTED_NAME'))line.append(pill('Researcher-selected wording'));
    if(g.source_names?.length)line.append(pill('This source calls it '+g.source_names.map(n=>'“'+n.name+'”').join(', ')),document.createTextNode(' The author pairs this local name with the scientific name; the pairing is theirs, not a name-list match.'));
  }
  renderResearchSummary(g);
  renderIdentityMatrix(g);
  renderIdentity();
  setupFilters();
  renderEvidence();
  renderBrief();
  renderReviews();
}

/* ---------- Research hand-off ---------- */
function renderBrief() {
  const next = $("#research-next"), box = $("#research-brief");
  next.replaceChildren();
  box.replaceChildren();
  const brief = data.research_brief;
  const handoff=el('button','Record an evidence handoff','quiet');handoff.type='button';handoff.addEventListener('click',()=>showView('handoffs'));box.append(handoff);
  const name = brief?.names.find((n) => n.key === selected);
  if (!name) {
    box.append(el("p", "No research brief for this name. Re-run an older analysis, or check the source manually when no name was recognised.", "empty"));
    return;
  }
  next.append(el("strong", "Next research step"), el("p", name.next_actions[0].text));
  const open = el("button", "Open research brief", "quiet");
  open.type = "button";
  open.addEventListener("click", () => showTab("tab-review", true));
  next.append(open);
  box.append(el("h3", `Research brief: “${name.label}”`), el("p", "A hand-off for checking this source and planning your next search. Review judgements annotate the automated results; they do not establish efficacy.", "hint"));
  if (name.identity_review_state === "CONFLICTING_ACCEPTS") box.append(el("p", "More than one candidate accepted. Reconcile these judgements before choosing a plant.", "error"));
  const tasks = el("ol", undefined, "research-tasks");
  for (const action of name.next_actions) {
    const task = el("li", action.text);
    if(action.kind==='SEARCH_BEYOND_SNAPSHOT'){
      const searches=el('div',undefined,'research-search-links');
      for(const branch of group()?.branches||[]){const row=el('div');row.append(el('i',branch.name),document.createTextNode(' · '),currentLiterature(branch.name));searches.append(row);}
      task.append(searches);
    }
    if (action.evidence_ids.length) {
      const inspect = el("button", `Inspect ${plural(action.evidence_ids.length, "record")}`, "quiet task-records");
      inspect.type = "button";
      inspect.addEventListener("click", () => {
        let first;
        for (const item of box.querySelectorAll(".reading-record")) {
          if (JSON.parse(item.dataset.records).some((id) => action.evidence_ids.includes(id))) {
            item.open = true;
            if (item.parentElement.tagName === "DETAILS") item.parentElement.open = true;
            first ||= item;
          }
        }
        first?.scrollIntoView?.({ block: "nearest" });
      });
      task.append(inspect);
    }
    tasks.append(task);
  }
  box.append(tasks);
  const claims = el("details");
  claims.append(el("summary", `Source statements (${name.source_claims.length})`));
  for (const c of name.source_claims) {
    claims.append(pill(statementRoleLabel(c),c.statement_role==='ADVERSE_EFFECT_RECORDED'?'bad':'neutral'),el("blockquote", c.text));
    const qualifier=statementQualifier(c);if(qualifier)claims.append(el('p',qualifier,'hint'));
  }
  box.append(claims, el("h4", "Reading and verification queue"), el("p", brief.reading_order, "hint"));
  const queue = el("div", undefined, "reading-queue");
  if (!name.reading_list.length) queue.append(el("p", "No records retrieved in this snapshot. Search beyond it before drawing a conclusion.", "empty"));
  const publications = new Map();
  for (const r of name.reading_list) {
    if (!publications.has(r.paper.id)) publications.set(r.paper.id, []);
    publications.get(r.paper.id).push(r);
  }
  const rest = el("details", undefined, "more-reading");
  if (publications.size > 5) rest.append(el("summary", `Show ${publications.size - 5} more publications`));
  let index = 0;
  for (const records of publications.values()) {
    const p = records[0].paper;
    const row = el("details", undefined, "reading-record");
    row.dataset.records = JSON.stringify(records.map((r) => r.evidence_id));
    row.append(el("summary", `${cleanTitle(p.title)} · ${p.year || "year unknown"}`));
    row.append(link("Read original publication ↗", p.url), el("p", `${p.id} · ${p.licence}`, "hint"));
    const compareSource=el('button','Compare this study with the source','quiet');
    compareSource.type='button';compareSource.addEventListener('click',()=>openBranchPublication(records[0].taxon_id,p.id));row.append(compareSource);
    if(records[0].reported_results?.length){
      row.append(el('h4','Author-reported results · study intervention and population'));
      for(const context of records[0].reported_results)row.append(el('blockquote',context.text),link('Original Results section ↗',context.url));
    }
    for (const r of records) {
      const scope = el("div", undefined, "reading-scope");
      scope.append(el("p", `${r.taxon_name} · ${human(r.condition_id.replace("condition:", ""))} · ${r.evidence_id}`, "hint"));
      scope.append(el("p", `Species check: ${human(r.species_check)}. Final relation: ${human(r.final_relation)}.`));
      scope.append(el("p", `Failed checks: ${r.failed_checks.join(", ") || "none recorded"}. Unresolved: ${r.unresolved_checks.join(", ") || "none recorded"}. Screening: ${human(r.screening)}.`, "hint"));
      if (r.review) scope.append(el("p", `Researcher review: ${human(r.review.decision)} — ${r.review.reason}`));
      row.append(scope);
    }
    (index++ < 5 ? queue : rest).append(row);
  }
  if (publications.size > 5) queue.append(rest);
  box.append(queue);
}

/* ---------- Identity ---------- */
function historicalIdentityMarkdown(g){
  const references=data.historical_identity_references?.[g.key]||[];
  const lines=['# FoliaTrace historical name reading','','Current source: '+data.source.title,'Current source URL: '+(data.source.url||'not supplied'),'Historical name: '+g.label,'Analysis: '+data.run_id,'Snapshot: '+data.snapshot_sha256,'','The sources below share an exact normalized chapter heading, allowing camomile/chamomile and featherfew/feverfew. A later author’s scientific-name wording does not settle an earlier author’s plant identity. Candidate ranking and evidence relations are unchanged.'];
  for(const reference of references){
    const source=reference.source;lines.push('','## '+source.title+' · '+(source.collection||'Culpeper 1850'),'Date: '+(source.date||'not established'),'Source: '+source.url,'Rights: '+source.licence,'Source ID: '+source.id,'Text SHA256: '+reference.text_sha256);
    if(!reference.excerpts.length)lines.push('No current candidate scientific-name spelling was found in this matching chapter. Read its full text before concluding anything about its identification.');
    for(const excerpt of reference.excerpts){
      lines.push('',excerpt.text,'Source input span: '+excerpt.start+'–'+excerpt.end);
      for(const name of excerpt.names)lines.push('Source wording: '+name.text+'; exact '+name.alias_kind+' spelling for '+name.candidate_name+' ('+name.candidate_id+') in the bundled taxonomy. The source may distinguish or reject this name; read the complete quote.');
    }
  }
  return lines.join('\n');
}
function renderHistoricalIdentityReferences(g){
  const box=$('#historical-identity-references');box.replaceChildren();
  if(!g)return;
  const references=data.historical_identity_references?.[g.key];
  if(!references?.length)return;
  const panel=el('section',undefined,'historical-name-reading');
  panel.append(el('h3','What another historical source calls this plant'),el('p','Read the other author’s name wording and distinctions before applying a modern identity. A matching chapter title does not prove the two sources mean the same plant. A name can occur as a contrast with another plant.','hint'));
  for(const reference of references){
    const source=reference.source,card=el('article',undefined,'historical-name-source');
    card.append(el('h4',source.title+' · '+(source.collection||'Culpeper 1850')),el('p',(source.date||'date unknown')+' · '+source.licence,'hint'),link('Original historical source ↗',source.url));
    const full=el('details',undefined,'historical-name-chapter');full.append(el('summary','Read this chapter without leaving your analysis'));
    const chapter=el('div',undefined,'historical-name-original');chapter.tabIndex=0;chapter.setAttribute('role','region');chapter.setAttribute('aria-label',source.title+' '+(source.collection||'Culpeper 1850')+' source context');
    const chars=Array.from(reference.input);
    const showContext=excerpt=>{
      chapter.replaceChildren();
      if(!excerpt){chapter.append(document.createTextNode(reference.input));return;}
      const mark=el('mark',excerpt.text,'statement-highlight');chapter.append(document.createTextNode(chars.slice(0,excerpt.start).join('')),mark,document.createTextNode(chars.slice(excerpt.end).join('')));
      full.open=true;requestAnimationFrame(()=>{chapter.scrollTop+=mark.getBoundingClientRect().top-chapter.getBoundingClientRect().top-24;chapter.focus({preventScroll:true});});
    };
    showContext(null);full.append(chapter);
    for(const excerpt of reference.excerpts){
      const leading=excerpt.start>0&&chars.slice(Math.max(0,excerpt.start-2),excerpt.start).join('')!=='\n\n';
      const trailing=excerpt.end<chars.length&&chars.slice(excerpt.end,excerpt.end+2).join('')!=='\n\n';
      const quote=el('section',undefined,'historical-name-quote');quote.append(el('p','Excerpt · open the chapter to read the surrounding context','hint'),el('blockquote',(leading?'… ':'')+excerpt.text+(trailing?' …':'')));
      const names=new Map(excerpt.names.map(name=>[name.text+'::'+name.candidate_id,name]));
      for(const name of names.values())quote.append(el('p','Source names “'+name.text+'” · '+(name.alias_kind==='ACCEPTED_NAME'?'accepted scientific spelling':'stored scientific synonym')+' for '+name.candidate_name+' in the bundled taxonomy.','historical-name-match'));
      const read=el('button','Read this wording in the chapter','text-action');read.type='button';read.addEventListener('click',()=>{showContext(excerpt);full.scrollIntoView({behavior:'smooth',block:'nearest'});});quote.append(read);card.append(quote);
    }
    if(!reference.excerpts.length)card.append(el('p','This chapter shares the heading, but no current candidate’s scientific-name spelling was found. Its full text remains available below.','hint'));
    card.append(full);panel.append(card);
  }
  const exportButton=el('button','Export this historical name reading','quiet');exportButton.type='button';exportButton.addEventListener('click',()=>offerExport(historicalIdentityMarkdown(g),'foliatrace-historical-name-reading.md','text/markdown;charset=utf-8','Historical name reading'));panel.append(exportButton);box.append(panel);
}
function identityPairKey(g){return data.run_id+'::'+g.key;}
function identityPairRows(g,a,b){
  const evidence=groupEvidence();
  const read=(branch,paperId)=>{
    const records=evidence.filter(e=>e.taxon_id===branch.taxon_id&&e.paper.id===paperId);
    const record=records.find(e=>e.comparability?.checks?.some(c=>c.check==='identity'&&c.status==='PASS'))||records[0];
    const check=record?.comparability?.checks?.find(c=>c.check==='identity');
    return {record,check,state:!record?'NOT_RETRIEVED':check?.status||'NOT_SCREENED'};
  };
  return [...new Set([...a.papers,...b.papers])].map(id=>{
    const left=read(a,id),right=read(b,id);
    return {id,left,right,paper:(left.record||right.record).paper,changed:left.state!==right.state};
  }).sort((x,y)=>Number(y.changed)-Number(x.changed)||Number(y.paper.year||0)-Number(x.paper.year||0)||x.id.localeCompare(y.id));
}
const IDENTITY_READING={PASS:'Species wording found',FAIL:'Species not established',PARTIAL:'Species partly established',UNKNOWN:'Species not established',NOT_SCREENED:'Not screened',NOT_RETRIEVED:'Not retrieved for this candidate'};
function identityPairMarkdown(g,a,b,rows){
  const lines=['# FoliaTrace identity hypothesis comparison','','Historical name: '+g.label,'Source: '+data.source.title,'Source URL: '+(data.source.url||'not supplied'),'Analysis: '+data.run_id,'Snapshot: '+data.snapshot_sha256,'', 'Hypothesis A: '+a.name+' ('+a.taxon_id+')','Hypothesis B: '+b.name+' ('+b.taxon_id+')','','Changing a reading hypothesis does not resolve the historical identity. Retrieval and species wording are separate from intervention applicability or treatment effects. Differences apply only to this analysis and bundled literature.','','## Historical statements'];
  for(const claim of data.historical_claims.filter(c=>g.claim_ids.includes(c.id)))lines.push('',claim.support.text,'Statement: '+claim.id+'; scope: '+claim.relation_scope);
  lines.push('','## Publication comparison');
  for(const row of rows){
    lines.push('','### '+cleanTitle(row.paper.title),row.paper.url,row.paper.id+' · '+(row.paper.year||'year unknown')+' · '+row.paper.licence);
    for(const [branch,result] of [[a,row.left],[b,row.right]]){
      lines.push('',branch.name+': '+(IDENTITY_READING[result.state]||human(result.state)));
      if(result.check?.span?.text)lines.push('Species wording: '+result.check.span.text);
      if(result.check?.detail)lines.push('Screening detail: '+result.check.detail);
    }
  }
  return lines.join('\n');
}
function identityPairComparison(g){
  const panel=el('section',undefined,'identity-pair');
  panel.append(el('h4','Compare two identity hypotheses'),el('p','Choose the plants you want to compare. The source stays the same; inspect how retrieval and species wording change.','hint'));
  const key=identityPairKey(g),saved=identityComparisons.get(key);
  let a=g.branches.find(b=>b.taxon_id===saved?.[0])||g.branches[0];
  let b=g.branches.find(b=>b.taxon_id===saved?.[1]&&b.taxon_id!==a.taxon_id)||g.branches.find(b=>b.taxon_id!==a.taxon_id);
  const controls=el('div',undefined,'identity-pair-controls'),leftLabel=el('label','If this name means'),rightLabel=el('label','Compare with'),left=el('select'),right=el('select');
  left.id='identity-hypothesis-a';right.id='identity-hypothesis-b';
  leftLabel.htmlFor=left.id;rightLabel.htmlFor=right.id;
  for(const branch of g.branches){left.append(option(branch.taxon_id,branch.name));right.append(option(branch.taxon_id,branch.name));}
  left.value=a.taxon_id;right.value=b.taxon_id;leftLabel.append(left);rightLabel.append(right);controls.append(leftLabel,rightLabel);panel.append(controls);
  const output=el('div',undefined,'identity-pair-output');panel.append(output);
  const draw=()=>{
    identityComparisons.set(key,[a.taxon_id,b.taxon_id]);output.replaceChildren();
    const rows=identityPairRows(g,a,b),changed=rows.filter(row=>row.changed),shared=rows.filter(row=>row.left.record&&row.right.record).length;
    output.append(el('p',changed.length+' publication'+(changed.length===1?' changes':'s change')+' in retrieval or species wording · '+shared+' retrieved for both.','identity-pair-result'));
    const actions=el('div',undefined,'row'),exportButton=el('button','Export this hypothesis comparison','quiet');exportButton.type='button';
    exportButton.addEventListener('click',()=>offerExport(identityPairMarkdown(g,a,b,rows),'foliatrace-identity-comparison.md','text/markdown;charset=utf-8','Identity hypothesis comparison'));actions.append(exportButton);output.append(actions);
    if(!rows.length){output.append(el('p','Neither candidate retrieved publications for these historical topics in this snapshot. This does not establish that studies do not exist.','empty'));return;}
    if(!changed.length)output.append(el('p','These two candidates have the same retrieval and species-screening states here. Their historical identity and study applicability still need separate reading.','hint'));
    const renderPaper=row=>{
      const card=el('details',undefined,'identity-pair-paper');card.dataset.paper=row.id;
      card.append(el('summary',cleanTitle(row.paper.title)),el('p',(row.changed?'Changes between these hypotheses':'Same retrieval and species-screening state')+' · '+(row.paper.year||'year unknown'),'hint'));
      const design=(row.left.record||row.right.record).study.types;card.append(el('p',design.map(human).join(', ')||'Study design not established','hint'),link('Original publication ↗',row.paper.url));
      const grid=el('div',undefined,'identity-pair-grid');
      for(const [branch,result] of [[a,row.left],[b,row.right]]){
        const cell=el('section');cell.append(el('h5',branch.name),el('p',IDENTITY_READING[result.state]||human(result.state),result.state==='PASS'?'identity-wording-found':'hint'));
        if(result.check?.span?.text)cell.append(el('blockquote',result.check.span.text));
        if(result.check?.detail)cell.append(el('p',result.check.detail,'hint'));
        if(result.record){const inspect=el('button','Read study and source comparison','quiet');inspect.type='button';inspect.addEventListener('click',()=>openBranchPublication(branch.taxon_id,row.id,{returnToIdentityComparison:true}));cell.append(inspect);}
        grid.append(cell);
      }
      card.append(grid);return card;
    };
    for(const row of changed.slice(0,5))output.append(renderPaper(row));
    if(changed.length>5){const more=el('details',undefined,'identity-pair-more');more.append(el('summary','Read '+(changed.length-5)+' more changed publications'));for(const row of changed.slice(5))more.append(renderPaper(row));output.append(more);}
    const unchanged=rows.filter(row=>!row.changed);
    if(unchanged.length){const same=el('details',undefined,'identity-pair-more');same.append(el('summary','Read '+unchanged.length+' publications with unchanged screening'));for(const row of unchanged)same.append(renderPaper(row));output.append(same);}
    output.append(el('p','Species wording can occur in a review or a multi-ingredient study. It does not establish an experimental species, the historical identity or a treatment effect.','hint'));
  };
  left.addEventListener('change',()=>{const previous=a;a=g.branches.find(branch=>branch.taxon_id===left.value);if(a.taxon_id===b.taxon_id){b=previous;right.value=b.taxon_id;}draw();rememberReading();});
  right.addEventListener('change',()=>{const previous=b;b=g.branches.find(branch=>branch.taxon_id===right.value);if(a.taxon_id===b.taxon_id){a=previous;left.value=a.taxon_id;}draw();rememberReading();});
  draw();return panel;
}
function renderWhatIf(g) {
  const box = $("#whatif");
  box.replaceChildren();
  if (!g || !g.branches.length) return;
  const [headline, stable] = SENSITIVITY[g.sensitivity] || [human(g.sensitivity), true];
  const card = el("div", undefined, "whatif" + (stable ? " stable" : ""));
  card.append(el("h3", g.branches.length > 1 ? "If it is the other plant, what changes?" : "What a single answer would hide"), el("p", headline));
  const s = g.single_answer_view;
  if (g.branches.length > 1 || g.open_world.length) {
    const parts = [`A tool that returns one species would show ${s.name}${s.tie_broken_arbitrarily ? ", chosen only by sort order because the top candidates tie" : ""}.`];
    if (g.branches.length > 1) {
      const others = g.branches.filter((b) => b.taxon_id !== s.taxon_id).map((b) => b.name).join(" or ");
      if (s.misattributed_papers.length) parts.push(`${s.misattributed_papers.length} of the ${plural(s.shown_papers, "paper")} it lists actually name ${others}; it reaches them only through the shared common name.`);
      if (s.hidden_papers.length) parts.push(`It would drop ${plural(s.hidden_papers.length, "paper")} that only ${others} reaches.`);
      parts.push(`Its verdict would be “${BRANCH_STATE[s.would_state].toLowerCase()}”.`);
    } else parts.push(`It would not mention the ${plural(g.open_world.length, "other regional species")} listed below.`);
    const reconstruction=el('details',undefined,'identity-reconstruction');reconstruction.append(el('summary','What an automatic first choice would hide'),el('p',parts.join(' ')));card.append(reconstruction);
  }
  if (g.branches.length > 1) {
    card.append(identityPairComparison(g));
    const wrap = el("div", undefined, "table-wrap"),
      table = el("table"),
      head = el("tr");
    head.append(el("th", "Candidate"));
    for (const b of g.branches) {
      const th = el("th", b.name);
      th.style.fontStyle = "italic";
      head.append(th);
    }
    table.append(head);
    const row = (label, fn, cls) => {
      const tr = el("tr");
      tr.append(el("th", label));
      for (const b of g.branches) tr.append(el("td", fn(b), cls));
      table.append(tr);
    };
    row("Papers retrieved", (b) => b.papers.length, "num");
    row("Name the species", (b) => b.species_specific_papers.length, "num");
    row("Study designs", (b) => Object.entries(b.designs).map(([k, v]) => `${human(k)} ${v}`).join(", ") || "—");
    row("Main reason it can't answer", (b) => {
      const top = Object.entries(b.blocking_checks).sort((x, y) => y[1] - x[1])[0];
      return top ? `${BLOCKING[top[0]] || human(top[0])} (${top[1]})` : "—";
    });
    row("Branch conclusion", (b) => BRANCH_STATE[b.state] || human(b.state));
    wrap.append(table);
    const allCandidates=el('details',undefined,'identity-all-candidates');allCandidates.append(el('summary','Summary across all '+g.branches.length+' candidates'),wrap);card.append(allCandidates);
    const differences=el('details',undefined,'whatif-publications');
    differences.append(el('summary','Read the publications behind these differences'));
    for(const section of [
      {title:'Publications a single-species answer would omit',ids:s.hidden_papers},
      {title:'Shared-name results that name another candidate',ids:s.misattributed_papers},
    ]){
      if(!section.ids.length)continue;
      differences.append(el('h4',section.title));
      for(const paperId of section.ids){
        const matches=groupEvidence().filter(e=>e.paper.id===paperId&&e.taxon_id!==s.taxon_id);
        const record=matches.find(e=>e.comparability?.checks?.some(c=>c.check==='identity'&&c.status==='PASS'))||matches[0];
        if(!record)continue;
        const item=el('div',undefined,'reading-record');
        item.append(link(cleanTitle(record.paper.title),record.paper.url),el('p',taxonName(record.taxon_id)+' · '+(record.paper.year||'year unknown'),'hint'));
        const inspectStudy=el('button','Inspect species, abstract and applicability','quiet');
        inspectStudy.type='button';
        inspectStudy.addEventListener('click',()=>openBranchPublication(record.taxon_id,paperId));
        item.append(inspectStudy);differences.append(item);
      }
    }
    if(s.hidden_papers.length||s.misattributed_papers.length){
      differences.append(el('p','These are differences within this analysis and its literature snapshot. A species mention does not identify the historical plant or establish efficacy.','hint'));
      card.append(differences);
    }
  }
  box.append(card);
}
function renderIdentity() {
  const g = group();
  renderHistoricalIdentityReferences(g);
  renderWhatIf(g);
  const box = $("#identities");
  box.replaceChildren();
  if (!g || !g.branches.length) {
    box.append(el("p", "No modern candidate found. The name stays unresolved; nothing downstream is attached to it.", "empty"));
    if(g){const explore=el('button','Find historical cross-references','quiet');explore.addEventListener('click',()=>{showView('library');$('#library-query').value=g.label;searchLibrary();});box.append(explore);}
  }
  for (const b of g?.branches || []) {
    const c = data.resolutions.find((r) => g.mention_ids.includes(r.mention_id))?.candidates.find((x) => x.taxon_id === b.taxon_id);
    const card = el("div", undefined, "candidate");
    card.append(el("h3", b.name), el("p", `${c?.scientific_name ?? b.name} · ${c?.family ?? ""}`, "family"));
    const why = el("ul", undefined, "why");
    for (const r of b.reasons) why.append(el("li", REASONS[r] || human(r)));
    const alias = c?.matched_alias;
    const said = alias?.lang && alias.lang !== "en" ? ` (${languageName(alias.lang)})` : "";
    const recorded = alias?.sources?.length ? `, a local name recorded beside this identification in ${alias.sources.length === 1 ? "1 field study" : `${alias.sources.length} field studies`}` : "";
    if (alias?.name) why.append(el("li", alias.short_form_of ? `Matched “${alias.name}”${said}, the everyday short form of the recorded name “${alias.short_form_of}”` : `Matched “${alias.name}”${said}${recorded}`));
    card.append(why, el("p", `Ranking feature ${b.score.toFixed(2)} — orders candidates, not a probability.`, "hint"));
    const links = el("p", undefined, "hint");
    if (alias?.url) links.append(link(alias.sources?.length ? "Field study ↗" : "Taxonomy record ↗", alias.url));
    links.append(document.createTextNode(` · ${b.papers.length} papers on this branch`));
    card.append(links);
    card.append(currentLiterature(b.name));
    const actions = el("div", undefined, "actions");
    actions.append(reviewForm("identity", `${g.key}::${b.taxon_id}`, `Is “${g.label}” in this source ${b.name}?`));
    card.append(actions);
    box.append(card);
  }
  const ow = $("#open-world");
  ow.replaceChildren();
  if (g?.open_world.length) {
    const box2 = el("div", undefined, "openworld");
    box2.append(el("strong", "Also called this, outside the snapshot"), el("p", "GBIF lists these species of the same genus with a matching English name and at least 100 records in Great Britain. No evidence was retrieved for them.", "hint"));
    const ul = el("ul");
    for (const a of g.open_world) {
      const li = el("li");
      const i = el("i", a.name);
      const literature=currentLiterature(a.name);
      li.append(i, document.createTextNode(` — “${a.shared_vernacular.join("”, “")}”, ${a.region_records.toLocaleString()} GB records `));
      li.append(link("GBIF ↗", `https://www.gbif.org/species/${a.gbif_key}`));
      ul.append(li);
      li.append(document.createTextNode(' · '),literature);
    }
    box2.append(ul);
    ow.append(box2);
  }
}

/* ---------- Evidence ---------- */
function groupEvidence() {
  const g = group();
  if (!g) return [];
  const ids = new Set(g.branches.flatMap((b) => b.evidence_ids));
  return data.evidence.filter((e) => ids.has(e.id));
}
function statementReadingTarget(g=group()){
  const id=g&&statementReadingTargets.get(identityPairKey(g));
  return id?data.historical_claims.find(claim=>claim.id===id&&g.claim_ids.includes(claim.id)):null;
}
function statementReadingMarkdown(claim,rows){
  const g=group(),lines=['# FoliaTrace statement reading','','Source: '+data.source.title,'Source URL: '+(data.source.url||'not supplied'),'Source date: '+(data.source.date||'not established'),'Source licence: '+data.source.licence,'Analysis: '+data.run_id,'Snapshot: '+data.snapshot_sha256,'','## Selected historical statement','',claim.support.text,'','Plant wording being investigated: '+g.label,'Statement: '+claim.id+'; scope: '+claim.relation_scope,'','This list contains only stored publication links to this statement, after the current candidate/design/relation/year filters. The links are research leads, not diagnostic equivalence, confirmed historical identities or treatment-effect conclusions.','', 'Reading filters: '+['branch','study-type','relation','year'].map(id=>id+': '+($('#'+id).value||'all')).join('; '),'','## Candidate identities'];
  for(const branch of g.branches){
    lines.push('- '+branch.name+' ('+branch.taxon_id+')');
    const review=data.researcher_reviews?.find(review=>review.target_kind==='identity'&&review.target_id===g.key+'::'+branch.taxon_id);
    if(review)lines.push('Stored identity judgement: '+review.decision+'; '+review.reason+'; '+review.reviewer+'; '+review.created_at);
  }
  lines.push('','## Publication reading list');
  const publications=new Map();
  for(const row of rows){const key=row.taxon_id+'::'+row.paper.id;if(!publications.has(key))publications.set(key,[]);publications.get(key).push(row);}
  for(const records of publications.values()){
    const row=records[0];
    const context=row.historical_contexts.find(context=>context.claim_id===claim.id),indication=context?.indication_comparison;
    lines.push('','### '+taxonName(row.taxon_id)+' — '+cleanTitle(row.paper.title),row.paper.url,row.paper.id+' · '+(row.paper.year||'year unknown')+' · '+row.paper.licence,'Design: '+row.study.types.map(human).join(', '));
    lines.push('Authors: '+row.paper.authors,'DOI: '+(row.paper.doi||'not supplied')+'; PMID: '+(row.paper.pmid||'not supplied'));
    if(context?.preparation_comparison)lines.push('Preparation comparison: '+context.preparation_comparison.detail);
    if(indication){lines.push('Indication reading: '+indication.detail);if(indication.study_aim)lines.push('Original abstract aim/objective wording: '+indication.study_aim.text);}
    for(const result of row.paper.reported_results||[])lines.push('Author-reported Results for the study intervention and population ('+result.licence+'): '+result.text,result.url);
    for(const record of records){
      lines.push('Topic '+record.condition_id+': automated relation '+record.relation.relation+'; failed checks: '+(record.comparability?.checks?.filter(check=>check.status==='FAIL').map(check=>check.check).join(', ')||'none recorded'));
      const review=data.researcher_reviews?.find(review=>review.target_kind==='evidence'&&review.target_id===record.id);
      if(review)lines.push('Stored evidence judgement: '+review.decision+'; '+review.reason+'; '+review.reviewer+'; '+review.created_at);
    }
  }
  if(!rows.length)lines.push('No stored publication links match this selected statement and the current filters. This does not establish that relevant studies do not exist.');
  return lines.join('\n');
}
function renderStatementReading(g,target,rows){
  const select=$('#evidence-source-statement'),box=$('#statement-reading-context'),jump=$('#statement-reading-jump');
  jump.replaceChildren();jump.hidden=!target;
  if(target){const back=el('button','↑ Your selected source statement','text-action');back.type='button';back.addEventListener('click',()=>{$('.statement-reading').scrollIntoView({block:'start',behavior:'auto'});select.focus({preventScroll:true});});jump.append(back,el('span',target.support.text.slice(0,85)+(target.support.text.length>85?'…':''),'hint'));}
  select.replaceChildren(option('','All linked statements in this chapter'));
  for(const claim of data.historical_claims.filter(claim=>g?.claim_ids.includes(claim.id))){
    const text=claim.support.text,wording=[...new Set(claim.conditions.map(condition=>condition.original))].join(', ');
    select.append(option(claim.id,(wording?wording+' · ':'')+text.slice(0,110)+(text.length>110?'…':'')));
  }
  select.disabled=!g;select.value=target?.id||'';box.replaceChildren();
  if(!target){box.append(el('p','Chapter overview: the list includes all recorded-use topics linked to this plant name. Choose one statement to keep its research question separate.','hint'));return;}
  box.append(pill(statementRoleLabel(target),target.statement_role==='ADVERSE_EFFECT_RECORDED'?'bad':'neutral'),el('blockquote',target.support.text));
  const describe=field=>[...new Set((target[field]||[]).map(span=>span.text))].join(', ')||'not stated';
  box.append(el('p','Part: '+describe('part')+' · Preparation: '+describe('preparation')+' · Route: '+describe('route'),'hint'));
  const qualifier=statementQualifier(target);if(qualifier)box.append(el('p',qualifier,'hint'));
  const actions=el('div',undefined,'row'),whole=el('button','Show all linked statements','quiet'),exportButton=el('button','Export this statement’s reading list','quiet');
  whole.type='button';whole.addEventListener('click',()=>{statementReadingTargets.set(identityPairKey(g),'');renderEvidence();rememberReading();});
  exportButton.type='button';exportButton.addEventListener('click',()=>offerExport(statementReadingMarkdown(target,rows),'foliatrace-statement-reading.md','text/markdown;charset=utf-8','Selected statement reading'));
  actions.append(whole,exportButton);box.append(actions,el('p','This scope selects existing statement links. The identity comparison and full-analysis exports retain the chapter overview.','hint'));
}
$('#evidence-source-statement').addEventListener('change',()=>{if(!group())return;statementReadingTargets.set(identityPairKey(group()),$('#evidence-source-statement').value);renderEvidence();rememberReading();});
function setupFilters() {
  const g = group();
  const b = $("#branch"),
    s = $("#study-type");
  b.replaceChildren(option("", "All candidates"));
  for (const br of g?.branches || []) b.append(option(br.taxon_id, br.name));
  s.replaceChildren(option("", "All designs"));
  for (const t of [...new Set(groupEvidence().flatMap((e) => e.study.types))].sort()) s.append(option(t, human(t)));
  $("#relation").value = "";
  $("#year").value = "";
}
function openBranchPublication(taxonId,paperId,{returnToIdentityComparison=false}={}){
  const target=statementReadingTarget();
  if(target&&!groupEvidence().some(e=>e.taxon_id===taxonId&&e.paper.id===paperId&&(e.historical_contexts||[]).some(context=>context.claim_id===target.id))){
    statementReadingTargets.set(identityPairKey(group()),'');
    status('Opened this publication in the chapter overview: it has no stored link to the previously selected statement.');
  }
  $('#branch').value=taxonId;
  for(const id of ['study-type','relation','year'])$('#'+id).value='';
  renderEvidence();showTab('tab-evidence',true);
  const card=[...$('#evidence').querySelectorAll('.evidence-item')].find(item=>item.dataset.paper===paperId&&item.dataset.taxon===taxonId);
  if(!card)return;
  card.hidden=false;
  const section=card.closest('.branch-group'),more=section?.querySelector(':scope > button.more');
  if(more){const remaining=section.querySelectorAll(':scope > .evidence-item[hidden]').length;if(remaining)more.textContent='Read '+remaining+' more publications';else more.remove();}
  const sourceComparison=card.querySelector(':scope > .study-source-comparison');if(sourceComparison)sourceComparison.open=true;
  const context=card.querySelector(':scope > .study-context');if(context)context.open=true;
  if(returnToIdentityComparison){
    const back=el('button','← Back to these identity hypotheses','quiet');back.type='button';back.className+=' back-to-identity-comparison';
    back.addEventListener('click',()=>{
      showTab('tab-identity',true);
      const original=[...$('#whatif').querySelectorAll('.identity-pair-paper')].find(item=>item.dataset.paper===paperId);
      const target=original||$('#whatif .identity-pair');if(target){if(original)original.open=true;target.tabIndex=-1;target.focus({preventScroll:true});target.scrollIntoView({block:'start',behavior:'smooth'});}
    });card.prepend(back);
  }
  card.tabIndex=-1;card.focus({preventScroll:true});card.scrollIntoView({block:'start',behavior:'smooth'});
}
const TRIAL_READING_FIELDS=[['population','Participants'],['design','Design'],['intervention','Formulation'],['comparator','Comparator'],['follow_up','Follow-up'],['primary_outcome','Primary endpoint'],['primary_result','Primary finding'],['other_results','Other findings'],['reading_question','Reading question']];
function trialReadingMarkdown(readingSet){
  const lines=['# '+readingSet.title,'',readingSet.takeaway,'',readingSet.selection,'',readingSet.annotation.method,readingSet.annotation.licence,readingSet.annotation.rights_scope,'',readingSet.link_basis];
  for(const study of readingSet.studies){
    const publication=study.publication;
    lines.push('','## '+study.label,'',publication.title,publication.authors,'PMID '+publication.pmid+' · DOI '+publication.doi,publication.url,'');
    for(const [key,label] of TRIAL_READING_FIELDS)lines.push(label+': '+study[key],'');
  }
  lines.push('Reading-set ID: '+readingSet.id,'Metadata source: '+readingSet.studies[0].publication.provenance.url,'Factual note source: '+readingSet.note_source.path+' · '+readingSet.note_source.sha256);
  return lines.join('\n');
}
function trialReadingComparison(readingSet){
  const panel=el('details',undefined,'trial-readings');panel.dataset.readingSet=readingSet.id;
  panel.append(el('summary','Compare controlled trials · '+plural(readingSet.studies.length,'selected reading')),
    el('h3',readingSet.title),el('p','Compare the primary endpoints and results. Open each trial for its formulation, participants and secondary findings.'),el('p','AI-assisted factual notes · linked original studies · separate from automated relation labels','hint'));
  const grid=el('div',undefined,'trial-reading-grid');
  for(const study of readingSet.studies){
    const card=el('article',undefined,'trial-reading-card');card.dataset.pmid=study.pmid;
    card.append(el('h4',study.label),link('Original study ↗',study.publication.url),el('p',study.follow_up+' · '+study.comparator,'hint'));
    const fields=el('dl'),contextFields=el('dl'),context=el('details',undefined,'trial-reading-context');
    context.append(el('summary','Formulation, population and other findings'),el('p',cleanTitle(study.publication.title),'hint'));
    for(const [key,label] of TRIAL_READING_FIELDS){
      const target=['primary_outcome','primary_result'].includes(key)?fields:contextFields;
      target.append(el('dt',label),el('dd',study[key],key==='primary_result'?'primary-reading-result':undefined));
    }
    context.append(contextFields);card.append(fields,context);grid.append(card);
  }
  panel.append(grid,el('p',readingSet.takeaway));
  const provenance=el('details',undefined,'reading-note-provenance');provenance.append(el('summary','Reading-note sources and scope'),el('p',readingSet.selection),el('p',readingSet.link_basis),el('p',readingSet.annotation.method),el('p',readingSet.annotation.licence),el('p',readingSet.annotation.rights_scope));
  for(const study of readingSet.studies)provenance.append(el('p',study.publication.authors+' · PMID '+study.pmid+' · DOI '+study.publication.doi,'hint'),link('Indexed source record ↗',study.publication.url));
  panel.append(provenance);
  const actions=el('div',undefined,'row'),markdown=el('button','Export trial comparison','quiet'),csv=el('button','Comparison CSV','quiet');
  markdown.type='button';markdown.addEventListener('click',()=>offerExport(trialReadingMarkdown(readingSet),'foliatrace-trial-comparison.md','text/markdown;charset=utf-8',readingSet.title));
  csv.type='button';csv.addEventListener('click',()=>{
    const rows=[['study','title','pmid','doi','source_url',...TRIAL_READING_FIELDS.map(([key])=>key),'annotation_method','annotation_licence']];
    for(const study of readingSet.studies)rows.push([study.label,study.publication.title,study.pmid,study.publication.doi,study.publication.url,...TRIAL_READING_FIELDS.map(([key])=>study[key]),readingSet.annotation.method,readingSet.annotation.licence]);
    offerExport(rows.map(row=>row.map(csvValue).join(',')).join('\r\n'),'foliatrace-trial-comparison.csv','text/csv;charset=utf-8','Controlled-trial reading comparison (CSV)');
  });
  actions.append(markdown,csv);panel.append(actions);return panel;
}
function openTrialReadingSet(id){
  const readingSet=(data.study_reading_sets||[]).find(item=>item.id===id);
  const name=readingSet&&data.identity_counterfactuals.find(g=>g.branches.some(b=>readingSet.taxon_ids.includes(b.taxon_id))&&g.conditions.some(c=>readingSet.condition_ids.includes(c)));
  if(!name){status('This analysis has no matching trial reading set. Analyze the source again to obtain the current readings.',true);return;}
  statementReadingTargets.set(identityPairKey(name),'');selectName(name.key);$('#branch').value=readingSet.taxon_ids.find(id=>name.branches.some(b=>b.taxon_id===id))||'';
  for(const filter of ['study-type','relation','year'])$('#'+filter).value='';
  renderEvidence();showTab('tab-evidence',true);
  const panel=[...$('#evidence').querySelectorAll('.trial-readings')].find(item=>item.dataset.readingSet===id);
  if(panel){panel.open=true;panel.tabIndex=-1;panel.focus({preventScroll:true});panel.scrollIntoView({block:'start',behavior:'smooth'});}
}
function studyComparisonScope(){
  return (group()?identityPairKey(group()):'none')+'::'+(statementReadingTarget()?.id||'chapter');
}
function studyComparisonPool(){
  const target=statementReadingTarget(),pool=new Map();
  for(const e of groupEvidence()){
    if(target&&!(e.historical_contexts||[]).some(c=>c.claim_id===target.id))continue;
    const key=JSON.stringify([e.taxon_id,e.paper.id]);
    if(!pool.has(key))pool.set(key,{key,records:[]});
    pool.get(key).records.push(e);
  }
  return pool;
}
function selectedStudyComparisons(){
  const pool=studyComparisonPool();
  return (studyComparisons.get(studyComparisonScope())||[]).map(key=>pool.get(key)).filter(Boolean);
}
function toggleStudyComparison(e){
  const key=JSON.stringify([e.taxon_id,e.paper.id]),scope=studyComparisonScope(),selected=selectedStudyComparisons().map(item=>item.key);
  if(selected.includes(key))selected.splice(selected.indexOf(key),1);
  else if(selected.length<3)selected.push(key);
  else {status('Three studies are selected. Remove one before adding another.',true);return;}
  studyComparisons.set(scope,selected);renderStudyComparisonSelection();rememberReading();
}
function renderStudyComparisonSelection(){
  const box=$('#study-comparison-selection'),selected=selectedStudyComparisons(),keys=new Set(selected.map(item=>item.key));
  box.replaceChildren();box.hidden=!selected.length;
  if(selected.length){
    box.append(el('h3','Your study comparison'),el('p','Choose two or three study / candidate records for this source question. Changing a filter keeps your selection; a different source statement has its own selection.','hint'));
    const list=el('ul');
    for(const item of selected){
      const e=item.records[0],row=el('li'),remove=el('button','Remove','text-action');
      row.append(el('span',cleanTitle(e.paper.title)+' · '+taxonName(e.taxon_id)));
      remove.type='button';remove.setAttribute('aria-label','Remove '+cleanTitle(e.paper.title)+' for '+taxonName(e.taxon_id));
      remove.addEventListener('click',()=>{toggleStudyComparison(e);$('#study-comparison-selection').querySelector('button')?.focus();});row.append(remove);list.append(row);
    }
    const actions=el('div',undefined,'row'),open=el('button',selected.length>1?'Compare selected studies ('+selected.length+')':'Choose one more study'),clear=el('button','Clear selection','quiet');
    open.type='button';open.disabled=selected.length<2;open.addEventListener('click',openStudyComparison);
    clear.type='button';clear.addEventListener('click',()=>{studyComparisons.delete(studyComparisonScope());renderStudyComparisonSelection();rememberReading();$('#modern-question').tabIndex=-1;$('#modern-question').focus();});
    actions.append(open,clear);box.append(list,actions);
  }
  for(const button of document.querySelectorAll('[data-study-choice]')){
    const included=keys.has(button.dataset.studyChoice);button.textContent=included?'Remove from comparison':'Select for comparison';button.setAttribute('aria-pressed',String(included));
    button.disabled=!included&&selected.length>=3;
  }
  for(const button of document.querySelectorAll('[data-open-study-comparison]')){button.hidden=selected.length<2;button.textContent='Compare selected ('+selected.length+')';}
}
function studyMeasurementReadings(e){
  const primary=/\b(?:co[- ]?)?primary\s+(?:clinical\s+)?(?:outcomes?|end\s*points?|efficacy\s+(?:variables?|parameters?|measures?))\b/i;
  const secondary=/\bsecondary\s+(?:clinical\s+)?(?:outcomes?|end\s*points?|efficacy\s+(?:variables?|parameters?|measures?))\b/i;
  return (e.paper.methods_contexts||[]).filter(context=>context.source_kind!=='FULL_TEXT_METHODS_TABLE').filter(context=>{
    const explicit=primary.test(context.text)||secondary.test(context.text)||/\boutcome measures?\b/i.test(context.text);
    const measurementSection=/assessments?|outcomes?|measurements?|biophysical parameters|data collection/i.test(context.section);
    return explicit||measurementSection&&/\b(?:record(?:ed)?|assess(?:ed|ment)?|measur(?:ed|ements?)|evaluat(?:ed|ion)|analy[sz]ed|rating scales?|questionnaires?)\b/i.test(context.text);
  }).map(context=>{
    const priorities=[primary.test(context.text)?'primary':null,secondary.test(context.text)?'secondary':null].filter(Boolean);
    return {context,priority:priorities.length?'Authors explicitly use '+priorities.join(' and ')+' outcome wording in this excerpt.':'Primary/secondary priority is not stated in this excerpt.'};
  });
}
function studyMeasurementPanel(e,readings){
  const panel=el('details',undefined,'study-outcome-definitions');
  panel.append(el('summary',readings.length?'What was measured · '+plural(readings.length,'source excerpt'):'What was measured · read the original study'));
  if(!readings.length){
    panel.append(el('p','No measurement definition has been isolated in the stored Methods excerpts. This does not mean the study had no outcomes.'),link('Read original study ↗',e.paper.url));return panel;
  }
  panel.append(el('p','Original Methods wording. Outcomes may belong to different parts of a study; a measurement or endpoint is not a finding.','hint'));
  for(const reading of readings){
    const {context,priority}=reading,section=el('section');
    section.append(el('p',context.section,'quote-label'),el('p',priority,'hint'),el('blockquote',context.text),link('Original Methods ↗',context.url),el('p',context.id+' · '+context.licence,'hint'));panel.append(section);
  }
  return panel;
}
function studyComparisonFields(item){
  const records=item.records,e=records[0],paper=e.paper,study=e.study,target=statementReadingTarget();
  const measurements=studyMeasurementReadings(e);
  const unique=values=>[...new Set(values.filter(Boolean))];
  const quote=span=>{
    if(!span)return 'Not established in the stored source excerpts.';
    const context=(paper.methods_contexts||[]).find(c=>c.id===span.source_id);
    return '“'+span.text+'” — '+(context?context.section+' · '+context.id:human(span.source_kind||'ABSTRACT'))+(Number.isInteger(span.start)?' · characters '+span.start+'–'+span.end:'')+(context?.url?' · '+context.url:'');
  };
  const forms=study.preparation_attribution?.forms||[],comparator=e.comparability?.checks.find(c=>c.check==='comparator');
  const contexts=[...new Map(records.flatMap(record=>(record.historical_contexts||[]).filter(c=>!target||c.claim_id===target.id)).map(c=>[c.claim_id,c])).values()];
  const findings=unique((paper.reported_results||[]).map(c=>c.section+' · '+c.licence+'\n“'+c.text+'”\n'+c.url));
  if(!findings.length)for(const record of records){const finding=record.relation.reported_finding;if(finding?.direction!=='NO_RESULT_STATEMENT')for(const statement of finding?.statements?.length?finding.statements:[finding])if(statement?.supporting_text)findings.push('Original abstract finding ('+human(statement.direction)+')\n“'+statement.supporting_text+'”');}
  const formulation=unique(forms.map(form=>quote({...form,text:form.context?.text||form.text,start:form.context?.start??form.start,end:form.context?.end??form.end})));
  if(!formulation.length)formulation.push(study.pico_source_spans?.intervention_preparation?quote(study.pico_source_spans.intervention_preparation):'No preparation wording has been assigned to this candidate in the stored excerpts.');
  const methodIds=new Set([...(study.preparation_attribution?.methods_context_ids||[]),...(e.comparability?.checks||[]).map(c=>c.span?.source_id)].filter(Boolean));
  for(const context of paper.methods_contexts||[])if(methodIds.has(context.id)&&/intervention|preparation/i.test(context.section)&&context.source_kind!=='FULL_TEXT_METHODS_TABLE')formulation.push(context.section+' · original wording\n“'+context.text+'”\n'+context.url+' · '+context.licence+' · '+context.id);
  formulation.push('Candidate / preparation association: '+human(study.preparation_attribution?.status||'NOT_RECORDED')+'. Lexical association requires intervention review.');
  const historical=unique(contexts.flatMap(c=>['Historical statement · '+c.claim_id+'\n“'+c.support.text+'”',c.preparation_comparison?.detail,c.indication_comparison?.detail]));
  return [
    {label:'Candidate being investigated',paragraphs:[taxonName(e.taxon_id)+' · '+e.taxon_id]},
    {label:'Study design',paragraphs:[study.types.map(human).join(', '),'Automated classification · '+human(study.population_status)+'. Risk of bias has not been appraised.']},
    {label:'Population wording',paragraphs:[quote(study.pico_source_spans?.population),...(study.sample_size_support?['Sample-size wording: '+(typeof study.sample_size_support==='string'?study.sample_size_support:quote(study.sample_size_support))]:[])]},
    {label:'Candidate-linked preparation in context',paragraphs:formulation},
    {label:'Comparator wording',paragraphs:[study.pico_source_spans?.comparator?quote(study.pico_source_spans.comparator):comparator?.span?.source_kind?.startsWith('FULL_TEXT_METHODS')?'Design wording in Methods: '+quote(comparator.span):'No comparator wording was established in the stored excerpts.',...(comparator?[comparator.detail]:[])]},
    {label:'Measurement definitions and outcome priorities',paragraphs:measurements.length?measurements.map(({context,priority})=>priority+'\n'+context.section+' · original Methods\n“'+context.text+'”\n'+context.url+' · '+context.licence+' · '+context.id):['No measurement definition has been isolated in the stored Methods excerpts. Read the original study; missing extraction is not absence of an outcome.']},
    {label:'Reported findings',paragraphs:[...(unique(findings).length?unique(findings):['No explicit result statement was extracted in the stored excerpts. Open the original study.']),...unique(records.flatMap(record=>record.relation.reported_finding?.comparison_notes||[]))]},
    {label:'Link to the historical question',paragraphs:historical.length?historical:['No statement context stored for this record.']},
    {label:'Reading limits by topic',paragraphs:records.map(record=>human(record.condition_id.replace('condition:',''))+' · '+(record.comparability?.checks||[]).map(c=>(CHECK_LABEL[c.check]||c.check)+': '+human(c.status)).join('; '))},
    {label:'Publication and rights',paragraphs:[paper.authors||'Authors not supplied',paper.id+' · '+(paper.year||'year not supplied')+' · '+paper.licence,paper.url,...(paper.doi?['DOI https://doi.org/'+paper.doi]:[])]}
  ];
}
function studyComparisonMarkdown(items){
  const g=group(),target=statementReadingTarget(),lines=['# FoliaTrace selected-study comparison','','Source: '+data.source.title,data.source.url,'Source date: '+data.source.date+' · '+data.source.licence,'Analysis: '+data.run_id,'Snapshot: '+data.snapshot_sha256,'Plant wording: '+g.label,'Reading scope: '+(target?target.id+' · '+target.support.text:'Chapter overview — these records may link to different historical statements.'),'','Reader-selected records, not a systematic review or pooled effect estimate. The same publication may appear under different candidate hypotheses; those columns are not independent studies. Source wording and rule-based checks require critical reading.'];
  lines.push('Historical-name resolution: '+human(g.status)+'. Modern candidate names do not establish the historical referent.');
  for(const item of items){
    const e=item.records[0];lines.push('','## '+cleanTitle(e.paper.title),'Stored links: '+item.records.map(record=>record.id).join(', '));
    lines.push('Identity scope: '+(e.identity_qualifier||'Conditional on the candidate identity being investigated'));
    for(const field of studyComparisonFields(item))lines.push('','### '+field.label,...field.paragraphs.map(p=>p+'\n'));
    const reviews=(data.researcher_reviews||[]).filter(review=>review.target_kind==='evidence'&&item.records.some(record=>record.id===review.target_id)||review.target_kind==='identity'&&review.target_id===g.key+'::'+e.taxon_id);
    for(const review of reviews)lines.push('Stored '+review.target_kind+' judgement ('+review.target_id+'): '+review.decision+' · '+review.reason+' · '+review.reviewer+' · '+review.created_at);
  }
  lines.push('','## Original study excerpts','One source appendix per publication, even when several candidate hypotheses use it. These are the stored licensed excerpts, not full articles.');
  for(const paper of new Map(items.map(item=>[item.records[0].paper.id,item.records[0].paper])).values()){
    lines.push('','### '+paper.id+' · '+cleanTitle(paper.title),paper.authors||'Authors not supplied',paper.url);
    if(paper.abstract_rights==='LOCAL_CACHE_NOT_REDISTRIBUTED')lines.push('Abstract not copied into this export: rights remain with the publisher. Read it at the link above.');
    else lines.push('Abstract rights: '+paper.licence,'','#### Original abstract','',paper.abstract);
    for(const context of paper.methods_contexts||[])lines.push('','#### '+context.section,'Original source: '+context.url,'Excerpt: '+context.id+' · '+context.licence,'Text SHA256: '+context.text_sha256,'Document SHA256: '+context.document_sha256,context.text_format||'Whitespace-normalized JATS paragraph; no inferred wording.','',context.text);
  }
  return lines.join('\n');
}
function openStudyComparison(){
  const items=selectedStudyComparisons();if(items.length<2)return;
  const dialog=el('dialog',undefined,'study-comparison-dialog'),head=el('div',undefined,'study-comparison-heading'),heading=el('h2','Compare selected studies'),close=el('button','Close','quiet');
  heading.id='study-comparison-title';dialog.setAttribute('aria-labelledby',heading.id);close.type='button';close.autofocus=true;close.addEventListener('click',()=>dialog.close());head.append(heading,close);
  const target=statementReadingTarget(),intro=el('section',undefined,'study-comparison-question');intro.append(el('strong',data.source.title+' · '+group().label));
  intro.append(target?el('blockquote',target.support.text):el('p','Chapter overview: these records may address different source statements. Compare their historical links below.'));
  intro.append(el('p','Reader-selected research leads. Compare interventions and outcomes before interpreting differences. Columns for the same publication under different candidate hypotheses are not independent studies.','hint'));
  const scroller=el('div',undefined,'study-comparison-scroll');scroller.tabIndex=0;scroller.setAttribute('role','region');scroller.setAttribute('aria-label','Study comparison table; scroll horizontally to read every column');
  const table=el('table'),caption=el('caption','Selected study records · original wording and reading limits'),thead=el('thead'),tr=el('tr');
  table.style.minWidth=(150+items.length*300)+'px';
  const corner=el('th','Reading question');corner.scope='col';tr.append(corner);
  for(const item of items){const e=item.records[0],th=el('th');th.scope='col';th.append(link(cleanTitle(e.paper.title),e.paper.url),el('p',taxonName(e.taxon_id)+' · '+(e.paper.year||'year unknown'),'hint'));tr.append(th);}
  thead.append(tr);const tbody=el('tbody'),fields=items.map(studyComparisonFields);
  fields[0].forEach((field,index)=>{
    const row=el('tr'),label=el('th',field.label);label.scope='row';row.append(label);
    for(const column of fields){const cell=el('td');for(const paragraph of column[index].paragraphs)cell.append(el('p',paragraph));row.append(cell);}tbody.append(row);
  });
  const sourceRow=el('tr'),sourceLabel=el('th','Read original excerpts');sourceLabel.scope='row';sourceRow.append(sourceLabel);
  for(const item of items){
    const e=item.records[0],cell=el('td'),details=el('details');details.append(el('summary','Full abstract and available Methods'),el('p',e.paper.abstract,'abstract'));
    for(const context of e.paper.methods_contexts||[])details.append(el('h4',context.section),el('blockquote',context.text),link('Original Methods ↗',context.url),el('p',context.id+' · '+context.licence,'hint'));
    cell.append(details);sourceRow.append(cell);
  }
  tbody.append(sourceRow);table.append(caption,thead,tbody);scroller.append(table);
  const actions=el('div',undefined,'row'),exportButton=el('button','Export this comparison','quiet');exportButton.type='button';
  exportButton.addEventListener('click',()=>offerExport(studyComparisonMarkdown(items),'foliatrace-selected-study-comparison.md','text/markdown;charset=utf-8','Selected-study comparison'));actions.append(exportButton);
  dialog.append(head,intro,el('p','Scroll across the table to read each selected study.','hint'),scroller,actions);
  dialog.addEventListener('close',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
}
function renderEvidence() {
  const g = group();
  const branch = $("#branch").value,
    type = $("#study-type").value,
    relation = $("#relation").value,
    year = Number($("#year").value) || 0;
  const target=statementReadingTarget(g);
  const all = groupEvidence().filter(e=>!target||(e.historical_contexts||[]).some(context=>context.claim_id===target.id));
  const rows = all.filter((e) => (!branch || e.taxon_id === branch) && (!type || e.study.types.includes(type)) && (!relation || (e.relation.reported_finding?.direction||'NO_RESULT_STATEMENT') === relation) && (!year || Number(e.paper.year) >= year));
  renderStatementReading(g,target,rows);
  const topicIds=target?[...new Set(target.conditions.map(condition=>condition.id))]:(g?.conditions||[]);
  const conditions = topicIds.map((c) => human(c.replace("condition:", "")));
  $("#modern-question").textContent = !g?.branches.length?'No candidate, so no modern question is asked.':target?'Reading question: do the studies’ species, preparations and measured outcomes address this exact source statement? Check each candidate separately.':`Modern question, asked separately for each candidate: does a specified preparation help ${conditions.join(", ") || "the recorded conditions"} in humans? A historical use is not evidence that it does.`;
  $('#evidence-count').textContent=new Set(rows.map(e=>e.paper.id)).size+' publications · '+rows.length+(target?' links to this statement':' links to historical topics');
  const blocking = $("#blocking");
  blocking.replaceChildren();
  if (rows.length) {
    const counts = {};
    for (const e of rows) {
      const k = blockingKey(e);
      counts[k] = (counts[k] || 0) + 1;
    }
    blocking.append(el("span", "Why records stop short:"));
    for (const [k, n] of Object.entries(counts).sort((a, b) => b[1] - a[1])) blocking.append(el("span", `${BLOCKING[k] || human(k)} ${n}`));
  }
  const conflicts = $("#conflicts");
  conflicts.replaceChildren();
  for (const c of data.conflicts.filter((c) => rows.some(e=>e.taxon_id===c.taxon_id&&e.condition_id===c.condition_id) && ["MIXED", "POTENTIAL_CONFLICT_REQUIRES_COMPARABILITY_REVIEW"].includes(c.state)))
    conflicts.append(el("div", `${taxonName(c.taxon_id)} · ${human(c.condition_id.replace("condition:", ""))}: ${human(c.state)}. ${c.limitation}`, "conflict"));
  const box = $("#evidence");
  box.replaceChildren();
  if(!type&&!relation&&!year){
    for(const readingSet of data.study_reading_sets||[]){
      if(g?.branches.some(b=>readingSet.taxon_ids.includes(b.taxon_id))&&(!branch||readingSet.taxon_ids.includes(branch))&&topicIds.some(c=>readingSet.condition_ids.includes(c))&&(!target||all.length))box.append(trialReadingComparison(readingSet));
    }
  }
  if (!rows.length)
    box.append(el("p", all.length ? "No record matches these filters." : target?"No stored publication links to this exact statement in this analysis. Statements outside recorded uses do not start a literature question. Switch to the chapter overview or analyze again if this saved record lacks statement links.":"No evidence for this name in the local snapshot. That is not evidence of no effect.", "empty"));
  // Keep candidate identities separate, while letting the researcher read each paper once.
  for (const b of g?.branches || []) {
    const mine=rows.filter(e=>e.taxon_id===b.taxon_id);
    if(!mine.length)continue;
    const papers=new Map();for(const e of mine){if(!papers.has(e.paper.id))papers.set(e.paper.id,[]);papers.get(e.paper.id).push(e);}
    const section=el('section',undefined,'branch-group'),head=el('h3');
    head.append(el('i',b.name),document.createTextNode(' · '+papers.size+' publication'+(papers.size===1?'':'s')));section.append(head);
    [...papers.values()].forEach((links,i)=>{
      const card=evidenceCard(links[0]);
      if(links.length>1){const related=el('details',undefined,'linked-conditions');const topics=[...new Set(links.slice(1).map(e=>human(e.condition_id.replace('condition:',''))))];related.append(el('summary','Also linked to '+topics.join(', ')));for(const e of links.slice(1))related.append(evidenceCard(e));card.append(related);}
      if(i>=3)card.hidden=true;section.append(card);
    });
    if(papers.size>3){const more=el('button','Read '+(papers.size-3)+' more publications','quiet more');more.addEventListener('click',()=>{for(const card of section.querySelectorAll(':scope > .evidence-item[hidden]'))card.hidden=false;more.remove();});section.append(more);}box.append(section);
  }
  renderStudyComparisonSelection();
}

function sourceStudyComparison(e){
  const box=el('details',undefined,'study-source-comparison');
  const target=statementReadingTarget(),contexts=(e.historical_contexts||[]).filter(context=>!target||context.claim_id===target.id),study=e.study,attribution=study.preparation_attribution;
  box.append(el('summary','Compare historical wording and study intervention'+(contexts.length?' · '+plural(contexts.length,'statement'):'')));
  if(!contexts.length){
    box.append(el('p','This saved analysis has no statement-level comparison. Analyze the source again to link exact original statements and candidate-specific preparation wording.','hint'));
    return box;
  }
  box.open=!target&&contexts.length===1;
  box.append(el('p','The topic mapping is a search aid. The original condition wording is not treated as an equivalent modern diagnosis.','hint'));
  const grid=el('div',undefined,'source-study-grid'),source=el('section'),modern=el('section');
  source.append(el('h4','Historical source'));
  const prioritized=[...contexts].sort((a,b)=>{
    const priority=context=>(libraryFocus?.source_id===data.source.id&&libraryFocus.statement.start===context.support.start?4:0)+(context.preparation.length?1:0);
    return priority(b)-priority(a);
  });
  const additional=el('details',undefined,'more-source-statements');
  additional.append(el('summary',plural(contexts.length-1,'more historical statement')+' linked to this topic'));
  for(const [index,context] of prioritized.entries()){
    const item=el('div',undefined,'source-study-statement');
    item.append(el('blockquote',context.support.text));
    const wording=(context.condition_wording||[]).map(c=>c.original).filter(Boolean);
    const describe=field=>[...new Set((context[field]||[]).map(x=>x.text))].join(', ')||'not stated';
    item.append(el('p','Original topic wording: '+[...new Set(wording)].join(', '),'hint'),el('p','Part: '+describe('part')+' · Preparation: '+describe('preparation')+' · Route: '+describe('route'),'hint'));
    const qualifier=statementQualifier(context);if(qualifier)item.append(el('p',qualifier,'hint'));
    const comparison=context.preparation_comparison;
    if(comparison)item.append(el('p','Preparation comparison: '+comparison.detail,'source-study-assessment'));
    const indication=context.indication_comparison;
    if(indication&&(indication.historical_wording.length||indication.study_wording.length)){
      const wording=spans=>[...new Map(spans.map(span=>[span.text.toLowerCase(),span.text])).values()].join(', ')||'Not established by this word screen';
      const reading=el('details',undefined,'indication-comparison');
      reading.append(el('summary',indication.status==='DIFFERENT_EXPLICIT_SITE_WORDING'?'Different site words · compare the actual indications':'Compare indication and site wording'));
      reading.open=indication.status==='DIFFERENT_EXPLICIT_SITE_WORDING';
      const fields=el('dl',undefined,'study-wording');fields.append(el('dt','Words in this historical statement'),el('dd',wording(indication.historical_wording)),el('dt',indication.study_aim?'Words in the study title / aim':'Words in the study title / abstract'),el('dd',wording(indication.study_wording)));
      reading.append(fields,el('p',indication.detail,'source-study-assessment'));
      if(indication.study_aim)reading.append(el('p','Stated study aim · original abstract wording','quote-label'),el('blockquote',indication.study_aim.text),link('Original publication ↗',e.paper.url));
      else reading.append(el('p','Study title: '+cleanTitle(e.paper.title)),el('p','No explicit aim sentence was found; the site words also include abstract context.','hint'));
      const scope=el('details',undefined,'indication-screen-scope');scope.append(el('summary','How these words were compared'),el('p',indication.scope),el('p','Literal word groups, not an anatomical ontology, diagnosis or outcome-equivalence decision. Negation and grammatical relations still require source reading.','hint'));
      reading.append(scope);item.append(reading);
    }
    const read=el('button','Read this statement in the full source','text-action');
    read.type='button';
    read.addEventListener('click',()=>{
      sourceEvidenceFocus={nameKey:selected,taxonId:e.taxon_id,paperId:e.paper.id};
      sourceFocusOrigin='evidence';libraryFocus={source_id:data.source.id,statement:context.support};renderSource();
      requestAnimationFrame(()=>{
        $('#source-focus')?.scrollIntoView({behavior:'auto',block:'start'});
        $('#original').focus({preventScroll:true});
      });
    });
    item.append(read);(index===0?source:additional).append(item);
  }
  if(contexts.length>1)source.append(additional);
  modern.append(el('h4','Modern study'),el('p','Candidate being checked: '+taxonName(e.taxon_id),'hint'));
  const fields=el('dl',undefined,'study-wording');
  fields.append(el('dt','Study title / question'),el('dd',cleanTitle(e.paper.title)));
  for(const [label,key] of [['Population wording','population'],['Preparation wording','intervention_preparation'],['Comparator wording','comparator']]){
    const comparison=e.comparability?.checks.find(c=>c.check==='comparator');
    const value=key==='comparator'&&comparison?.span?.source_kind==='FULL_TEXT_METHODS'?'Methods comparison / design wording: “'+comparison.span.text+'”':study.pico_source_spans?.[key]?.text||'Not established in the abstract';
    fields.append(el('dt',label),el('dd',value));
  }
  modern.append(fields);
  const methodIds=new Set((e.comparability?.checks||[]).map(c=>c.span?.source_kind?.startsWith('FULL_TEXT_METHODS')?c.span.source_id:null).filter(Boolean));
  for(const span of study.preparation_attribution?.forms||[])if(span.source_id)methodIds.add(span.source_id);
  for(const id of study.preparation_attribution?.methods_context_ids||[])methodIds.add(id);
  const methods=(e.paper.methods_contexts||[]).filter(context=>methodIds.has(context.id));
  if(methods.length){
    const excerpts=el('details',undefined,'study-methods-source');
    excerpts.append(el('summary','Read the Methods behind the species, design and preparation checks'));
    for(const context of methods)excerpts.append(el('h4',context.section),el('blockquote',context.text),link('Original Methods section ↗',context.url),el('p',context.licence+' · '+(context.source_kind==='FULL_TEXT_METHODS_TABLE'?'Original table cells transcribed with | separators':'Whitespace-normalized JATS paragraph')+' · '+context.id,'hint'));
    modern.append(excerpts);
    const comparator=e.comparability.checks.find(c=>c.check==='comparator');
    if(comparator?.span?.source_kind==='FULL_TEXT_METHODS')modern.append(el('p',comparator.detail,'source-study-assessment'));
  }
  const otherMethods=(e.paper.methods_contexts||[]).filter(context=>!methodIds.has(context.id));
  if(otherMethods.length){
    const excerpts=el('details',undefined,'study-methods-source');excerpts.append(el('summary','Read '+plural(otherMethods.length,'other stored Methods excerpt')));
    for(const context of otherMethods)excerpts.append(el('h4',context.section),el('blockquote',context.text),link('Original Methods section ↗',context.url),el('p',context.licence+' · '+context.id,'hint'));
    modern.append(excerpts);
  }
  if(attribution){
    if(attribution.scientific_grounding_scope==='FULL_TEXT_METHODS')modern.append(el('p','The scientific name is grounded in the Methods excerpt. The abstract’s nearby preparation wording still requires intervention review.','hint'));
    if(attribution.status==='COMMON_NAME_ONLY_PREPARATION_WORDING')modern.append(el('p','Preparation wording is near a common plant name. The study species remains unconfirmed for this candidate.','hint'));
    if(attribution.status==='MULTIPLE_CANDIDATE_FORMS')modern.append(el('p','Several preparation forms are linked to this species. A single intervention has not been established.','hint'));
    else if(attribution.status==='CANDIDATE_PREPARATION_UNRESOLVED')modern.append(el('p','The abstract’s preparation wording is not assigned to this candidate species.','hint'));
    if(attribution.forms.length){
      const form=attribution.forms.find(f=>f.start===study.pico_source_spans?.intervention_preparation?.start)||attribution.forms[0];
      modern.append(el('p',form.source_kind==='FULL_TEXT_METHODS_TABLE'?'Candidate formulation row · original Methods table:':'Candidate-linked wording in context:','quote-label'),el('blockquote',form.context.text));
    }
    if(attribution.forms.length>1||attribution.other_preparation_wording.length){
      const signals=el('details');signals.append(el('summary','Inspect all preparation wording'));
      for(const form of attribution.forms)signals.append(el('p','Near '+form.candidate_wording+': '+form.text),el('blockquote',form.context.text));
      for(const form of attribution.other_preparation_wording){signals.append(el('p','Other wording, not assigned to this candidate: '+form.text,'hint'));if(form.context)signals.append(el('blockquote',form.context.text));}
      modern.append(signals);
    }
    modern.append(el('p','Nearby wording is a lexical reading aid. It does not establish the administered intervention, isolate an ingredient’s effect, or show equivalent dose and preparation.','hint'));
  }else modern.append(el('p','This older analysis did not assign preparation wording to a candidate species.','hint'));
  grid.append(source,modern);box.append(grid);return box;
}

function evidenceCard(e) {
  const card = el("article", undefined, "evidence-item");
  card.dataset.paper=e.paper.id;card.dataset.taxon=e.taxon_id;card.dataset.condition=e.condition_id;
  const top = el("div", undefined, "row");
  top.append(pill(e.relation.relation==='INSUFFICIENT'?(e.comparability?.first_blocking_check?'Limited applicability':'Applicability unresolved'):human(e.relation.relation), relationTone(e.relation.relation)), el("span", `${human(e.condition_id.replace("condition:", ""))} · ${e.study.types.map(human).join(", ")}`, "hint"));
  const title = el("h3");
  title.append(link(cleanTitle(e.paper.title), e.paper.url));
  card.append(top, title, el('p', [e.paper.year,e.paper.licence].filter(Boolean).join(' · '), 'meta'));
  const comparisonActions=el('div',undefined,'row study-comparison-actions'),choose=el('button','Select for comparison','quiet'),compare=el('button','Compare selected','quiet');
  choose.type='button';choose.dataset.studyChoice=JSON.stringify([e.taxon_id,e.paper.id]);choose.setAttribute('aria-label','Select or remove '+cleanTitle(e.paper.title)+' for '+taxonName(e.taxon_id)+' in the study comparison');choose.addEventListener('click',()=>toggleStudyComparison(e));
  compare.type='button';compare.dataset.openStudyComparison='';compare.hidden=true;compare.addEventListener('click',openStudyComparison);comparisonActions.append(choose,compare);card.append(comparisonActions);
  const measurements=studyMeasurementReadings(e);if(measurements.length)card.append(studyMeasurementPanel(e,measurements));
  if(e.paper.reported_results?.length){
    const results=el('section',undefined,'reported-results');
    results.append(el('h4','What the study reports'));
    for(const context of e.paper.reported_results){
      results.append(el('blockquote',context.text),link('Original Results section ↗',context.url),el('p',context.licence+' · '+context.section,'hint'));
    }
    const uncontrolled=e.comparability?.checks.some(c=>c.check==='comparator'&&c.status==='FAIL'&&c.span?.source_kind==='FULL_TEXT_METHODS');
    results.append(el('p',uncontrolled?'These are reported changes during an uncontrolled study. They do not isolate a treatment effect.':'These results concern this study’s intervention and population. Compare them with the source statement below.','hint'));
    for(const note of e.relation.reported_finding?.comparison_notes||[])results.append(el('p',note,'source-study-assessment'));
    card.append(results);
  }
  const checks = el("ul", undefined, "checks");
  for (const c of e.comparability?.checks || []) {
    const li = el("li", `${CHECK_LABEL[c.check] || c.check}`, c.status);
    li.title = c.detail;
    li.setAttribute("aria-label", `${CHECK_LABEL[c.check] || c.check}: ${human(c.status)}. ${c.detail}`);
    checks.append(li);
  }
  card.append(checks);
  card.append(sourceStudyComparison(e));
  const open = (e.comparability?.checks || []).filter((c) => c.status === "PARTIAL" || c.status === "UNKNOWN");
  if (!e.comparability?.first_blocking_check && open.length)
    card.append(el('p', 'Still unclear: '+open.map(c=>(CHECK_LABEL[c.check]||c.check).toLowerCase()).join(', ')+'. Read the full study before carrying this finding over to the historical preparation.', 'hint'));
  if (e.relation.pre_comparability_relation)
    card.append(el('p', 'This finding cannot be carried over directly: the '+(CHECK_LABEL[e.comparability.first_blocking_check]?.toLowerCase()||e.comparability.first_blocking_check)+' is different or remains unclear.', 'hint'));
  const finding = e.relation.reported_finding;
  if(finding?.candidate_scope_note)card.append(el('p',finding.candidate_scope_note,'hint'));
  if (finding && finding.direction !== "NO_RESULT_STATEMENT") card.append(el("p", finding.comparison_notes?.length?'A treatment-versus-comparator direction could not be established from these statements. Read the comparison notes and source findings.':`Automated abstract reading: ${human(finding.direction)}. Read the quoted findings for the study's own population and preparation.`, "hint"));
  // Say what the quoted sentence is: a result statement, or only a mention of the condition.
  const isResult = finding && finding.direction !== "NO_RESULT_STATEMENT" && finding.supporting_text === e.relation.supporting_text;
  if(!e.paper.reported_results?.length){
    if (finding?.statements?.length) {
      card.append(el('p', 'Endpoint-specific result statements:', 'quote-label'));
      for (const statement of finding.statements) card.append(el('p',human(statement.direction),'quote-label'),el('blockquote',statement.supporting_text));
    } else {
      if (e.relation.supporting_text) card.append(el("p", isResult ? "Result sentence:" : "Sentence that mentions the condition (not a reported result):", "quote-label"));
      card.append(el("blockquote", e.relation.supporting_text || "No sentence in the abstract mentions the condition."));
    }
  }
  const d = el("details",undefined,"study-context");
  d.append(el('summary', 'Study context, source and full abstract'), el('p', e.relation.rationale),el('p', 'Publication '+e.paper.id+(e.paper.pmid?' · PMID '+e.paper.pmid:''), 'hint'));
  if(finding?.unassigned_statements?.length){
    const unassigned=el('div',undefined,'source-study-assessment');
    unassigned.append(el('strong','Findings not assigned to this candidate'));
    for(const statement of finding.unassigned_statements)unassigned.append(el('blockquote',statement.supporting_text));
    unassigned.append(el('p','These source findings may concern another intervention. They do not contribute a direction for this candidate.','hint'));
    d.append(unassigned);
  }
  const list = el("ul", undefined, "why");
  for (const c of e.comparability?.checks || []) list.append(el("li", `${CHECK_LABEL[c.check] || c.check} — ${human(c.status)}: ${c.detail}`));
  d.append(list, el("p", "Question: " + e.modern_hypothesis.question), el("p", `Citation: ${human(e.citation.status)}. The identifier and quoted sentence match the stored record; that does not prove the paper supports the claim.`, "hint"));
  if (e.paper.doi) d.append(link("DOI " + e.paper.doi, "https://doi.org/" + e.paper.doi));
  d.append(el("p", "Authors: " + (e.paper.authors || "not supplied"), "hint"));
  if (e.study.local_model?.used) d.append(el("p", `Local design classifier proposes “${human(e.study.local_model.label)}”. A proposal for review, not a verified label.`, "hint"));
  d.append(el("p", e.paper.abstract, "abstract"));
  if (!recorded) d.append(outcomeForm(e));
  if (e.safety_signals.length) {
    d.append(el("strong", "Safety or interaction wording in the abstract"));
    for (const s of e.safety_signals) d.append(el("blockquote", s.supporting_text));
    d.append(el("p", "Source wording only; not a safety assessment for any person.", "hint"));
  }
  if (e.compound_co_mentions.length) {
    const p = el("p", "Compounds mentioned (not proof the plant contains them): ", "hint");
    for (const c of e.compound_co_mentions) p.append(link(`${c.name} · CID ${c.cid}`, c.url), document.createTextNode(" "));
    d.append(p);
    const leads = (data.compound_assay_leads || []).filter((a) => a.linked_evidence.some((x) => x.evidence_id === e.id));
    if (leads.length) {
      const chemistry = el("details", undefined, "chemistry");
      chemistry.append(el("summary", `Compound assay leads (${leads.length})`), el("p", "These molecules are mentioned in the publication. The database join does not show that this plant or historical preparation contains them. Assay measurements are not clinical effects.", "hint"));
      for (const a of leads) {
        const item = el("div", undefined, "reading-scope");
        item.append(el("strong", `${a.compound} → ${a.target.pref_name}`), el("p", `${a.standard_type} ${a.standard_relation} ${a.standard_value} ${a.standard_units} · ${a.target.organism} · ${human(a.target.target_type)}`), el("p", a.assay_description, "hint"), link("ChEMBL assay record ↗", a.url), el("p", `${a.document_id} · ${a.assay_id} · ${a.licence}`, "hint"));
        chemistry.append(item);
      }
      d.append(chemistry);
    }
  }
  const actions = el("div", undefined, "row");
  const raw = el("button", "Show provenance record", "quiet");
  raw.type = "button";
  raw.addEventListener("click", () => {
    inspect(e, "Publication evidence");
    showView("graph");
  });
  actions.append(raw);
  if (!recorded) {
    const v = el("button", "Re-check metadata at the source", "quiet");
    v.type = "button";
    v.addEventListener("click", async () => {
      v.disabled = true;
      try {
        const r = await api(`/api/citations/${e.paper.id}/verify-live`);
        status(`Source metadata ${r.metadata_match ? "matches" : "does NOT match"} the stored record for ${e.paper.id}. Entailment is not checked by this lookup.`, !r.metadata_match);
      } catch (error) {
        status(error.message, true);
      } finally {
        v.disabled = false;
      }
    });
    actions.append(v);
  }
  d.append(actions, reviewForm("evidence", e.id, "Does this record bear on the modern question?"));
  card.append(d);
  return card;
}

/* ---------- Reviews ---------- */
function outcomeForm(e) {
  const d = el("details", undefined, "outcome-tool");
  d.append(el("summary", "Explore a reported outcome with the local model"), el("p", "Specify the study's actual comparison. The model proposes increased, decreased or no significant difference for that outcome. It does not change the evidence verdict.", "hint"));
  const form = el("form"), fields = {};
  for (const [key, label, value] of [["intervention", "Intervention studied", ""], ["comparator", "Comparator", ""], ["outcome", "Outcome measured", ""], ["evidence", "Exact evidence from this abstract", e.relation.supporting_text || ""]]) {
    const l = el("label", label), input = el(key === "evidence" ? "textarea" : "input");
    input.required = true;
    input.maxLength = key === "evidence" ? 12000 : 500;
    input.minLength = key === "evidence" ? 15 : 2;
    input.value = value;
    if (key === "evidence") input.rows = 4;
    l.append(input);
    form.append(l);
    fields[key] = input;
  }
  const button = el("button", "Propose outcome direction");
  button.type = "submit";
  const result = el("p", "", "hint");
  result.setAttribute("aria-live", "polite");
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    button.disabled = true;
    try {
      const response = await api('/api/research/outcome-direction', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({run_id: data.run_id, paper_id: e.paper.id, ...Object.fromEntries(Object.entries(fields).map(([key, input]) => [key, input.value.trim()]))})});
      result.textContent = `${response.direction ? "Model proposal: " + human(response.direction) + ". " : ""}${response.scope}`;
    } catch (error) { result.textContent = error.message; }
    finally { button.disabled = false; }
  });
  form.append(button, result);
  d.append(form);
  return d;
}

function reviewFor(kind, id) {
  return (data.researcher_reviews || []).find((r) => r.target_kind === kind && r.target_id === id);
}
function reviewForm(kind, id, question) {
  const wrap = el("div", undefined, "review-form");
  const existing = reviewFor(kind, id);
  if (existing) {
    const p = el("p", undefined, "review-saved");
    p.append(pill("Your review: " + human(existing.decision), existing.decision === "ACCEPT" ? "ok" : existing.decision === "REJECT" ? "bad" : "warn"), document.createTextNode(existing.reason));
    wrap.append(p);
    if(existing.carried_forward)wrap.append(el('p','Retained from an earlier analysis of this exact source and research question.','hint'));
  }
  if (recorded) {
    if (!existing) wrap.append(el("p", "Reviews can be recorded in the local application.", "hint"));
    return wrap;
  }
  const d = el("details");
  d.append(el("summary", existing ? "Change review" : "Record your judgement"));
  const fs = el("fieldset");
  fs.append(el("legend", question));
  const name = `review-${kind}-${id}`.replace(/[^\w-]/g, "_");
  for (const [value, label] of [["ACCEPT", "Accept"], ["REJECT", "Reject"], ["INSUFFICIENT_INFORMATION", "Can't tell"]]) {
    const l = el("label", undefined, "choice");
    const r = el("input");
    r.type = "radio";
    r.name = name;
    r.value = value;
    r.checked = existing?.decision === value;
    l.append(r, document.createTextNode(label));
    fs.append(l);
  }
  const reasonLabel = el("label", "Reason (kept with exports)");
  const reason = el("input");
  reason.type = "text";
  reason.maxLength = 1000;
  reason.value = existing?.reason || "";
  reasonLabel.append(reason);
  const save = el("button", "Save review");
  save.type = "button";
  save.addEventListener("click", async () => {
    const decision = fs.querySelector("input:checked")?.value;
    if (!decision || reason.value.trim().length < 3) {
      status("Choose a decision and give a short reason.", true);
      return;
    }
    save.disabled = true;
    const reviewRunId=data.run_id;
    try {
      const r = await api(`/api/analyses/${reviewRunId}/reviews`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ target_kind: kind, target_id: id, decision, reason: reason.value.trim() }) });
      if(data?.run_id!==reviewRunId)return;
      data.researcher_reviews = r.reviews;
      data.research_brief = r.research_brief;
      status("Review saved. It is stored apart from the automated output.");
      renderInspector();
    } catch (error) {
      status(error.message, true);
      save.disabled = false;
    }
  });
  fs.append(reasonLabel, save);
  d.append(fs);
  wrap.append(d);
  return wrap;
}
function renderReviews() {
  const box = $("#reviews");
  box.replaceChildren();
  const reviews = data.researcher_reviews || [];
  if (!reviews.length) box.append(el("p", "No judgements recorded for this analysis yet. Record them from the Identity and Evidence tabs.", "empty"));
  for (const r of reviews) {
    const row = el("div", undefined, "review-row");
    const target = r.target_kind === "identity" ? `Identity: “${r.target_id.split("::")[0]}” → ${taxonName(r.target_id.split("::")[1])}` : `Evidence: ${cleanTitle(data.evidence.find((e) => e.id === r.target_id)?.paper.title) || r.target_id}`;
    const left = el("div");
    left.append(pill(human(r.decision), r.decision === "ACCEPT" ? "ok" : r.decision === "REJECT" ? "bad" : "warn"), el("strong", target), el("p", r.reason, "hint"), el("p", `${r.reviewer} · ${r.created_at.slice(0, 16).replace("T", " ")} UTC`, "hint"));
    if(r.carried_forward)left.append(el('p','Retained from your earlier analysis of the same source and target.','hint'));
    row.append(left);
    if (!recorded) {
      const del = el("button", "Remove judgement", "quiet");
      del.title='Remove this judgement for the same source and target across evidence rankings.';
      del.type = "button";
      del.addEventListener("click", async () => {
        const reviewRunId=data.run_id;
        try {
          const res = await api(`/api/analyses/${reviewRunId}/reviews/${r.target_kind}/${encodeURIComponent(r.target_id)}`, { method: "DELETE" });
          if(data?.run_id!==reviewRunId)return;
          data.researcher_reviews = res.reviews;
          data.research_brief = res.research_brief;
          renderInspector();
        } catch (error) {
          status(error.message, true);
        }
      });
      row.append(del);
    }
    box.append(row);
  }
  const x = $("#export-links");
  x.replaceChildren();
  for (const [f, label] of [["brief", "Research brief (Markdown)"], ["json", "Full record (JSON)"], ["csv", "Evidence table (CSV)"], ["bibtex", "Citations (BibTeX)"], ["graph", "Graph (JSON)"]]) {
    const a = el("a", label);
    a.href = `/api/exports/${data.run_id}?format=${f}`;
    a.setAttribute("download", "");
    const sourceTitle=data.source.title,runId=data.run_id;
    a.addEventListener('click',async event=>{
      event.preventDefault();
      try{const response=await fetch(a.href);if(!response.ok)throw new Error('Export is unavailable');const text=await response.text();const extension={brief:'md',json:'json',csv:'csv',bibtex:'bib',graph:'json'}[f];offerExport(text,'foliatrace-'+runId+'.'+extension,response.headers.get('Content-Type')||'text/plain;charset=utf-8',label+' · '+sourceTitle);}
      catch(error){status(error.message,true);}
    });
    x.append(a);
  }
}

/* ---------- Graph ---------- */
const colors = {
  HistoricalSource: "#e3cc9c",
  PlantMention: "#efe0bd",
  HistoricalClaim: "#f1e6d0",
  Condition: "#eedcae",
  PlantPart: "#efe6cf",
  Preparation: "#efe6cf",
  Route: "#efe6cf",
  ModernTaxon: "#c4dfc6",
  ModernHypothesis: "#dbe8d8",
  Publication: "#c6d7ea",
  Compound: "#dad0ea",
  SafetySignal: "#f1cfc8",
};
function svgEl(tag, attrs = {}) {
  const e = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  return e;
}
function inspect(value, title = "Source provenance") {
  const box = $("#inspector");
  box.replaceChildren(el("h3", title));
  if (value.url || value.paper?.url) box.append(link("Original source ↗", value.url || value.paper.url));
  box.append(el("pre", JSON.stringify(value, null, 2)));
}
async function renderGraph() {
  if (!data) return;
  const legend = $("#legend");
  legend.replaceChildren();
  for (const [k, c] of Object.entries(colors).filter(([k]) => data.graph.nodes.some((n) => n.kind === k))) {
    const s = el("span");
    const i = el("i");
    i.style.background = c;
    s.append(i, document.createTextNode(k.replace(/([a-z])([A-Z])/g, "$1 $2")));
    legend.append(s);
  }
  const params = new URLSearchParams({ limit: "80" });
  if (graphFocus) params.set("focus", graphFocus);
  if ($("#edge-filter").value) params.set("predicate", $("#edge-filter").value);
  let g;
  try {
    g = await api(`/api/graph/${data.run_id}?${params}`);
  } catch (error) {
    status(error.message, true);
    return;
  }
  const svg = $("#graph");
  svg.replaceChildren();
  const nodes = g.nodes.slice(0, 45),
    ids = new Set(nodes.map((n) => n.id)),
    positions = new Map();
  [["HistoricalSource", "PlantMention"], ["HistoricalClaim", "Condition", "PlantPart", "Preparation", "Route"], ["ModernTaxon", "ModernHypothesis"], ["Publication", "Compound", "SafetySignal", "AssayMeasurement", "MolecularTarget"]].forEach((kinds, col) => {
    const ns = nodes.filter((n) => kinds.includes(n.kind));
    ns.forEach((n, i) => positions.set(n.id, [col * 235 + 14, 32 + i * Math.min(440 / Math.max(ns.length, 1), 70)]));
  });
  const edges = g.edges.filter((e) => ids.has(e.subject) && ids.has(e.object));
  for (const edge of edges) {
    const a = positions.get(edge.subject),
      b = positions.get(edge.object);
    if (!a || !b) continue;
    const line = svgEl("line", { x1: a[0] + 88, y1: a[1] + 18, x2: b[0] + 88, y2: b[1] + 18, tabindex: "0", role: "button", "aria-label": human(edge.predicate) + "; inspect source" }),
      action = () => inspect(edge.provenance, human(edge.predicate));
    line.addEventListener("click", action);
    line.addEventListener("keydown", (event) => {
      if (["Enter", " "].includes(event.key)) {
        event.preventDefault();
        action();
      }
    });
    svg.append(line);
  }
  for (const n of nodes) {
    const pos = positions.get(n.id);
    if (!pos) continue;
    const node = svgEl("g", { class: "node", tabindex: "0", role: "button", "aria-label": n.kind + ": " + n.label });
    node.append(svgEl("rect", { x: pos[0], y: pos[1], width: 180, height: 37, rx: 5, fill: colors[n.kind] || "#e5e5e5" }));
    const text = svgEl("text", { x: pos[0] + 8, y: pos[1] + 23 });
    text.textContent = n.label.slice(0, 25) + (n.label.length > 25 ? "…" : "");
    node.append(text);
    const action = () => {
      graphFocus = n.id;
      inspect(n, n.kind);
      renderGraph();
    };
    node.addEventListener("click", action);
    node.addEventListener("keydown", (event) => {
      if (["Enter", " "].includes(event.key)) {
        event.preventDefault();
        action();
      }
    });
    svg.append(node);
  }
  const list = $("#graph-list");
  list.replaceChildren(el("p", `Showing ${nodes.length} nodes and ${edges.length} lines from a bounded neighbourhood.`, "hint"));
  for (const edge of g.edges) {
    const b = el("button", `${edge.subject} — ${human(edge.predicate)} — ${edge.object}`);
    b.type = "button";
    b.addEventListener("click", () => inspect(edge.provenance, human(edge.predicate)));
    list.append(b);
  }
}
function setupGraphFilter() {
  const ef = $("#edge-filter");
  ef.replaceChildren(option("", "All relations"));
  for (const p of [...new Set(data.graph.edges.map((e) => e.predicate))].sort()) ef.append(option(p, human(p)));
}

/* ---------- Evaluation ---------- */
const TIER = {
  SOURCE_ASSERTED_REFERENCE: ["warn", "Historical author's own Latin name; not expert gold"],
  EXTERNAL_HUMAN_GOLD: ["ok", "Published human labels for a narrow clinical task"],
  SILVER: ["neutral", "Database-derived labels"],
  SILVER_SOURCE_RECORDS: ["neutral", "Consistency with stored source records"],
  WEAK: ["neutral", "Weak labels from title matching or headings"],
  SYNTHETIC: ["neutral", "Constructed perturbations"],
  BEHAVIOURAL_COUNT: ["neutral", "Counts of system behaviour, not accuracy"],
};
function productEvaluation(report, known, books, outside) {
  const section = el("section", undefined, "metric-group");
  const c = report.coverage, t = report.identity_transfer, s = report.statement_audit;
  section.append(el("h3", "Whole-product measurements"), el("p", report.scope, "hint"));
  const wrap = el("div", undefined, "table-wrap"), table = el("table"), head = el("tr");
  head.append(el("th", "Measure"), el("th", "Result"));
  table.append(head);
  const rows = [
    ["Chapters whose plant has a modern candidate", `${c.chapters.subject_resolved} of ${c.chapters.total}`],
    ["Chapters whose plant reaches modern papers", `${c.chapters.subject_has_papers} of ${c.chapters.total}`],
    ["Chapters whose plant reaches a species-named human study", `${c.chapters.subject_has_human_study} of ${c.chapters.total}`],
    ["Author-asserted identity references: selected Latin clue masked, chapter context retained (development rerun)", `${(100 * t.without_historical_lexicon.top1_of_all).toFixed(1)}% without the lexicon, ${(100 * t.with_historical_lexicon.top1_of_all).toFixed(1)}% with it; common-name lookup baseline ${(100 * t.baseline_gbif_vernacular.top1_of_all).toFixed(1)}%. This is not expert gold, a name-only test, or a mask of every scientific name in the chapter.`],
    ["Identity recovery at genus level (first answer)", `${(100 * t.with_historical_lexicon.genus_top1_of_all).toFixed(1)}%`],
    ["Outside texts, development panel: plants recovered", `${report.external_texts_final.plants_found} of ${report.external_texts_final.plants_expected} across ${report.external_texts_final.passages} passages`],
  ];
  if (known?.by_split?.held_out) {
    const h = known.by_split.held_out;
    rows.push([`Known plant and topic findings, held-out pairs (n = ${h.pairs})`, `human study found ${(100 * h.found_human_study).toFixed(0)}%, direction compatible ${(100 * h.compatible).toFixed(0)}%, opposite ${(100 * h.opposite).toFixed(0)}%`]);
  }
  const blind = known?.blind_cochrane_first_run, again = known?.blind_cochrane;
  if (blind) rows.push([`Cochrane conclusions, one blind run with each review hidden (n = ${blind.pairs})`, `human study found ${(100 * blind.found_human_study).toFixed(0)}%, direction compatible ${(100 * blind.compatible).toFixed(0)}%, exact ${(100 * blind.exact).toFixed(0)}%, opposite ${(100 * blind.opposite).toFixed(0)}%${again ? `; after the fix it prompted, no longer blind: exact ${(100 * again.exact).toFixed(0)}%, opposite ${(100 * again.opposite).toFixed(0)}%` : ""}`]);
  const records = outside?.independent_records;
  if (records) rows.push([`Duke database concordance on the displayed map cohort (${records.pairs_read_as_use} pairs; not held out)`, `${(100 * records.agreement_read_as_use).toFixed(1)}%, against ${(100 * records.agreement_shuffled_mean).toFixed(1)}% shuffled (permutation p ${records.permutation_p <= 0.0001 ? "< 0.001" : "= " + records.permutation_p}); context-only diagnostic ${typeof records.agreement_read_as_context_only === 'number' ? (100 * records.agreement_read_as_context_only).toFixed(1) + '%' : 'not measured'}. Duke also informs candidate ranking.`]);
  const committee = outside?.regulator_agreement;
  if (committee) rows.push([`EU herbal committee: does the reading separate well-established from traditional use? (${committee.pairs} pairs, labels read from monographs by rule)`, `AUC ${committee.auc} (95% interval ${committee.auc_95_interval.join(" to ")}), human study found ${(100 * committee.well_established_human_study_found).toFixed(0)}% against ${(100 * committee.traditional_human_study_found).toFixed(0)}%. The one blind run gave AUC ${committee.first_blind_run.auc}; the later figure follows fixes it prompted`]);
  const folk = outside?.folklore_blind;
  if (folk) rows.push([`Folklore never opened during development, Folkard 1884 (${folk.entries} entries, one blind run)`, `plant found ${(100 * folk.heading_plant_found).toFixed(0)}%; ${(100 * folk.agreement).toFixed(1)}% of ${folk.pairs} use pairs are in Duke's records against ${(100 * folk.agreement_shuffled_mean).toFixed(1)}% shuffled`]);
  if (outside?.independent_records?.constituent_signal) { const signals = outside.independent_records; rows.push(["Descriptive checks of ranking inputs against Duke records", `related species ${signals.related_species_signal.observed} against ${signals.related_species_signal.shuffled_mean} shuffled; constituents ${signals.constituent_signal.observed} against ${signals.constituent_signal.shuffled_mean}. These checks involve data also used by ranking; they are not held-out validation. Constituents carry no priority weight.`]); }
  const review = outside?.expert_review;
  if (review) rows.push([`Human expert review: ${review.reviewer}`, `use statements ${(100 * review.use_statements.agreement).toFixed(0)}% (kappa ${review.use_statements.cohen_kappa}), plant identity ${(100 * review.plant_identity.agreement).toFixed(0)}%, study direction ${(100 * review.study_direction.agreement).toFixed(0)}%`]);
  const hausa = books?.tiers?.blind_round3?.["dalziel-1916-hausa"];
  if (hausa) rows.push([`Language no rule was tuned on, Hausa vocabulary: species found (n = ${hausa.as_printed.entries}, one blind run)`, `as printed ${(100 * hausa.as_printed.reference_among_candidates).toFixed(0)}%; from the Hausa name alone ${(100 * hausa.latin_names_hidden.reference_among_candidates).toFixed(0)}%, because no open list holds most of these names`]);
  const revisited = books?.tiers?.revisited_after_blind || {};
  for (const [label, book] of Object.entries(books?.tiers?.blind || {})) {
    const hidden = revisited[label]?.latin_names_hidden;
    rows.push([`Book not used in development, ${label}: species found (n = ${book.as_printed.entries})`, `as printed ${(100 * book.as_printed.reference_among_candidates).toFixed(0)}% on the first blind run${hidden ? `; Latin names hidden ${(100 * hidden.reference_among_candidates).toFixed(0)}% on a later rerun, no longer blind` : ""}`]);
  }
  for (const [tier, label, unit] of [["blind_round4", "Waring 1897, India: twelve Indian languages per entry", "Indian names"], ["blind_round5", "Flora of the Sudan 1929: the Arabic name selected by the reader", "the Arabic name"], ["blind_round6", "Henkel 1906, United States: English common names", "common names"]]) {
    const first = Object.values(books?.tiers?.[tier] || {})[0];
    const later = Object.values(books?.tiers?.[tier.replace("blind", "revisited")] || {})[0];
    if (first) rows.push([`Book never opened before its run, ${label} (n = ${first.as_printed.entries})`, `species found as printed ${(100 * first.as_printed.reference_among_candidates).toFixed(0)}%; from ${unit} alone ${(100 * first.latin_names_hidden.reference_among_candidates).toFixed(0)}% on the one blind run${later ? `, ${(100 * later.latin_names_hidden.reference_among_candidates).toFixed(0)}% after its misses were fixed (no longer blind)` : ""}`]);
  }
  const foresightReport = outside?.lead_foresight;
  const foresight = foresightReport?.protocol_version === 'SOURCE_ONLY_ALL_HUMAN_STUDIES_V2' ? foresightReport.cutoffs?.["2010"] : null;
  if (foresight) {
    const benefit = foresight.benefit_reported_after;
    const interval = Array.isArray(benefit.auc_95_interval) ? benefit.auc_95_interval.join(' to ') : 'not estimable';
    const percent = value => value == null ? 'not estimable' : (100*value).toFixed(0)+'%';
    rows.push([`Retrospective source-only ranking: dated historical support, no retrieved human study dated before 2010 (n = ${foresight.eligible_pairs}); all retrieved human studies checked`, `top tenth: ${percent(benefit.top_decile_rate)} later had a retrieved human study reporting benefit, against ${percent(benefit.overall_rate)} overall; AUC ${benefit.auc_history_score ?? 'not estimable'} (95% interval ${interval}), ${benefit.auc_history_within_publication_bands ?? 'not estimable'} within bands of retrieved prior publication volume (permutation p ${benefit.permutation_p_within_bands ?? 'not estimable'}). Retrieved prior publication volume alone gives ${benefit.auc_prior_publications_only ?? 'not estimable'}. No retrieved earlier study does not prove a use was never tested. Retrospective association, not prospective validation or proof of benefit.`]);
  }
  const firstTemporal = foresightReport?.first_run?.cutoffs?.['2010']?.benefit_reported_after;
  if(firstTemporal)rows.push(['Superseded exploratory temporal result, retained for audit',`Original AUC ${firstTemporal.auc_history_score}. Its eligibility used the six-study display subset, and auxiliary historical features were not filtered by publication date. It is not the current validation result.`]);
  const pasted = outside?.free_text_blind;
  if (pasted) {
    const [first, current] = [pasted.first_run, pasted.current];
    const share = ([hit, total]) => `${hit} of ${total}`;
    rows.push([`Text a reviewer pastes in, round 8: ${pasted.texts} short texts in Albanian, Bulgarian, Turkish, Portuguese, Romanian, Spanish, Croatian, 1850s German, 1650s English and Balkan field notes; answers written before the run`, `one blind run: right plant leads for ${share(first.names_leading)} names, use read for ${share(first.uses)}, ${first.other_leading_names.length} words wrongly read as plants. After the fixes it prompted (a development figure): ${share(current.names_leading)}, ${share(current.uses)}, ${current.other_leading_names.length} wrong`]);
  }
  const fresh = outside?.free_text_blind_round9;
  if (fresh) {
    const [first, current] = [fresh.first_run, fresh.current];
    const share = ([hit, total]) => `${hit} of ${total}`;
    const later = JSON.stringify(current.names_leading) !== JSON.stringify(first.names_leading) || JSON.stringify(current.uses) !== JSON.stringify(first.uses) ? ` After later fixes (a development figure): ${share(current.names_leading)}, ${share(current.uses)}, ${current.other_leading_names.length} wrong` : "";
    rows.push([`Round 9, new languages after the round 8 fixes: ${fresh.texts} texts in Macedonian, Slovenian, Italian, French, Polish, Hungarian, Greek, Czech, Dutch, Serbian, Albanian local names in English field notes, and 1597 English; answers written before the run`, `one blind run: right plant leads for ${share(first.names_leading)} names, use read for ${share(first.uses)}, ${first.other_leading_names.length} words wrongly read as plants.${later}`]);
  }
  const tenth = outside?.free_text_blind_round10;
  if (tenth?.first_run) {
    const [first, current] = [tenth.first_run, tenth.current];
    const share = ([hit, total]) => `${hit} of ${total}`;
    const later = JSON.stringify(current.names_leading) !== JSON.stringify(first.names_leading) || JSON.stringify(current.uses) !== JSON.stringify(first.uses) ? ` After later fixes (a development figure): ${share(current.names_leading)}, ${share(current.uses)}, ${current.other_leading_names.length} wrong` : "";
    rows.push([`Round 10, written before any of its texts was run: ${tenth.texts} texts in Kosovo Albanian, Macedonian, Serbian Cyrillic, Slovenian, Polish, Hungarian, German, Italian, English field notes, 1700s English, Spanish, Turkish, Greek and Romanian`, `one blind run: right plant leads for ${share(first.names_leading)} names, use read for ${share(first.uses)}, ${first.other_leading_names.length} words wrongly read as plants.${later}`]);
  }
  if (s) rows.push(["Statement screen, held-out sample (single AI annotator)", `use precision ${(100 * s.use_precision).toFixed(1)}%, use recall ${(100 * s.use_recall).toFixed(1)}%, topic ${(100 * s.topic_correct).toFixed(0)}%, plant name ${(100 * s.plant_name_correct).toFixed(0)}%, n = ${s.n}`]);
  const audit = outside?.book_statement_audit;
  if (audit) rows.push(["Statement screen on outside books (single AI annotator)", `use precision ${(100 * audit.precision).toFixed(1)}%, estimated recall ${(100 * audit.recall_estimated).toFixed(0)}%, plant name ${(100 * audit.plant_name_correct).toFixed(0)}%, n = 60`]);
  for (const [label, value] of rows) { const tr = el("tr"); tr.append(el("td", label), el("td", value)); table.append(tr); }
  wrap.append(table);
  section.append(wrap);
  return section;
}
function languageName(code) {
  try { return new Intl.DisplayNames(["en"], { type: "language" }).of(code) || code; } catch { return code; }
}
async function loadMetrics() {
  const box = $("#metrics");
  try {
    const m = await benchmarks();
    if (m.product_evaluation) box.append(productEvaluation(m.product_evaluation, m.known_answers, m.unseen_books, m));
    if (m.retrieval_external) {
      const r = m.retrieval_external, section = el('section', undefined, 'metric-group retrieval-metric');
      section.append(el('h3', 'Independent biomedical retrieval benchmark'), el('p', `SciFact: ${r.documents} abstracts, ${r.queries} claims with published human evidence labels. Both supporting and contradicting papers count as relevant.`, 'hint'));
      const wrap = el('div', undefined, 'table-wrap'), table = el('table'), head = el('tr');
      head.append(el('th', 'Method'), el('th', 'Recall@5'), el('th', 'Recall@10'), el('th', 'nDCG@10'), el('th', 'MRR@10'));
      table.append(head);
      for (const [method, values] of Object.entries(r.metrics)) {
        const row = el('tr');
        row.append(el('td', human(method)), ...['recall@5', 'recall@10', 'ndcg@10', 'mrr@10'].map((key) => el('td', values[key].toFixed(3))));
        table.append(row);
      }
      wrap.append(table);
      section.append(wrap, el('p', `Cluster-bootstrap 95% interval for reranking minus BM25 nDCG@10: ${r.rerank_minus_bm25_ndcg10_cluster_bootstrap.interval95.map((n) => n.toFixed(3)).join(' to ')}. ${r.scope}`, 'hint'));
      box.append(section);
    }
    if (m.outcome_model) {
      const learned = el("section", undefined, "metric-group outcome-metric");
      learned.append(el("h3", "Supervised outcome direction"), el("p", `Published human annotations · ${m.outcome_model.test_articles} disjoint test articles · ${m.outcome_model.test.selected_supervised.n} prompts. Given the annotated evidence and comparison; not end-to-end extraction.`, "hint"));
      const wrap = el("div", undefined, "table-wrap"), table = el("table"), head = el("tr");
      head.append(el("th", "Method"), el("th", "Macro-F1"), el("th", "Accuracy, all"), el("th", "Accuracy, answered"), el("th", "Coverage"));
      table.append(head);
      for (const [method, values] of Object.entries(m.outcome_model.test)) {
        const tr = el("tr");
        tr.append(el("td", human(method)), el("td", values.macro_f1.toFixed(3)), el("td", (100 * values.accuracy).toFixed(1) + "%"), el("td", values.accuracy_when_answered == null ? '—' : (100 * values.accuracy_when_answered).toFixed(1) + "%"), el("td", (100 * values.coverage).toFixed(1) + "%"));
        table.append(tr);
      }
      wrap.append(table);
      learned.append(wrap, el("p", `Article-bootstrap 95% interval for macro-F1 gain over lexical rules: ${m.outcome_model.delta_macro_f1_vs_lexical_article_bootstrap_95.map((n) => n.toFixed(3)).join(" to ")}. Validation-only parameter selection. Rules answer fewer questions but are more accurate on those they answer; the learned model's broader coverage is not higher conditional precision.`, "hint"));
      // Keep the main historical-identity results first in the page.
      box.append(learned);
    }
    if (m.status === "NOT_RUN") {
      box.append(el("p", "The benchmark has not been run. No score is asserted.", "empty"));
      return;
    }
    // Group by task and tier: one task can have rows from different label tiers and sample sizes.
    const groups = new Map();
    const tiersOf = new Map();
    for (const row of m.summary ?? []) {
      const key = row.task + "\u0000" + row.tier;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(row);
      tiersOf.set(row.task, (tiersOf.get(row.task) || new Set()).add(row.tier));
    }
    // Lead with the identity results the tool exists for; the report's own order is chronological.
    const first = (task) => (task.startsWith("Historical identity transfer") ? 0 : 1);
    const archived = [...groups.values()].filter(rows => /Identity propagation|silver/i.test(rows[0].task + ' ' + rows[0].tier));
    const archive = el('details', undefined, 'metric-group');
    archive.append(el('summary', 'Archived component checks · earlier build'));
    archive.append(el('p', 'These frozen lookup and silver-label checks describe an earlier component snapshot. They do not measure the current product or expert-validated historical identification.', 'hint'));
    for (const rows of [...groups.values()].sort((a, b) => first(a[0].task) - first(b[0].task))) {
      const sec = el("section", undefined, "metric-group");
      const { task, tier } = rows[0];
      const [tone, meaning] = TIER[tier] || ["neutral", human(tier)];
      sec.append(el("h3", tiersOf.get(task).size > 1 ? `${task} · ${human(tier).toLowerCase()} cases` : task));
      const p = el("p", undefined, "hint");
      p.append(pill(human(tier), tone), document.createTextNode(meaning + ` · n = ${rows[0].n}`));
      sec.append(p);
      const wrap = el("div", undefined, "table-wrap"),
        table = el("table"),
        head = el("tr");
      head.append(el("th", "Method"), el("th", "Result"));
      table.append(head);
      for (const r of rows) {
        const tr = el("tr");
        tr.append(el("td", r.method), el("td", r.result));
        table.append(tr);
      }
      wrap.append(table);
      sec.append(wrap);
      (archived.includes(rows) ? archive : box).append(sec);
    }
    if (archived.length) box.append(archive);
    if (box.querySelector('.outcome-metric')) box.append(box.querySelector('.outcome-metric'));
    if (box.querySelector('.retrieval-metric')) box.append(box.querySelector('.retrieval-metric'));
    box.append(el("p", (m.limitations || []).join(" "), "hint"));
  } catch (error) {
    box.append(el("p", "Evaluation report unavailable: " + error.message, "empty"));
  }
}

/* ---------- Research map ---------- */
let evidenceMap = null, mapLimit = 40, mapScrollY = 0;
const openMapLeads = new Set();
const openMapSourceTrails = new Set();
function mapRows() {
  const query = $("#map-query").value.trim().toLowerCase(), state = $("#map-state").value, order = $("#map-order").value;
  const rows = evidenceMap.rows.filter((r) => (!state || r.state === state) && (!query || (r.taxon + " " + r.topic + " " + r.headings.join(" ")).toLowerCase().includes(query)));
  const key = { lead: (r) => [-r.lead_score, -r.historical_statements], places: (r) => [-(r.independent_use?.places || 0), -(r.independent_use?.records || 0)], statements: (r) => [-r.historical_statements, -r.human_studies], human: (r) => [-r.human_studies, -r.historical_statements] }[order];
  return rows.sort((a, b) => { const x = key(a), y = key(b); return x[0] - y[0] || x[1] - y[1]; });
}
function independentLine(reach) {
  if (!reach) return "";
  return `${plural(reach.records, "record")}${reach.places ? ", " + plural(reach.places, "place") : ""}`;
}
function independentCell(reach) {
  const cell = el("td");
  if (!reach) { cell.append(el("span", "—", "digest-meta")); return cell; }
  cell.append(link(independentLine(reach) + " ↗", reach.source.url));
  if (reach.place_names.length) cell.append(el("span", reach.place_names.slice(0, 4).join(", "), "digest-meta map-heading"));
  return cell;
}
const REGULATORY = { WELL_ESTABLISHED: "well-established use, which needs clinical evidence", TRADITIONAL: "traditional use, resting on long use rather than trials" };
function regulatoryLine(row) {
  return row ? `EMA herbal committee: ${REGULATORY[row.class]}` : "";
}
function nextQuestion(r) {
  if (r.direct_statements === 0) return `Resolve the source attribution first: these passages have an uncertain or shared plant subject. They do not raise the reading priority for ${r.taxon}.`;
  const noun = (r.preparations || []).find((p) => /^(?:infusion|decoction|tincture|syrup|tea|oil|poultice|ointment|juice|powder|extract|plaster|wash|gargle|lotion)$/.test(p));
  const prep = noun ? `${/^[aeiou]/.test(noun) ? "an" : "a"} ${noun} of ${r.taxon}` : r.taxon;
  const opening = r.recorded_poisonous ? `Establish safe exposure first: ${r.taxon} is recorded as poisonous. ` : "";
  const asks = {
    PRECLINICAL_ONLY: `Laboratory work exists but no human study was retrieved. Does ${prep} change ${r.topic} in a controlled human study?`,
    HUMAN_FINDINGS_EARLY: `Do larger controlled trials confirm the early findings for ${r.taxon} and ${r.topic}?`,
    HUMAN_FINDINGS_MIXED: `Which preparation, dose or population explains the disagreement for ${r.taxon} and ${r.topic}?`,
    HUMAN_NO_BENEFIT_REPORTED: `Was the preparation tested the one the sources describe? Reported benefit for ${r.topic} is absent, so ${prep} is the open question.`,
    HUMAN_FINDINGS_FAVOURABLE: `Does the tested preparation match the historical one, ${prep}?`,
  };
  return opening + (asks[r.state] || `No tested result was retrieved. Is there laboratory evidence that ${prep} acts on ${r.topic}?`);
}
function leadText(r) {
  const lines = [`${r.taxon}: ${r.topic}`, `Identity assumption: the map's primary candidate, not a confirmed historical identification.`, `Modern research: ${(RESEARCH_STATE[r.state] || [0, human(r.state)])[1]} (${r.human_studies} human, ${r.preclinical_studies} laboratory)`];
  if (r.priority_components) lines.push(`Reading priority ${r.lead_score}: ${r.direct_statements} eligible source statements; ${r.uncertain_statements} uncertain links add no weight.`, priorityExplanation(r));
  for (const q of r.statements || r.quotes || []) {
    lines.push(`${q.book}, ${sourceLabel(q.heading)}: "${q.text}"`);
    if(q.attribution) lines.push(`Source link: ${human(q.attribution)}; ${q.source_id}/${q.claim_id}; span ${q.statement.start}-${q.statement.end}; ${q.source_url}; ${q.licence}`);
    if(q.identity_candidates?.length>1) lines.push(`Candidate identities retained: ${q.identity_candidates.map(c=>c.name).join('; ')}.`);
  }
  const references=r.studies?.length?r.studies:r.best_study?[r.best_study]:[];
  if (r.assessment_basis) {
    lines.push(`Summary basis: ${human(r.assessment_basis.kind)}. ${r.assessment_basis.scope}`);
    for (const s of r.assessment_basis.records || []) lines.push(`Summary source: ${s.title} (${s.year || 'year unknown'}); ${s.paper_id}; ${s.direction}; ${s.url}`);
  }
  for(const study of references) {
    lines.push(`Research to read: ${study.title} (${study.year||'year unavailable'}). ${study.paper_id}; ${study.url}; ${(study.design||[]).join(', ')}; reported direction ${study.direction||'not stated'}; identity ${study.identity||'not established'}.`);
    for(const statement of study.finding_statements||[])lines.push(`Abstract finding (${statement.direction}; span ${statement.start}-${statement.end}): “${statement.supporting_text}”`);
  }
  if(r.combination_only)lines.push('Study scope: the listed studies use combinations; the findings do not isolate this plant.');
  if (r.independent_use) lines.push(`Recorded elsewhere: ${independentLine(r.independent_use)}: ${r.independent_use.place_names.join(", ")}. Dr. Duke's databases, ${r.independent_use.source.url}`);
  if (r.relatives) lines.push(`Related species with this use: ${r.relatives.names.join(", ")} (${plural(r.relatives.species, "species").replace("speciess", "species")}, ${plural(r.relatives.places, "place")})`);
  if (r.constituents) lines.push(`Constituents to inspect (no ranking weight): ${r.constituents.rarest.map((c) => `${c.chemical} (${c.activity})`).join(", ")}`);
  if (r.regulatory) lines.push(`${regulatoryLine(r.regulatory)}. ${r.regulatory.url}`);
  if (r.recorded_poisonous) lines.push("Safety: recorded as poisonous.");
  lines.push(`Next question: ${nextQuestion(r)}`, "A recorded use is not evidence that a treatment works.");
  return lines.join("\n");
}
function priorityExplanation(r) {
  const p=r.priority_components;
  return p?`(${p.source_statements} source statements + ${p.additional_books} additional-book points + ${p.independent_places} independent-place points + ${p.related_species} related-species points) × ${p.research_state_weight} research-state weight ÷ ${p.poison_divisor} safety divisor. Uncertain source links add zero.`:'Priority was calculated by an earlier build; its source attribution was not screened.';
}
async function openMapStatement(r,q) {
  if(!q?.statement){choosePassage(r.passages[0].id);showView('workspace');await analyze();return;}
  mapScrollY=window.scrollY;
  await openLibraryRecord({id:q.source_id+':'+q.claim_id,source_id:q.source_id,statement:q.statement},'map');
  if(data?.source.id!==q.source_id)return;
  const claim=data.historical_claims.find(c=>c.support.start===q.statement.start&&c.support.end===q.statement.end);
  const target=claim&&data.identity_counterfactuals.find(g=>g.claim_ids.includes(claim.id)&&g.branches.some(b=>b.taxon_id===r.taxon_id));
  if(target){statementReadingTargets.set(identityPairKey(target),claim.id);selectName(target.key);}
}
function leadRow(r, columns) {
  const row = el("tr", undefined, "lead-row"), cell = el("td"), box = el("div", undefined, "lead-brief");
  cell.colSpan = columns;
  const part = (title, ...content) => { const block = el("div"); block.append(el("h4", title), ...content); box.append(block); };
  if(r.priority_components) part('Why this lead is ranked here',el('p',`Reading priority ${r.lead_score} · ${r.direct_statements} eligible statements · ${r.uncertain_statements} uncertain links`),el('p',priorityExplanation(r),'hint'),el('p',`Assuming ${r.taxon}. Candidate identity remains conditional.`,'hint'));
  const sourceStatement = (q) => {
    const box=el('div'),quote=el("blockquote", q.text);
    quote.append(el("span", `${q.book}, ${sourceLabel(q.heading)}`, "digest-meta map-heading"));box.append(quote);
    if(q.attribution)box.append(pill(q.eligible_for_priority?(q.attribution==='EXPLICIT_SINGLE_PLANT'?'Plant named in this statement':'Single chapter subject'):'Uncertain subject · no priority weight',q.eligible_for_priority?'neutral':'warn'));
    if(q.identity_candidates?.length>1)box.append(el('p','Identity hypotheses: '+q.identity_candidates.map(c=>c.name).join(' · '),'hint'));
    if(q.statement){const read=el('button','Read this source statement →','text-action');read.type='button';read.addEventListener('click',()=>openMapStatement(r,q));box.append(read);}
    return box;
  };
  if (r.quotes?.length) part("From the books", ...r.quotes.map(sourceStatement));
  const shown=new Set((r.quotes||[]).map(q=>q.source_id+':'+q.claim_id));
  const remaining=(r.statements||[]).filter(q=>!shown.has(q.source_id+':'+q.claim_id));
  if(remaining.length){const more=el('details',undefined,'map-source-statements'),key=r.taxon_id+'::'+r.condition_id;more.open=openMapSourceTrails.has(key);more.addEventListener('toggle',()=>{more.open?openMapSourceTrails.add(key):openMapSourceTrails.delete(key);});more.append(el('summary',`${remaining.length} more source statement${remaining.length===1?'':'s'} behind this reading`),...remaining.map(sourceStatement));part('Complete source trail',more);}
  if (r.independent_use) part("Recorded elsewhere", el("p", `${independentLine(r.independent_use)}: ${r.independent_use.place_names.join(", ")}.`), el("p", `Recorded as ${r.independent_use.activities.join(", ")}.`, "digest-meta"));
  if (r.relatives) part("Related species", el("p", `${r.relatives.names.join(", ")}: ${r.relatives.species > 1 ? r.relatives.species + " species" : "1 species"} of this genus recorded for this use in ${plural(r.relatives.places, "place")}.`));
  if (r.constituents) part("Constituents", el("p", r.constituents.rarest.map((c) => `${c.chemical} (${c.activity.toLowerCase()})`).join(", ") + "."), el("p", `${plural(r.constituents.count, "distinctive chemical")} with a recorded activity, in any assay and dose. Random plant and topic pairs reach one about as often as real uses, so read this as chemistry to inspect, not as support.`, "digest-meta"));
  if (r.regulatory) { const line = el("p", regulatoryLine(r.regulatory) + " "); line.append(link("monograph ↗", r.regulatory.url)); part("Regulators", line, el("p", r.regulatory.indication, "digest-meta")); }
  const next = [el("p", nextQuestion(r))], copy = el("button", "Copy this lead", "quiet");
  copy.type = "button";
  copy.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(leadText(r)); copy.textContent = "Copied"; }
    catch { copy.textContent = "Copy failed"; }
  });
  part("Next question", ...next, copy);
  cell.append(box);
  row.append(cell);
  return row;
}
function renderEvidenceMap() {
  const rows = mapRows(), table = $("#map-table");
  $("#map-count").textContent = `${rows.length} plant and topic pairs`;
  const head = el("tr");
  for (const label of ["Plant", "Topic", "Historical record", "Recorded elsewhere", "Modern research", "Key study"]) head.append(el("th", label));
  table.replaceChildren(head);
  for (const r of rows.slice(0, mapLimit)) {
    const leadKey=r.taxon_id+'::'+r.condition_id;
    const tr = el("tr"), plant = el("td"), open = el("button", r.taxon, "text-action");
    open.type = "button";
    open.addEventListener("click", () => openMapStatement(r,r.quotes?.[0]));
    const more = el("button", "Open lead", "text-action lead-toggle");
    more.type = "button";
    more.setAttribute("aria-expanded", String(openMapLeads.has(leadKey)));
    plant.append(open, el("span", r.headings.slice(0, 2).map(sourceLabel).join(" · "), "digest-meta map-heading"), more);
    more.addEventListener("click", () => {
      const shown = tr.nextElementSibling?.classList.contains("lead-row");
      if (shown) tr.nextElementSibling.remove(); else tr.after(leadRow(r, 6));
      if(shown)openMapLeads.delete(leadKey);else openMapLeads.add(leadKey);
      more.setAttribute("aria-expanded", String(!shown));
      more.textContent = shown ? "Open lead" : "Close lead";
    });
    if (r.recorded_poisonous) plant.append(pill("Recorded as poisonous", "bad"));
    const [tone, label] = RESEARCH_STATE[r.state] || ["neutral", human(r.state)];
    const research = el("td");
    research.append(pill(label, tone));
    const counts = resultCounts(r);
    if (r.human_studies || r.preclinical_studies) research.append(el("span", ` ${r.human_studies} human · ${r.preclinical_studies} laboratory${counts ? " · " + counts : ""}${r.combination_only ? " · only with other ingredients" : ""}`, "digest-meta"));
    const best = el("td");
    if (r.studies?.length) best.append(studyList(r));
    else {
      const basis = assessmentBasis(r);
      if (basis) best.append(basis);
      if (r.best_study) { best.append(link(cleanTitle(r.best_study.title).slice(0, 90) + (r.best_study.title.length > 90 ? "…" : "") + " ↗", r.best_study.url)); if (r.best_study.year) best.append(el("span", " " + r.best_study.year, "digest-meta")); }
      else if (!basis) best.append(el("span", "—", "digest-meta"));
    }
    const historical=el('td',`${plural(r.historical_statements, "statement")} · ${r.books.length === 2 ? "both books" : r.books[0]}`);
    if(r.direct_statements!==undefined)historical.append(el('span',`${r.direct_statements} eligible · ${r.uncertain_statements} uncertain`,'digest-meta map-heading'));
    tr.append(plant, el("td", r.topic), historical, independentCell(r.independent_use), research, best);
    table.append(tr);
    if(openMapLeads.has(leadKey)){tr.after(leadRow(r,6));more.textContent='Close lead';}
  }
  $("#map-more").hidden = rows.length <= mapLimit;
}
function mapTemporalSummary(map, report) {
  const box=el('section',undefined,'hint map-foresight');
  box.append(el('h3','What this ranking has demonstrated'));
  const current=report?.protocol_version==='SOURCE_ONLY_ALL_HUMAN_STUDIES_V2'&&report.code_fingerprint===map.code_fingerprint&&report.snapshot_sha256===map.snapshot_sha256&&report.pairs_in_map===map.totals.pairs&&map.build_status!=='PREVIOUS_BUILD';
  const cohort=current?report.cutoffs?.['2010']:null,reading=cohort?.benefit_reported_after;
  if(!reading){box.append(el('p','A matching source-only retrospective evaluation is unavailable for this map. These priorities guide source reading; predictive performance is not established here.'));return box;}
  const metric=value=>Number.isFinite(value)?value.toFixed(3):'not estimable';
  box.append(el('p',`Retrospective 2010 split: ${cohort.eligible_pairs} attributable plant–use pairs with dated historical support and no earlier human study retrieved in this collection. Missing retrieval does not establish that a use was never tested.`));
  box.append(el('p',`Later retrieved human studies reporting benefit: history score AUC ${metric(reading.auc_history_score)}; prior-publication-count baseline AUC ${metric(reading.auc_prior_publications_only)}.`));
  if(Number.isFinite(reading.auc_history_score)&&Number.isFinite(reading.auc_prior_publications_only))box.append(el('p',reading.auc_history_score<=reading.auc_prior_publications_only?'The history score did not outperform the publication-count baseline in this analysis.':'The history score exceeded the publication-count baseline in this retrospective analysis; prospective performance has not been established.'));
  box.append(el('p','This source-only retrospective score differs from the displayed reading priority, which also considers research state and safety. It is not prospective validation, a treatment-effect estimate, or evidence that a lead works.'));
  return box;
}
let evidenceMapLoading;
function loadEvidenceMap() {
  if(!evidenceMapLoading)evidenceMapLoading=populateEvidenceMap().finally(()=>{evidenceMapLoading=null;});
  return evidenceMapLoading;
}
async function populateEvidenceMap() {
  if (!evidenceMap) {
    try { evidenceMap = await api("/api/research/evidence-map"); }
    catch (error) { $("#map-count").textContent = error.message; return; }
    const states = $("#map-state");
    for (const [key, value] of Object.entries(RESEARCH_STATE)) if (evidenceMap.counts[key]) states.append(option(key, `${value[1]} (${evidenceMap.counts[key]})`));
    const summary = $("#map-summary");
    if (evidenceMap.build_warning) summary.before(el('p', evidenceMap.build_warning, 'error'));
    for (const [number, label] of [[evidenceMap.totals.pairs, "plant and topic pairs"], [evidenceMap.totals.with_human_studies, "with human studies"], [evidenceMap.totals.leads, "research leads"], [evidenceMap.totals.plants, "plants"]]) { const tile = el("div", undefined, "map-tile"); tile.append(el("strong", number), el("span", label)); summary.append(tile); }
    const report=await benchmarks().then(result=>result.lead_foresight).catch(()=>null);
    summary.after(mapTemporalSummary(evidenceMap,report));
    for (const id of ["#map-query", "#map-state", "#map-order"]) $(id).addEventListener("input", () => { mapLimit = 40; renderEvidenceMap(); });
    $("#map-more").addEventListener("click", () => { mapLimit += 60; renderEvidenceMap(); });
  }
  renderEvidenceMap();
}

/* ---------- Analysis ---------- */
function render() {
  if(!$('#view-handoffs').hidden)handoffs.open();
  const groups = data.identity_counterfactuals;
  const manual=new Set(data.mentions.filter(m=>m.method==='RESEARCHER_SELECTED_NAME').map(m=>m.id));
  const announced=new Set(data.mentions.filter(m=>m.method==='SOURCE_HEADING_SUBJECT').map(m=>m.id));
  const preferred = groups.find(g=>g.mention_ids.some(id=>manual.has(id))) || groups.find(g=>g.branches.length&&g.mention_ids.some(id=>announced.has(id))) || groups.find((g) => g.branches.length > 1 || g.open_world.length) || groups.find((g) => g.branches.length) || groups[0];
  selected = preferred?.key ?? null;
  renderSource();
  renderNames();
  renderInspector();
  renderClaims();
  setupGraphFilter();
  graphFocus = null;
  if (!$("#view-graph").hidden) renderGraph();
  $("#limitations").replaceChildren(...data.limitations.map((x) => el("li", x)));
  $("#run-info").textContent = `Run ${data.run_id} · pipeline ${data.pipeline_version} · ${data.performance.latency_ms} ms${data.cache_hit ? " · cached" : ""}`;
  $('#run-info').textContent='Local research workspace';
  for (const b of document.querySelectorAll(".case")) b.setAttribute("aria-pressed", String(!custom && b.dataset.passage === $("#passage").value));
}
async function analyze(options={}) {
  const b = $("#analyze"),serial=++analysisSerial;
  b.disabled = true;
  status(recorded ? "Loading the recorded pipeline output…" : "Extracting names, building identity branches and screening evidence…");
  try {
    const request=custom?{text:$('#input').value,retrieval:$('#analysis-ranking').value}:{passage_id:$('#passage').value,retrieval:$('#analysis-ranking').value};
    request.name_to_inspect=requestedSourceName;
    const result = await api("/api/analyses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    });
    if(serial!==analysisSerial)return;
    if(libraryFocus){const span=libraryFocus.statement;if(libraryFocus.source_id!==result.source.id||Array.from(result.input).slice(span.start,span.end).join('')!==span.text){libraryFocus=null;sourceEvidenceFocus=null;}}
    data=result;
    data.researcher_reviews ||= [];
    render();
    showTab("tab-identity");
    readingResumeActive=options.remember!==false;
    rememberReading();
    const onDemand=data.literature_access?.plants_read_on_demand?.length||0,offline=data.literature_access?.status==='NETWORK_UNAVAILABLE';
    status(new Set(data.evidence.map(e=>e.paper.id)).size+' publications connected to '+plural(data.identity_counterfactuals.length,'plant name')+(data.language&&data.language!=='en'?' · source language: '+languageName(data.language):'')+(onDemand?' · '+plural(onDemand,'plant')+' read from PubMed just now':'')+(offline?' · offline: plants outside the snapshot could not be looked up':'')+'.');
    return result;
  } catch (error) {
    if(serial===analysisSerial)status(error.message, true);
  } finally {
    if(serial===analysisSerial)b.disabled = false;
  }
}
function invalidatePendingAnalysis() {
  analysisSerial++;
  $('#analyze').disabled=false;
  status('Input changed. Analyze to read this version; the previous analysis is still shown.');
}
function choosePassage(id) {
  invalidatePendingAnalysis();
  requestedSourceName=null;
  $("#passage").value = id;
  const p = passages.find((x) => x.id === id);
  if (p) {
    $("#input").value = p.title + "\n\n" + p.text;
    custom = false;
  }
}
let searchSerial=0;
async function search() {
  const q = $("#search").value.trim();
  const serial=++searchSerial;
  if (q.length < 2) return;
  const box = $("#search-results");
  try {
    const r = await api("/api/search?" + new URLSearchParams({ q }));
    if(serial!==searchSerial||q!==$('#search').value.trim())return;
    box.replaceChildren(el("p", `${r.results.length} results (at most 100)`, "hint"));
    const kinds = { HistoricalSource: "Historical section", ModernTaxon: "Modern taxon", Publication: "Publication", Compound: "Compound" };
    for (const item of r.results) {
      if (item.kind === "HistoricalSource" && passages.some((p) => p.id === item.id)) {
        const b = el("button", undefined, "result");
        b.type = "button";
        b.append(pill(kinds[item.kind]), document.createTextNode(item.label));
        b.addEventListener("click", () => {
          choosePassage(item.id);
          analyze();
        });
        box.append(b);
      } else {
        const row = el("div", undefined, "result");
        row.append(pill(kinds[item.kind] || item.kind), link(cleanTitle(item.label), item.url));
        box.append(row);
      }
    }
  } catch (error) {
    if(serial===searchSerial&&q===$('#search').value.trim())status(error.message, true);
  }
}
function renderCases() {
  const box = $("#cases");
  box.replaceChildren();
  for (const [title, label, why, settings={}] of CASES) {
    const p = passages.find((x) => x.title === title&&(settings.collection===undefined||Boolean(x.collection)===settings.collection));
    if (!p) continue;
    const b = el("button", label, "case");
    b.type = "button";
    b.dataset.passage = p.id;
    b.setAttribute("aria-pressed", "false");
    b.append(el("small", why));
    b.addEventListener("click", async () => {
      showView('workspace');libraryFocus=null;sourceEvidenceFocus=null;
      choosePassage(p.id);
      const result=await analyze();
      if(result?.source.id===p.id&&settings.sourceStudy&&!openSourceStudyReading(settings.sourceStudy))status('This analysis has no active matching study link. Read the source and available studies instead.',true);
    });
    box.append(b);
  }
}

$("#analyze").addEventListener("click", analyze);
$('#inspect-source-name-form').addEventListener('submit',async event=>{
  event.preventDefault();const button=$('#inspect-source-name-form button[type="submit"]'),previous=requestedSourceName;
  requestedSourceName=$('#source-name-input').value.trim();button.disabled=true;
  $('#source-name-state').textContent='Finding the exact wording in this source…';
  try{const pending=analyze(),serial=analysisSerial,result=await pending;if(!result&&serial===analysisSerial){requestedSourceName=previous;$('#source-name-state').textContent='Could not inspect this name. Check the source spelling and the message above.';}}
  finally{button.disabled=false;}
});
$('#source-name-reset').addEventListener('click',()=>{requestedSourceName=null;analyze();});
$("#passage").addEventListener("change", () => choosePassage($("#passage").value));
$("#input").addEventListener("input", () => {
  invalidatePendingAnalysis();
  custom = true;
  requestedSourceName=null;
});
$('#analysis-ranking').addEventListener('change',invalidatePendingAnalysis);
$('#search').addEventListener('input',()=>{searchSerial++;$('#search-results').replaceChildren();});
$("#search-button").addEventListener("click", search);
$("#search").addEventListener("keydown", (e) => {
  if (e.key === "Enter") search();
});
for (const id of ["branch", "study-type", "relation", "year"]) $("#" + id).addEventListener("change", () => data && renderEvidence());
$("#edge-filter").addEventListener("change", renderGraph);
$("#graph-reset").addEventListener("click", () => {
  graphFocus = null;
  renderGraph();
});
for (const b of document.querySelectorAll(".view-tab")) b.addEventListener("click", () => showView(b.dataset.view));
const tabs = [...document.querySelectorAll('[role="tab"]')];
for (const t of tabs) {
  t.addEventListener("click", () => showTab(t.id));
  t.addEventListener("keydown", (e) => {
    const i = tabs.indexOf(t);
    const next = e.key === "ArrowRight" ? tabs[(i + 1) % tabs.length] : e.key === "ArrowLeft" ? tabs[(i - 1 + tabs.length) % tabs.length] : e.key === "Home" ? tabs[0] : e.key === "End" ? tabs.at(-1) : null;
    if (next) {
      e.preventDefault();
      showTab(next.id, true);
    }
  });
}
$("#text-file").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const form = new FormData();
  form.append("file", file);
  const serial=++analysisSerial;
  try {
    const result = await api("/api/uploads/text", { method: "POST", body: form });
    if(serial!==analysisSerial)return;
    data=result;
    libraryFocus=null;sourceEvidenceFocus=null;
    requestedSourceName=null;
    data.researcher_reviews ||= [];
    custom = true;
    $("#input").value = data.input;
    render();
    readingResumeActive=true;rememberReading();
    status("Uploaded text analysed. Its historical provenance is not verified.");
  } catch (error) {
    if(serial===analysisSerial)status(error.message, true);
  } finally {
    if(serial===analysisSerial)$('#analyze').disabled=false;
  }
});
const handoffs=initHandoffs({getAnalysis:()=>recorded?null:data,api,el,link,showView});
const questionReview=initQuestionReview({api,el,link,onAttach:(context,reviewId)=>consultation.attach(context,reviewId),onReturn:async()=>{await showView('consultation');consultation.focusSaved();}});
const consultation=initConsultation({api,el,link,isOffline:()=>health?.offline!==false,openQuestion:initial=>showView('question',initial)});
$('#care-start-own').addEventListener('click',()=>{const editor=$('#consultation-editor');editor.open=true;const input=editor.querySelector('[name="product_name"]');input?.scrollIntoView({block:'center',behavior:'smooth'});input?.focus({preventScroll:true});});
$('#start-source-check').addEventListener('click',()=>{showView('workspace');$('#custom-input').open=true;$('#input').focus();});
$('#open-evidence-handoffs').addEventListener('click',()=>showView('handoffs'));
async function init() {
  const requestedView=location.hash.slice(1);
  const initialView=['workspace','library','map','chemistry','graph','evaluation','handoffs','consultation','question'].includes(requestedView)?requestedView:(location.pathname.startsWith('/research')?'library':'consultation');
  try {
    // Draft entry does not wait for model, health or the historical library.
    const opening=showView(initialView);
    health = await api("/api/health");
    recorded = health.mode === "READ_ONLY_RECORDED_PIPELINE";
    const badge = $("#system-state");
    badge.textContent = recorded ? "Recorded outputs · read-only" : health.offline ? "Offline workspace" : "Local workspace";
    badge.className = "mode" + (recorded ? " recorded" : "");
    badge.title = recorded ? "These results were computed by the local pipeline and recorded. This page runs no new analysis." : `Snapshot: ${health.passages} historical sections, ${health.taxa} taxa, ${health.papers} literature records; ${health.abstracts_available ?? health.papers} abstracts available locally.`;
    if (recorded) {
      $("#analysis-ranking-label").hidden = true;
      $("#custom-input").hidden = true;
      $("#external-name-check").hidden = true;
      $('#inspect-source-name').hidden=true;
      $("#knowledge-search").hidden = false;
      $("#knowledge-method-label").hidden = true;
      $("#analyze").textContent = "Load record";
    }
    if (!recorded) {
      const semantic = Boolean(health.encoder_installed), reranking = semantic && Boolean(health.reranker_installed);
      for (const choice of $('#knowledge-method').options) if (choice.value !== 'bm25') choice.disabled = !semantic;
      $('#analysis-ranking').querySelector('option[value="rerank"]').disabled = !reranking;
      if (reranking) { $('#knowledge-method').append(option('rerank', 'Best match')); $('#knowledge-method').value='rerank'; }
      else $('#knowledge-method').value='bm25';
    }
    if (!recorded && health.abstracts_available < health.papers) {
      const availability = $('#literature-availability');
      availability.textContent = `${health.abstracts_available.toLocaleString()} abstracts available locally · additional records have citation metadata only`;
      availability.hidden = initialView==='consultation';
    }
    await opening;
    const saved=savedReading();let resumed=false,resumeError=null;
    if(saved&&!custom&&!['consultation','question'].includes(initialView)){try{resumed=await resumeReading(saved,{navigate:false,position:['workspace','graph'].includes(initialView)});}catch(error){resumeError=error.message;}}
    // A reader may have started typing while the collection was still loading.
    if(resumed===false&&!custom&&!['consultation','question'].includes(initialView)){
      const p=passages.find(p=>p.title===CASES[0][0])||passages[0];
      if(p){choosePassage(p.id);await analyze({remember:false});}
      if(!saved&&data&&['workspace','graph'].includes(initialView)){readingResumeActive=true;rememberReading();}
    }
    if(resumeError)status('Your saved analysis is unavailable here: '+resumeError+'. Choose a source to start a new reading.',true);
    updateResumeControl();
    // Research evaluation is loaded only when that view is opened.
  } catch (error) {
    status("Startup failed: " + error.message, true);
    $("#system-state").textContent = "Service unavailable";
    $("#system-state").className = "mode error";
  }
}
init();

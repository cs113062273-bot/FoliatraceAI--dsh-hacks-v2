const $=s=>document.querySelector(s);
fetch('product-metrics.json').then(r=>{if(!r.ok)throw Error();return r.json()}).then(metrics=>{for(const node of document.querySelectorAll('[data-metric]'))if(metrics[node.dataset.metric]!==undefined)node.textContent=metrics[node.dataset.metric];}).catch(()=>{});
const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
// Recorded pharmacist evidence examples and live on-device research search.
function sourceLink(text,url){const a=el('a',text);try{const u=new URL(url);if(!['https:','http:'].includes(u.protocol))throw Error();a.href=u.href;a.target='_blank';a.rel='noopener noreferrer';}catch{a.removeAttribute('href');}return a;}
const signalLabels={PASS:'Text signal found',PARTIAL:'Needs source reading',UNKNOWN:'Not established',FAIL:'Scope conflict'};
function quotes(parent,spans,licence){for(const span of spans){const block=el('blockquote',undefined,'source-quote');block.append(el('p','“'+span.text+'”'),sourceLink((span.source_kind||'Source')+' · characters '+span.start+'–'+span.end,span.url),el('p',span.licence||licence||'Rights remain with source','small'));parent.append(block);}}
function renderCase(c,data){for(const b of $('#case-tabs').children)b.setAttribute('aria-pressed',String(b.dataset.case===c.id));
 const box=$('#case-detail');box.replaceChildren();const top=el('div',undefined,'case-top'),question=el('div');question.append(el('h3',c.question));
 const metrics=el('div',undefined,'metrics');for(const [value,label] of [[c.overview.unique_publications,'unique publications found'],[c.overview.endpoint_publications,'with exact outcome wording'],[c.overview.human_trial_signals,'human-trial text signals']]){const m=el('div',undefined,'metric');m.append(el('strong',String(value)),el('span',label));metrics.append(m);}question.append(metrics);

 const source=el('aside',undefined,'case-source');source.append(el('h3',c.reported.name));if(c.ingredient)source.append(el('p','Investigated ingredient: '+c.ingredient));source.append(el('p','Actual amount: '+(c.reported.dose||'Not provided')),el('p','How often: '+(c.reported.frequency||'Not provided')));
 if(c.source_label)source.append(sourceLink('NIH DSLD label #'+c.source_label.id,c.source_label.url));
 const names=el('details');names.append(el('summary',c.candidates.length+' candidate '+(c.candidates.length===1?'identity':'identities')+' retained'));const list=el('ul');for(const candidate of c.candidates)list.append(el('li',candidate.name));names.append(list);source.append(names);top.append(question,source);box.append(top);
 if(!c.studies.length)box.append(el('p','No matching human study in this small open-access library.'));
 for(const [index,s] of c.studies.entries()){const study=el('details',undefined,'study');study.open=index===0;study.append(el('summary',(index+1)+'. '+s.bridge.paper.title.replace(/<[^>]*>/g,'')));const head=el('div',undefined,'study-head');head.append(el('span','Source comparison '+(index+1),'badge'),sourceLink('Open original publication ↗',s.bridge.paper.url),el('p','Candidate branch: '+s.bridge.candidate+' · '+s.study_types.join(', '),'small'));study.append(head);
 const wrap=el('div',undefined,'table-wrap'),table=el('table');const thead=el('thead'),tr=el('tr');for(const title of ['Dimension','The product / person','What the study check establishes']){const th=el('th',title);th.scope='col';tr.append(th);}thead.append(tr);table.append(thead);const tbody=el('tbody');
 for(const d of s.bridge.dimensions){const row=el('tr'),key=el('th',d.label);key.scope='row';const result=el('td');result.append(el('span',signalLabels[d.status]||d.status,'signal '+(d.status==='UNKNOWN'?'unknown':'')),el('div',d.detail));row.append(key,el('td',d.product),result);tbody.append(row);}table.append(tbody);wrap.append(table);study.append(wrap);
 const detail=el('details');detail.append(el('summary','Read the exact source excerpts and saved criteria'));

 let count=0;for(const d of s.bridge.dimensions){if(!d.spans.length)continue;detail.append(el('h4',d.label));quotes(detail,d.spans,s.licence);count+=d.spans.length;}if(!count)detail.append(el('p','No quoted source wording for these dimensions. Bibliographic metadata alone does not establish study eligibility.'));
 if(s.abstract){const abstract=el('details');abstract.append(el('summary','Read the bundled abstract'),el('p',s.abstract),el('p','Article rights: '+s.licence,'small'));detail.append(abstract);}study.append(detail);box.append(study);
 }

 $('#case-status').textContent=c.title+' · recorded example loaded.';
}
async function loadRecordedCases(){try{const response=await fetch('care-cases.json');if(!response.ok)throw Error('Examples are unavailable');const data=await response.json();for(const c of data.cases){const b=el('button',c.title);b.type='button';b.dataset.case=c.id;b.setAttribute('aria-pressed','false');b.onclick=()=>renderCase(c,data);$('#case-tabs').append(b);}renderCase(data.cases[0],data);}catch(error){$('#case-status').textContent='The recorded evidence examples could not be loaded. Your browser-local product list still works. '+error.message;$('#case-status').className='error';}}
loadRecordedCases();

let searchWorker=null,searchId=0,searchRunning=false;
const liveState=(message,bad=false)=>{$('#live-status').textContent=message;$('#live-status').className=bad?'error':'small';};
$('#live-form input').oninput=()=>{searchId++;$('#live-results').hidden=true;liveState('Question changed. Run a new search to update the reading order.');};
$('#live-form').onsubmit=event=>{event.preventDefault();if(searchRunning)return;const query=$('#live-form').elements.query.value.trim();if(query.length<3||query.length>500){liveState('Enter 3–500 characters.',true);return;}const method=event.submitter?.value||'ai';const id=++searchId;searchRunning=true;$('#live-results').hidden=true;for(const b of $('#live-form').querySelectorAll('button'))b.disabled=true;liveState('Opening the bundled literature library…');
 const reset=()=>{searchRunning=false;for(const b of $('#live-form').querySelectorAll('button'))b.disabled=false;};
 try{if(!searchWorker)searchWorker=new Worker(new URL('model-search-worker.js',location.href),{type:'module'});
 searchWorker.onmessage=({data})=>{if(data.type!=='progress')reset();if(data.id!==searchId)return;if(data.type==='progress'){liveState(data.text);return;}if(data.type==='error'){liveState(data.text,true);return;}
 const box=$('#live-results');box.replaceChildren(el('h3',(data.method==='ai'?'On-device AI':'Keyword')+' reading order'),el('p',data.query),el('p',data.library_count+' abstracts · '+data.candidate_count+' candidates · '+data.seconds.toFixed(1)+' s on this device','small'));
 if(!data.rows.length)box.append(el('p','No match. Try different wording.'));
 for(const [position,row] of data.rows.entries()){const card=el('article',undefined,'card');card.style.marginBottom='18px';card.append(el('span',String(position+1)+' / '+row.id,'badge'),el('h4',row.title.replace(/<[^>]*>/g,'')),sourceLink('Read original source ↗',row.url));const details=el('details');details.append(el('summary','Read bundled abstract and rights'),el('p',row.abstract),el('p','Article rights: '+row.licence,'small'));card.append(details);box.append(card);}
 if(data.method==='ai'){const compare=el('details',undefined,'card');compare.append(el('summary','Compare the keyword candidate order'));const list=el('ol');for(const paperId of data.baseline.slice(0,5)){const title=data.rows.find(r=>r.id===paperId)?.title?.replace(/<[^>]*>/g,'');list.append(el('li',title||paperId));}compare.append(list);box.append(compare);}
 box.hidden=false;box.dataset.method=data.method;box.dataset.query=data.query;box.dataset.resultIds=JSON.stringify(data.rows.map(r=>r.id));box.dataset.scores=JSON.stringify(data.rows.map(r=>r.score));liveState('Finished on this device. No question was sent to a server.');};
 searchWorker.onerror=()=>{reset();liveState('This browser could not start local inference. Reload to retry; your saved preparation is unchanged.',true);searchWorker?.terminate();searchWorker=null;};searchWorker.postMessage({id,query,method});
 }catch(error){reset();liveState('Local search is unavailable: '+error.message,true);}
};
for(const button of $('#live-form').querySelectorAll('button'))button.disabled=false;

window.addEventListener('foliatrace:research',e=>{const input=$('#live-form').elements.query;input.value=String(e.detail||'').slice(0,500);$('#live-search').scrollIntoView({block:'start'});input.focus({preventScroll:true});liveState('Query filled from your brief. Choose AI or keyword search.');});

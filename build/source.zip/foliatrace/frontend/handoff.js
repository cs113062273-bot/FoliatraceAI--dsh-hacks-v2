// Portable reading decisions are distinct from inference and never change its labels.
export function initHandoffs({getAnalysis, api, el, link, showView}) {
  const $ = s => document.querySelector(s);
  let composedRun = null, serial = 0;
  const report = (message, bad=false) => {$('#handoff-list-status').textContent=message;$('#handoff-list-status').className=bad?'error':'hint';};
  function field(form, label, tag, name, maxLength) {
    const wrap=el('label',label), input=el(tag);
    input.name=name;input.required=true;
    if(maxLength)input.maxLength=maxLength;
    if(tag==='textarea')input.rows=3;
    wrap.append(input);form.append(wrap);return input;
  }
  function compose() {
    const data=getAnalysis(),box=$('#handoff-compose');
    if(!data){box.replaceChildren(el('h2','Start with a source'),el('p','Analyze a source in the workspace, check its possible species and studies, then record your reading here.'));const start=el('button','Open workspace');start.onclick=()=>showView('workspace');box.append(start);return;}
    if(data.run_id===composedRun)return;
    composedRun=data.run_id;box.replaceChildren(el('h2','Create a source-scoped handoff'),el('p',data.source.title));
    const form=el('form'),question=field(form,'Research question','textarea','question',600),statement=field(form,'Source statement','select','claim_id');statement.required=false;
    const whole=el('option','Whole source — no specific statement');whole.value='';statement.append(whole);
    for(const c of data.historical_claims){const opt=el('option',c.support.text);opt.value=c.id;statement.append(opt);}
    const quote=el('blockquote'),assumptions=el('fieldset'),legend=el('legend','Candidate assumptions — these do not establish the source identity');assumptions.append(legend);form.append(quote,assumptions);
    const decision=field(form,'Reading decision','select','decision');
    for(const [value,text] of [['INSUFFICIENT_INFORMATION','Insufficient information'],['NEXT_READING','Continue to the next reading'],['EXCLUDE_FROM_THIS_QUESTION','Exclude from this research question']]){const opt=el('option',text);opt.value=value;decision.append(opt);}
    const reason=field(form,'Reason and remaining uncertainty','textarea','reason',3000),next=field(form,'Next verification step','textarea','next_step',2000),reviewer=field(form,'Recorded by','input','reviewer',80);reviewer.value='Local researcher';
    const save=el('button','Save evidence handoff');save.type='submit';const state=el('p','','hint');state.setAttribute('role','status');state.setAttribute('aria-live','polite');form.append(save,state);box.append(form);
    const key='foliatrace.handoff.draft.'+data.run_id;
    function candidates(selectedIds=null){
      const c=data.historical_claims.find(c=>c.id===statement.value);quote.textContent=c?c.support.text:'Whole source reading. Select a statement above to restrict the handoff and its studies.';
      assumptions.replaceChildren(legend);const seen=new Set();
      for(const g of data.identity_counterfactuals){if(c&&!g.mention_ids.some(id=>c.mention_ids.includes(id)))continue;for(const b of g.branches){if(seen.has(b.taxon_id))continue;seen.add(b.taxon_id);const label=el('label'),input=el('input');input.type='checkbox';input.name='candidate';input.value=b.taxon_id;input.checked=selectedIds?selectedIds.includes(b.taxon_id):true;label.append(input,document.createTextNode(' '+b.name));assumptions.append(label);}}
      if(!seen.size)assumptions.append(el('p','No candidate for this selection. The unresolved source and your next step can still be saved.','hint'));
    }
    function draft(){return {question:question.value,claim_id:statement.value||null,candidate_ids:[...assumptions.querySelectorAll('input:checked')].map(x=>x.value),decision:decision.value,reason:reason.value,next_step:next.value,reviewer:reviewer.value};}
    function persist(){try{localStorage.setItem(key,JSON.stringify(draft()));}catch{state.textContent='Draft storage unavailable. Keep this page open and save the handoff to this local service before leaving.';}}
    let saved=null;try{saved=JSON.parse(localStorage.getItem(key)||'null');}catch{}
    if(saved){question.value=saved.question||'';if([...statement.options].some(o=>o.value===(saved.claim_id||'')))statement.value=saved.claim_id||'';decision.value=['NEXT_READING','INSUFFICIENT_INFORMATION','EXCLUDE_FROM_THIS_QUESTION'].includes(saved.decision)?saved.decision:'INSUFFICIENT_INFORMATION';reason.value=saved.reason||'';next.value=saved.next_step||'';reviewer.value=saved.reviewer||'Local researcher';}
    candidates(saved?.candidate_ids);statement.addEventListener('change',()=>{candidates();persist();});form.addEventListener('input',persist);form.addEventListener('change',persist);
    form.addEventListener('submit',async event=>{event.preventDefault();save.disabled=true;state.textContent='Saving the source, candidate assumptions and research checks…';try{const record=await api('/api/analyses/'+data.run_id+'/handoffs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(draft())});state.textContent='Saved. Download JSON for another installation or Markdown for a reading note.';showRecord(record);await refresh();}catch(error){state.textContent='Not saved: '+error.message+'. Your draft remains in this form.';}finally{save.disabled=false;}});
  }
  function showRecord(record){
    const box=$('#handoff-detail'),p=record.packet,a=p.assessment;box.hidden=false;box.replaceChildren(el('h2',a.question),el('p',record.origin==='IMPORTED_UNVERIFIED_RECORD'?'Imported record · author and scientific claims unverified':'Saved local research decision','pill warn'));
    const links=el('div',undefined,'row');for(const [format,label] of [['json','Download portable JSON'],['markdown','Download reading note']]){const anchor=el('a',label);anchor.href='/api/handoffs/'+record.id+(format==='markdown'?'?format=markdown':'');anchor.download='foliatrace-handoff-'+record.id+(format==='json'?'.json':'.md');links.append(anchor);}box.append(links,el('p',a.decision.replaceAll('_',' ')),el('p',a.reason),el('p','Next step: '+a.next_step),el('p','Recorded by '+a.reviewer+' · '+p.created_at,'hint'),el('h3','Source statement'),el('p',p.source.title),el('blockquote',p.statement?.support.text||p.source_input));
    if(p.source.url)box.append(link('Read source ↗',p.source.url));box.append(el('p','Rights: '+(p.source.licence||'not established'),'hint'),el('h3','Candidate assumptions'));
    box.append(el('p',p.candidates.map(c=>c.name).join(' · ')||'No species selected; unresolved source.'));
    box.append(el('h3',p.studies.length+' candidate/study records'),el('p','Automatic checks describe the original analysis. Your recorded question and decision do not rerun or validate those checks.','hint'));
    for(const s of p.studies){const details=el('details'),summary=el('summary',s.paper.title+' · '+(p.candidates.find(c=>c.taxon_id===s.taxon_id)?.name||s.taxon_id));details.append(summary,link('Original study ↗',s.paper.url),el('p','Conditional on candidate identity. '+s.relation.relation));if(s.relation.supporting_text)details.append(el('blockquote',s.relation.supporting_text));if(!s.paper.abstract)details.append(el('p','Abstract unavailable; read the original publication.','hint'));for(const check of s.comparability.checks||[])details.append(el('p',check.check+': '+check.status+' · '+(check.detail||''),'hint'));box.append(details);}
    const methods=el('section');
    for(const s of p.studies){const forms=s.study?.preparation_attribution?.forms||[];if(!forms.length)continue;methods.append(el('h3','Preparation wording · '+s.paper.title));for(const form of forms){methods.append(el('blockquote',form.context?.text||form.text));if(form.url)methods.append(link('Check preparation at source ↗',form.url));if(form.licence)methods.append(el('p',form.licence,'hint'));}methods.append(el('p','Candidate-linked wording is a reading lead. It does not establish equivalent formulation, dose or causal effect.','hint'));}
    if(methods.childElementCount)box.append(methods);
    box.append(el('h3','Coverage and limitations'),el('p',p.coverage.publications+' publications included. Unselected candidates and studies remain outside this handoff.'));
    for(const text of p.limitations)box.append(el('p',text,'hint'));
    box.append(el('p','Analysis '+p.analysis_id+' · snapshot '+p.snapshot_sha256,'hint'),el('p','SHA-256 checks file integrity; it does not prove authorship or scientific correctness.','hint'));
  }
  async function refresh(){const current=++serial;try{const result=await api('/api/handoffs');if(current!==serial)return;const box=$('#handoff-list');box.replaceChildren();if(!result.handoffs.length)box.append(el('p','No saved handoffs yet.','hint'));for(const row of result.handoffs){const button=el('button',row.question,'handoff-list-item quiet');button.type='button';button.onclick=async()=>{try{showRecord(await api('/api/handoffs/'+row.id));report('Opened saved handoff.');}catch(error){report(error.message,true);}};box.append(button,el('p',row.source_title+' · '+row.saved_at,'hint'));}}catch(error){if(current===serial)report('Could not load saved handoffs: '+error.message,true);}}
  $('#handoff-refresh').addEventListener('click',refresh);
  $('#handoff-import').addEventListener('change',async event=>{const file=event.target.files[0];if(!file)return;if(file.size>20_000_000){report('Handoff exceeds 20 MB; existing records are unchanged.',true);return;}const body=new FormData();body.append('file',file);try{const record=await api('/api/handoffs/import',{method:'POST',body});showRecord(record);report('Imported as a separate unverified record. Existing decisions were kept.');await refresh();}catch(error){report('Import failed: '+error.message+'. Existing records were kept.',true);}finally{event.target.value='';}});
  return {open(){compose();return refresh();},analysisChanged(){composedRun=null;}};
}

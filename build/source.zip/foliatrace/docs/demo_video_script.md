# FoliaTrace AI — demo script

目標約 5 分 25 秒。英文旁白；保留慢速操作、點擊前橘框、大水波紋、章節標籤、平滑捲動與切頁提示。先展示 AI 真正處理的輸入與結果，再展示來源與交接。

開場 40 秒內必須說出並展示：人話用藥理解、瓶子與目的驅動的研究、裝置端執行。OCR 是可選輸入方式。

數字由評估報告讀取。語言評估標示 synthetic English phrases；研究元件評估標示 separate full-local SciFact benchmark。不能說「臨床驗證」「AI 證明安全」，不能把 Ray 的藥物假設說成已確認 statin。

錄製準則：每個點擊先讓目標穩定再畫框；待模型完成才指向結果；第一次開外站先提示；原句與 AI 結果要同框；錄製比較保留 replay 標示。不要以 mock NIH 當正式錄影。

## 01 · The gap

**畫面：** 兩張統計字卡慢慢出現；保留 CDC 2017–18 與 NHIS 2002 的來源及年份。

**VO / 字幕：** More than half of American adults use supplements. In a national survey, only one in three herb and supplement users told a conventional healthcare provider.

## 02 · The gap

**畫面：** 人物字卡：藥盒旁出現 “my cholesterol pill”。不要一開始堆醫療警告。

**VO / 字幕：** People do not always remember medicine names. A medicine list cannot match a description such as my cholesterol pill.

## 03 · FoliaTrace AI

**畫面：** 首頁品牌與主張；先框住語言理解，再框住 bottle and goal。

**VO / 字幕：** FoliaTrace AI understands medicine descriptions, finds research for your bottle and goals, and builds a brief your pharmacist can check. Both language and research AI run on your device.

## 04 · Mei · language AI

**畫面：** 框住 Mei 的 “her water pill”；停一下讓觀眾讀。

**VO / 字幕：** Meet Mei. She is seventy two, takes warfarin and what she calls her water pill. Her daughter bought her a supplement for memory and joints.

## 05 · Mei · language AI

**畫面：** 點 Run check，等簡報；框住人話 → 藥物群組，展開 evidence trail。

**VO / 字幕：** The language AI suggests a blood-pressure medicine group from her water pill. That is a hypothesis, so the exact medicine stays a question for the pharmacist. Watch the AI result appear in the brief.

## 06 · Mei · source-linked brief

**畫面：** 由 AI 假設平滑捲到摘要，再到兩張來源卡。

**VO / 字幕：** The brief keeps the AI hypothesis visible, then connects her named medicines to the ingredients in her bottle. Raise these first.

## 07 · Mei · NIH evidence

**畫面：** 框住 Ginkgo × Warfarin 及 Garlic × Warfarin。

**VO / 字幕：** Here are ginkgo and garlic, each paired with warfarin. The cards quote the NIH statements that name this medicine or its group.

## 08 · Mei · NIH evidence

**畫面：** 先出現 “Opens NIH’s website”，再點銀杏來源。

**VO / 字幕：** AI understands and finds evidence. It does not write warnings. This sentence comes directly from the National Institutes of Health. Open the source.

## 09 · Mei · NIH evidence

**畫面：** NIH 網頁淡入；用橘色標記同一句原文，停留。

**VO / 字幕：** There it is on NIH’s own page. The same words, with the source one click away. That boundary is built into the product.

## 10 · Mei · questions

**畫面：** 返回網站先提示再淡入；框 Ask，點 Copy my questions。

**VO / 字幕：** Back in the brief, each card becomes a question Mei can take to the pharmacist. One click copies the questions.

## 11 · Mei · identity gaps

**畫面：** 框 ginseng 候選物種，逐一移動；不稱為 AI 身分辨識。

**VO / 字幕：** The label also says ginseng root. That can describe different plants. FoliaTrace AI keeps the candidate identities open and shows which NIH statements would apply.

## 12 · Mei · label gaps

**畫面：** 框複方總量與 BioPerine/curcumin 卡；不念額外醫療結論。

**VO / 字幕：** It keeps other gaps visible too: a blend with no amount for each herb, and a formulation detail the pharmacist should check. Missing information does not disappear.

## 13 · Sam · quick check

**畫面：** 回三個人物；點 Sam；讓來源卡出現。

**VO / 字幕：** Sam takes sertraline and birth control pills, and bought a mood supplement containing St. John’s wort. Here is the same source-linked workflow for a different person.

## 14 · Sam · quick check

**畫面：** 框 Birth control pill、NIH list item、Sertraline；之後馬上進 Ray。

**VO / 字幕：** The NIH cards identify the named medicine groups and keep the original wording. The questions are ready for a pharmacist to review.

## 15 · Ray · why AI matters

**畫面：** 框 Ray 故事中的 “my cholesterol pill”，再點 Run。

**VO / 字幕：** Now Ray, sixty one. He knows he takes metformin, but remembers his other medicine only as my cholesterol pill. An exact-name lookup cannot identify that description.

## 16 · Ray · why AI matters

**畫面：** 先展開 AI evidence trail，再平滑移到 Red yeast rice × my cholesterol pill，框 AI 標籤與 NIH 原文。

**VO / 字幕：** Language AI suggests a statin group, connecting his words to the NIH red yeast rice card. Here is the trail: no name match, an AI hypothesis, a verified source. The pharmacist confirms the exact drug.

## 17 · Your bottle

**畫面：** Erase，Search NIH labels，輸入 ginkgo，點 Search；真實 API。

**VO / 字幕：** Your own bottle starts here. Search the NIH label database by product or ingredient. This is a live lookup, not a replay.

## 18 · Your bottle

**畫面：** 等待結果，選 Add，框標籤編號與成分；不得用錄製資料假裝 live。

**VO / 字幕：** Choose the matching label. Its recorded ingredients and scientific names are added with the NIH record link.

## 19 · Optional photo input

**畫面：** 展示虛構標籤照片，再上傳，等 editable text。

**VO / 字幕：** Or photograph the ingredient panel. Text recognition reads it on your device. You check and correct the text before adding it.

## 20 · Optional photo input

**畫面：** 框 editable textarea 與 Type or paste；Add product。

**VO / 字幕：** You can also type or paste a label. All three paths lead to the same ingredient and evidence workflow.

## 21 · Names and descriptions

**畫面：** 輸入 Coumadin；框已解析的 warfarin。

**VO / 字幕：** For medicine names, brands work too. Coumadin resolves to warfarin through the name dictionary, before the language model is needed.

## 22 · Names and descriptions

**畫面：** 輸入 zolpidm 但旁白不念該字；再輸入 my blood pressure pill，等待 AI chip。

**VO / 字幕：** A typo can still find the sleep medicine. A description such as my blood pressure pill uses language AI. When the model is unsure, the description stays unrecognised for the pharmacist.

## 23 · Your goal

**畫面：** 在 purpose 欄輸入 sleep；選 surgery；Build。

**VO / 字幕：** Add what you want the supplement to help with, such as sleep. That goal guides the research AI. Add a relevant situation, then build the brief.

## 24 · Your brief

**畫面：** 框來源卡與重複成分；不重念前面所有警告。

**VO / 字幕：** Here are the source cards, the medicine hypothesis and ingredients repeated across bottles. The brief brings them together without pretending every uncertainty is settled.

## 25 · Pharmacist handoff

**畫面：** 點 Hand to pharmacist；QR 完整出現。

**VO / 字幕：** At the pharmacy, tap Hand to pharmacist. FoliaTrace AI puts the brief inside a QR link.

## 26 · Pharmacist handoff

**畫面：** 提示 “Pharmacist’s computer” 後切到新視窗；顯示 shared banner。

**VO / 字幕：** The pharmacist opens the same brief and sources on their screen. The data travels inside the link. No account or uploaded patient record is required.

## 27 · Private exports

**畫面：** 取消 My medicines，顯示匯出內容已去掉個人藥名；恢復全部勾選再看帶 QR 的列印。

**VO / 字幕：** For paper or download, choose what to include. Excluding medicines removes personal medicine details from the cards and questions too. Include everything if you want the printed QR handoff.

## 28 · Research AI · personal goal

**畫面：** 回同一簡報，等 Ranked；捲到 AI research leads，框 valerian 與 matched goal。

**VO / 字幕：** The research is already ranked for the herbs in this bottle and the goal sleep. The model reads candidate studies and orders the closest matches. Unrelated results are left out.

## 29 · Research AI · exact context

**畫面：** 展開 live lead 的 Compare source wording；依序框 Your label、Population、Preparation、Comparator。

**VO / 字幕：** Open a lead. Compare the actual label with the study’s own population, preparation and comparator wording. AI ranks the study; literal excerpts let the pharmacist judge the differences.

## 30 · Research AI · deeper review

**畫面：** 到 For pharmacists，示範自由問題搜尋；錄製比較面板只作最後短鏡頭並保留 replay 標示。

**VO / 字幕：** A pharmacist can ask a different research question and run the neural search locally. Five labelled examples also replay the full app’s deeper study-to-product comparisons.

## 31 · Measured language AI

**畫面：** 語言測試字卡；Synthetic English phrases 必須與數字一起出現。

**VO / 字幕：** On a fresh test of 54 synthetic English phrases, 37 of 39 medicine descriptions reached the correct group. There were 0 wrong group assignments. The rest stayed unknown, and all 15 other or negated descriptions remained unassigned.

## 32 · Measured research AI

**畫面：** AI proof 表：keyword → hybrid → reranking；保留 full local component / SciFact 範圍。

**VO / 字幕：** In a separate benchmark with published human relevance labels, neural reranking puts relevant papers higher in the full local pipeline. Methods and results ship with the code.

## 33 · FoliaTrace AI

**畫面：** 新版品牌收尾；網址與免費、不需帳號；停留三秒。

**VO / 字幕：** FoliaTrace AI. Your words, your bottle, evidence your pharmacist can check. Bring the bottle. Start a better conversation.

## 製作與一致性

`python scripts/build_demo_script.py` 重新產生本文件及錄影旁白資料；`.runtime/video/make-video2.mjs --script-only` 驗證 33 個場景。正式錄製前每句使用 `tts.py check` 核對。

發音：FoliaTrace AI → “Folia Trace AI”；Mei → “May”；Ginkgo → “Ghingko”；Coumadin → “Coomadin”；NIH → “N I H”；QR → “Q R”。不念 zolpidem。

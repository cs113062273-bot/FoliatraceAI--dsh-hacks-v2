# AI disclosure

## AI inside the product (runtime)

| Where | Model | Runs on | What it may and may not do |
|---|---|---|---|
| Reading a label photo | Tesseract LSTM text recogniser (English) | The user's device (WebAssembly) | Turns the photo into editable text. The person reviews the text before it is used; tolerant name matching (1–2 character edits) applies only to recognised text. The photo is never uploaded. |
| Ranking research for the pharmacist | Pinned cross-encoder reranker (`data/reranker.lock.json`) | The user's device (ONNX Runtime Web) | Re-orders up to 20 keyword candidates from 415 open-access abstracts by relevance. It does not judge benefit or safety. |
| Safety statements | **None** | — | Every warning is a deterministic match to an NCCIH sentence verified word-for-word at build time. No generative model writes, summarises or paraphrases a warning. |

No paid AI API is called and no health information is sent to any AI service.

## AI in building the product (development)

FoliaTrace was developed by the entrant with substantial help from AI coding assistants:

- **OpenAI Codex** — earlier versions (October–November 2026): the local FastAPI/SQLite consultation app, product-label versioning, pharmacist study-to-product comparison, the browser reranker and recorded evidence cases. Three clinical-trial factual reading notes in `data/reading_notes/` are Codex-assisted and labelled as such.
- **Anthropic Claude (Claude Code)** — v0.8 (12 November 2026): the label-to-pharmacist-brief checker, the NCCIH knowledge-base builder and verifier, the matching engine, live NIH label search, on-device OCR, the QR handoff, the Content-Security-Policy, tests, browser QA and the real-label evaluation.

Choices made with AI assistance and checked by code, but **not yet reviewed by a pharmacist**:

- which 25 herbs are covered and which NCCIH sentences are quoted (each sentence is verified verbatim against the NIH page);
- which medicine groups each sentence is linked to (only groups the sentence itself names);
- the medicine name list (134 medicines, 325 generic and brand names);
- the three fictional people and labels used as examples.

## How the evaluation was kept honest

Name matching is graded against NIH DSLD curators' declared genus and species on real labels (`reports/label_matching_*`). The first development run exposed a Latin-name parsing bug in the knowledge-base builder; it was fixed and the development sample re-run. The engine and knowledge base were then frozen before a held-out sample — with every label from the development sample removed — was run once. Both samples are search-ranked, not random market samples.

No user study, pharmacist review or clinical outcome is claimed.

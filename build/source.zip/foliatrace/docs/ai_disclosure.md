# FoliaTrace AI — AI architecture and evidence

FoliaTrace AI delivers an on-device workflow from a supplement label to a pharmacist brief. It interprets everyday medicine descriptions, ranks research for the actual bottle and goal, and connects warning cards and research leads to their original sources.

## Where AI changes the result

Ray remembers “my cholesterol pill.” A name lookup leaves that description unresolved. The language model proposes the statin group, which connects his words to the NIH red yeast rice card and a question to confirm the medicine. The [same-input ablation](../reports/ai_feature_ablation_2026-11-12.json) records the difference with language AI enabled and disabled.

## Completed browser workflows

Four workflows were re-run on the public site on 13 November 2026:

- **Mei:** warfarin and "her water pill" with a memory/joint blend. AI suggested a blood-pressure group; ginkgo/garlic source cards, ginseng identity, blend amounts and separate memory/joint research appeared.
- **Sam:** sertraline and birth control with St. John's wort, valerian and chamomile. Both medicine-specific source cards and chamomile species candidates appeared.
- **Ray:** metformin, "my cholesterol pill" and lisinopril with two supplements. AI suggested a statin group and added the red yeast rice card; goldenseal/metformin, repeated green tea and withheld unrelated goldenseal research were visible.
- **Own-bottle:** live NIH ginkgo lookup plus a photo, Coumadin, the typo "zolpidm", "my blood pressure pill" and ibuprofen. Brand/typo resolution, semantic inference, source cards, duplicate ginkgo and sleep research completed. A fresh browser opened the same brief from the QR link; excluding medicines from the download removed all four medicine names.

The [workflow report](../reports/project_scenarios_2026-11-13.json) preserves the actual inputs, model outputs, NIH source links, study scores and handoff/export results.

## Architecture

| Component | Implementation | Contribution |
|---|---|---|
| Medicine language | Sentence embeddings · `sentence-transformers/all-MiniLM-L6-v2` | Matches everyday descriptions to medicine-group prototypes after exact, brand and typo lookup |
| Personal research | Cross-encoder reranking · `cross-encoder/ms-marco-MiniLM-L6-v2` | Ranks candidate studies for each herb and goal in a library of 423 open-access abstracts |
| Photo input | Tesseract English LSTM | Converts a label photo into editable ingredient text |
| Source cards | Deterministic matching | Connects ingredients and medicine groups to 74 verified NIH passages across 25 herbs |

The medicine model compares sentence embeddings with group prototypes using cosine similarity, with a floor of 0.55 and a runner-up margin of 0.06. Negated, historical and supplement-only descriptions stay unassigned. Suggested groups retain the person’s original words and an exact-name confirmation prompt.

BM25 retrieves candidates from the herb-filtered library. The cross-encoder scores each query–abstract pair and keeps up to two leads above a raw-logit floor of 2.0, calibrated on three development examples. Expand a lead to inspect literal population, preparation and comparator excerpts beside the bottle. The five deeper seven-dimension comparisons are labelled replays from the full local app.

Warning cards quote NIH verbatim. Model and tokenizer hashes are checked before inference; the pinned assets are recorded in `data/models.lock.json` and `data/reranker.lock.json`.

## Measured results

| Evaluation | Result | Dataset and method |
|---|---|---|
| Medicine descriptions | **37/39 correct groups; 0 wrong group assignments** | 54 synthetic English phrases; 2 medicine descriptions left unassigned; all 15 other or negated descriptions also unassigned |
| Label matching | **96.3% exact-species precision** | 789 held-out NIH labels retrieved by product search |
| Full-local research pipeline | **0.812 → 0.826 → 0.866 nDCG@10** | SciFact development data: 188 annotated claims and 5,183 abstracts; keyword search, hybrid retrieval, neural reranking |

Browser workers and Python agree on medicine-group decisions across the original 34-phrase regression set and the fresh 54-phrase evaluation. Reports retain the inputs and scoring details.

Engineering validation covers software behavior and labelled datasets. Pharmacist review and clinical outcome testing are the next evaluation milestones.

[Medicine report](../reports/ai_medicine_understanding_v2_2026-11-12.json) · [Label report](../reports/label_matching_holdout_2026-11-12.json) · [Research benchmark](../reports/retrieval_external.json) · [Browser verification](../reports/checker_browser_qa_public_2026-11-12.json)

## Data flow

Medicine descriptions, conditions, goals and photos stay in the browser. NIH receives the separate label-search query or record ID. QR sharing encodes the brief in the link; the recipient chooses whether to save it on their device. Research excerpts preserve the wording of the cited abstract.

## Development and provenance

Hao directed the product with substantial assistance from OpenAI Codex and Anthropic Claude across architecture, implementation, evaluations, documentation and demo production. The project began as an EthnoHack herbal-literature workspace; the DSH edition introduced the bottle-to-pharmacist workflow and its on-device medicine understanding.

Example people and products are fictional. NIH quotations are public-domain source material; article and model licences are recorded in [data/NOTICE.md](../data/NOTICE.md). Product code is MIT-licensed.

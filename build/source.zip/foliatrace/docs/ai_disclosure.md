# AI disclosure

## Runtime AI

The product contains three on-device models. Language understanding and personal research ranking are its two core AI tasks; OCR is an optional input aid.

| Role | Model | Limits |
|---|---|---|
| Understand medicine descriptions | `sentence-transformers/all-MiniLM-L6-v2`, pinned in `data/models.lock.json` | Cosine comparison with group descriptions/prototypes, floor 0.55, margin 0.06. Dictionary matches take precedence; negated/historical/supplement mentions are excluded. Results are hypotheses with a pharmacist-confirmation prompt |
| Rank research for each herb and goal | `cross-encoder/ms-marco-MiniLM-L6-v2`, pinned in `data/reranker.lock.json` | 423 open-access abstracts; herb candidates and explicit nonclinical/protocol title cues filtered before neural scoring. Floor 2.0 selected on development examples; at most two leads per herb. No calibrated confidence, clinical entailment or applicability claim |
| Read a label photo | Tesseract English LSTM | Browser-local, editable text; photo never uploaded |

Warnings are deterministic matches to 74 verified NIH quotations. No generative model writes, summarises or paraphrases a warning. Excerpts for population, preparation and comparator are extracted by deterministic text cues with literal offsets; absent extracted wording is left empty and is not proof the study omitted it. Recorded seven-dimension comparisons remain explicitly labelled replays.

Model/tokenizer SHA-256 checks run before inference. No paid AI API, hosted LLM or external inference service is used. Health inputs never enter requests; separate NIH label searches do. Worker queues prevent concurrent model initialisation, and input changes/erasure invalidate stale asynchronous results. Shared links do not persist data without the keep action.

The public hosting provider injects a Cloudflare bot-detection inline script. The strict CSP blocks it. Deployed QA retains every policy event and identifies this exact hosting script separately using its browser report sample and script contents; it never enables inline scripts or reports those platform blocks as zero. Local/static application runs have zero policy violations. [Cloudflare documents this interaction](https://developers.cloudflare.com/cloudflare-challenges/challenge-types/javascript-detections/).

## Evaluation and its limits

- Fresh frozen v2 set: **37/39 medicine descriptions assigned to the correct group (94.9%); 0 wrong group assignments, 2 left unknown; all 15 other/negated phrases left unassigned (54 synthetic English phrases total)**. Synthetic English phrases authored for development/testing; no patient/user study.
- The original v1 34-phrase holdout is retained unchanged and used as a regression set, not presented as fresh v2 testing. V2 adds conservative short prototypes and exclusions; thresholds were chosen using development phrases before scoring the fresh set. Failures remain in the report.
- Actual browser-worker decisions match Python on both sets. Maximum cosine difference: **0.008** on the original set, **0.013** on v2. Pinned int8 CPU and WebAssembly kernels can differ numerically; QA tolerances are 0.01 / 0.02 respectively. No threshold was retuned on held-out results.
- Research floor 2.0 and clinical question wording were calibrated on the three fictional development examples after a 2.5 short-query floor missed relevant cognition/joint studies. Explicit animal/bench/protocol title exclusions prevent obvious scope errors. This is development calibration, **not** a held-out research-relevance benchmark or proof a study applies to a person.
- Separate external component evaluation: 188 published human-annotated SciFact claims over 5,183 abstracts; full local pipeline nDCG@10 0.812 keywords → 0.826 hybrid → 0.866 with neural reranking. Settings unchanged on public development labels; not an official blind test, browser-library score or clinical outcome.
- A same-input feature ablation demonstrates that Ray's informal medicine description connects to the red yeast rice NIH card only with the language-AI hypothesis. This uses a development example and does not add held-out evaluation cases.
- Label matching: 789 unseen NIH labels: 96.3% exact species, 99.3% genus-or-better precision, 100% recall of covered species. Search-ranked samples; curator declarations are imperfect ground truth. Engine frozen before the held-out label run.
- 52/52 public-build and 52/52 local `/check/` real-browser checks; 18/18 behavioral unit tests; no uncaught page exceptions, CSP violations or axe WCAG 2 A/AA violations in the recorded runs.

Full methods/results: `reports/ai_medicine_understanding*_2026-11-12.json`, `reports/ai_research_relevance_2026-11-12.json` and browser reports.

## Development assistance

The entrant developed FoliaTrace AI with substantial assistance from **OpenAI Codex** and **Anthropic Claude (Claude Code)**. Earlier Codex work covered the local FastAPI/SQLite consultation app, versioning, study comparisons and browser reranker. Claude's v0.8 work introduced the NIH checker, language AI, OCR, QR handoff and evaluations. Codex's follow-up corrected browser/Python padding, added conservative medicine prototypes/exclusions, goal-specific research with source excerpts, licensed clinical additions, cancellation/privacy fixes and verification.

AI-assisted choices have **not been reviewed by a pharmacist**: covered herbs, statement-to-medicine mappings, group descriptions/prototypes and fictional scenarios. NIH wording is checked verbatim, which does not validate those mappings or imply NIH endorsement. Three older factual study-reading notes in `data/reading_notes/` retain their Codex labels. No clinical validation is claimed.

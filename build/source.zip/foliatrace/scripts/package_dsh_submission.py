"""Package the judge-facing FoliaTrace source archive from an explicit allow-list.

Only what is needed to read, run, test and verify v0.8 is included. Internal planning notes,
historical reports, research-era acquisition scripts and screenshots stay out.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / 'dist/dsh-v2/foliatrace-source.zip'

TOP = ['README.md', 'LICENSE', 'package.json', 'package-lock.json', 'requirements.in', 'requirements.lock',
       'app.py', '.gitignore', '.gitattributes', '.env.example']
TREES = ['src', 'frontend', 'data', 'tests']          # whole trees, filtered below
SCRIPTS = ['start.ps1', 'start.mjs', 'validate_data.py', 'build_safety_knowledge.py', 'sync_public_demo.py',
           'build_care_demo.py', 'build_browser_inference.mjs', 'setup_model.py', 'setup_reranker.py',
           'evaluate_label_matching.mjs', 'verify_checker.mjs', 'verify_engine.mjs', 'ai_medicine_groups.py',
           'acquire_care_research.py', 'evaluate_ai_value.mjs', 'acquire_scifact.py', 'evaluate_retrieval.py', 'product_metrics.py', 'sync_product_docs.py',
           'build_product_onepage.py', 'build_code_pdf.py', 'package_dsh_submission.py']
DOCS = ['docs/release_v08_2026-11-12.md', 'docs/ai_disclosure.md']
REPORTS = ['reports/safety_knowledge_verification.json', 'reports/checker_browser_qa_public_2026-11-12.json',
           'reports/checker_browser_qa_local_2026-11-12.json', 'reports/label_matching_dev_2026-11-12.json',
           'reports/label_matching_holdout_2026-11-12.json', 'reports/retrieval_external.json',
           'reports/ai_medicine_understanding_2026-11-12.json', 'reports/ai_medicine_understanding_v2_2026-11-12.json',
           'reports/ai_research_relevance_2026-11-12.json', 'reports/ai_feature_ablation_2026-11-12.json', 'reports/engine_tests_2026-11-12.json',
           'reports/project_scenarios_2026-11-13.json']
OTHER = ['output/pdf/foliatrace-one-page.pdf',
         # checksum-frozen reference files that scripts/validate_data.py verifies at start-up
         'benchmark/historical_transfer/FREEZE.json', 'benchmark/historical_transfer/fernie_reference.json',
         'benchmark/historical_transfer/fernie_ai_audit.json']
SKIP_PARTS = {'__pycache__', 'node_modules', 'raw', 'private', 'local', '.runtime', '.cache', '.git'}
SKIP_PATHS = ('frontend/demo/research/',)            # EthnoHack-era research explorer front end


def wanted(path: Path) -> bool:
    rel = path.relative_to(ROOT).as_posix()
    if any(part in SKIP_PARTS for part in path.relative_to(ROOT).parts) or rel.startswith(SKIP_PATHS):
        return False
    if path.suffix in ('.pyc', '.sqlite', '.db', '.zip'):
        return False
    if rel.startswith('src/') and path.name == 'README.md':   # stale per-package stubs
        return False
    return True


def main() -> None:
    files = [ROOT / f for f in TOP + DOCS + REPORTS + OTHER if (ROOT / f).is_file()]
    files += [ROOT / 'scripts' / f for f in SCRIPTS if (ROOT / 'scripts' / f).is_file()]
    files += [ROOT / 'scripts/lib' / f.name for f in (ROOT / 'scripts/lib').glob('*.mjs')]
    for tree in TREES:
        files += [p for p in (ROOT / tree).rglob('*') if p.is_file() and wanted(p)]
    missing = [f for f in TOP[:7] + SCRIPTS + DOCS[:2] if not (ROOT / f).exists() and not (ROOT / 'scripts' / f).exists()]
    if missing:
        raise SystemExit(f'Missing required files: {missing}')
    files = sorted(set(files))
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    manifest = {'created_at': datetime.now(timezone.utc).isoformat(), 'product': 'FoliaTrace AI v0.8',
                'scope': 'Allow-listed source to read, run, test and verify FoliaTrace. No credentials, model binaries, '
                         'runtime caches or saved user records. Data rights: data/NOTICE.md. Start with README.md.',
                'files': {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    with ZipFile(TARGET, 'w', ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, 'foliatrace/' + path.relative_to(ROOT).as_posix())
        archive.writestr('foliatrace/SOURCE_MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'path': str(TARGET.relative_to(ROOT)), 'files': len(files), 'bytes': TARGET.stat().st_size}, indent=2))


if __name__ == '__main__':
    main()

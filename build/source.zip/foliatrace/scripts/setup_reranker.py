"""Download pinned Apache-2.0 MS MARCO cross-encoder ONNX artifacts."""
import json
import sys
from pathlib import Path
from urllib.request import urlopen
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import ROOT, read_json, write_json, digest, now
from src.ingestion.tls import tls_context


def main():
    lockpath = ROOT / 'data/reranker.lock.json'
    target = ROOT / 'models/reranker'
    target.mkdir(parents=True, exist_ok=True)
    if lockpath.exists():
        lock = read_json(lockpath)
    else:
        model = 'cross-encoder/ms-marco-MiniLM-L6-v2'
        with urlopen(f'https://huggingface.co/api/models/{model}?blobs=true', context=tls_context(), timeout=45) as response:
            data = json.load(response)
        if data.get('cardData', {}).get('license') != 'apache-2.0':
            raise ValueError('Unexpected upstream model rights')
        files = {f['rfilename']: f for f in data['siblings']}
        remote = next((f for f in ('onnx/model_quint8_avx2.onnx', 'onnx/model_qint8_avx512_vnni.onnx', 'onnx/model.onnx') if f in files), None)
        if not remote:
            raise ValueError('No supported upstream ONNX artifact')
        lock = {'model': model, 'revision': data['sha'], 'licence': 'Apache-2.0', 'observed_at': now(), 'purpose': 'Query-document relevance ranking, not scientific entailment or calibrated confidence', 'files': [{'remote': remote, 'local': 'model.onnx', 'sha256': files[remote].get('lfs', {}).get('sha256')}, {'remote': 'tokenizer.json', 'local': 'tokenizer.json'}]}
    for f in lock['files']:
        path = target / f['local']
        if path.exists() and f.get('sha256') == digest(path.read_bytes()):
            print('verified:', f['local'], flush=True)
            continue
        url = f"https://huggingface.co/{lock['model']}/resolve/{lock['revision']}/{f['remote']}"
        with urlopen(url, context=tls_context(), timeout=120) as response:
            data = response.read(150_000_001)
        if len(data) > 150_000_000 or (f.get('sha256') and f['sha256'] != digest(data)):
            raise ValueError('Artifact size/checksum failure')
        path.write_bytes(data)
        f.update({'sha256': digest(data), 'bytes': len(data), 'url': url})
        print('installed:', f['local'], len(data), flush=True)
    write_json(lockpath, lock)


if __name__ == '__main__':
    main()

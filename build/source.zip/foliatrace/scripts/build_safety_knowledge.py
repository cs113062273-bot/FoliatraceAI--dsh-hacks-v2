"""Build FoliaTrace's NIH-sourced botanical safety knowledge base.

Every quotation below is checked against the downloaded NCCIH page text before
it is written. A quote that is not found verbatim stops the build. NCCIH fact
sheets state that they are not copyrighted and are in the public domain.

Usage:
  python scripts/build_safety_knowledge.py            # download pages, verify, write
  python scripts/build_safety_knowledge.py --offline  # use .runtime/nccih/*.html
"""
from __future__ import annotations

import hashlib
import html
import json
import re
import sys
import urllib.request
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / '.runtime/nccih'
OUT = ROOT / 'frontend/demo/safety-knowledge.json'
REPORT = ROOT / 'reports/safety_knowledge_verification.json'
BASE = 'https://www.nccih.nih.gov/health/'

# ---------------------------------------------------------------- medicines
# Each entry: canonical name, aliases (generic + common US brands), classes.
# Classes are only those that an NCCIH sentence below names (directly or as a
# named group such as "sedatives" or "medicines for diabetes").
MEDS = [
    # blood thinners
    ('warfarin', ['coumadin', 'jantoven'], ['warfarin', 'anticoagulant', 'bleeding']),
    ('apixaban', ['eliquis'], ['anticoagulant', 'bleeding']),
    ('rivaroxaban', ['xarelto'], ['anticoagulant', 'bleeding']),
    ('dabigatran', ['pradaxa'], ['anticoagulant', 'bleeding']),
    ('edoxaban', ['savaysa'], ['anticoagulant', 'bleeding']),
    ('heparin', [], ['anticoagulant', 'bleeding']),
    ('enoxaparin', ['lovenox'], ['anticoagulant', 'bleeding']),
    ('aspirin', ['acetylsalicylic acid', 'baby aspirin', 'ecotrin', 'bayer aspirin'], ['aspirin', 'bleeding']),
    ('clopidogrel', ['plavix'], ['bleeding']),
    ('prasugrel', ['effient'], ['bleeding']),
    ('ticagrelor', ['brilinta'], ['bleeding']),
    # contraception
    ('birth control pill', ['the pill', 'oral contraceptive', 'combined pill', 'ethinyl estradiol', 'levonorgestrel',
                            'norethindrone', 'norgestimate', 'desogestrel', 'drospirenone', 'yaz', 'yasmin',
                            'loestrin', 'sprintec', 'ortho tri-cyclen', 'slynd', 'seasonique', 'lo loestrin'],
     ['oral_contraceptive']),
    # transplant / immune
    ('cyclosporine', ['ciclosporin', 'neoral', 'sandimmune', 'gengraf'], ['cyclosporine', 'immunosuppressant']),
    ('tacrolimus', ['prograf', 'envarsus', 'astagraf'], ['immunosuppressant']),
    ('mycophenolate', ['cellcept', 'myfortic'], ['immunosuppressant']),
    ('azathioprine', ['imuran'], ['immunosuppressant']),
    ('sirolimus', ['rapamune'], ['immunosuppressant']),
    ('everolimus', ['zortress'], ['immunosuppressant']),
    # antidepressants / serotonin
    ('amitriptyline', ['elavil'], ['sjw_antidepressant', 'tca', 'serotonergic']),
    ('bupropion', ['wellbutrin', 'zyban'], ['sjw_antidepressant']),
    ('nortriptyline', ['pamelor'], ['tca', 'serotonergic']),
    ('imipramine', ['tofranil'], ['tca', 'serotonergic']),
    ('doxepin', ['silenor'], ['tca', 'serotonergic']),
    ('clomipramine', ['anafranil'], ['tca', 'serotonergic']),
    ('desipramine', ['norpramin'], ['tca', 'serotonergic']),
    ('sertraline', ['zoloft'], ['serotonergic']),
    ('fluoxetine', ['prozac'], ['serotonergic']),
    ('escitalopram', ['lexapro'], ['serotonergic']),
    ('citalopram', ['celexa'], ['serotonergic']),
    ('paroxetine', ['paxil'], ['serotonergic']),
    ('fluvoxamine', ['luvox'], ['serotonergic']),
    ('venlafaxine', ['effexor'], ['serotonergic']),
    ('desvenlafaxine', ['pristiq'], ['serotonergic']),
    ('duloxetine', ['cymbalta'], ['serotonergic']),
    ('trazodone', ['desyrel'], ['serotonergic']),
    ('vortioxetine', ['trintellix'], ['serotonergic']),
    ('tramadol', ['ultram'], ['serotonergic']),
    ('sumatriptan', ['imitrex'], ['serotonergic']),
    ('rizatriptan', ['maxalt'], ['serotonergic']),
    ('phenelzine', ['nardil'], ['maoi', 'serotonergic']),
    ('tranylcypromine', ['parnate'], ['maoi', 'serotonergic']),
    ('isocarboxazid', ['marplan'], ['maoi', 'serotonergic']),
    ('selegiline', ['emsam', 'eldepryl'], ['maoi', 'serotonergic']),
    # seizures
    ('phenytoin', ['dilantin'], ['sjw_anticonvulsant', 'anticonvulsant']),
    ('carbamazepine', ['tegretol'], ['sjw_anticonvulsant', 'anticonvulsant']),
    ('levetiracetam', ['keppra'], ['anticonvulsant']),
    ('lamotrigine', ['lamictal'], ['anticonvulsant']),
    ('valproate', ['valproic acid', 'divalproex', 'depakote'], ['anticonvulsant']),
    ('topiramate', ['topamax'], ['anticonvulsant']),
    ('oxcarbazepine', ['trileptal'], ['anticonvulsant']),
    ('lacosamide', ['vimpat'], ['anticonvulsant']),
    ('phenobarbital', [], ['anticonvulsant', 'sedative']),
    # heart
    ('digoxin', ['lanoxin'], ['digoxin']),
    ('ivabradine', ['corlanor'], ['ivabradine']),
    # HIV
    ('indinavir', ['crixivan'], ['hiv']),
    ('nevirapine', ['viramune'], ['hiv']),
    ('ritonavir', ['norvir'], ['hiv']),
    ('darunavir', ['prezista'], ['hiv']),
    ('atazanavir', ['reyataz'], ['hiv']),
    ('efavirenz', ['sustiva'], ['hiv']),
    ('rilpivirine', ['edurant'], ['hiv']),
    ('lopinavir', ['kaletra'], ['hiv']),
    # cancer
    ('irinotecan', ['camptosar'], ['sjw_cancer']),
    ('imatinib', ['gleevec'], ['sjw_cancer']),
    ('docetaxel', ['taxotere'], ['sjw_cancer']),
    # cholesterol
    ('simvastatin', ['zocor'], ['statin', 'simvastatin']),
    ('atorvastatin', ['lipitor'], ['statin', 'atorvastatin']),
    ('rosuvastatin', ['crestor'], ['statin']),
    ('pravastatin', ['pravachol'], ['statin']),
    ('lovastatin', ['mevacor', 'altoprev'], ['statin']),
    ('pitavastatin', ['livalo'], ['statin']),
    ('fluvastatin', ['lescol'], ['statin']),
    # diabetes
    ('metformin', ['glucophage', 'glumetza', 'fortamet'], ['metformin', 'diabetes_med']),
    ('insulin', ['lantus', 'humalog', 'novolog', 'levemir', 'tresiba', 'basaglar', 'humulin', 'novolin', 'toujeo'], ['diabetes_med']),
    ('glipizide', ['glucotrol'], ['diabetes_med']),
    ('glyburide', ['glynase', 'diabeta'], ['diabetes_med']),
    ('glimepiride', ['amaryl'], ['diabetes_med']),
    ('sitagliptin', ['januvia'], ['diabetes_med']),
    ('linagliptin', ['tradjenta'], ['diabetes_med']),
    ('empagliflozin', ['jardiance'], ['diabetes_med']),
    ('dapagliflozin', ['farxiga'], ['diabetes_med']),
    ('canagliflozin', ['invokana'], ['diabetes_med']),
    ('semaglutide', ['ozempic', 'rybelsus', 'wegovy'], ['diabetes_med']),
    ('liraglutide', ['victoza'], ['diabetes_med']),
    ('dulaglutide', ['trulicity'], ['diabetes_med']),
    ('tirzepatide', ['mounjaro', 'zepbound'], ['diabetes_med']),
    ('pioglitazone', ['actos'], ['diabetes_med']),
    # blood pressure
    ('lisinopril', ['zestril', 'prinivil'], ['bp_med']),
    ('enalapril', ['vasotec'], ['bp_med']),
    ('ramipril', ['altace'], ['bp_med']),
    ('benazepril', ['lotensin'], ['bp_med']),
    ('losartan', ['cozaar'], ['bp_med']),
    ('valsartan', ['diovan'], ['bp_med']),
    ('olmesartan', ['benicar'], ['bp_med']),
    ('irbesartan', ['avapro'], ['bp_med']),
    ('telmisartan', ['micardis'], ['bp_med']),
    ('amlodipine', ['norvasc'], ['bp_med']),
    ('nifedipine', ['procardia', 'adalat'], ['bp_med']),
    ('diltiazem', ['cardizem'], ['bp_med']),
    ('verapamil', ['calan'], ['bp_med']),
    ('metoprolol', ['lopressor', 'toprol'], ['bp_med']),
    ('atenolol', ['tenormin'], ['bp_med']),
    ('carvedilol', ['coreg'], ['bp_med']),
    ('propranolol', ['inderal'], ['bp_med']),
    ('bisoprolol', ['zebeta'], ['bp_med']),
    ('nadolol', ['corgard'], ['bp_med', 'nadolol']),
    ('hydrochlorothiazide', ['hctz', 'microzide'], ['bp_med']),
    ('chlorthalidone', ['thalitone'], ['bp_med']),
    ('furosemide', ['lasix'], ['bp_med']),
    ('spironolactone', ['aldactone'], ['bp_med']),
    ('clonidine', ['catapres'], ['bp_med']),
    ('hydralazine', [], ['bp_med']),
    # steroids
    ('prednisone', ['deltasone', 'rayos'], ['corticosteroid']),
    ('prednisolone', ['orapred', 'millipred'], ['corticosteroid']),
    ('methylprednisolone', ['medrol', 'solu-medrol'], ['corticosteroid']),
    ('dexamethasone', ['decadron'], ['corticosteroid']),
    ('hydrocortisone', ['cortef'], ['corticosteroid']),
    ('fludrocortisone', ['florinef'], ['corticosteroid']),
    ('budesonide', ['entocort', 'uceris'], ['corticosteroid']),
    # sedatives
    ('alprazolam', ['xanax'], ['benzodiazepine', 'sedative']),
    ('lorazepam', ['ativan'], ['benzodiazepine', 'sedative']),
    ('diazepam', ['valium'], ['benzodiazepine', 'sedative']),
    ('clonazepam', ['klonopin'], ['benzodiazepine', 'sedative', 'anticonvulsant']),
    ('temazepam', ['restoril'], ['benzodiazepine', 'sedative']),
    ('triazolam', ['halcion'], ['benzodiazepine', 'sedative']),
    ('chlordiazepoxide', ['librium'], ['benzodiazepine', 'sedative']),
    ('zolpidem', ['ambien', 'edluar', 'intermezzo'], ['sedative']),
    ('eszopiclone', ['lunesta'], ['sedative']),
    ('zaleplon', ['sonata'], ['sedative']),
    ('suvorexant', ['belsomra'], ['sedative']),
    # thyroid / bone
    ('levothyroxine', ['synthroid', 'levoxyl', 'unithroid', 'euthyrox', 'tirosint'], ['thyroid_hormone']),
    ('liothyronine', ['cytomel'], ['thyroid_hormone']),
    ('thyroid desiccated', ['armour thyroid', 'np thyroid'], ['thyroid_hormone']),
    ('raloxifene', ['evista'], ['raloxifene']),
]

CLASS_LABELS = {
    'warfarin': 'warfarin', 'anticoagulant': 'an anticoagulant (blood thinner)',
    'bleeding': 'a medicine that affects bleeding', 'aspirin': 'aspirin',
    'oral_contraceptive': 'birth control pills', 'cyclosporine': 'cyclosporine',
    'immunosuppressant': 'an immunosuppressant', 'sjw_antidepressant': 'an antidepressant NIH names',
    'serotonergic': 'a medicine that affects serotonin', 'tca': 'a tricyclic antidepressant',
    'maoi': 'an MAO inhibitor antidepressant', 'sjw_anticonvulsant': 'a seizure medicine NIH names',
    'anticonvulsant': 'an anti-seizure medicine', 'digoxin': 'digoxin', 'ivabradine': 'ivabradine',
    'hiv': 'an HIV medicine', 'sjw_cancer': 'a cancer medicine NIH names', 'statin': 'a statin',
    'simvastatin': 'simvastatin', 'atorvastatin': 'atorvastatin', 'metformin': 'metformin',
    'diabetes_med': 'a diabetes medicine', 'bp_med': 'a blood-pressure medicine', 'nadolol': 'nadolol',
    'corticosteroid': 'a corticosteroid', 'benzodiazepine': 'a benzodiazepine', 'sedative': 'a sedative',
    'thyroid_hormone': 'a thyroid hormone medicine', 'raloxifene': 'raloxifene',
}

CONDITIONS = {
    'pregnancy': 'Pregnant, trying to conceive or breastfeeding',
    'surgery': 'Surgery or a procedure planned',
    'diabetes': 'Diabetes or blood-sugar problems',
    'heart_bp_kidney': 'High blood pressure, heart or kidney condition',
    'liver': 'Liver condition',
    'autoimmune_thyroid': 'Autoimmune or thyroid condition',
    'ragweed': 'Allergic to ragweed, daisies or marigolds',
    'hormone_sensitive': 'Hormone-sensitive condition (e.g. breast, uterine or prostate cancer)',
}

# ------------------------------------------------------------------- herbs
# level: 'discuss' = NIH names an interaction with this medicine/group;
#        'caution' = NIH describes conflicting/theoretical evidence or a
#                    condition-specific concern;
#        'note'    = product-quality or label caution.
# 'meds' lists class ids. 'conditions' lists condition ids.
HERBS = [
    dict(id='st-johns-wort', name="St. John's wort", page='st-johns-wort',
         aliases=["st john's wort", 'st johns wort', 'saint johns wort', "saint john's wort", 'st. john', 'hypericum', 'hypericum perforatum'],
         rules=[
             dict(level='discuss', meds=['sjw_antidepressant', 'oral_contraceptive', 'cyclosporine', 'sjw_anticonvulsant', 'digoxin', 'ivabradine', 'hiv', 'sjw_cancer', 'warfarin', 'simvastatin'],
                  quote="St. John’s wort can weaken the effects of many medicines, including crucially important medicines such as:",
                  items={'sjw_antidepressant': 'Some antidepressants, including amitriptyline and bupropion',
                         'oral_contraceptive': 'Birth control pills',
                         'cyclosporine': 'Cyclosporine, which prevents the body from rejecting transplanted organs',
                         'sjw_anticonvulsant': 'Some drugs used to prevent seizures, including phenytoin and carbamazepine',
                         'digoxin': 'Some heart medications, including digoxin and ivabradine',
                         'ivabradine': 'Some heart medications, including digoxin and ivabradine',
                         'hiv': 'Some HIV drugs, including indinavir and nevirapine',
                         'sjw_cancer': 'Some cancer medications, including irinotecan, imatinib, and docetaxel',
                         'warfarin': 'Warfarin, an anticoagulant (blood thinner)',
                         'simvastatin': 'Certain statins, including simvastatin'},
                  effect='may weaken the medicine'),
             dict(level='discuss', meds=['serotonergic'],
                  quote="taking St. John’s wort with certain antidepressants or other drugs that affect serotonin (a substance produced by some nerve cells) may lead to increased serotonin-related side effects, which can be serious.",
                  effect='serotonin-related side effects'),
             dict(level='discuss', always=True,
                  quote="St. John’s wort can interact in dangerous, sometimes life-threatening ways with a variety of medicines.",
                  effect='interacts with many medicines'),
             dict(level='caution', conditions=['pregnancy'],
                  quote="It may be unsafe to use St. John’s wort during pregnancy because it may increase the risk of birth defects."),
         ]),
    dict(id='ginkgo', name='Ginkgo', page='ginkgo', aliases=['ginkgo', 'ginkgo biloba', 'gingko', 'maidenhair tree'],
         rules=[
             dict(level='discuss', meds=['anticoagulant'],
                  quote='Ginkgo may increase the risk of bleeding in people who are taking anticoagulant drugs, such as warfarin.',
                  effect='bleeding risk'),
             dict(level='caution', conditions=['pregnancy'],
                  quote='It might cause early labor or extra bleeding during delivery if used near that time.'),
         ]),
    dict(id='goldenseal', name='Goldenseal', page='goldenseal', aliases=['goldenseal', 'golden seal', 'hydrastis', 'hydrastis canadensis'],
         rules=[
             dict(level='discuss', meds=['metformin'],
                  quote='For example, a study funded by the National Center for Complementary and Integrative Health (NCCIH) found that levels of metformin—the most commonly prescribed diabetes medicine—decreased about 25 percent in healthy adults who were given goldenseal extract plus metformin. This drop was enough to potentially hinder glucose control in people with type 2 diabetes taking metformin.',
                  effect='may lower metformin levels'),
             dict(level='discuss', always=True, quote='Goldenseal may change the way your body processes many medications.',
                  effect='changes how many medicines are processed'),
             dict(level='caution', conditions=['pregnancy'],
                  quote='Women who are pregnant or breastfeeding should not use goldenseal, and it should not be given to infants.'),
             dict(level='note', quote='Some commercial goldenseal products have been found to contain other herbs or ingredients not listed on the label in addition to or instead of goldenseal.'),
         ]),
    dict(id='red-yeast-rice', name='Red yeast rice', page='red-yeast-rice',
         aliases=['red yeast rice', 'monascus', 'monascus purpureus', 'red rice yeast', 'red mold rice', 'monacolin'],
         identity_note='Not a plant: a mold (Monascus purpureus) fermented on rice.',
         rules=[
             dict(level='discuss', meds=['statin'],
                  quote='Monacolin K is structurally identical to the medicine lovastatin.',
                  effect='same compound as a statin drug'),
             dict(level='discuss', meds=['statin'],
                  quote='Red yeast rice products can have the same types of drug interactions as statin drugs and therefore may interfere with certain medicines or increase the chance for side effects.',
                  effect='statin-type interactions'),
             dict(level='caution', conditions=['pregnancy'],
                  quote='Red yeast rice products are not recommended for those who are pregnant or lactating.'),
             dict(level='note', quote='Levels of monacolin K and lovastatin are not usually included on product labels.'),
         ]),
    dict(id='licorice', name='Licorice root', page='licorice-root',
         aliases=['licorice', 'liquorice', 'licorice root', 'glycyrrhiza', 'glycyrrhiza glabra', 'glycyrrhiza uralensis', 'glycyrrhizin'],
         variants=[dict(pattern=r'deglycyrrhizinated|\bdgl\b', label='Deglycyrrhizinated (DGL)',
                        quote='Oral licorice products that do not contain glycyrrhizin (deglycyrrhizinated licorice) might be safe for up to 4 months.')],
         rules=[
             dict(level='discuss', meds=['corticosteroid'], quote='Interactions between licorice and corticosteroids have been reported.',
                  effect='reported interaction'),
             dict(level='caution', conditions=['heart_bp_kidney'], meds=['bp_med'],
                  quote='Even small amounts of glycyrrhizin from licorice root products have been linked to severe adverse effects in people who consume a lot of salt, in people with hypertension, and in people with heart or kidney conditions.'),
         ]),
    dict(id='garlic', name='Garlic', page='garlic', aliases=['garlic', 'allium sativum', 'aged garlic', 'allicin'],
         rules=[
             dict(level='discuss', meds=['bleeding'],
                  quote='Taking garlic supplements may increase the risk of bleeding. If you take garlic supplements, make sure to tell your health care providers. This is especially important if you are going to have surgery or if you take medicines, such as anticoagulants or aspirin, that may also affect bleeding.',
                  effect='bleeding risk'),
             dict(level='caution', conditions=['surgery'], quote='Taking garlic supplements may increase the risk of bleeding.'),
         ]),
    dict(id='kava', name='Kava', page='kava', aliases=['kava', 'kava kava', 'piper methysticum', 'kavalactones', 'kavalactone'],
         rules=[
             dict(level='discuss', meds=['benzodiazepine', 'sedative'],
                  quote='Kava should not be used together with other substances that have sedative effects, such as benzodiazepines or alcohol.',
                  effect='added sedation'),
             dict(level='caution', always=True, conditions=['liver'],
                  quote='Various kava products have been linked to rare cases of liver injury, some of which have been serious or even fatal.'),
         ]),
    dict(id='green-tea', name='Green tea extract', page='green-tea',
         aliases=['green tea', 'green tea extract', 'camellia sinensis', 'egcg', 'epigallocatechin gallate', 'epigallocatechin'],
         rules=[
             dict(level='discuss', meds=['nadolol'],
                  quote='Green tea at high doses has been shown to reduce blood levels and, therefore, the effectiveness of the drug nadolol, a beta-blocker used for high blood pressure and heart problems.',
                  effect='may lower nadolol levels'),
             dict(level='discuss', meds=['atorvastatin'], quote='Green tea extract can reduce blood levels of the cholesterol-lowering drug atorvastatin.',
                  effect='may lower atorvastatin levels'),
             dict(level='discuss', meds=['raloxifene'],
                  quote='A study funded by the National Center for Complementary and Integrative Health showed an interaction between green tea and the drug raloxifene, which is used to treat osteoporosis.',
                  effect='reported interaction'),
             dict(level='caution', conditions=['liver'],
                  quote='Although uncommon, liver injury has been reported in some people who used green tea products, primarily green tea extracts in tablet or capsule form.'),
         ]),
    dict(id='asian-ginseng', name='Asian ginseng', page='asian-ginseng',
         aliases=['asian ginseng', 'panax ginseng', 'korean ginseng', 'chinese ginseng', 'red ginseng', 'white ginseng', 'korean red ginseng'],
         rules=[
             dict(level='caution', conditions=['diabetes'], meds=['diabetes_med'],
                  quote='If you have diabetes, consult your health care provider before using Asian ginseng.'),
             dict(level='caution', meds=['anticoagulant'], conditions=['autoimmune_thyroid'],
                  quote='Asian ginseng may worsen autoimmune disorders and interfere with blood clotting.'),
             dict(level='caution', conditions=['pregnancy'],
                  quote='Some studies of Asian ginseng suggest it may be unsafe when taken orally during pregnancy.'),
         ]),
    dict(id='turmeric', name='Turmeric / curcumin', page='turmeric',
         aliases=['turmeric', 'curcumin', 'curcuma longa', 'curcuminoids', 'curcuminoid'],
         variants=[dict(pattern=r'piperine|bioperine|black pepper|piper nigrum|phytosome|meriva|longvida|theracurmin|enhanced absorption|high absorption|bioavailab|nano',
                        label='Absorption-enhanced formulation',
                        quote='Highly bioavailable formulations of curcumin, which enhance the body’s ability to absorb the curcumin, may harm your liver.',
                        level='caution')],
         rules=[
             dict(level='caution', conditions=['liver'],
                  quote='Many curcumin products with increased bioavailability are on the market, and liver damage has been reported in some people who have consumed these bioavailable formulations.'),
             dict(level='caution', conditions=['pregnancy'], quote='The use of turmeric supplements during pregnancy may be unsafe.'),
         ]),
    dict(id='valerian', name='Valerian', page='valerian', aliases=['valerian', 'valeriana officinalis', 'valerian root'],
         rules=[
             dict(level='discuss', meds=['sedative'],
                  quote='Because it is possible (though not proven) that valerian might have a sleep-inducing effect, it should not be taken along with alcohol or sedatives.',
                  effect='added sedation'),
         ]),
    dict(id='ashwagandha', name='Ashwagandha', page='ashwagandha',
         aliases=['ashwagandha', 'withania', 'withania somnifera', 'indian ginseng', 'winter cherry'],
         rules=[
             dict(level='discuss', meds=['diabetes_med', 'bp_med', 'immunosuppressant', 'sedative', 'anticonvulsant', 'thyroid_hormone'],
                  quote='There is evidence that ashwagandha might interact with some medications, including those for diabetes and high blood pressure, medicines that decrease the immune system response (immunosuppressants), sedatives, anti-seizure medications (anticonvulsants), and thyroid hormone medications.',
                  effect='may interact'),
             dict(level='caution', conditions=['surgery', 'autoimmune_thyroid'],
                  quote='Ashwagandha is not recommended for people who are about to have surgery, or for those who have autoimmune or thyroid disorders.'),
             dict(level='caution', conditions=['pregnancy'], quote='Ashwagandha should be avoided during pregnancy and should not be used while breastfeeding.'),
             dict(level='caution', conditions=['liver'], quote='Although it is rare, there have been a number of cases that link liver injury to ashwagandha supplements.'),
         ]),
    dict(id='echinacea', name='Echinacea', page='echinacea',
         aliases=['echinacea', 'echinacea purpurea', 'echinacea angustifolia', 'echinacea pallida', 'purple coneflower'],
         rules=[
             dict(level='caution', meds=['immunosuppressant'],
                  quote='There is conflicting evidence about whether echinacea interacts with some drugs metabolized by the liver, and there are theoretical reasons to suspect that echinacea might interact with immunosuppressants or caffeine.'),
             dict(level='caution', conditions=['ragweed'], quote='However, some people have allergic reactions to echinacea, which may be severe.'),
         ]),
    dict(id='black-cohosh', name='Black cohosh', page='black-cohosh',
         aliases=['black cohosh', 'actaea racemosa', 'cimicifuga', 'cimicifuga racemosa', 'black snakeroot'],
         rules=[
             dict(level='caution', conditions=['liver'],
                  quote='Cases of liver damage—some very serious—have been reported in people taking products labeled as black cohosh.'),
             dict(level='caution', conditions=['pregnancy'], quote='Black cohosh may not be safe for use during pregnancy or while breastfeeding.'),
             dict(level='note', quote='Some commercial black cohosh products have been found to contain the wrong herb or to contain mixtures of black cohosh and other herbs that are not listed on the label.'),
         ]),
    dict(id='bitter-orange', name='Bitter orange', page='bitter-orange',
         aliases=['bitter orange', 'citrus aurantium', 'synephrine', 'p-synephrine', 'seville orange'],
         rules=[
             dict(level='caution', conditions=['heart_bp_kidney'], meds=['bp_med'],
                  quote='Cases of serious medical events, including abnormal heart rhythms, heart attacks, and strokes, have been reported in people who had taken bitter orange products, but most of the products contained multiple ingredients rather than bitter orange alone.'),
             dict(level='caution', conditions=['pregnancy'],
                  quote='It may not be safe to use bitter orange during pregnancy or while breastfeeding, and data from animal experiments suggest that substances in bitter orange might decrease milk production.'),
             dict(level='note', quote='Of 23 products with labels that stated the amount of synephrine in the product, only 5 contained amounts of synephrine close to that indicated on the label (between 80 and 120 percent of the stated amount).'),
         ]),
    dict(id='yohimbe', name='Yohimbe', page='yohimbe', aliases=['yohimbe', 'yohimbine', 'pausinystalia', 'pausinystalia johimbe', 'corynanthe johimbe'],
         rules=[
             dict(level='discuss', meds=['maoi', 'tca'],
                  quote='Do not use yohimbe if you are taking types of antidepressant medications called monoamine oxidase inhibitors or tricyclic antidepressants.',
                  effect='do not combine'),
             dict(level='caution', always=True, conditions=['heart_bp_kidney'],
                  quote='Yohimbine, a component of yohimbe, has been associated with cardiac arrhythmia (irregular heartbeat), blood pressure problems, heart attacks, and seizures.'),
             dict(level='caution', conditions=['pregnancy'], quote='It might be unsafe to use yohimbe orally (taken by mouth) during pregnancy or while breastfeeding.'),
         ]),
    dict(id='milk-thistle', name='Milk thistle', page='milk-thistle', aliases=['milk thistle', 'silybum', 'silybum marianum', 'silymarin', 'silibinin'],
         rules=[
             dict(level='caution', conditions=['ragweed'],
                  quote='Milk thistle may cause allergic reactions, particularly among people who are allergic to related plants (for example, ragweed, chrysanthemum, marigold, and daisy).'),
             dict(level='note', quote='Some products have been found to contain amounts of silymarin substantially different from what’s stated on the label or to be contaminated with pesticides, microorganisms, or mycotoxins (harmful substances produced by molds or other fungi).'),
         ]),
    dict(id='ginger', name='Ginger', page='ginger', aliases=['ginger', 'ginger root', 'zingiber', 'zingiber officinale'],
         rules=[]),
    dict(id='chamomile', name='Chamomile', page='chamomile',
         aliases=['chamomile', 'camomile', 'german chamomile', 'matricaria', 'matricaria recutita', 'matricaria chamomilla', 'chamomilla recutita'],
         rules=[
             dict(level='discuss', meds=['warfarin'],
                  quote='Interactions between chamomile and some drugs metabolized by the liver and warfarin (a blood thinner) have been reported, and there are theoretical reasons to suspect that chamomile might interact with other drugs as well, such as sedatives.',
                  effect='reported interaction'),
             dict(level='caution', meds=['oral_contraceptive'],
                  quote='Preliminary studies suggest that taking chamomile along with birth control pills might decrease the effects of birth control pills.'),
             dict(level='caution', meds=['sedative'],
                  quote='Interactions between chamomile and some drugs metabolized by the liver and warfarin (a blood thinner) have been reported, and there are theoretical reasons to suspect that chamomile might interact with other drugs as well, such as sedatives.'),
             dict(level='caution', conditions=['ragweed'],
                  quote='People are more likely to experience allergic reactions to chamomile if they’re allergic to related plants such as ragweed, chrysanthemums, marigolds, or daisies.'),
             dict(level='caution', conditions=['hormone_sensitive'],
                  quote='In addition, chamomile might worsen any condition that is sensitive to exposure to estrogen, such as breast or uterine cancer.'),
         ]),
    dict(id='hawthorn', name='Hawthorn', page='hawthorn', aliases=['hawthorn', 'hawthorne', 'crataegus', 'tejocote', 'shanzha'],
         variants=[dict(pattern=r'tejocote|crataegus mexicana|mexican hawthorn', label='Labeled “tejocote root”',
                        quote='In January 2024, the FDA published a list of products, including dietary supplements labeled “tejocote root” (C. mexicana), that actually contain yellow oleander, a toxic plant known to cause harm to the nervous system, heart, stomach, and intestines.',
                        level='discuss')],
         rules=[
             dict(level='caution', meds=['digoxin', 'bp_med'], conditions=['heart_bp_kidney'],
                  quote='It’s unclear why, but one possibility is that hawthorn might have interacted with drugs the patients were taking.'),
         ]),
    dict(id='fenugreek', name='Fenugreek', page='fenugreek', aliases=['fenugreek', 'trigonella', 'trigonella foenum-graecum'],
         rules=[
             dict(level='caution', meds=['diabetes_med'], conditions=['diabetes'], quote='Large doses may cause a harmful drop in blood sugar.'),
             dict(level='caution', conditions=['pregnancy'],
                  quote='Fenugreek is not safe for use during pregnancy in amounts greater than those found in food; its use has been linked to increased risks of birth defects in both animals and people.'),
         ]),
    dict(id='cranberry', name='Cranberry', page='cranberry', aliases=['cranberry', 'vaccinium macrocarpon', 'cranberry extract'],
         rules=[
             dict(level='caution', meds=['warfarin'],
                  quote='There is conflicting evidence about whether cranberry interacts with the anticoagulant (blood thinner) warfarin.'),
         ]),
    dict(id='passionflower', name='Passionflower', page='passionflower', aliases=['passionflower', 'passion flower', 'passiflora', 'passiflora incarnata', 'maypop'],
         rules=[
             dict(level='caution', conditions=['surgery'],
                  quote='Passionflower might interact with some anesthesia drugs, so avoid its use before surgery unless recommended by a health care provider.'),
             dict(level='caution', conditions=['pregnancy'],
                  quote='Passionflower should not be used during pregnancy as it may induce uterine contractions and possibly lead to other problems.'),
         ]),
    dict(id='peppermint-oil', name='Peppermint oil', page='peppermint-oil',
         aliases=['peppermint', 'peppermint oil', 'mentha piperita', 'mentha x piperita', 'mentha × piperita'],
         rules=[
             dict(level='note', quote='Capsules containing peppermint oil are often enteric-coated to reduce the likelihood of heartburn.'),
         ]),
    dict(id='saw-palmetto', name='Saw palmetto', page='saw-palmetto', aliases=['saw palmetto', 'serenoa', 'serenoa repens', 'sabal'],
         rules=[
             dict(level='caution', conditions=['pregnancy'], quote='Saw palmetto may be unsafe for use during pregnancy or while breastfeeding.'),
         ]),
]

GENERAL_QUOTE = 'some herbs and medicines interact in harmful ways.'

# ------------------------------------------------- name ambiguity (identity)
# A bare common name that can denote different species. The checker never
# picks one; it shows each candidate and which NIH page (if any) applies.
AMBIGUOUS = [
    dict(term='ginseng', pattern=r'\bginseng\b',
         qualified=r'(asian|korean|chinese|red|white|american|siberian|indian|brazilian|peruvian)\s+ginseng|panax|eleuthero',
         candidates=[
             dict(species='Panax ginseng', common='Asian / Korean ginseng', herb='asian-ginseng'),
             dict(species='Panax quinquefolius', common='American ginseng', herb=None),
             dict(species='Eleutherococcus senticosus', common='“Siberian ginseng” (eleuthero), a different genus', herb=None),
         ],
         source_quote='Asian ginseng is one of several types of ginseng.', source_page='asian-ginseng'),
    dict(term='mint', pattern=r'\bmint\b', qualified=r'(pepper|spear|corn|water)\s*mint|mentha',
         candidates=[
             dict(species='Mentha × piperita', common='Peppermint', herb='peppermint-oil'),
             dict(species='Mentha spicata', common='Spearmint', herb=None),
             dict(species='Mentha arvensis', common='Corn mint', herb=None),
         ],
         source_quote=None, source_page=None),
    dict(term='chamomile', pattern=r'\bc(h)?amomile\b', qualified=r'(german|roman)\s+c(h)?amomile|matricaria|chamaemelum|anthemis|chamomilla',
         candidates=[
             dict(species='Matricaria chamomilla', common='German chamomile', herb='chamomile'),
             dict(species='Chamaemelum nobile', common='Roman chamomile', herb=None),
         ],
         source_quote='There are two types of chamomile: German chamomile and Roman chamomile.', source_page='chamomile'),
    dict(term='cohosh', pattern=r'\bcohosh\b', qualified=r'(black|blue)\s+cohosh|actaea|cimicifuga|caulophyllum',
         candidates=[
             dict(species='Actaea racemosa', common='Black cohosh', herb='black-cohosh'),
             dict(species='Caulophyllum thalictroides', common='Blue cohosh — a different herb', herb=None),
         ],
         source_quote='Blue cohosh may cause adverse effects such as high blood pressure, high blood sugar, and chest pain.', source_page='black-cohosh'),
]

# Botanical words that suggest an herb we have not verified (shown as coverage gaps).
UNVERIFIED_HINTS = ['ashitaba', 'astragalus', 'bacopa', 'boswellia', 'burdock', 'cat\'s claw', 'cayenne', 'cinnamon',
    'dandelion', 'dong quai', 'elderberry', 'eleuthero', 'evening primrose', 'feverfew', 'gotu kola', 'guarana',
    'hops', 'horny goat weed', 'horse chestnut', 'lemon balm', 'maca', 'moringa', 'motherwort', 'nettle',
    'olive leaf', 'oregano', 'pau d\'arco', 'pygeum', 'rhodiola', 'rosemary', 'schisandra', 'skullcap', 'slippery elm',
    'spirulina', 'tribulus', 'uva ursi', 'white willow', 'yarrow', 'yerba mate', 'american ginseng', 'siberian ginseng',
    'panax quinquefolius', 'eleutherococcus', 'eleutherococcus senticosus', 'caulophyllum', 'chamaemelum', 'roman chamomile',
    'mentha spicata', 'mentha arvensis', 'valeriana wallichii',
    'spearmint', 'blue cohosh', 'roman chamomile', 'berberine', 'quercetin', 'resveratrol', 'aloe', 'senna',
    'cascara', 'chasteberry', 'vitex', 'damiana', 'kratom', 'kanna', 'mucuna', 'black seed', 'nigella', 'garcinia',
    'forskolin', 'coleus', 'gymnema', 'bitter melon', 'holy basil', 'tulsi', 'shatavari', 'triphala', 'amla',
    'lion\'s mane', 'reishi', 'cordyceps', 'chaga', 'turkey tail', 'beetroot', 'grape seed', 'pine bark', 'bilberry',
    'lutein', 'marshmallow root', 'mullein', 'licorice', 'angelica', 'lavender', 'lemon verbena', 'linden',
    'pomegranate', 'sea buckthorn', 'tongkat ali', 'fadogia', 'yohimbine', 'hibiscus', 'butterbur', 'kudzu']


def norm(text: str) -> str:
    text = html.unescape(text)
    text = text.replace('’', "'").replace('‘', "'").replace('“', '"').replace('”', '"')
    text = text.replace('—', '-').replace('–', '-').replace('\xa0', ' ')
    return re.sub(r'\s+', ' ', text).strip()


def page_text(raw: str) -> str:
    m = re.search(r'<main.*?</main>', raw, re.S)
    body = m.group(0) if m else raw
    body = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', body, flags=re.S)
    body = re.sub(r'<[^>]+>', ' ', body)
    return norm(body)


def fetch(slug: str, offline: bool) -> str:
    path = CACHE / f'{slug}.html'
    if not offline:
        req = urllib.request.Request(BASE + slug, headers={'User-Agent': 'Mozilla/5.0 (FoliaTrace source verification)'})
        with urllib.request.urlopen(req, timeout=40) as r:
            CACHE.mkdir(parents=True, exist_ok=True)
            path.write_bytes(r.read())
    return path.read_text(encoding='utf-8', errors='ignore')


def names_from(text: str, label: str) -> list[str]:
    m = re.search(label + r':\s*(.*?)\s+(?:Latin Names:|Common Names:|Background\b)', text)
    if not m:
        return []
    raw = m.group(1)
    if label == 'Latin Names':
        # "Curcuma longa , synonym Curcuma domestica; ..." / "X (also known as Y )" -> separate binomials
        raw = re.sub(r'\(\s*(?:synonyms?|also known as)\s*([^)]*)\)', r', \1', raw)
        raw = re.sub(r'\b(?:synonyms?|also known as)\b', ',', raw)
        names = [n.strip(' .') for n in re.split(r'[,;]', raw)]
        return [n for n in names if re.fullmatch(r'[A-Z][a-z]+ (?:x |× )?[a-z][a-z-]+', n)]
    return [n.strip(' .') for n in re.split(r',\s*', raw) if 1 < len(n.strip()) < 60]


def main() -> None:
    offline = '--offline' in sys.argv
    today = date.today().isoformat()
    pages, checks, failures = {}, 0, []
    for herb in HERBS:
        slug = herb['page']
        raw = fetch(slug, offline)
        text = page_text(raw)
        if 'public domain' not in text:
            failures.append(f'{slug}: public-domain statement not found')
        updated = re.search(r'Last Updated:\s*([A-Za-z]+ \d{4})', text)
        title = re.search(r'og:title" content="([^"]+)"', raw)
        pages[slug] = dict(url=BASE + slug, title=norm(title.group(1)) if title else herb['name'],
                           updated=updated.group(1) if updated else None, retrieved=today,
                           text_sha256=hashlib.sha256(text.encode()).hexdigest(),
                           common_names=names_from(text, 'Common Names'), latin_names=names_from(text, 'Latin Names'))
        quotes = [r['quote'] for r in herb['rules']] + [v['quote'] for v in herb.get('variants', [])]
        quotes += [item for r in herb['rules'] for item in r.get('items', {}).values()]
        for q in quotes:
            checks += 1
            if norm(q) not in text:
                failures.append(f'{slug}: quote not found verbatim: {q[:90]}')
        pages[slug]['general_advice'] = norm(GENERAL_QUOTE) in text
    for amb in AMBIGUOUS:
        if amb['source_quote']:
            checks += 1
            if norm(amb['source_quote']) not in page_text(fetch(amb['source_page'], True)):
                failures.append(f"ambiguity {amb['term']}: quote not found")
    meds_by_alias = {}
    for name, aliases, classes in MEDS:
        for c in classes:
            if c not in CLASS_LABELS:
                failures.append(f'unknown class {c} for {name}')
        for alias in [name] + aliases:
            key = norm(alias).lower()
            if key in meds_by_alias and meds_by_alias[key] != name:
                failures.append(f'duplicate medicine alias {alias}')
            meds_by_alias[key] = name
    for herb in HERBS:
        for r in herb['rules']:
            for c in r.get('meds', []):
                if c not in CLASS_LABELS:
                    failures.append(f"{herb['id']}: unknown class {c}")
            for c in r.get('conditions', []):
                if c not in CONDITIONS:
                    failures.append(f"{herb['id']}: unknown condition {c}")
    if failures:
        print('\n'.join(failures))
        raise SystemExit(f'{len(failures)} verification failure(s); nothing written.')
    herbs_out = []
    for herb in HERBS:
        p = pages[herb['page']]
        alias = sorted({norm(a).lower() for a in herb['aliases'] + p['common_names'] + p['latin_names'] if len(a) > 2}, key=len, reverse=True)
        # Generic words that would over-match are kept out of automatic aliases.
        # NCCIH common names that other species also use ('bearberry' is often uva ursi, 'holy thistle'
        # often blessed thistle, 'golden root' rhodiola) are excluded rather than over-matched.
        alias = [a for a in alias if a not in {'ginseng root', 'ginseng', 'chamomile', 'mint', 'orange', 'tea', 'root',
                                               'bearberry', 'holy thistle', 'yellow root', 'goldenroot', 'coneflower',
                                               'awa', 'kawa', 'sweet root', 'water lemon', 'all-heal'}]
        herbs_out.append(dict(id=herb['id'], name=herb['name'], aliases=alias, latin=p['latin_names'],
                              identity_note=herb.get('identity_note'), source=herb['page'],
                              variants=herb.get('variants', []), rules=herb['rules']))
    passages = {norm(q) for h in HERBS for q in [r['quote'] for r in h['rules']] + [v['quote'] for v in h.get('variants', [])]
                + [i for r in h['rules'] for i in r.get('items', {}).values()]} | {norm(a['source_quote']) for a in AMBIGUOUS if a['source_quote']}
    payload = dict(
        version='2026.11.12', built=today, verified_passages=len(passages),
        scope='Statements quoted verbatim from NCCIH “Usefulness and Safety” fact sheets (U.S. National Institutes of Health; public domain). '
              'Only medicines or groups that a quoted sentence names are matched. Not finding a statement does not mean a combination is safe.',
        general_quote=GENERAL_QUOTE,
        sources=pages,
        conditions=CONDITIONS,
        class_labels=CLASS_LABELS,
        medicines=[dict(name=n, aliases=a, classes=c) for n, a, c in MEDS],
        herbs=herbs_out,
        ambiguous=AMBIGUOUS,
        unverified_hints=sorted(set(UNVERIFIED_HINTS)),
    )
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
    REPORT.parent.mkdir(exist_ok=True)
    REPORT.write_text(json.dumps(dict(
        built=today, mode='offline-cache' if offline else 'live-download', pages=len(pages), herbs=len(HERBS),
        medicines=len(MEDS), medicine_aliases=len(meds_by_alias), quote_checks=checks, unique_verified_passages=len(passages), failures=0,
        sources={k: {kk: v[kk] for kk in ('url', 'updated', 'retrieved', 'text_sha256')} for k, v in pages.items()},
        method='Each quotation is normalised only for whitespace and typographic quotes/dashes, then required to occur in the page body text.'),
        indent=1) + '\n', encoding='utf-8')
    print(f'OK {len(HERBS)} herbs, {len(MEDS)} medicines ({len(meds_by_alias)} names), {checks} verbatim checks, {len(passages)} unique passages -> {OUT.relative_to(ROOT)}')


if __name__ == '__main__':
    main()

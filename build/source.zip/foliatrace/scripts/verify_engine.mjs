// Run the behavioral tests and retain a small, machine-readable release report.
import {spawnSync} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
const result=spawnSync(process.execPath,['--test','--test-reporter=tap','tests/safety_engine.test.mjs','tests/research_evidence.test.mjs'],{encoding:'utf8',windowsHide:true});
const count=key=>Number(result.stdout.match(new RegExp('^# '+key+' (\\d+)$','m'))?.[1]||0);
const report={created:new Date().toISOString(),status:result.status===0?'PASS':'FAIL',tests:count('tests'),passed:count('pass'),failed:count('fail'),runner:'node --test; medicine matching, exclusions, source quotes and research evidence invariants'};
await writeFile('reports/engine_tests_2026-11-12.json',JSON.stringify(report,null,1)+'\n');
console.log(JSON.stringify(report));process.exitCode=result.status||0;

"""Acquire the original published SciFact corpus and existing human annotations."""
import io
import sys
import tarfile
from pathlib import Path
from urllib.request import urlopen
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import ROOT, write_json, digest, now
from src.ingestion.tls import tls_context


def main():
    base = ROOT / 'benchmark/scifact'
    base.mkdir(parents=True, exist_ok=True)
    url = 'https://scifact.s3-us-west-2.amazonaws.com/release/latest/data.tar.gz'
    with urlopen(url, context=tls_context(), timeout=90) as response:
        body = response.read(50_000_001)
    if len(body) > 50_000_000:
        raise ValueError('Dataset archive exceeds size bound')
    files = {}
    with tarfile.open(fileobj=io.BytesIO(body), mode='r:gz') as tar:
        for name in ('corpus.jsonl', 'claims_train.jsonl', 'claims_dev.jsonl'):
            member = next(m for m in tar.getmembers() if m.name.split('/')[-1] == name and m.isfile())
            if member.size > 40_000_000:
                raise ValueError('Dataset member exceeds bound')
            data = tar.extractfile(member).read()
            (base / name).write_bytes(data)
            files[name] = {'sha256': digest(data), 'bytes': len(data)}
    write_json(base / 'manifest.json', {'created_at': now(), 'url': url, 'archive_sha256': digest(body), 'files': files, 'authors': 'David Wadden, Shanchuan Lin, Kyle Lo, Lucy Lu Wang, Madeleine van Zuylen, Arman Cohan, Hannaneh Hajishirzi', 'citation': 'Fact or Fiction: Verifying Scientific Claims, EMNLP 2020', 'rights_url': 'https://github.com/allenai/scifact/blob/master/LICENSE.md', 'licences': {'claims_and_annotations': 'CC-BY-4.0', 'abstract_database': 'ODC-By-1.0'}, 'scope': 'Independent biomedical document retrieval component evaluation; not historical-use extraction or clinical validity. Use only claims with annotated evidence, not cited_doc_ids as relevance.'})
    print('Acquired original SciFact:', list(files), flush=True)


if __name__ == '__main__':
    main()

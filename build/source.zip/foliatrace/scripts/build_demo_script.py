"""Build the AI-first demo script and recording narration from release reports."""
import json
import re
from pathlib import Path
from product_metrics import release_metrics

ROOT=Path(__file__).resolve().parents[1]


def main():
    m=release_metrics();h=m['held'];c=h['counts']
    scenes=[]
    def add(chapter,visual,vo,selectors=''):
        tts=vo.replace('FoliaTrace AI','Folia Trace AI').replace('Ginkgo','Ghingko').replace('ginkgo','ghingko').replace('Coumadin','Coomadin').replace('Mei','May').replace('NIH','N I H').replace('QR','Q R')
        scenes.append(dict(id=len(scenes)+1,chapter=chapter,visual=visual,sub=vo,tts=tts,selectors=selectors))
    add('The gap','兩張統計字卡慢慢出現；保留 CDC 2017–18 與 NHIS 2002 的來源及年份。','More than half of American adults use supplements. In a national survey, only one in three herb and supplement users told a conventional healthcare provider.')
    add('The gap','人物字卡：藥盒旁出現 “my cholesterol pill”。不要一開始堆醫療警告。','People do not always remember medicine names. A medicine list cannot match a description such as my cholesterol pill.')
    add('FoliaTrace AI','首頁品牌與主張；先框住語言理解，再框住 bottle and goal。','FoliaTrace AI understands medicine descriptions, finds research for your bottle and goals, and builds a brief your pharmacist can check. Both language and research AI run on your device.','#hero-title,.lead')
    add('Mei · language AI','框住 Mei 的 “her water pill”；停一下讓觀眾讀。','Meet Mei. She is seventy two, takes warfarin and what she calls her water pill. Her daughter bought her a supplement for memory and joints.','[data-example=mei]')
    add('Mei · language AI','點 Run check，等簡報；框住人話 → 藥物群組，展開 evidence trail。','The language AI reads her water pill as a likely blood-pressure medicine group. The exact medicine becomes a question for the pharmacist. Here is the AI result in the brief.','[data-example=mei] .ex-go,.ai-understanding,.inference-trace')
    add('Mei · source-linked brief','由 AI 假設平滑捲到摘要，再到兩張來源卡。','The brief keeps the AI result visible, then connects her named medicines to the ingredients in her bottle. Raise these first.','#brief-summary')
    add('Mei · NIH evidence','框住 Ginkgo × Warfarin 及 Garlic × Warfarin。','Here are ginkgo and garlic, each paired with warfarin. The cards quote the NIH statements that name this medicine or its group.','.finding.discuss')
    add('Mei · NIH evidence','先出現 “Opens NIH’s website”，再點銀杏來源。','AI understands and finds evidence. It does not write warnings. This sentence comes directly from the National Institutes of Health. Open the source.','.nih-source a')
    add('Mei · NIH evidence','NIH 網頁淡入；用橘色標記同一句原文，停留。','There it is on NIH’s own page. The same words, with the source one click away. That boundary is built into the product.')
    add('Mei · questions','返回網站先提示再淡入；框 Ask，點 Copy my questions。','Back in the brief, each card becomes a question for Mei to ask her pharmacist. One click copies the questions.','#copy-questions,.ask')
    add('Mei · identity gaps','框 ginseng 候選物種，逐一移動；不稱為 AI 身分辨識。','The label also says ginseng root. That can describe different plants. FoliaTrace AI keeps the candidate identities open and shows which NIH statements would apply.','.gap.identity')
    add('Mei · label gaps','框複方總量與 BioPerine/curcumin 卡；不念額外醫療結論。','It keeps other gaps visible too: a blend with no amount for each herb, and a formulation detail the pharmacist should check. Missing information does not disappear.','.gap-list,.finding.caution')
    add('Sam · quick check','回三個人物；點 Sam；讓來源卡出現。','Sam takes sertraline and birth control pills, and bought a mood supplement containing St. John’s wort. Here is the same source-linked workflow for a different person.','[data-example=sam]')
    add('Sam · quick check','框 Birth control pill、NIH list item、Sertraline；之後馬上進 Ray。','The NIH cards identify the named medicine groups and keep the original wording. The questions are ready for a pharmacist to review.','.finding.discuss')
    add('Ray · why AI matters','框 Ray 故事中的 “my cholesterol pill”，再點 Run。','Now Ray, sixty one. He knows his diabetes medicine, but remembers his other medicine only as my cholesterol pill. An exact-name lookup cannot identify that description.','[data-example=ray]')
    add('Ray · why AI matters','先展開 AI evidence trail，再平滑移到 Red yeast rice × my cholesterol pill，框 AI 標籤與 NIH 原文。','Language AI suggests a statin group, connecting his words to the NIH red yeast rice card. First, no name match. Then an AI group match. Then a verified source. The pharmacist confirms the exact drug.','.ai-understanding,.inference-trace,.finding.discuss')
    add('Your bottle','Erase，Search NIH labels，輸入 ginkgo，點 Search；真實 API。','Your own bottle starts here. Search the NIH label database by product or ingredient. This is a live lookup, not a replay.','#clear-all,#dsld-q,#dsld-form')
    add('Your bottle','等待結果，選 Add，框標籤編號與成分；不得用錄製資料假裝 live。','Choose the matching label. Its recorded ingredients and scientific names are added with the NIH record link.','#dsld-results,.product-card')
    add('Optional photo input','展示虛構標籤照片，再上傳，等 editable text。','Or photograph the ingredient panel. Text recognition reads it on your device. You check and correct the text before adding it.','#tab-photo,#photo-input')
    add('Optional photo input','框 editable textarea 與 Type or paste；Add product。','You can also type or paste a label. All three paths lead to the same ingredient and evidence workflow.','#text-form,#tab-text')
    add('Names and descriptions','輸入 Coumadin；框已解析的 warfarin。','For medicine names, brands work too. Coumadin resolves to warfarin through the name dictionary, before the language model is needed.','#med-input,#med-list')
    add('Names and descriptions','輸入 zolpidm 但旁白不念該字；再輸入 my blood pressure pill，等待 AI chip。','A typo can still find the sleep medicine. A description such as my blood pressure pill uses language AI. When the model is unsure, the description stays unrecognised for the pharmacist.','#med-input,#med-list .chip.ai')
    add('Your goal','在 purpose 欄輸入 sleep；選 surgery；Build。','Add what you want the supplement to help with, such as sleep. That goal guides the research AI. Add a relevant situation, then build the brief.','#reason-input,#condition-list,#run-check')
    add('Your brief','框來源卡與重複成分；不重念前面所有警告。','Here are the source cards, the AI medicine match and ingredients repeated across bottles. The brief brings them together without pretending every uncertainty is settled.','#brief,.gap-list')
    add('Pharmacist handoff','點 Hand to pharmacist；QR 完整出現。','At the pharmacy, tap Hand to pharmacist. FoliaTrace AI puts the brief inside a QR link.','#show-handoff,#handoff-qr')
    add('Pharmacist handoff','提示 “Pharmacist’s computer” 後切到新視窗；顯示 shared banner。','The pharmacist opens the same brief and sources on their screen. The data travels inside the link. No account or uploaded patient record is required.','#shared-banner')
    add('Private exports','取消 My medicines，顯示匯出內容已去掉個人藥名；恢復全部勾選再看帶 QR 的列印。','For paper or download, choose what to include. Excluding medicines removes personal medicine details from the cards and questions too. Include everything if you want the printed QR handoff.','.share-choice,#download-brief,#print-brief')
    add('Research AI · personal goal','回同一簡報，等 Ranked；捲到 AI research leads，框 valerian 與 matched goal。','The research is already ranked for the herbs in this bottle and the goal sleep. The model reads candidate studies and orders the closest matches. Unrelated results are left out.','#ai-research')
    add('Research AI · exact context','展開 live lead 的 Compare source wording；依序框 Your label、Population、Preparation、Comparator。','Open a lead. Compare the actual label with the study’s own population, preparation and comparator wording. AI ranks the study; literal excerpts let the pharmacist judge the differences.','.lead-context')
    add('Research AI · deeper review','到 For pharmacists，示範自由問題搜尋；先呈現查詢與 AI 結果，再開啟明確標為 replay 的七維比較。','A pharmacist can ask a different research question and run the AI search on their computer. Here, we search for valerian and sleep studies in adults. The five separate examples are labelled replays. Open one to compare the product and study across seven details, including dose and preparation.','#live-form,#live-results,#evidence')
    add('Measured language AI','語言測試字卡；Synthetic English phrases 必須與數字一起出現。',f'On a fresh test of {h["phrases"]} synthetic English phrases, {c["correct_group"]} of {h["drug_phrases"]} medicine descriptions reached the correct group. There were {c["wrong_group"]} wrong group assignments. The rest stayed unknown, and all {c["correctly_unassigned"]} other or negated descriptions remained unassigned.')
    add('Measured research AI','AI proof 表：keyword → hybrid → reranking；保留 full local component / SciFact 範圍。','In a separate test using studies labelled by people, AI ranking brings relevant papers nearer the top. This checks the full local research system. The methods and results come with the code.','.ai-proof')
    add('FoliaTrace AI','新版品牌收尾；網址與免費、不需帳號；停留三秒。','FoliaTrace AI. Your words, your bottle, evidence your pharmacist can check. Bring the bottle. Start a better conversation.')
    assert len(scenes)==33
    payload=dict(product='FoliaTrace AI',target='about 6–7 minutes; preserve the approved slow, visible pace',scenes=scenes,
                 proof=dict(phrases=h['phrases'],correct=c['correct_group'],drugs=h['drug_phrases'],wrong=c['wrong_group'],unassigned=c['correctly_unassigned'],library=m['library']))
    out=ROOT/'.runtime/video/ai-demo-script.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(payload,ensure_ascii=False,indent=1)+'\n',encoding='utf-8')
    lines=['# FoliaTrace AI — demo script','',
           '約 6–7 分鐘。英文旁白；沿用使用者滿意的上一版節奏與效果：慢速操作、點擊前橘框、大水波紋、章節標籤、平滑捲動與切頁提示。先展示 AI 真正處理的輸入與結果，再展示來源與交接，不為壓縮片長而加速。',
           '', '開場 40 秒內必須說出並展示：人話用藥理解、瓶子與目的驅動的研究、裝置端執行。OCR 是可選輸入方式。',
           '', '數字由評估報告讀取。語言評估標示 synthetic English phrases；研究元件評估標示 separate full-local SciFact benchmark。不能說「臨床驗證」「AI 證明安全」，不能把 Ray 的藥物假設說成已確認 statin。',
           '', '錄製準則：每個點擊先讓目標穩定再畫框；待模型完成才指向結果；第一次開外站先提示；原句與 AI 結果要同框；錄製比較保留 replay 標示。不要以 mock NIH 當正式錄影。', '']
    for s in scenes:
        lines += [f'## {s["id"]:02d} · {s["chapter"]}', '', f'**畫面：** {s["visual"]}', '', f'**VO / 字幕：** {s["sub"]}', '']
    lines += ['## 製作與一致性','', '`python scripts/build_demo_script.py` 重新產生本文件及錄影旁白資料；`.runtime/video/make-video-ai.mjs --script-only` 驗證 33 個場景。正式錄製前每句使用 `tts.py check` 核對。', '',
              '發音：FoliaTrace AI → “Folia Trace AI”；Mei → “May”；Ginkgo → “Ghingko”；Coumadin → “Coomadin”；NIH → “N I H”；QR → “Q R”。不念 zolpidem。', '']
    (ROOT/'docs/demo_video_script.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Built 33 AI-first scenes; narration words:',sum(len(re.findall(r"\S+",s['sub'])) for s in scenes))


if __name__=='__main__':main()

"""Everyday-language medicine groups for FoliaTrace's on-device AI, and their evaluation.

The browser embeds what a person typed ("my blood pressure pill") with all-MiniLM-L6-v2 and compares
it with each group description below. A group is used only at cosine >= THRESHOLD; otherwise the
medicine stays "not recognised" and goes to the pharmacist. Groups map only to KB classes that a
quoted NIH sentence names, so an AI-understood group can trigger exactly the same NIH statements.

  python scripts/ai_medicine_groups.py      # evaluate on the development and held-out phrase sets
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
THRESHOLD = 0.55  # v2: calibrated on expanded development phrases, never on held-out results
MARGIN = 0.06

GROUPS = [
    dict(id='blood_thinner', label='a blood thinner (anticoagulant)', classes=['anticoagulant', 'bleeding'],
         description='A blood thinner (anticoagulant) such as warfarin, Coumadin, Eliquis or Xarelto, taken to prevent blood clots and stroke.'),
    dict(id='aspirin', label='daily aspirin', classes=['aspirin', 'bleeding'],
         description='Daily low-dose aspirin, a baby aspirin taken for the heart.'),
    dict(id='birth_control', label='birth control pills', classes=['oral_contraceptive'],
         description='Birth control pills, oral contraceptives taken to prevent pregnancy.'),
    dict(id='antidepressant', label='an antidepressant', classes=['serotonergic'],
         description='An antidepressant for depression or anxiety, such as an SSRI like Zoloft, Prozac or Lexapro.'),
    dict(id='sleep', label='a sleeping pill or sedative', classes=['sedative'],
         description='A sleeping pill or sedative for insomnia, such as Ambien, or a benzodiazepine like Xanax or Valium.'),
    dict(id='seizure', label='an anti-seizure medicine', classes=['anticonvulsant'],
         description='An anti-seizure medicine for epilepsy, such as Keppra, Dilantin or Lamictal.'),
    dict(id='cholesterol', label='a statin (cholesterol medicine)', classes=['statin'],
         description='A statin to lower cholesterol, such as Lipitor, Crestor or Zocor.'),
    dict(id='diabetes', label='a diabetes medicine', classes=['diabetes_med'],
         description='A diabetes medicine to lower blood sugar, such as metformin, insulin or Ozempic.'),
    dict(id='blood_pressure', label='a blood-pressure medicine', classes=['bp_med'],
         description='A blood pressure medicine for hypertension, such as lisinopril, amlodipine, losartan, a beta blocker or a water pill (diuretic).'),
    dict(id='steroid', label='a steroid (corticosteroid)', classes=['corticosteroid'],
         description='A steroid pill such as prednisone, taken for inflammation, asthma flare-ups or arthritis.'),
    dict(id='thyroid', label='a thyroid hormone medicine', classes=['thyroid_hormone'],
         description='Thyroid hormone pills, such as levothyroxine or Synthroid, for an underactive thyroid.'),
    dict(id='transplant', label='an anti-rejection medicine (immunosuppressant)', classes=['immunosuppressant'],
         description='An anti-rejection medicine after an organ transplant, an immunosuppressant such as tacrolimus or cyclosporine.'),
    dict(id='hiv', label='an HIV medicine', classes=['hiv'], description='HIV medicine, antiretroviral therapy.'),
]

PROTOTYPES = {
    'blood_thinner': ['Blood thinning medicine to prevent blood clots.'],
    'aspirin': ['Aspirin taken daily in a low dose for the heart.'],
    'birth_control': ['Contraceptive medicine to prevent pregnancy.'],
    'antidepressant': ['Antidepressant medicine prescribed for depression and anxiety.'],
    'sleep': ['Prescription sleeping medicine for insomnia.'],
    'seizure': ['Anticonvulsant medicine to prevent seizures and epileptic fits.'],
    'cholesterol': ['Cholesterol lowering medicine, a statin tablet.'],
    'diabetes': ['Medicine for diabetes to control blood sugar.'],
    'blood_pressure': ['A water pill, a diuretic medicine that helps remove excess fluid.',
                       'Medicine to lower high blood pressure and treat hypertension.'],
    'steroid': ['Corticosteroid tablets to treat inflammation.'],
    'thyroid': ['Thyroid hormone replacement for an underactive thyroid.'],
    'transplant': ['Immunosuppressant medicine to prevent rejection after organ transplant.'],
    'hiv': ['Antiretroviral medicines to treat HIV.'],
}
for group in GROUPS:
    group['prototypes'] = PROTOTYPES[group['id']]

DEV = [
    ('my blood thinner', 'blood_thinner'), ('pill to stop blood clots', 'blood_thinner'), ('the clot medicine after my stroke', 'blood_thinner'),
    ('baby aspirin every morning', 'aspirin'), ('aspirin for my heart', 'aspirin'),
    ('the pill', 'birth_control'), ('my contraceptive', 'birth_control'), ('pill so I don’t get pregnant', 'birth_control'),
    ('my antidepressant', 'antidepressant'), ('pill for depression', 'antidepressant'), ('something for my mood and anxiety', 'antidepressant'),
    ('my sleeping pill', 'sleep'), ('something to help me sleep at night', 'sleep'),
    ('epilepsy medicine', 'seizure'), ('pill for my seizures', 'seizure'),
    ('my cholesterol pill', 'cholesterol'), ('statin', 'cholesterol'),
    ('my sugar pill', 'diabetes'), ('diabetes medication', 'diabetes'), ('insulin shots', 'diabetes'),
    ('my blood pressure pill', 'blood_pressure'), ('water pill', 'blood_pressure'), ('pill for high blood pressure', 'blood_pressure'),
    ('steroids for my arthritis', 'steroid'), ('prednisone pack', 'steroid'),
    ('thyroid pill', 'thyroid'), ('hormone for my thyroid', 'thyroid'),
    ('anti-rejection pills for my kidney transplant', 'transplant'), ('HIV meds', 'hiv'),
    ('painkiller for my back', None), ('antibiotics', None), ('allergy pill', None), ('vitamin D', None), ('antacid for heartburn', None), ('my inhaler', None),
]
DEV += [('my water pill', 'blood_pressure'), ('her water pill', 'blood_pressure'),
        ('the tablet to get rid of extra fluid', 'blood_pressure'),
        ('I take a pill to keep my cholesterol down', 'cholesterol'), ('my statin at night', 'cholesterol'),
        ('a small white pill', None), ('I cannot remember', None), ('medicine', None),
        ('herbal sleeping tea', None), ('fish oil for cholesterol', None), ('ibuprofen', None), ('water', None),
        ('my pain pill', None), ('vitamin C', None), ('not taking any pills', None), ('I stopped taking my statin', None)]
# A bare "the pill" is ambiguous; v2 deliberately leaves it for the pharmacist.
DEV = [(t, None if t == 'the pill' else g) for t, g in DEV]
HELD_OUT = [
    ('the medicine that thins my blood', 'blood_thinner'), ('anticoagulant', 'blood_thinner'), ('stroke prevention pill for my AFib', 'blood_thinner'),
    ('daily aspirin', 'aspirin'), ('low dose aspirin', 'aspirin'),
    ('birth control', 'birth_control'), ('oral contraceptive pill', 'birth_control'),
    ('depression medication', 'antidepressant'), ('SSRI', 'antidepressant'), ('pill my psychiatrist gave me for depression', 'antidepressant'),
    ('sleep aid prescription', 'sleep'), ('pill for insomnia', 'sleep'), ('nerve pill to calm me down', 'sleep'),
    ('anticonvulsant', 'seizure'), ('medicine to prevent fits', 'seizure'),
    ('pill to lower my cholesterol', 'cholesterol'), ('lipid medicine', 'cholesterol'),
    ('blood sugar medicine', 'diabetes'), ('type 2 diabetes pill', 'diabetes'),
    ('hypertension medicine', 'blood_pressure'), ('diuretic', 'blood_pressure'), ('heart pressure pill', 'blood_pressure'),
    ('corticosteroid tablets', 'steroid'), ('steroid pills', 'steroid'),
    ('levothyroxine for hypothyroidism', 'thyroid'), ('underactive thyroid medicine', 'thyroid'),
    ('immunosuppressant after liver transplant', 'transplant'), ('antiretrovirals', 'hiv'),
    ('ibuprofen', None), ('cough syrup', None), ('eye drops', None), ('multivitamin', None), ('medicine for acid reflux', None), ('antihistamine for hay fever', None),
]


# Frozen v2 synthetic holdout, authored after the prototype design and before
# any v2 scores were inspected. Keep failures; do not tune on these phrases.
HELD_OUT_V2 = [
    ('tablets that prevent my blood from clotting', 'blood_thinner'), ('my anticoagulation medication', 'blood_thinner'), ('a blood thinner for atrial fibrillation', 'blood_thinner'),
    ('the little aspirin I take each day', 'aspirin'), ('a low-dose aspirin tablet for my heart', 'aspirin'), ('my daily baby aspirin tablet', 'aspirin'),
    ('the contraception tablets I take daily', 'birth_control'), ('a pill to avoid getting pregnant', 'birth_control'), ('my oral birth control medicine', 'birth_control'),
    ('the medication for my depression', 'antidepressant'), ('an SSRI tablet every morning', 'antidepressant'), ('the antidepressant my doctor prescribed', 'antidepressant'),
    ('my prescribed insomnia medication', 'sleep'), ('a sedative I take before bed', 'sleep'), ('tablets prescribed to help with sleeping', 'sleep'),
    ('tablets for controlling epilepsy', 'seizure'), ('an anti seizure drug every day', 'seizure'), ('my medicine that stops seizures', 'seizure'),
    ('the tablets for high cholesterol', 'cholesterol'), ('a statin my doctor gave me', 'cholesterol'), ('medicine for lowering my lipids', 'cholesterol'),
    ('tablets to manage my type two diabetes', 'diabetes'), ('medication that controls my glucose', 'diabetes'), ('my daily diabetes treatment', 'diabetes'),
    ('my diuretic tablet for fluid buildup', 'blood_pressure'), ('the tablets that bring my blood pressure down', 'blood_pressure'), ('her prescribed water tablets', 'blood_pressure'),
    ('oral corticosteroids prescribed for inflammation', 'steroid'), ('a steroid course for an asthma flare', 'steroid'), ('the prednisone tablets for inflammation', 'steroid'),
    ('my thyroid replacement tablets', 'thyroid'), ('hormone replacement for hypothyroidism', 'thyroid'), ('medicine for a sluggish thyroid gland', 'thyroid'),
    ('the medication to stop my transplanted kidney being rejected', 'transplant'), ('anti rejection treatment after my transplant', 'transplant'), ('immunosuppressive pills for my donor liver', 'transplant'),
    ('antiretroviral treatment for HIV infection', 'hiv'), ('the drugs I take to manage HIV', 'hiv'), ('my HIV antiviral therapy', 'hiv'),
    ('an antibiotic course for an infection', None), ('a pain relief tablet for headaches', None), ('nasal spray for hay fever', None),
    ('tablets for indigestion', None), ('an iron supplement for anemia', None), ('chamomile tea before bed', None),
    ('I no longer take blood thinners', None), ('I used to take cholesterol tablets', None), ('not taking diabetes medication', None),
    ('the tiny round tablet', None), ('something my neighbour recommended', None), ('medicine for nausea on the boat', None),
    ('my calcium and vitamin D', None), ('cough lozenges', None), ('cream for my eczema', None),
]


def embedder():
    import numpy as np
    import onnxruntime as ort
    from tokenizers import Tokenizer
    tok = Tokenizer.from_file(str(ROOT / 'models/minilm/tokenizer.json')); tok.enable_truncation(256)
    sess = ort.InferenceSession(str(ROOT / 'models/minilm/model.onnx')); names = {i.name for i in sess.get_inputs()}
    def emb(text):
        e = tok.encode(text); m = np.array([e.attention_mask], dtype=np.int64)
        feed = {'input_ids': np.array([e.ids], dtype=np.int64), 'attention_mask': m, 'token_type_ids': np.array([e.type_ids], dtype=np.int64)}
        h = sess.run(None, {k: v for k, v in feed.items() if k in names})[0][0]
        v = (h * m[0][:, None]).sum(0) / m.sum(); return v / np.linalg.norm(v)
    return emb


def exclusion(text):
    import re
    s = text.lower().replace('’', "'")
    if re.search(r"\b(not taking|no longer|stopped|used to|don't take|do not take|never take|without medication|not on|none)\b", s): return 'not_current'
    if re.search(r'\b(herbal|tea|fish oil|vitamin|multivitamin|supplement|probiotic)\b', s): return 'not_medicine'
    if re.fullmatch(r'the pill|a pill|pill|medicine|medication|tablets?|a small white pill|i cannot remember', s.strip()): return 'too_vague'
    return None


def score(data, emb, group_vecs):
    rows, c = [], dict(correct_group=0, wrong_group=0, correctly_unassigned=0, missed=0)
    for text, gold in data:
        v = emb(text); sims = {g: max(float(v @ p) for p in gv) for g, gv in group_vecs.items()}
        ranked = sorted(sims, key=sims.get, reverse=True); best = ranked[0]; margin = sims[best] - sims[ranked[1]]
        pred = best if not exclusion(text) and sims[best] >= THRESHOLD and margin >= MARGIN else None
        if pred and pred == gold: c['correct_group'] += 1
        elif pred: c['wrong_group'] += 1
        elif gold is None: c['correctly_unassigned'] += 1
        else: c['missed'] += 1
        rows.append(dict(text=text, gold=gold, predicted=pred, similarity=round(sims[best], 3), margin=round(margin, 3), excluded=exclusion(text)))
    drugs = sum(1 for _, g in data if g)
    return dict(counts=c, phrases=len(data), drug_phrases=drugs, recall=round(c['correct_group'] / max(1, drugs), 3),
                precision=round(c['correct_group'] / max(1, c['correct_group'] + c['wrong_group']), 3), rows=rows)


def main():
    emb = embedder(); gv = {g['id']: [emb(p) for p in [g['description'], *g['prototypes']]] for g in GROUPS}
    report = dict(created='2026-11-12', version=2, model='sentence-transformers/all-MiniLM-L6-v2 (data/models.lock.json)', threshold=THRESHOLD, margin=MARGIN,
                  method='Cosine similarity between the typed phrase and each group description; below the threshold the medicine stays unrecognised. '
                         'V2 adds short semantic prototypes, conservative exclusions for negated/historical/supplement mentions, and a runner-up margin. '
                         'Thresholds 0.50/0.55/0.60/0.65 and margins 0/0.03/0.06 were explored on development only. '
                         'The original held-out set is now a regression set; fresh held-out phrases were authored before scoring v2. '
                         'These are synthetic English phrases, not a clinical or user validation. Class inferences require pharmacist confirmation.',
                  groups=GROUPS, development=score(DEV, emb, gv), regression=score(HELD_OUT, emb, gv), held_out=score(HELD_OUT_V2, emb, gv))
    out = ROOT / 'reports/ai_medicine_understanding_v2_2026-11-12.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
    for k in ('development', 'held_out'):
        r = report[k]; print(k, r['counts'], 'recall', r['recall'], 'precision', r['precision'])


if __name__ == '__main__':
    main()

"""Build product documents from the verified release reports."""
from pathlib import Path
from product_metrics import release_metrics

ROOT=Path(__file__).resolve().parents[1]
LIVE='https://foliatrace-research.civil-bell-5511.chatgpt.site'


def write(name, text):
    (ROOT/name).write_text(text.strip()+'\n',encoding='utf-8')


def main():
    m=release_metrics();h=m['held'];c=h['counts'];kb=m['kb'];hold=m['hold'];med=m['med'];retrieval=m['retrieval']
    original,v2=sorted(m['public']['ai_medicine_parity'],key=lambda p:p['phrases'])
    write('README.md',f"""# FoliaTrace AI

**Bring the bottle. Start a better conversation.**

FoliaTrace AI turns supplement labels and everyday medicine descriptions into a pharmacist brief. It brings ingredient identities, medicine-group suggestions and goal-specific research together with the exact source passages.

**[Open FoliaTrace AI]({LIVE})** · [One-page overview]({LIVE}/one-page.pdf) · [Source code]({LIVE}/source.zip)

## From a bottle to a brief

1. **Add the label.** Search NIH product records, paste ingredients or read a photo with editable text recognition.
2. **Describe the medicines.** Enter a name, brand or everyday description such as “my cholesterol pill.” Language AI proposes a medicine group for confirmation.
3. **Review the evidence.** Get relevant NIH quotations, questions for the pharmacist, label gaps and studies ranked for each herb and goal.
4. **Share the brief.** Use a QR link, print it or download the details you choose to include.

**Core AI:** MiniLM sentence embeddings for medicine descriptions; BM25 retrieval and MiniLM cross-encoder reranking for research. Both neural models run in the browser, keeping health inputs on the device.

## Run locally

Use Python 3.11+ and Node 24. These commands install dependencies, download the pinned model assets and build the browser product:

```powershell
npm ci
python -m pip install -r requirements.lock
python scripts/setup_model.py
python scripts/setup_reranker.py
node scripts/build_browser_inference.mjs
python scripts/build_safety_knowledge.py
python scripts/build_care_demo.py
python scripts/sync_public_demo.py
.\scripts\start.ps1
```

Open `http://127.0.0.1:8000/check/`. The full local app adds saved consultations, version history and pharmacist reading decisions.

## Verify and explore

```powershell
npm test
node scripts/verify_checker.mjs http://127.0.0.1:8000/check
```

[AI architecture, measured results and development provenance](docs/ai_disclosure.md) · [Release notes](docs/release_v08_2026-11-12.md) · [Data and model attribution](data/NOTICE.md)

The source archive includes the application, build tools and evaluation reports. `scripts/package_dsh_submission.py` rebuilds it; the two PDF builders use `reportlab` and `pypdf`. Code is licensed under MIT.
""")

    write('docs/ai_disclosure.md',f"""# FoliaTrace AI — AI architecture and evidence

FoliaTrace AI delivers an on-device workflow from a supplement label to a pharmacist brief. It interprets everyday medicine descriptions, ranks research for the actual bottle and goal, and connects warning cards and research leads to their original sources.

## Where AI changes the result

Ray remembers “my cholesterol pill.” A name lookup leaves that description unresolved. The language model proposes the statin group, which connects his words to the NIH red yeast rice card and a question to confirm the medicine. The [same-input ablation](../reports/ai_feature_ablation_2026-11-12.json) records the difference with language AI enabled and disabled.

## Architecture

| Component | Implementation | Contribution |
|---|---|---|
| Medicine language | Sentence embeddings · `sentence-transformers/all-MiniLM-L6-v2` | Matches everyday descriptions to medicine-group prototypes after exact, brand and typo lookup |
| Personal research | Cross-encoder reranking · `cross-encoder/ms-marco-MiniLM-L6-v2` | Ranks candidate studies for each herb and goal in a library of {m['library']} open-access abstracts |
| Photo input | Tesseract English LSTM | Converts a label photo into editable ingredient text |
| Source cards | Deterministic matching | Connects ingredients and medicine groups to {kb['unique_verified_passages']} verified NIH passages across {kb['herbs']} herbs |

The medicine model compares sentence embeddings with group prototypes using cosine similarity, with a floor of {med['threshold']:.2f} and a runner-up margin of {med['margin']:.2f}. Negated, historical and supplement-only descriptions stay unassigned. Suggested groups retain the person’s original words and an exact-name confirmation prompt.

BM25 retrieves candidates from the herb-filtered library. The cross-encoder scores each query–abstract pair and keeps up to two leads above a raw-logit floor of 2.0, calibrated on three development examples. Expand a lead to inspect literal population, preparation and comparator excerpts beside the bottle. The five deeper seven-dimension comparisons are labelled replays from the full local app.

Warning cards quote NIH verbatim. Model and tokenizer hashes are checked before inference; the pinned assets are recorded in `data/models.lock.json` and `data/reranker.lock.json`.

## Measured results

| Evaluation | Result | Dataset and method |
|---|---|---|
| Medicine descriptions | **{c['correct_group']}/{h['drug_phrases']} correct groups; {c['wrong_group']} wrong group assignments** | {h['phrases']} synthetic English phrases; {c['missed']} medicine descriptions left unassigned; all {c['correctly_unassigned']} other or negated descriptions also unassigned |
| Label matching | **{hold['precision_exact_species']:.1%} exact-species precision** | {hold['labels_fetched']} held-out NIH labels retrieved by product search |
| Full-local research pipeline | **{retrieval['metrics']['bm25']['ndcg@10']:.3f} → {retrieval['metrics']['hybrid']['ndcg@10']:.3f} → {retrieval['metrics']['rerank']['ndcg@10']:.3f} nDCG@10** | SciFact development data: {retrieval['queries']} annotated claims and {retrieval['documents']:,} abstracts; keyword search, hybrid retrieval, neural reranking |
| Product behavior | **{m['unit']['passed']}/{m['unit']['tests']} unit tests; {m['public_checks']}/{m['public_checks']} static site checks; {m['local_checks']}/{m['local_checks']} local app checks** | Live label lookup, OCR, medicine inference, research, exports, QR, erasure, accessibility and request privacy |

Browser workers and Python agree on medicine-group decisions across the original {original['phrases']}-phrase regression set and the fresh {v2['phrases']}-phrase evaluation. Reports retain the inputs and scoring details.

Engineering validation covers software behavior and labelled datasets. Pharmacist review and clinical outcome testing are the next evaluation milestones.

[Medicine report](../reports/ai_medicine_understanding_v2_2026-11-12.json) · [Label report](../reports/label_matching_holdout_2026-11-12.json) · [Research benchmark](../reports/retrieval_external.json) · [Browser verification](../reports/checker_browser_qa_public_2026-11-12.json)

## Data flow

Medicine descriptions, conditions, goals and photos stay in the browser. NIH receives the separate label-search query or record ID. QR sharing encodes the brief in the link; the recipient chooses whether to save it on their device. Research excerpts preserve the wording of the cited abstract.

## Development and provenance

Hao directed the product with substantial assistance from OpenAI Codex and Anthropic Claude across architecture, implementation, evaluations, documentation and demo production. The project began as an EthnoHack herbal-literature workspace; the DSH edition introduced the bottle-to-pharmacist workflow and its on-device medicine understanding.

Example people and products are fictional. NIH quotations are public-domain source material; article and model licences are recorded in [data/NOTICE.md](../data/NOTICE.md). Product code is MIT-licensed.
""")

    write('docs/release_v08_2026-11-12.md',f"""# FoliaTrace AI v0.8

This release connects everyday medicine descriptions, supplement ingredients and personal research goals in a pharmacist brief.

## Delivered

- Medicine-name, brand and typo lookup with semantic interpretation of everyday descriptions.
- AI group explanations linked to the exact NIH source card.
- Per-herb, per-goal research ranking with literal study excerpts beside the bottle.
- Live NIH label lookup, editable photo input and preservation of short ingredient names.
- QR handoff, selective exports, printable briefs and local consultation history.
- Readable medicine labels with the original description above the AI explanation.

## Verification

| Check | Passed |
|---|---|
| Behavioral unit tests | {m['unit']['passed']}/{m['unit']['tests']} |
| Static-build browser checks | {m['public_checks']}/{m['public_checks']} |
| Local-app browser checks | {m['local_checks']}/{m['local_checks']} |

The browser checks cover medicine inference, source links, research, live NIH lookup, OCR, QR, exports, erasure, request privacy and WCAG A/AA accessibility.

See [AI architecture and evidence](ai_disclosure.md) for evaluation methods and [README](../README.md) to run the product.
""")

    write('docs/dsh_v2_submission.md',f"""# FoliaTrace AI — submission text

## Tagline

Your words. Your bottle. Evidence your pharmacist can use.

## Inspiration

People remember what a medicine does more easily than its name. A supplement label adds another layer: unfamiliar plant names, blends and claims that are difficult to connect to a personal medicine list. We started with that moment at the pharmacy and built a way to arrive with the right questions and their sources.

## What it does

FoliaTrace AI turns a supplement label and a person’s own words into a pharmacist brief. Add a bottle through NIH label search, pasted ingredients or a photo. Enter medicine names or descriptions and the goal for taking the supplement. The brief brings together relevant NIH quotations, questions, label gaps and research ranked for each herb and goal.

“My cholesterol pill” shows the core AI contribution: language understanding proposes a statin group and connects it to the relevant red yeast rice source card. The original description and confirmation question stay visible. A pharmacist can compare the bottle with a study’s population, preparation and comparator wording, then explore a different research question.

QR handoff opens the brief on another screen. Selected details can also be printed or downloaded.

## How we built it

The browser combines MiniLM sentence embeddings for medicine language, BM25 retrieval and MiniLM cross-encoder reranking over {m['library']} open-access abstracts, and optional Tesseract label recognition. Pinned assets and hash checks make the models reproducible. A deterministic engine matches ingredients and medicine groups to {kb['unique_verified_passages']} verified NIH quotations.

Workers run inference locally. The full FastAPI/SQLite app adds saved consultations, version history and seven-dimension study comparisons.

## Evidence

- **Medicine language:** {c['correct_group']}/{h['drug_phrases']} correct groups and {c['wrong_group']} wrong group assignments across {h['phrases']} synthetic English phrases. All {c['correctly_unassigned']} other or negated descriptions remained unassigned.
- **Real labels:** {hold['precision_exact_species']:.1%} exact-species precision on {hold['labels_fetched']} held-out NIH product labels.
- **Research component:** full-local SciFact nDCG@10 improved from {retrieval['metrics']['bm25']['ndcg@10']:.3f} with keywords to {retrieval['metrics']['rerank']['ndcg@10']:.3f} with neural reranking.
- **Working product:** {m['unit']['passed']} unit tests and {m['public_checks']} browser checks on each of the static build and local checker passed.

## Challenges we ran into

The hard part was connecting evidence to the right person. We built explicit handling for ambiguous plant identities, proprietary blends, descriptions that need confirmation, and differences between a study preparation and a product label. Each uncertainty becomes an inspectable part of the brief.

## Accomplishments

AI makes an otherwise incomplete medicine description useful. Source-linked questions give the pharmacist a practical starting point. The entire browser workflow runs on the person’s device, including language understanding and research ranking.

## What we learned

The value of health AI grows when its output helps a professional inspect the evidence and make the next decision.

## What’s next

Pharmacist review, usability sessions with older adults and caregivers, more source coverage, multilingual briefs and barcode lookup.

## Built with

JavaScript · MiniLM · MS MARCO cross-encoder · ONNX Runtime Web · WebAssembly · Tesseract.js · Python · FastAPI · SQLite · NIH DSLD · NIH NCCIH

## Development disclosure

Hao developed the product with substantial Codex and Claude assistance. The project began as an EthnoHack research workspace and was rebuilt around the DSH pharmacy workflow. Methods, validation status, source rights and development provenance are documented in `docs/ai_disclosure.md` in the source archive.
""")

    write('sites/foliatrace-research/README.md',f"""# FoliaTrace AI

**Your words. Your bottle. Evidence your pharmacist can use.**

FoliaTrace AI turns supplement labels and everyday medicine descriptions into a brief for the pharmacy conversation. Try Ray: “my cholesterol pill” becomes a group suggested by AI, a relevant NIH source card and a question to confirm the exact medicine.

## Try the product

**[Open FoliaTrace AI]({LIVE})**

- Add a bottle through NIH search, pasted ingredients or a label photo.
- Describe your medicines and your goal for the supplement.
- Read the questions and cited research, then share the brief by QR or export.

**Core AI:** MiniLM sentence embeddings for medicine descriptions, plus BM25 retrieval and MiniLM cross-encoder reranking for research. Inference runs in the browser. This repository includes the static product and its pinned model assets.

## Downloads

[One-page overview](build/one-page.pdf) · [Product source](build/source.zip) · [Complete code PDF](build/code.pdf)

The source archive includes the full local app, reproducible evaluations and AI development disclosure. [Data and model attribution](build/DATA-NOTICE.md) · [MIT code licence](build/CODE-LICENSE.txt)
""")
    print('Built concise product README, AI evidence, release notes and submission copy from verified reports.')


if __name__=='__main__':main()

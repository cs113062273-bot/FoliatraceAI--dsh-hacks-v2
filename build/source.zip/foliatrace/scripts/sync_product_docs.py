"""Synchronize judge-facing descriptions from verified release reports."""
from pathlib import Path
import re
from product_metrics import release_metrics
ROOT=Path(__file__).resolve().parents[1]


def main():
    m=release_metrics(); h=m['held']; c=h['counts']; kb=m['kb']; hold=m['hold']; med=m['med']; retrieval=m['retrieval']
    ai=f"{c['correct_group']}/{h['drug_phrases']} medicine descriptions assigned to the correct group ({h['recall']:.1%}); {c['wrong_group']} wrong group assignments, {c['missed']} left unknown; all {c['correctly_unassigned']} other/negated phrases left unassigned ({h['phrases']} synthetic English phrases total)"
    labels=f"{hold['labels_fetched']} unseen NIH labels: {hold['precision_exact_species']:.1%} exact species, {hold['precision_genus_or_better']:.1%} genus-or-better precision, {hold['recall_of_covered_species']:.0%} recall of covered species"
    qa=f"{m['public_checks']}/{m['public_checks']} public-build and {m['local_checks']}/{m['local_checks']} local `/check/` real-browser checks; {m['unit']['passed']}/{m['unit']['tests']} behavioral unit tests"
    parity=m['public']['ai_medicine_parity']; original=parity[0]; v2=parity[1]
    (ROOT/'README.md').write_text(f'''# FoliaTrace AI

**Bring the bottle. Start a better conversation.**

Can't remember a medicine's name? Describe it. FoliaTrace AI uses on-device language AI to suggest its group and a second neural model to find research for the person's bottle and goals. It builds a pharmacist brief with exact NIH warnings, explicit uncertainties and source links. No account or paid AI API.

**[Try FoliaTrace AI](https://foliatrace-research.civil-bell-5511.chatgpt.site)** — choose Mei, Sam or Ray, or check your own bottle.

Mei, 72, takes warfarin and "her water pill". Her daughter buys a memory-and-joint supplement. Only one in three herb/supplement users disclosed their use to a conventional provider in NHIS 2002 ([Mehta et al. 2008](https://pmc.ncbi.nlm.nih.gov/articles/PMC2787410/)); 57.6% of U.S. adults used supplements in 2017–18 ([CDC NCHS](https://www.cdc.gov/nchs/products/databriefs/db399.htm)). The product connects the bottle, the person's own words and evidence a pharmacist can inspect.

![Pharmacist brief](docs/assets/foliatrace-v08-brief.png)

## What works

| Task | Behavior |
|---|---|
| Add a bottle | Live NIH DSLD label lookup, pasted ingredients, or on-device photo OCR with editable review |
| Describe medicines | Exact/brand/typo matching first; MiniLM semantic inference when a name is unknown. "My water pill" and "my cholesterol pill" become explicit AI hypotheses, never identified prescriptions. Negated, historical and supplement-only mentions stay unassigned |
| Get the brief | Ingredient identities and medicine groups match verified NIH text. Every warning quotes NIH verbatim. Ambiguous species, unknown medicines, missing amounts and duplicate botanicals remain visible |
| Find personal research | Split compound goals; filter herb candidates and explicit nonclinical/protocol title cues; neural cross-encoder ranks each herb/goal. Low-scoring results stay empty. Expand a live lead to compare literal population, preparation and comparator excerpts with the actual bottle |
| Hand to pharmacist | QR/link carries data in the URL fragment; browser-local print/download and selective sharing. Opening a shared link does not save it unless requested |
| Go deeper | Free-form on-device AI/keyword research and five labelled replays of the local app's seven-dimension study-to-product comparisons |

## Evidence you can reproduce

| Check | Measured result | Source |
|---|---|---|
| Language understanding v2 | {ai} | [Report](reports/ai_medicine_understanding_v2_2026-11-12.json); `python scripts/ai_medicine_groups.py` |
| Browser/Python agreement | Same group decisions on original {original['phrases']} and fresh {v2['phrases']} phrases. Maximum cosine difference {original['max_cosine_delta']:.3f} / {v2['max_cosine_delta']:.3f}; int8 CPU/WASM kernels differ slightly | Browser QA reports |
| Research screening | {m['library']} licensed open-access abstracts; raw-logit floor 2.0 selected on the three development examples. Title screening and source excerpts are deterministic. No held-out relevance accuracy claimed | [Development report](reports/ai_research_relevance_2026-11-12.json) |
| AI feature ablation | Same Ray input: the red yeast rice medicine card appears only when the language model supplies its measured group hypothesis; exact-name lookup alone leaves the description unknown | [Causal feature demonstration](reports/ai_feature_ablation_2026-11-12.json) |
| External research component | Full local pipeline on {retrieval['queries']} annotated SciFact claims / {retrieval['documents']:,} abstracts: nDCG@10 keywords {retrieval['metrics']['bm25']['ndcg@10']:.3f}, hybrid {retrieval['metrics']['hybrid']['ndcg@10']:.3f}, hybrid + neural reranking {retrieval['metrics']['rerank']['ndcg@10']:.3f}. Untuned published development labels; not browser herbal-library accuracy | [Report](reports/retrieval_external.json); `acquire_scifact.py`, `evaluate_retrieval.py` |
| Verbatim warnings | {kb['herbs']} herbs, {kb['unique_verified_passages']} unique NIH passages; build refuses a missing quotation | `python scripts/build_safety_knowledge.py --offline` |
| Real-label matching | {labels} | [Held-out report](reports/label_matching_holdout_2026-11-12.json) |
| Label uncertainty | {m['hidden']:,}/{m['botanical']:,} botanical rows ({m['blend']}) across {m['labels']:,} labels had no individual amount | Label-matching dev/holdout reports |
| End-to-end behavior | {qa}; live NIH, photos, QR, inference cancellation, privacy, WCAG A/AA and phone layout | `npm test`; `node scripts/verify_checker.mjs` |

The language phrases are synthetic English examples, not patient data. The original v1 holdout is now a regression set; v2 uses a fresh frozen set. No pharmacist review, user study or clinical outcome is claimed.

## AI architecture

1. **Language understanding:** pinned `sentence-transformers/all-MiniLM-L6-v2`; sentence embeddings compared with short medicine-group prototypes; cosine ≥ {med['threshold']:.2f} and runner-up margin ≥ {med['margin']:.2f}, plus conservative exclusions. The exact medicine still needs confirmation.
2. **Research relevance:** pinned `cross-encoder/ms-marco-MiniLM-L6-v2`; up to twenty keyword candidates per herb/goal, reranked on-device. Scores are relevance logits, not benefit, safety or applicability probabilities.
3. **Photo convenience:** Tesseract LSTM OCR; text is editable before analysis.

Every warning remains a deterministic match to verified NIH text. No generative model writes a warning. Source-excerpt extraction uses text cues and literal offsets; it is not an additional AI model. Models and tokenizers are checksum-verified and self-hosted. Medicines, purposes, conditions and photos stay in the browser; NIH receives only the separate label query or record ID.

## Run and verify

Use Python 3.11+ and Node 24. The source archive excludes model binaries; install the pinned assets before building:

```powershell
npm ci
python -m pip install -r requirements.lock
python scripts/setup_model.py
python scripts/setup_reranker.py
node scripts/build_browser_inference.mjs
python scripts/build_safety_knowledge.py
python scripts/build_care_demo.py
python scripts/sync_public_demo.py
npm test
```

Serve `sites/foliatrace-research/build/` for the static product, or run `scripts/start.ps1` for the complete local app at `http://127.0.0.1:8000`; the same checker is mounted at `/check/`. First use downloads self-hosted models; once assets are cached, analysis needs no AI service. Live label lookup requires NIH connectivity.

```powershell
node scripts/verify_checker.mjs http://127.0.0.1:8015 --report=reports/checker_browser_qa_public_2026-11-12.json
node scripts/verify_checker.mjs http://127.0.0.1:8000/check --report=reports/checker_browser_qa_local_2026-11-12.json
```

`--no-live` skips only the live NIH checks. `python scripts/package_dsh_submission.py` creates the allow-listed source archive. [Release notes](docs/release_v08_2026-11-12.md) · [AI disclosure](docs/ai_disclosure.md) · [Attribution](data/NOTICE.md).

Submission artifacts: [one-page overview](output/pdf/foliatrace-one-page.pdf) and [complete code PDF](output/pdf/foliatrace-code.pdf). To rebuild them, install `reportlab` and `pypdf`, run `build_product_onepage.py`, `package_dsh_submission.py`, then `build_code_pdf.py`. The code PDF lists every first-party code file in the source ZIP with its hash; model/vendor binaries stay excluded.

## Scope and prior work

Prepares a pharmacist conversation; does not identify a prescription, recommend doses, replace professional review or certify safety. Coverage is limited to the covered herbs, and labels are manufacturer declarations. Both label samples are search-ranked, not representative market samples; curator names can themselves be misspelt. Fictional example people and products.

The project began as an EthnoHack herbal-literature workspace and was rebuilt for DSH Hacks V2 around the person-to-pharmacist task. Development was substantially assisted by Codex and Claude. Code MIT; third-party data/models retain their licences. Prior-work eligibility remains the organisers' decision.
''',encoding='utf-8')
    (ROOT/'docs/ai_disclosure.md').write_text(f'''# AI disclosure

## Runtime AI

The product contains three on-device models. Language understanding and personal research ranking are its two core AI tasks; OCR is an optional input aid.

| Role | Model | Limits |
|---|---|---|
| Understand medicine descriptions | `sentence-transformers/all-MiniLM-L6-v2`, pinned in `data/models.lock.json` | Cosine comparison with group descriptions/prototypes, floor {med['threshold']:.2f}, margin {med['margin']:.2f}. Dictionary matches take precedence; negated/historical/supplement mentions are excluded. Results are hypotheses with a pharmacist-confirmation prompt |
| Rank research for each herb and goal | `cross-encoder/ms-marco-MiniLM-L6-v2`, pinned in `data/reranker.lock.json` | {m['library']} open-access abstracts; herb candidates and explicit nonclinical/protocol title cues filtered before neural scoring. Floor 2.0 selected on development examples; at most two leads per herb. No calibrated confidence, clinical entailment or applicability claim |
| Read a label photo | Tesseract English LSTM | Browser-local, editable text; photo never uploaded |

Warnings are deterministic matches to {kb['unique_verified_passages']} verified NIH quotations. No generative model writes, summarises or paraphrases a warning. Excerpts for population, preparation and comparator are extracted by deterministic text cues with literal offsets; absent extracted wording is left empty and is not proof the study omitted it. Recorded seven-dimension comparisons remain explicitly labelled replays.

Model/tokenizer SHA-256 checks run before inference. No paid AI API, hosted LLM or external inference service is used. Health inputs never enter requests; separate NIH label searches do. Worker queues prevent concurrent model initialisation, and input changes/erasure invalidate stale asynchronous results. Shared links do not persist data without the keep action.

The public hosting provider injects a Cloudflare bot-detection inline script. The strict CSP blocks it. Deployed QA retains every policy event and identifies this exact hosting script separately using its browser report sample and script contents; it never enables inline scripts or reports those platform blocks as zero. Local/static application runs have zero policy violations. [Cloudflare documents this interaction](https://developers.cloudflare.com/cloudflare-challenges/challenge-types/javascript-detections/).

## Evaluation and its limits

- Fresh frozen v2 set: **{ai}**. Synthetic English phrases authored for development/testing; no patient/user study.
- The original v1 {original['phrases']}-phrase holdout is retained unchanged and used as a regression set, not presented as fresh v2 testing. V2 adds conservative short prototypes and exclusions; thresholds were chosen using development phrases before scoring the fresh set. Failures remain in the report.
- Actual browser-worker decisions match Python on both sets. Maximum cosine difference: **{original['max_cosine_delta']:.3f}** on the original set, **{v2['max_cosine_delta']:.3f}** on v2. Pinned int8 CPU and WebAssembly kernels can differ numerically; QA tolerances are 0.01 / 0.02 respectively. No threshold was retuned on held-out results.
- Research floor 2.0 and clinical question wording were calibrated on the three fictional development examples after a 2.5 short-query floor missed relevant cognition/joint studies. Explicit animal/bench/protocol title exclusions prevent obvious scope errors. This is development calibration, **not** a held-out research-relevance benchmark or proof a study applies to a person.
- Separate external component evaluation: {retrieval['queries']} published human-annotated SciFact claims over {retrieval['documents']:,} abstracts; full local pipeline nDCG@10 {retrieval['metrics']['bm25']['ndcg@10']:.3f} keywords → {retrieval['metrics']['hybrid']['ndcg@10']:.3f} hybrid → {retrieval['metrics']['rerank']['ndcg@10']:.3f} with neural reranking. Settings unchanged on public development labels; not an official blind test, browser-library score or clinical outcome.
- A same-input feature ablation demonstrates that Ray's informal medicine description connects to the red yeast rice NIH card only with the language-AI hypothesis. This uses a development example and does not add held-out evaluation cases.
- Label matching: {labels}. Search-ranked samples; curator declarations are imperfect ground truth. Engine frozen before the held-out label run.
- {qa}; no uncaught page exceptions, CSP violations or axe WCAG 2 A/AA violations in the recorded runs.

Full methods/results: `reports/ai_medicine_understanding*_2026-11-12.json`, `reports/ai_research_relevance_2026-11-12.json` and browser reports.

## Development assistance

The entrant developed FoliaTrace AI with substantial assistance from **OpenAI Codex** and **Anthropic Claude (Claude Code)**. Earlier Codex work covered the local FastAPI/SQLite consultation app, versioning, study comparisons and browser reranker. Claude's v0.8 work introduced the NIH checker, language AI, OCR, QR handoff and evaluations. Codex's follow-up corrected browser/Python padding, added conservative medicine prototypes/exclusions, goal-specific research with source excerpts, licensed clinical additions, cancellation/privacy fixes and verification.

AI-assisted choices have **not been reviewed by a pharmacist**: covered herbs, statement-to-medicine mappings, group descriptions/prototypes and fictional scenarios. NIH wording is checked verbatim, which does not validate those mappings or imply NIH endorsement. Three older factual study-reading notes in `data/reading_notes/` retain their Codex labels. No clinical validation is claimed.
''',encoding='utf-8')
    (ROOT/'docs/release_v08_2026-11-12.md').write_text(f'''# FoliaTrace AI v0.8 — language to evidence to pharmacist brief

2026-11-12. The browser product now uses language AI in the patient flow and neural evidence ranking in the brief itself.

## Behavior

- "Her water pill" / "my cholesterol pill" produce visible AI medicine-group hypotheses; the exact name remains a pharmacist question. Known medicine names take precedence. Negated/historical medicine mentions and supplement-only descriptions stay unassigned.
- The person's bottle and separate goals drive live on-device research. Herb filtering, explicit nonclinical/protocol title exclusions and a 2.0 raw-logit floor prevent obvious unrelated fills. Expand a study to read population, preparation and comparator excerpts alongside the bottle label; these excerpts are literal source text, selected by rules.
- {m['library']} open-access abstracts, including a bounded set of licensed cognition/joint/lipid studies. Rights/provenance remain per article; missing or unsupported abstracts are omitted.
- NIH quotations remain deterministic and verified verbatim. No model writes a warning.
- Async worker requests are serialized; input edits and erasure invalidate old briefs. Erasure cannot be undone by an inference completion. Shared-link inference cannot silently save the brief.
- QR, photo input, live NIH lookup, print/download, optional situations and the five recorded local-app comparisons remain available.

## Verification

| Check | Result |
|---|---|
| Knowledge base | {kb['herbs']} herbs; {kb['quote_checks']} checks; {kb['unique_verified_passages']} unique verbatim passages |
| Behavioral tests | {m['unit']['passed']}/{m['unit']['tests']} |
| Public-build browser QA | {m['public_checks']}/{m['public_checks']} |
| Local `/check/` browser QA | {m['local_checks']}/{m['local_checks']} |
| Fresh language holdout | {ai} |
| Browser/Python decisions | Identical on original {original['phrases']} and fresh {v2['phrases']}; max cosine deltas {original['max_cosine_delta']:.3f}/{v2['max_cosine_delta']:.3f} |
| Real-label holdout | {labels} |
| WCAG A/AA / CSP / uncaught errors | zero in both browser reports |

Research relevance is development-calibrated, not independently validated. Language tests are synthetic English; labels are search-ranked. No pharmacist review, usability study or clinical outcome is claimed. Coverage, ambiguity and missing evidence remain explicit. NIH may rate-limit live lookup; paste/photo remain available.

## Reproduce

See README setup. `npm test`, `node scripts/verify_engine.mjs`, `python scripts/ai_medicine_groups.py`, and `node scripts/verify_checker.mjs [base] --report=[path]`. `sync_public_demo.py` derives homepage metrics from reports; `sync_product_docs.py` derives these release claims; `build_product_onepage.py` builds the one-page overview. `package_dsh_submission.py` uses an explicit allow-list and excludes `.runtime`, caches, credentials and model binaries.
''',encoding='utf-8')
    path=ROOT/'docs/dsh_v2_submission.md';s=path.read_text(encoding='utf-8')
    a=s.index('## Tagline');b=s.index('## Inspiration',a)
    s=s[:a]+'## Tagline\n\nOn-device AI turns supplement labels and everyday medicine descriptions into evidence your pharmacist can check.\n\n'+s[b:]
    start=s.index('## What it does');end=s.index('## How we built it')
    s=s[:start]+f'''## What it does

FoliaTrace AI uses **on-device language AI to understand how people describe their medicines**, then **neural research ranking to find evidence for their bottle and goals**. "My cholesterol pill" becomes an explicit statin hypothesis and a pharmacist-confirmation question alongside the relevant NIH red yeast rice quotation. AI understands and retrieves; every warning remains NIH's exact words.

1. **The bottle.** Search NIH DSLD labels, paste ingredients, or photograph the panel. OCR is an optional input aid, and the person reviews its text.
2. **Your words.** Names/brands/typos resolve first. MiniLM compares unknown descriptions with medicine-group prototypes, or abstains. Historical, negated and supplement-only mentions remain unassigned. Suggested groups stay labelled AI and require exact-name confirmation.
3. **The brief.** Verified NIH sentences, source links, questions for the pharmacist, ambiguous species, proprietary blends, duplicates and uncovered ingredients. No generated warning or safety verdict.
4. **Personal research.** For each herb and each goal, a cross-encoder ranks the on-device library of {m['library']} abstracts. Explicit nonclinical/protocol title cues and a relevance floor screen candidates. Expand a lead to inspect literal population, preparation and comparator wording beside the bottle label. A relevance score does not establish benefit or applicability.
5. **The handoff.** A QR/link opens the same brief using browser-local URL-fragment data; print, download and selective sharing are available. The pharmacist can explore more research or inspect five labelled replays of the local app's seven-dimension comparisons.

Mei shows water-pill understanding plus memory/joint research; Sam shows mood-supplement questions; Ray shows cholesterol-pill understanding, red yeast rice warnings and lipid research. People and products are fictional.

'''+s[end:]
    a=s.index('- **On-device AI:**');b=s.index('\n- **Serverless handoff:**',a)
    s=s[:a]+'- **On-device AI:** pinned MiniLM sentence embeddings for medicine language, a pinned MS MARCO cross-encoder for goal-specific research, and optional Tesseract LSTM OCR. Model/tokenizer hashes are verified. No generative model writes a warning.\n'+s[b:]
    a=s.index('## Evidence');b=s.index('## Challenges',a)
    s=s[:a]+f'''## Evidence

- **Language AI, fresh frozen synthetic holdout:** {ai}. The original holdout is retained as a regression set; browser and Python group decisions agree on both. These are synthetic phrases, not patient outcomes.
- **Real-label holdout:** {labels}. Both samples are search-ranked and curator names can be misspelt.
- **Working product:** {qa}, covering live NIH, photos, QR, inference, research, erasure, privacy, accessibility and layout.
- **Research calibration:** three fictional development examples; raw-logit floor 2.0. No held-out relevance accuracy or clinical applicability claimed.
- Methods, failures and reports ship with the source. No pharmacist review, usability study or clinical outcome claimed.

'''+s[b:]
    s=s.replace('OCR, a neural reranker and a QR encoder all run','Language understanding, purpose-specific research, OCR and a QR encoder all run')
    s=s.replace('JavaScript · WebAssembly · Tesseract.js','JavaScript · MiniLM · MS MARCO cross-encoder · WebAssembly · Tesseract.js')
    s=s.replace('two-page brief','printable brief')
    s=re.sub(r'\bFoliaTrace\b(?! AI)', 'FoliaTrace AI', s)
    path.write_text(s,encoding='utf-8')
    notice=ROOT/'data/NOTICE.md'; text=notice.read_text(encoding='utf-8')
    marker='## On-device medicine AI and clinical research additions (2026-11-12)'
    if marker in text: text=text[:text.index(marker)].rstrip()+'\n'
    additions=__import__('json').loads((ROOT/'data/demo/care_research_additions.json').read_text(encoding='utf-8'))
    text+='\n'+marker+'\n\n'
    text+='The pinned `sentence-transformers/all-MiniLM-L6-v2` sentence encoder and tokenizer (`data/models.lock.json`) are Apache-2.0. Self-hosted runtime assets retain `inference/MODEL-LICENSE.txt`; model/tokenizer hashes are checked before use. Group prototypes and synthetic test phrases were authored with AI coding assistance; they are not clinical annotations.\n\n'
    text+='`data/demo/care_research_additions.json` adds a bounded selection of human studies/reviews to the public browser library. Only abstracts with CC BY/CC0 rights reported by Europe PMC are redistributed; unsupported or missing abstracts are omitted. Authors, article links, acquisition URLs and response SHA-256 are retained. Selection is not an exhaustive evidence review; a study formulation is not the actual bottle. Article-specific licence versions and attribution requirements remain authoritative at the original source. No full articles, images or figures are bundled.\n\n'
    for p in additions['papers']: text+=f"- **{p['id']}** — {p['title']} {p['authors']} ({p['year']}). [{p['licence']}]({p['url']}). DOI: {p.get('doi') or 'not listed'}.\n"
    notice.write_text(text,encoding='utf-8')
    site=ROOT/'sites/foliatrace-research/README.md'
    site.write_text(f'''# FoliaTrace AI — public browser product

**Bring the bottle. Start a better conversation.** On-device language AI suggests a group from "my water pill" or "my cholesterol pill"; a neural cross-encoder finds research for the bottle and each goal. Every warning stays a verbatim NIH sentence.

Live: https://foliatrace-research.civil-bell-5511.chatgpt.site

This repository contains the static `build/` declared in `.openai/hosting.json`. `ai-worker.js` and `medicine-language.js` handle language inference/exclusions. `model-search-worker.js` and `research-evidence.js` rank evidence and extract literal context. `safety-engine.js` matches verified NIH text. OCR is an optional input aid; QR carries brief data in a URL fragment. All analysis runs locally in the browser.

Fresh synthetic language holdout: {ai}. Library: {m['library']} licensed abstracts. Verification: {qa}. Development-calibrated research floor, unreviewed medicine mappings, synthetic language tests and other limits are disclosed in `source.zip` → `README.md` and `docs/ai_disclosure.md`.

`source.zip` contains the complete local app, source, builders, behavioral tests and evaluation reports. `one-page.pdf` introduces the product; `DATA-NOTICE.md`, `CODE-LICENSE.txt` and `inference/*LICENSE*` retain attribution. Models/tokenizers are pinned and hash-checked. `.gitattributes` preserves exact deployed bytes.

Fictional people/products. A pharmacist must confirm inferred medicine groups and clinical applicability. No generated medical warning, dose recommendation or safety guarantee.
''',encoding='utf-8')
    readiness=ROOT/'docs/championship_readiness_2026-11-12.md'
    s=readiness.read_text(encoding='utf-8')
    tag='## Codex 接手後的實測更新'
    if tag in s:
        a=s.index(tag);b=s.index('## 一句話',a);s=s[:a]+s[b:]
    if tag not in s:
        s=s.replace('## 一句話',f'''{tag}

目前核心 AI 是**人話用藥理解**與**瓶內成分 × 個別目的的研究排序**；OCR 只列為可選輸入輔助。首頁與簡報直接呈現 AI 藥物群組假設，以及可展開的研究原句。下方早期改造對照為歷史紀錄；最新結果以報告與英文 release notes 為準。

- 新版語言保留集：{c['correct_group']}/{h['drug_phrases']} 句藥物描述正確，{c['wrong_group']} 錯誤分組，{c['missed']} 保留未知；{c['correctly_unassigned']} 句其他／否定描述全部不歸類。總共 {h['phrases']} 句合成英文，沒有臨床或使用者驗證。
- 瀏覽器／Python 分組一致；原始 {original['phrases']} 句最大 cosine 差 {original['max_cosine_delta']:.3f}，新版 {v2['phrases']} 句 {v2['max_cosine_delta']:.3f}。
- 公開 build {m['public_checks']} 項、本機 `/check/` {m['local_checks']} 項瀏覽器 QA 全過；{m['unit']['tests']} 項行為測試全過。
- 研究庫 {m['library']} 篇；相關性門檻 2.0 僅由開發範例校準，沒有宣稱獨立相關性準確率。植物、明確非臨床／protocol 標題先過濾；原句摘錄使用規則，沒有冒充另一個 AI 模型。
- 主辦要求仍含影片、一頁 PDF、原始碼交付；影片依使用者指示暫不重錄。舊作沿用資格由主辦判斷，不能以功能通過取代資格確認。

## 一句話''')
        readiness.write_text(s,encoding='utf-8')
    print('Synchronized README, AI disclosure, release notes and Devpost description from reports.')


if __name__=='__main__': main()

"""Build product documents from the verified release reports."""
from pathlib import Path
from product_metrics import release_metrics

ROOT=Path(__file__).resolve().parents[1]
LIVE='https://foliatrace-research.civil-bell-5511.chatgpt.site'


def write(name, text):
    (ROOT/name).write_text(text.strip()+'\n',encoding='utf-8')



def project_readme(m, public):
    h=m['held']; c=h['counts']; labels=m['hold']; kb=m['kb']; retrieval=m['retrieval']
    downloads = ('[One-page project description](build/one-page.pdf) · [Full product source](build/source.zip)' if public else f'[One-page project description]({LIVE}/one-page.pdf) · [Full product source]({LIVE}/source.zip)')
    repo = """## Repository contents

This repository contains the deployable browser product in `build/`. The complete development source is packaged in `build/source.zip`, including the FastAPI/SQLite application, frontend source, build scripts, evaluation inputs/results and AI development disclosure.

| Location | Contents |
|---|---|
| `build/index.html`, CSS and JavaScript | Interactive checker, pharmacist research and brief handoff |
| `build/inference/` | Pinned sentence-embedding and cross-encoder models, tokenizers and ONNX Runtime |
| `build/ocr/`, `build/vendor/` | Browser-local label recognition and QR generation |
| `build/*.json` | NIH knowledge, licensed abstracts, recorded comparisons and report-derived metrics |
| `build/one-page.pdf`, `build/source.zip` | One-page project description and full development source |

## Run the browser product locally

Clone this repository and serve its included assets with Python 3.11+:

```powershell
git clone https://github.com/cs113062273-bot/FoliatraceAI--dsh-hacks-v2.git
cd FoliatraceAI--dsh-hacks-v2
python -m http.server 8015 --directory build
```

Open **http://127.0.0.1:8015/**. The two neural models and OCR assets are included. Live NIH label lookup uses an internet connection; the first inference loads the model files into browser memory.

## Run the full application from source

Extract `build/source.zip`, open its `foliatrace/` directory and use Python 3.11+ and Node 24. Install the pinned dependencies and generate the browser assets:
""" if public else """## Run the full application

Use Python 3.11+ and Node 24 from this source directory. Install the pinned dependencies and generate the browser assets:
"""
    attribution = ('[Data and model attribution](build/DATA-NOTICE.md) · [MIT code licence](build/CODE-LICENSE.txt)' if public else '[Data and model attribution](data/NOTICE.md) · [MIT code licence](LICENSE)')
    return f"""# FoliaTrace AI

FoliaTrace AI helps older adults and caregivers prepare for a conversation with a pharmacist about supplements and medicines. It combines the bottle's ingredients, the person's own description of their medicines and their reason for taking the supplement in a source-linked brief.

**[Open the working product]({LIVE})** · {downloads}

## The problem and the people using it

A person may remember a medicine as "my cholesterol pill" while a supplement label lists an unfamiliar plant, a proprietary blend or an ingredient already present in another bottle. Connecting that information to a relevant source takes several steps.

- **Older adults and other supplement users** enter the bottle and the medicines they remember.
- **Caregivers** bring together several products and preserve the questions that the labels leave open.
- **Pharmacists** review source passages, confirm suggested medicine groups and compare a product with the preparations used in research.

The resulting brief includes medicine-related NIH cards, ambiguous plant identities, blend-dose questions, repeated ingredients and research leads for the entered goal.

## Use the product

1. Select **Check a bottle**. Search NIH product labels, paste an ingredient list or upload a photo of the Supplement Facts panel. Photo text is editable before it becomes a product.
2. Add medicine names, brands, typos or everyday descriptions. Add the supplement goal and relevant circumstances, such as a planned procedure.
3. Select **Build my brief**. Read the AI medicine-group suggestion beside the original words, inspect the NIH quotations and review the ingredient questions.
4. Open **Research leads, ranked on your device**. Compare the label with the study's population, preparation and comparator excerpts. Pharmacists can also enter a different research question.
5. Select **Hand to pharmacist (QR)** to open the brief on another screen, or use **Print / PDF** or **Download**. Choose which medicine, circumstance and ingredient details to include in the exported copy.

Choose **Mei**, **Sam** or **Ray** on the homepage to run an example immediately.

## AI architecture and its contribution

| Component | Technology | What it does |
|---|---|---|
| Medicine descriptions | `sentence-transformers/all-MiniLM-L6-v2` sentence embeddings | Compares unresolved descriptions with medicine-group prototypes using cosine similarity after exact-name, brand and typo lookup |
| Research retrieval | BM25 | Retrieves up to 20 candidate abstracts for each herb and user goal |
| Research ranking | `cross-encoder/ms-marco-MiniLM-L6-v2` | Scores query/abstract pairs and orders leads from {m['library']} open-access abstracts; up to two leads per herb clear the relevance threshold |
| Label photo input | Tesseract.js LSTM OCR | Reads the photographed ingredient panel into editable text |
| Source cards | Deterministic ingredient/medicine rules | Selects the relevant text from {kb['unique_verified_passages']} verified NIH passages covering {kb['herbs']} herbs |
| Model execution | ONNX Runtime Web, WebAssembly and browser workers | Runs medicine understanding and research ranking on the device |

**Ray shows the difference AI makes.** With the same products and medicines, a dictionary-only run leaves "my cholesterol pill" unresolved and produces the goldenseal/metformin medicine card. The semantic model proposes a statin group, which adds the red yeast rice NIH card. The original words, suggested group, source passage and question to confirm the exact medicine remain visible together.

Research ranking also uses the person's input: Mei's memory and joint-pain goals produce separate ginkgo and turmeric leads. Ray's unrelated goldenseal studies are withheld by the relevance filter. Each displayed lead retains literal study excerpts for the pharmacist to inspect.

## Completed demonstration workflows

These four workflows ran on the public site on 13 November 2026. Profiles and the photographed label are fictional; the fourth workflow retrieves a live NIH product record.

| Case and input | Observed result |
|---|---|
| **Mei, 72:** warfarin, "her water pill," memory/joint blend | AI suggests a blood-pressure medicine group; ginkgo/garlic source cards for warfarin, ginseng species candidates and blend-dose questions appear; research separates memory from joint pain |
| **Sam, 29:** sertraline, birth control pill, St. John's wort/valerian/chamomile blend | Two medicine-specific NIH cards appear, together with chamomile species candidates |
| **Ray, 61:** metformin, "my cholesterol pill," lisinopril and two supplements | AI adds the red yeast rice medicine card; goldenseal/metformin and green tea repeated across bottles are shown; unrelated goldenseal research is withheld |
| **Own bottle:** live NIH ginkgo label plus photo; Coumadin, "zolpidm," "my blood pressure pill," ibuprofen; sleep goal | Brand/typo lookup and semantic inference work together; ginkgo/Coumadin and valerian/zolpidem cards, duplicate ginkgo and unresolved ibuprofen remain visible; a fresh browser opens the same brief from its QR link, and the medicine-excluded download removes all four names |

The source archive preserves the inputs, source URLs, model outputs, research scores and handoff/export results in `reports/project_scenarios_2026-11-13.json`. The same-input AI comparison is in `reports/ai_feature_ablation_2026-11-12.json`.

## Evaluation results

| Evaluation | Dataset and result | Evidence in the source archive |
|---|---|---|
| Medicine understanding | {h['phrases']} synthetic English phrases: {c['correct_group']}/{h['drug_phrases']} medicine descriptions assigned to the correct group, {c['wrong_group']} wrong groups, {c['missed']} left unassigned; all {c['correctly_unassigned']} negative/other inputs unassigned | `reports/ai_medicine_understanding_v2_2026-11-12.json` |
| Ingredient matching | {labels['labels_fetched']} held-out NIH labels: {labels['precision_exact_species']:.1%} exact-species precision and {labels['precision_genus_or_better']:.1%} genus-or-better precision | `reports/label_matching_holdout_2026-11-12.json` |
| Separate full-local research benchmark | SciFact: {retrieval['queries']} annotated claims, {retrieval['documents']:,} abstracts; nDCG@10 {retrieval['metrics']['bm25']['ndcg@10']:.3f} with BM25, {retrieval['metrics']['hybrid']['ndcg@10']:.3f} with hybrid retrieval, {retrieval['metrics']['rerank']['ndcg@10']:.3f} with neural reranking | `reports/retrieval_external.json` |

The browser worker and Python agree on group decisions across the original 34-phrase regression set and the fresh 54-phrase evaluation.

## Data flow and handoff

Medicine descriptions, goals, circumstances and photos are processed in the browser. NIH receives the separate product-search query or label record ID. A handoff link stores the case inputs in its compressed URL fragment, and the receiving browser rebuilds the brief. The recipient can choose to save it on that device. Export settings recompute the shared content so excluded medicine names also disappear from source cards and personal questions.

{repo}
```powershell
npm ci
python -m pip install -r requirements.lock
python scripts/setup_model.py
python scripts/setup_reranker.py
node scripts/build_browser_inference.mjs
python scripts/build_safety_knowledge.py
python scripts/build_care_demo.py
python scripts/sync_public_demo.py
.\\scripts\\start.ps1
```

Open **http://127.0.0.1:8000/check/**. The full FastAPI/SQLite application adds saved consultations, version history and pharmacist reading decisions. The browser product also includes five recorded study-to-product comparisons, explicitly labelled as replays.

To run the software checks from the extracted source directory:

```powershell
npm test
node scripts/verify_checker.mjs http://127.0.0.1:8000/check
```

## Source rights and development

{attribution}

`docs/ai_disclosure.md` in the source archive documents the model architecture, evaluation methods and development provenance. Hao directed the product with substantial Codex and Claude assistance. The project grew from an EthnoHack literature workspace into the DSH bottle-to-pharmacist workflow. NIH quotations, article licences and pinned model revisions are recorded with the source. Product code uses the MIT licence.
"""


def main():
    m=release_metrics();h=m['held'];c=h['counts'];kb=m['kb'];hold=m['hold'];med=m['med'];retrieval=m['retrieval']
    original,v2=sorted(m['public']['ai_medicine_parity'],key=lambda p:p['phrases'])
    write('README.md', project_readme(m, public=False))

    write('docs/ai_disclosure.md',f"""# FoliaTrace AI — AI architecture and evidence

FoliaTrace AI delivers an on-device workflow from a supplement label to a pharmacist brief. It interprets everyday medicine descriptions, ranks research for the actual bottle and goal, and connects warning cards and research leads to their original sources.

## Where AI changes the result

Ray remembers “my cholesterol pill.” A name lookup leaves that description unresolved. The language model proposes the statin group, which connects his words to the NIH red yeast rice card and a question to confirm the medicine. The [same-input ablation](../reports/ai_feature_ablation_2026-11-12.json) records the difference with language AI enabled and disabled.

## Completed browser workflows

Four workflows were re-run on the public site on 13 November 2026:

- **Mei:** warfarin and "her water pill" with a memory/joint blend. AI suggested a blood-pressure group; ginkgo/garlic source cards, ginseng identity, blend amounts and separate memory/joint research appeared.
- **Sam:** sertraline and birth control with St. John's wort, valerian and chamomile. Both medicine-specific source cards and chamomile species candidates appeared.
- **Ray:** metformin, "my cholesterol pill" and lisinopril with two supplements. AI suggested a statin group and added the red yeast rice card; goldenseal/metformin, repeated green tea and withheld unrelated goldenseal research were visible.
- **Own-bottle:** live NIH ginkgo lookup plus a photo, Coumadin, the typo "zolpidm", "my blood pressure pill" and ibuprofen. Brand/typo resolution, semantic inference, source cards, duplicate ginkgo and sleep research completed. A fresh browser opened the same brief from the QR link; excluding medicines from the download removed all four medicine names.

The [workflow report](../reports/project_scenarios_2026-11-13.json) preserves the actual inputs, model outputs, NIH source links, study scores and handoff/export results.

## Architecture

| Component | Implementation | Contribution |
|---|---|---|
| Medicine language | Sentence embeddings · `sentence-transformers/all-MiniLM-L6-v2` | Matches everyday descriptions to medicine-group prototypes after exact, brand and typo lookup |
| Personal research | Cross-encoder reranking · `cross-encoder/ms-marco-MiniLM-L6-v2` | Ranks candidate studies for each herb and goal in a library of {m['library']} open-access abstracts |
| Photo input | Tesseract English LSTM | Converts a label photo into editable ingredient text |
| Source cards | Deterministic matching | Connects ingredients and medicine groups to {kb['unique_verified_passages']} verified NIH passages across {kb['herbs']} herbs |

The medicine model compares sentence embeddings with group prototypes using cosine similarity, with a floor of {med['threshold']:.2f} and a runner-up margin of {med['margin']:.2f}. Negated, historical and supplement-only descriptions stay unassigned. Suggested groups retain the person’s original words and an exact-name confirmation prompt.

BM25 retrieves candidates from the herb-filtered library. The cross-encoder scores each query–abstract pair and keeps up to two leads above a raw-logit floor of 2.0, calibrated on three development examples. Expand a lead to inspect literal population, preparation and comparator excerpts beside the bottle. The five deeper seven-dimension comparisons are labelled replays from the full local app.

Warning cards quote NIH verbatim. Model and tokenizer hashes are checked before inference; the pinned assets are recorded in `data/models.lock.json` and `data/reranker.lock.json`.

## Measured results

| Evaluation | Result | Dataset and method |
|---|---|---|
| Medicine descriptions | **{c['correct_group']}/{h['drug_phrases']} correct groups; {c['wrong_group']} wrong group assignments** | {h['phrases']} synthetic English phrases; {c['missed']} medicine descriptions left unassigned; all {c['correctly_unassigned']} other or negated descriptions also unassigned |
| Label matching | **{hold['precision_exact_species']:.1%} exact-species precision** | {hold['labels_fetched']} held-out NIH labels retrieved by product search |
| Full-local research pipeline | **{retrieval['metrics']['bm25']['ndcg@10']:.3f} → {retrieval['metrics']['hybrid']['ndcg@10']:.3f} → {retrieval['metrics']['rerank']['ndcg@10']:.3f} nDCG@10** | SciFact development data: {retrieval['queries']} annotated claims and {retrieval['documents']:,} abstracts; keyword search, hybrid retrieval, neural reranking |

Browser workers and Python agree on medicine-group decisions across the original {original['phrases']}-phrase regression set and the fresh {v2['phrases']}-phrase evaluation. Reports retain the inputs and scoring details.

Engineering validation covers software behavior and labelled datasets. Pharmacist review and clinical outcome testing are the next evaluation milestones.

[Medicine report](../reports/ai_medicine_understanding_v2_2026-11-12.json) · [Label report](../reports/label_matching_holdout_2026-11-12.json) · [Research benchmark](../reports/retrieval_external.json) · [Browser verification](../reports/checker_browser_qa_public_2026-11-12.json)

## Data flow

Medicine descriptions, conditions, goals and photos stay in the browser. NIH receives the separate label-search query or record ID. QR sharing encodes the brief in the link; the recipient chooses whether to save it on their device. Research excerpts preserve the wording of the cited abstract.

## Development and provenance

Hao directed the product with substantial assistance from OpenAI Codex and Anthropic Claude across architecture, implementation, evaluations, documentation and demo production. The project began as an EthnoHack herbal-literature workspace; the DSH edition introduced the bottle-to-pharmacist workflow and its on-device medicine understanding.

Example people and products are fictional. NIH quotations are public-domain source material; article and model licences are recorded in [data/NOTICE.md](../data/NOTICE.md). Product code is MIT-licensed.
""")

    write('docs/release_v08_2026-11-12.md',f"""# FoliaTrace AI v0.8

This release connects everyday medicine descriptions, supplement ingredients and personal research goals in a pharmacist brief.

## Delivered

- Medicine-name, brand and typo lookup with semantic interpretation of everyday descriptions.
- AI group explanations linked to the exact NIH source card.
- Per-herb, per-goal research ranking with literal study excerpts beside the bottle.
- Live NIH label lookup, editable photo input and preservation of short ingredient names.
- QR handoff, selective exports, printable briefs and local consultation history.
- Readable medicine labels with the original description above the AI explanation.

## Verification

| Check | Passed |
|---|---|
| Behavioral unit tests | {m['unit']['passed']}/{m['unit']['tests']} |
| Static-build browser checks | {m['public_checks']}/{m['public_checks']} |
| Local-app browser checks | {m['local_checks']}/{m['local_checks']} |

The browser checks cover medicine inference, source links, research, live NIH lookup, OCR, QR, exports, erasure, request privacy and WCAG A/AA accessibility.

See [AI architecture and evidence](ai_disclosure.md) for evaluation methods and [README](../README.md) to run the product.
""")

    write('docs/dsh_v2_submission.md',f"""# FoliaTrace AI — submission text

## Tagline

Your words. Your bottle. Evidence your pharmacist can use.

## Inspiration

People remember what a medicine does more easily than its name. A supplement label adds another layer: unfamiliar plant names, blends and claims that are difficult to connect to a personal medicine list. We started with that moment at the pharmacy and built a way to arrive with the right questions and their sources.

## What it does

FoliaTrace AI turns a supplement label and a person’s own words into a pharmacist brief. Add a bottle through NIH label search, pasted ingredients or a photo. Enter medicine names or descriptions and the goal for taking the supplement. The brief brings together relevant NIH quotations, questions, label gaps and research ranked for each herb and goal.

“My cholesterol pill” shows the core AI contribution: language understanding proposes a statin group and connects it to the relevant red yeast rice source card. The original description and confirmation question stay visible. A pharmacist can compare the bottle with a study’s population, preparation and comparator wording, then explore a different research question.

QR handoff opens the brief on another screen. Selected details can also be printed or downloaded.

## How we built it

The browser combines MiniLM sentence embeddings for medicine language, BM25 retrieval and MiniLM cross-encoder reranking over {m['library']} open-access abstracts, and optional Tesseract label recognition. Pinned assets and hash checks make the models reproducible. A deterministic engine matches ingredients and medicine groups to {kb['unique_verified_passages']} verified NIH quotations.

Workers run inference locally. The full FastAPI/SQLite app adds saved consultations, version history and seven-dimension study comparisons.

## Evidence

- **Medicine language:** {c['correct_group']}/{h['drug_phrases']} correct groups and {c['wrong_group']} wrong group assignments across {h['phrases']} synthetic English phrases. All {c['correctly_unassigned']} other or negated descriptions remained unassigned.
- **Real labels:** {hold['precision_exact_species']:.1%} exact-species precision on {hold['labels_fetched']} held-out NIH product labels.
- **Research component:** full-local SciFact nDCG@10 improved from {retrieval['metrics']['bm25']['ndcg@10']:.3f} with keywords to {retrieval['metrics']['rerank']['ndcg@10']:.3f} with neural reranking.
- **Completed workflows:** Mei (warfarin, a water-pill description and memory/joint blend), Sam (sertraline, birth control and a mood blend), Ray (cholesterol-pill description and two bottles), and an own-bottle workflow all ran on the public site. The fourth combined live NIH lookup, photo input, brand/typo resolution, AI inference, sleep research, fresh-browser QR handoff and a medicine-excluded download. The source archive preserves the inputs and observed results in `reports/project_scenarios_2026-11-13.json`.

## Challenges we ran into

The hard part was connecting evidence to the right person. We built explicit handling for ambiguous plant identities, proprietary blends, descriptions that need confirmation, and differences between a study preparation and a product label. Each uncertainty becomes an inspectable part of the brief.

## Accomplishments

AI makes an otherwise incomplete medicine description useful. Source-linked questions give the pharmacist a practical starting point. The entire browser workflow runs on the person’s device, including language understanding and research ranking.

## What we learned

The value of health AI grows when its output helps a professional inspect the evidence and make the next decision.

## What’s next

Pharmacist review, usability sessions with older adults and caregivers, more source coverage, multilingual briefs and barcode lookup.

## Built with

JavaScript · MiniLM · MS MARCO cross-encoder · ONNX Runtime Web · WebAssembly · Tesseract.js · Python · FastAPI · SQLite · NIH DSLD · NIH NCCIH

## Development disclosure

Hao developed the product with substantial Codex and Claude assistance. The project began as an EthnoHack research workspace and was rebuilt around the DSH pharmacy workflow. Methods, validation status, source rights and development provenance are documented in `docs/ai_disclosure.md` in the source archive.
""")

    write('sites/foliatrace-research/README.md', project_readme(m, public=True))
    print('Built concise product README, AI evidence, release notes and submission copy from verified reports.')


if __name__=='__main__':main()

"""Offline data setup check, no network or hidden cache required."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.common import DATA, ROOT, read_json, digest


def validate():
    from src.evidence.product_labels import reference_labels
    reference_labels()  # Canonical hashes and ingredient hierarchy of bounded NIH examples.
    manifest=read_json(DATA/'acquisition.json')
    for name in ['passages.json','taxa.json','papers.json','compounds.json','vernacular_congeners.json']:
        if manifest['files'][name]['sha256']!=digest((DATA/name).read_bytes()):raise ValueError('Checksum mismatch: '+name)
    congeners=read_json(DATA/'vernacular_congeners.json')
    if congeners['taxa_sha256']!=digest((DATA/'taxa.json').read_bytes()):raise ValueError('Open-world congener data was built from a different taxa snapshot')
    freeze=read_json(ROOT/'benchmark'/'historical_transfer'/'FREEZE.json')
    for path,expected in freeze['files'].items():
        if digest((ROOT/path).read_bytes())!=expected:raise ValueError('Frozen historical transfer file changed: '+path)
    papers=read_json(DATA/'papers.json')
    if (DATA/'papers_extended.json').exists():
        papers += read_json(DATA/'papers_extended.json')['papers']
    for lockname in ('mechanisms.lock.json', 'second_corpus.lock.json', 'taxonomy_expansion.lock.json', 'literature_expansion.lock.json'):
        path = ROOT / 'data' / lockname
        if path.exists():
            lock = read_json(path)
            if digest((ROOT / lock['file']).read_bytes()) != lock['sha256']:
                raise ValueError('Optional snapshot checksum mismatch: ' + lockname)
    corpus = ROOT / 'benchmark/direction_corpus'
    if (corpus / 'manifest.json').exists():
        manifest = read_json(corpus / 'manifest.json')
        for split, value in manifest['splits'].items():
            path = corpus / (split + '.json')
            if digest(path.read_bytes()) != value['sha256']:
                raise ValueError('Outcome corpus checksum mismatch: ' + split)
    for paper in papers:
        if paper['licence'].lower() not in ['cc by','cc0','cc-by']:raise ValueError('Paper redistribution licence not approved')
        if not paper['id'].startswith('PMC') or not paper['provenance']['url'].startswith('https://www.ebi.ac.uk/'):raise ValueError('Missing source metadata')
    print('Verified core bundle:',len(read_json(DATA/'passages.json')),'historical sections,',len(read_json(DATA/'taxa.json')),'taxa,',len(papers),'licensed abstracts. Installed extension checksums also verified; full collection counts are shown in product health.')


if __name__=='__main__':validate()

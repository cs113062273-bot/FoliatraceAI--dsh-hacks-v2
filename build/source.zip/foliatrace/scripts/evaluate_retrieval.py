"""Untuned external retrieval evaluation against published SciFact human qrels."""
import json
import sys
import time
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import ROOT, read_json, write_json, digest, now
from src.retrieval.knowledge import TextIndex


def query_metrics(order, relevant):
    values = {}
    for k in (1, 5, 10, 40):
        hit = [id in relevant for id in order[:k]]
        values[f'recall@{k}'] = sum(hit) / len(relevant)
        ideal = sum(1 / np.log2(i+2) for i in range(min(k, len(relevant))))
        values[f'ndcg@{k}'] = sum(1 / np.log2(i+2) for i, h in enumerate(hit) if h) / ideal
    values['mrr@10'] = next((1/(i+1) for i, id in enumerate(order[:10]) if id in relevant), 0)
    return values


def main():
    base = ROOT / 'benchmark/scifact'
    manifest = read_json(base / 'manifest.json')
    for filename, record in manifest['files'].items():
        if digest((base / filename).read_bytes()) != record['sha256']:
            raise ValueError('External corpus checksum mismatch')
    docs = [json.loads(line) for line in (base / 'corpus.jsonl').read_text(encoding='utf-8').splitlines()]
    claims = [json.loads(line) for line in (base / 'claims_dev.jsonl').read_text(encoding='utf-8').splitlines()]
    queries = [q for q in claims if q['evidence']]
    index = TextIndex([d['title'] + ' ' + ' '.join(d['abstract']) for d in docs], cache_dir=ROOT / '.cache/scifact')
    predictions, timings = [], {}
    for method in ('bm25', 'embedding', 'hybrid', 'rerank'):
        start = time.perf_counter()
        for n, q in enumerate(queries):
            order = [str(docs[i]['doc_id']) for i, _ in index.rank(q['claim'], method=method, limit=40)]
            relevant = set(q['evidence'])
            predictions.append({'query_id': q['id'], 'method': method, 'relevant': sorted(relevant), 'ranked_ids': order, **query_metrics(order, relevant)})
            if n % 40 == 0:
                print(method, n, '/', len(queries), flush=True)
        timings[method] = round(time.perf_counter() - start, 2)
    keys = list(query_metrics([], {'0'}))
    metrics = {method: {key: float(np.mean([r[key] for r in predictions if r['method'] == method])) for key in keys} for method in timings}
    grouped = {m: {r['query_id']: r for r in predictions if r['method'] == m} for m in timings}
    # Cluster claims with the same relevant-article set, avoiding pseudo-independent paraphrases.
    groups = {}
    for q in queries:
        groups.setdefault(tuple(sorted(q['evidence'])), []).append(q['id'])
    rng = np.random.default_rng(20261021)
    clusters = list(groups.values())
    deltas = []
    for _ in range(1000):
        ids = [q for i in rng.integers(0, len(clusters), size=len(clusters)) for q in clusters[i]]
        deltas.append(np.mean([grouped['rerank'][id]['ndcg@10'] - grouped['bm25'][id]['ndcg@10'] for id in ids]))
    report = {'created_at': now(), 'dataset': 'SciFact original development split, annotated-evidence claims only', 'documents': len(docs), 'queries': len(queries), 'excluded_no_annotated_evidence': len(claims) - len(queries), 'labels': 'Published human claim-evidence annotations; relevance includes both support and contradiction; cited_doc_ids not used', 'configuration': 'Unchanged app TextIndex; BM25, pinned MiniLM embeddings, RRF k=60, pinned cross-encoder reranking top40 hybrid; sequence length384; no fitting or parameter search on these claims', 'metrics': metrics, 'rerank_minus_bm25_ndcg10_cluster_bootstrap': {'interval95': [float(np.quantile(deltas, .025)), float(np.quantile(deltas, .975))], 'clusters': len(clusters), 'draws': 1000, 'seed': 20261021}, 'seconds': timings, 'dataset_manifest_sha256': digest((base / 'manifest.json').read_bytes()), 'reranker_manifest_sha256': digest((ROOT / 'data/reranker.lock.json').read_bytes()), 'scope': 'External biomedical retrieval component evidence, not in-domain traditional-use search accuracy, historical identity or evidence entailment. Development labels are public; this is untuned evaluation, not blind test or official leaderboard submission.'}
    write_json(ROOT / 'reports/retrieval_external.json', report)
    write_json(ROOT / 'reports/retrieval_external_predictions.json', predictions)
    print(json.dumps(report['metrics'], indent=2), flush=True)


if __name__ == '__main__':
    main()

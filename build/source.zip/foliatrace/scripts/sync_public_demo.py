"""Copy the public browser app (checker, OCR runtime, knowledge base) into the static build.

Runs on its own for front-end iterations, and is called by build_care_demo.py.
The recorded evidence cases and the literature library are produced by build_care_demo.py.
"""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / 'sites/foliatrace-research/build'
APP_FILES = ('index.html', 'demo.css', 'demo.js', 'check.js', 'safety-engine.js', 'safety-examples.js',
             'safety-knowledge.json', 'pair-tokenizer.js', 'model-search-worker.js')
NM = ROOT / 'node_modules'
OCR_FILES = {
    'tesseract.min.js': NM / 'tesseract.js/dist/tesseract.min.js',
    'worker.min.js': NM / 'tesseract.js/dist/worker.min.js',
    'tesseract-core-lstm.wasm.js': NM / 'tesseract.js-core/tesseract-core-lstm.wasm.js',
    'tesseract-core-simd-lstm.wasm.js': NM / 'tesseract.js-core/tesseract-core-simd-lstm.wasm.js',
    'lang/eng.traineddata.gz': NM / '@tesseract.js-data/eng/4.0.0_best_int/eng.traineddata.gz',
    'LICENSE-tesseract.js.txt': NM / 'tesseract.js/LICENSE.md',
}


VENDOR = {'qrcode.js': NM / 'qrcode-generator/qrcode.js'}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    TARGET.mkdir(parents=True, exist_ok=True)
    # The EthnoHack-era historical research explorer is not part of the DSH product; keep it out of the site.
    for stale in ('research', 'assets', 'snapshots'):
        path = (TARGET / stale).resolve()
        if path.parent == TARGET.resolve() and path.exists():
            shutil.rmtree(path)
    for name in APP_FILES:
        shutil.copy2(ROOT / 'frontend/demo' / name, TARGET / name)
    manifest = {}
    for dest, src in OCR_FILES.items():
        if not src.exists():
            raise SystemExit(f'Missing {src}; run npm ci first.')
        out = TARGET / 'ocr' / dest
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, out)
        manifest[dest] = {'bytes': out.stat().st_size, 'sha256': sha(out)}
    for dest, src in VENDOR.items():
        (TARGET / 'vendor').mkdir(exist_ok=True)
        shutil.copy2(src, TARGET / 'vendor' / dest)
    pkg = json.loads((ROOT / 'package.json').read_text(encoding='utf-8'))
    manifest['_versions'] = {k: v for k, v in pkg.get('dependencies', {}).items() if 'tesseract' in k}
    (TARGET / 'ocr/manifest.json').write_text(json.dumps(manifest, indent=1) + '\n', encoding='utf-8')
    for dest, src in {'source.zip': ROOT / 'dist/dsh-v2/foliatrace-source.zip', 'one-page.pdf': ROOT / 'output/pdf/foliatrace-one-page.pdf',
                      'DATA-NOTICE.md': ROOT / 'data/NOTICE.md', 'CODE-LICENSE.txt': ROOT / 'LICENSE'}.items():
        if src.exists():
            shutil.copy2(src, TARGET / dest)
    print(f'Synced {len(APP_FILES)} app files and {len(OCR_FILES)} OCR files to {TARGET.relative_to(ROOT)}')


if __name__ == '__main__':
    main()

"""Copy the public browser app (checker, OCR runtime, knowledge base) into the static build.

Runs on its own for front-end iterations, and is called by build_care_demo.py.
The recorded evidence cases and the literature library are produced by build_care_demo.py.
"""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / 'sites/foliatrace-research/build'
APP_FILES = ('index.html', 'demo.css', 'demo.js', 'check.js', 'safety-engine.js', 'safety-examples.js',
             'safety-knowledge.json', 'pair-tokenizer.js', 'model-search-worker.js', 'ai-worker.js', 'medicine-language.js', 'research-evidence.js')
NM = ROOT / 'node_modules'
OCR_FILES = {
    'tesseract.min.js': NM / 'tesseract.js/dist/tesseract.min.js',
    'worker.min.js': NM / 'tesseract.js/dist/worker.min.js',
    'tesseract-core-lstm.wasm.js': NM / 'tesseract.js-core/tesseract-core-lstm.wasm.js',
    'tesseract-core-simd-lstm.wasm.js': NM / 'tesseract.js-core/tesseract-core-simd-lstm.wasm.js',
    'lang/eng.traineddata.gz': NM / '@tesseract.js-data/eng/4.0.0_best_int/eng.traineddata.gz',
    'LICENSE-tesseract.js.txt': NM / 'tesseract.js/LICENSE.md',
}


VENDOR = {'qrcode.js': NM / 'qrcode-generator/qrcode.js'}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    TARGET.mkdir(parents=True, exist_ok=True)
    # The EthnoHack-era historical research explorer is not part of the DSH product; keep it out of the site.
    for stale in ('research', 'assets', 'snapshots'):
        path = (TARGET / stale).resolve()
        if path.parent == TARGET.resolve() and path.exists():
            shutil.rmtree(path)
    for name in APP_FILES:
        shutil.copy2(ROOT / 'frontend/demo' / name, TARGET / name)
    # Always start from the original public-domain / CC-licensed corpus. Repeated
    # syncs cannot duplicate the bounded clinical additions.
    papers = []
    for name in ('papers.json', 'papers_extended.json'):
        records = json.loads((ROOT / 'data/demo' / name).read_text(encoding='utf-8'))
        papers.extend(records['papers'] if isinstance(records, dict) else records)
    additions = ROOT / 'data/demo/care_research_additions.json'
    if additions.exists():
        papers.extend(json.loads(additions.read_text(encoding='utf-8'))['papers'])
    library = {p['id']: {k: p.get(k, '') for k in ('id', 'title', 'abstract', 'url', 'licence')}
               for p in papers if p.get('abstract')}
    (TARGET / 'browser-library.json').write_text(json.dumps(list(library.values()), ensure_ascii=False) + '\n', encoding='utf-8')
    med = json.loads((ROOT / 'reports/ai_medicine_understanding_v2_2026-11-12.json').read_text(encoding='utf-8'))['held_out']
    dev = json.loads((ROOT / 'reports/label_matching_dev_2026-11-12.json').read_text(encoding='utf-8'))
    hold = json.loads((ROOT / 'reports/label_matching_holdout_2026-11-12.json').read_text(encoding='utf-8'))
    metrics = dict(library_count=len(library), medicine_wrong=med['counts']['wrong_group'], medicine_phrases=med['phrases'],
                   medicine_recall=f"{med['recall']:.0%}", medicine_correct=med['counts']['correct_group'], medicine_drugs=med['drug_phrases'],
                   species_precision=f"{hold['precision_exact_species']:.0%}", labels_holdout=hold['labels_fetched'],
                   labels_total=f"{dev['labels_fetched'] + hold['labels_fetched']:,}",
                   blend_percent=f"{(dev['botanical_rows_inside_blends_without_own_amount'] + hold['botanical_rows_inside_blends_without_own_amount']) / (dev['botanical_ingredient_rows'] + hold['botanical_ingredient_rows']):.0%}")
    (TARGET / 'product-metrics.json').write_text(json.dumps(metrics, indent=1) + '\n', encoding='utf-8')
    manifest = {}
    for dest, src in OCR_FILES.items():
        if not src.exists():
            raise SystemExit(f'Missing {src}; run npm ci first.')
        out = TARGET / 'ocr' / dest
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, out)
        manifest[dest] = {'bytes': out.stat().st_size, 'sha256': sha(out)}
    # On-device language understanding model (all-MiniLM-L6-v2), checksum-verified in the browser.
    lock = json.loads((ROOT / 'data/models.lock.json').read_text(encoding='utf-8'))
    inf = TARGET / 'inference'; inf.mkdir(exist_ok=True)
    shutil.copy2(ROOT / 'models/minilm/model.onnx', inf / 'embed-model.onnx')
    shutil.copy2(ROOT / 'models/minilm/tokenizer.json', inf / 'embed-tokenizer.json')
    (inf / 'embed-manifest.json').write_text(json.dumps({
        'model': lock['model'], 'revision': lock['revision'], 'licence': lock['licence'],
        'model_sha256': sha(inf / 'embed-model.onnx'), 'tokenizer_sha256': sha(inf / 'embed-tokenizer.json'),
        'purpose': 'Understanding how a person describes a medicine; similarity, not diagnosis.'}, indent=1) + '\n', encoding='utf-8')
    for dest, src in VENDOR.items():
        (TARGET / 'vendor').mkdir(exist_ok=True)
        shutil.copy2(src, TARGET / 'vendor' / dest)
    pkg = json.loads((ROOT / 'package.json').read_text(encoding='utf-8'))
    manifest['_versions'] = {k: v for k, v in pkg.get('dependencies', {}).items() if 'tesseract' in k}
    (TARGET / 'ocr/manifest.json').write_text(json.dumps(manifest, indent=1) + '\n', encoding='utf-8')
    for dest, src in {'source.zip': ROOT / 'dist/dsh-v2/foliatrace-source.zip', 'one-page.pdf': ROOT / 'output/pdf/foliatrace-one-page.pdf', 'code.pdf': ROOT / 'output/pdf/foliatrace-code.pdf',
                      'DATA-NOTICE.md': ROOT / 'data/NOTICE.md', 'CODE-LICENSE.txt': ROOT / 'LICENSE'}.items():
        if src.exists():
            shutil.copy2(src, TARGET / dest)
    print(f'Synced {len(APP_FILES)} app files and {len(OCR_FILES)} OCR files to {TARGET.relative_to(ROOT)}')


if __name__ == '__main__':
    main()

// Copy pinned, redistributable assets; no model or question goes to a third-party CDN.
import {copyFile,mkdir,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,join} from 'node:path';
const root=resolve(import.meta.dirname,'..'),target=join(root,'sites/foliatrace-research/build/inference');await mkdir(target,{recursive:true});
const lock=JSON.parse(await readFile(join(root,'data/reranker.lock.json'),'utf8'));
for(const file of lock.files){const source=join(root,'models/reranker',file.local);const bytes=await readFile(source);if(createHash('sha256').update(bytes).digest('hex')!==file.sha256)throw Error('Pinned model artifact differs: '+file.local);await copyFile(source,join(target,file.local));}
for(const file of ['ort.wasm.min.mjs','ort-wasm-simd-threaded.mjs','ort-wasm-simd-threaded.wasm'])await copyFile(join(root,'node_modules/onnxruntime-web/dist',file),join(target,file));
await copyFile(join(root,'node_modules/@huggingface/tokenizers/dist/tokenizers.mjs'),join(target,'tokenizers.mjs'));
for(const [name,url] of [['ONNX-RUNTIME-LICENSE.txt','https://raw.githubusercontent.com/microsoft/onnxruntime/main/LICENSE'],['ONNX-THIRD-PARTY-NOTICES.txt','https://raw.githubusercontent.com/microsoft/onnxruntime/main/ThirdPartyNotices.txt'],['MODEL-LICENSE.txt','https://www.apache.org/licenses/LICENSE-2.0.txt']]){
 const response=await fetch(url);if(!response.ok)throw Error('Required licence download failed: '+url);await writeFile(join(target,name),await response.text());
}
await copyFile(join(root,'node_modules/@huggingface/tokenizers/LICENSE'),join(target,'TOKENIZERS-LICENSE.txt'));
await writeFile(join(target,'manifest.json'),JSON.stringify({model:lock.model,revision:lock.revision,licence:lock.licence,model_sha256:lock.files.find(f=>f.local==='model.onnx').sha256,tokenizer_sha256:lock.files.find(f=>f.local==='tokenizer.json').sha256,runtime:'onnxruntime-web@1.31.1',tokenizers:'@huggingface/tokenizers@0.2.0',sequence_length:384,scope:'Relevance ranking only; not evidence entailment or probability.'},null,2));
console.log('Copied pinned browser inference assets to '+target);

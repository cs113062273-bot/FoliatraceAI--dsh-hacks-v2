// Causal demonstration on the fictional scenarios, using measured worker outputs.
// This is a feature ablation, not another holdout or a clinical benchmark.
import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {indexKnowledge,parseLabelText,analyze} from '../frontend/demo/safety-engine.js';
import {EXAMPLES} from '../frontend/demo/safety-examples.js';
const kb=JSON.parse(await readFile('frontend/demo/safety-knowledge.json','utf8'));
const language=JSON.parse(await readFile('reports/ai_medicine_understanding_v2_2026-11-12.json','utf8'));
const ai=Object.fromEntries(language.development.rows.map(r=>[r.text,{group:r.predicted,score:r.similarity}]));
const idx=indexKnowledge(kb);
const cases=EXAMPLES.map(ex=>{
 const input={products:ex.products.map(p=>parseLabelText(p.text,p.name)),medicines:ex.medicines,conditions:ex.conditions};
 const off=analyze(input,idx),on=analyze({...input,aiMedicines:ai},idx);
 const summarize=r=>({unrecognised:r.medicines.filter(m=>!m.known).map(m=>m.input),inferred:r.medicines.filter(m=>m.inferred).map(m=>({input:m.input,group:m.group})),medicine_cards:r.findings.filter(f=>f.because==='medicine').map(f=>({herb:f.herb,medicine:f.medicines[0].input,quotes:f.quotes.map(q=>q.text)}))});
 return {id:ex.id,dictionary_only:summarize(off),language_ai:summarize(on)};
});
const ray=cases.find(c=>c.id==='ray');
assert.ok(!ray.dictionary_only.medicine_cards.some(c=>c.herb==='red-yeast-rice'));
assert.ok(ray.language_ai.medicine_cards.some(c=>c.herb==='red-yeast-rice'&&c.medicine==='my cholesterol pill'));
const report={created:'2026-11-12',method:'Same fictional inputs and deterministic NIH engine; only measured language-AI group hypotheses are enabled/disabled. Development phrases, not held-out evaluation. A hypothesis is not an identified medicine.',cases};
await writeFile('reports/ai_feature_ablation_2026-11-12.json',JSON.stringify(report,null,1)+'\n');
console.log('PASS: Ray’s informal medicine produces a source-linked NIH card only when language AI supplies a group hypothesis.');

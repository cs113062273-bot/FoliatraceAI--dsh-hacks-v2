// Real-browser QA for the public FoliaTrace checker (Chrome/Edge via CDP, isolated profile).
// Usage: node scripts/verify_checker.mjs [baseUrl] [--no-live]
import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {mkdir, readFile, writeFile, mkdtemp} from 'node:fs/promises';
import {once} from 'node:events';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import assert from 'node:assert/strict';

const base = process.argv.find(a => a.startsWith('http')) || 'http://127.0.0.1:8015';
const live = !process.argv.includes('--no-live');
const out = '.runtime/checker-qa'; await mkdir(out, {recursive: true});
const exe = ['C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', '/usr/bin/chromium'].find(existsSync);
const profile = await mkdtemp(join(tmpdir(), 'foliatrace-qa-'));
const browser = spawn(exe, ['--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check', '--disable-extensions', 'about:blank'], {stdio: 'ignore'});
const delay = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, timeout = 30000, label = 'condition') { const end = Date.now() + timeout; let last; while (Date.now() < end) { try { const r = await fn(); if (r) return r; } catch (e) { last = e; } await delay(150); } throw Error('Timed out: ' + label + (last ? ' (' + last.message + ')' : '')); }
const report = {base, live, runner: 'Real Chromium via CDP; isolated profile; fictional data', started: new Date().toISOString(), checks: [], errors: [], requests: []};
let ws;
try {
  const port = await until(async () => Number((await readFile(join(profile, 'DevToolsActivePort'), 'utf8')).split('\n')[0]));
  const pages = await (await fetch(`http://127.0.0.1:${port}/json`)).json();
  ws = new WebSocket(pages.find(p => p.type === 'page').webSocketDebuggerUrl); await once(ws, 'open');
  let serial = 0; const pending = new Map();
  ws.addEventListener('message', e => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { const p = pending.get(m.id); pending.delete(m.id); m.error ? p.reject(Error(JSON.stringify(m.error))) : p.resolve(m.result); }
    else if (m.method === 'Runtime.exceptionThrown') report.errors.push(m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text);
    else if (m.method === 'Network.requestWillBeSent') report.requests.push({url: m.params.request.url, method: m.params.request.method, body: m.params.request.postData || ''}); });
  const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++serial; pending.set(id, {resolve, reject}); ws.send(JSON.stringify({id, method, params})); });
  const ev = async x => { const r = await send('Runtime.evaluate', {expression: x, awaitPromise: true, returnByValue: true}); if (r.exceptionDetails) throw Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text); return r.result.value; };
  const check = (label, ok) => { assert.ok(ok, label); report.checks.push(label); console.log('PASS ' + label); };
  const shot = async name => { const r = await send('Page.captureScreenshot', {format: 'png'}); await writeFile(join(out, name + '.png'), Buffer.from(r.data, 'base64')); };
  const goto = async url => { await send('Page.navigate', {url}); await until(() => ev(`document.documentElement.dataset.ready==='true'`), 30000, 'app ready'); };
  await send('Page.enable'); await send('Runtime.enable'); await send('Network.enable');
  await send('Page.addScriptToEvaluateOnNewDocument', {source: `addEventListener('securitypolicyviolation',e=>{const v=JSON.parse(sessionStorage.getItem('__csp')||'[]');v.push(e.violatedDirective+' '+e.blockedURI);sessionStorage.setItem('__csp',JSON.stringify(v))})`});
  await send('Emulation.setDeviceMetricsOverride', {width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false});

  await goto(base + '/');
  check('three example people render', await ev(`document.querySelectorAll('#example-list .example').length===3`));
  check('build button disabled until a product exists', await ev(`document.querySelector('#run-check').disabled`));
  check('knowledge base statistics shown from the verified file', await ev(`/25 herbs, 74 NIH passages verified word-for-word/.test(document.querySelector('#kb-stats').textContent)`));

  // Example 1: Mei
  await ev(`document.querySelector('[data-example=mei]').click()`);
  await until(() => ev(`!document.querySelector('#brief').hidden`), 5000, 'brief');
  const mei = await ev(`(()=>{const c=[...document.querySelectorAll('#brief .finding.discuss')];return {n:c.length,titles:c.map(x=>x.querySelector('h4').textContent),links:c.map(x=>x.querySelector('.nih-source a').href)}})()`);
  check('Mei: ginkgo × warfarin and garlic × warfarin raised first', mei.n === 2 && mei.titles.some(t => /Ginkgo × Warfarin/.test(t)) && mei.titles.some(t => /Garlic × Warfarin/.test(t)));
  check('Mei: every raised card links to an NIH NCCIH page', mei.links.every(h => h.startsWith('https://www.nccih.nih.gov/health/')));
  check('Mei: bare “ginseng” is an identity question with candidate species', await ev(`[...document.querySelectorAll('.gap.identity h4')].some(h=>/which ginseng/.test(h.textContent)) && document.querySelectorAll('.gap.identity .candidates>li').length===3`));
  check('Mei: proprietary blend reported once with its total', await ev(`[...document.querySelectorAll('.gap-list li')].filter(l=>/Proprietary Wellness Blend/.test(l.textContent)&&/300 mg in total/.test(l.textContent)).length===1`));
  check('Mei: BioPerine flags an absorption-enhanced curcumin form', await ev(`[...document.querySelectorAll('.finding h4')].some(h=>/Absorption-enhanced/.test(h.textContent))`));
  check('Mei: no invented ginger statement', await ev(`![...document.querySelectorAll('.finding h4')].some(h=>/^Ginger/.test(h.textContent))`));
  await shot('mei-brief');

  // Download / selective sharing / escaping
  const dl = await ev(`fetch(document.querySelector('#download-brief').href).then(r=>r.text())`);
  check('download contains verbatim NIH sentence and medicine list', dl.includes('Ginkgo may increase the risk of bleeding in people who are taking anticoagulant drugs, such as warfarin.') && dl.includes('Medicines I take:') && dl.includes('Warfarin 5 mg'));
  await ev(`document.querySelector('#share-meds').click()`);
  const dl2 = await ev(`new Promise(r=>setTimeout(r,200)).then(()=>fetch(document.querySelector('#download-brief').href)).then(r=>r.text())`);
  check('unticking “My medicines” removes the medicine list from the download', !dl2.includes('Medicines I take:'));
  await ev(`document.querySelector('#share-meds').click()`);

  // Serverless pharmacist handoff: QR + link round trip
  await ev(`document.querySelector('#show-handoff').click()`);
  await until(() => ev(`document.querySelector('#handoff-qr svg') && document.querySelector('#handoff-link').value.includes('#brief=')`), 10000, 'handoff QR');
  const link = await ev(`document.querySelector('#handoff-link').value`);
  check('handoff: QR code and link are generated in the browser (brief inside the URL fragment)', link.startsWith(base + '/#brief=') && link.length < 2500);
  report.handoff_link_chars = link.length;
  const meiTitles = await ev(`[...document.querySelectorAll('#brief .finding h4')].map(h=>h.textContent).join('|')`);
  await ev(`localStorage.clear()`);
  const before = report.requests.length;
  await send('Page.navigate', {url: 'about:blank'}); await delay(300);
  await goto(link);
  await until(() => ev(`!document.querySelector('#brief').hidden`), 8000, 'shared brief');
  check('handoff: a fresh browser opens the identical brief from the link alone', (await ev(`[...document.querySelectorAll('#brief .finding h4')].map(h=>h.textContent).join('|')`)) === meiTitles && await ev(`!document.querySelector('#shared-banner').hidden`));
  check('handoff: the brief data never appears in any request', report.requests.slice(before).every(r => !r.url.includes('#brief=') && !/warfarin/i.test(r.url + r.body)));
  check('handoff: opening a shared link does not save it on the device unless asked', await ev(`localStorage.getItem('foliatrace.check.v2')===null`));
  await ev(`document.querySelector('#print-root').innerHTML===''`);
  await send('Page.navigate', {url: base + '/'}); await until(() => ev(`document.documentElement.dataset.ready==='true'`), 20000, 'home');

  // Example 2 & 3
  await ev(`document.querySelector('[data-example=sam]').click()`);
  await until(() => ev(`document.querySelector('#brief-summary').textContent.length>0 && [...document.querySelectorAll('.finding h4')].some(h=>/St\\. John/.test(h.textContent))`), 5000, 'sam');
  check("Sam: St. John's wort × sertraline (serotonin) and × birth control pill (NIH list item quoted)", await ev(`(()=>{const c=[...document.querySelectorAll('.finding.discuss')];return c.some(x=>/Sertraline/.test(x.textContent)&&/serotonin/.test(x.textContent))&&c.some(x=>/Birth control pill/.test(x.querySelector('h4').textContent)&&/NIH’s list includes: Birth control pills/.test(x.textContent))})()`));
  await ev(`document.querySelector('[data-example=ray]').click()`);
  await until(() => ev(`[...document.querySelectorAll('.finding h4')].some(h=>/Red yeast rice/.test(h.textContent))`), 5000, 'ray');
  check('Ray: red yeast rice × atorvastatin shows “structurally identical to lovastatin”', await ev(`[...document.querySelectorAll('.finding.discuss')].some(x=>/Red yeast rice × Atorvastatin/.test(x.textContent)&&/structurally identical to the medicine lovastatin/.test(x.textContent))`));
  check('Ray: goldenseal × metformin and duplicate green tea across products', await ev(`[...document.querySelectorAll('.finding.discuss h4')].some(h=>/Goldenseal × Metformin/.test(h.textContent)) && [...document.querySelectorAll('.gap-list li')].some(l=>/Green tea extract.*2 products/.test(l.textContent))`));

  // Hostile input is escaped
  await ev(`document.querySelector('#clear-all').click(); document.querySelector('#tab-text').click(); const f=document.querySelector('#text-form'); f.elements.name.value='<img src=x onerror=window.__pwn=1>'; f.elements.text.value='Kava root 100 mg'; f.requestSubmit(); document.querySelector('#med-input').value='alprazolam, <b>xx</b>'; document.querySelector('#med-form').requestSubmit(); document.querySelector('#run-check').click();`);
  await until(() => ev(`!document.querySelector('#brief').hidden`), 5000, 'hostile brief');
  check('user text is never interpreted as HTML (screen and download)', await ev(`!window.__pwn && !document.querySelector('#brief img') && !document.querySelector('#product-list img')`) && !(await ev(`fetch(document.querySelector('#download-brief').href).then(r=>r.text())`)).includes('<img src=x'));
  check('kava × alprazolam (benzodiazepine) raised; unknown medicine kept for the pharmacist', await ev(`[...document.querySelectorAll('.finding.discuss h4')].some(h=>/Kava × alprazolam/.test(h.textContent)) && /did not recognise the medicine/.test(document.querySelector('#brief').textContent)`));

  // Reload persistence
  await send('Page.reload'); await until(() => ev(`document.documentElement.dataset.ready==='true'`), 20000, 'reload');
  check('products and medicines persist in this browser after reload', await ev(`document.querySelectorAll('.product-card').length===1 && document.querySelectorAll('#med-list .chip').length===2`));

  // OCR on a rendered label image
  await ev(`document.querySelector('#clear-all').click(); document.querySelector('#tab-photo').click();`);
  await ev(`(async()=>{const c=document.createElement('canvas');c.width=1100;c.height=520;const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.fillStyle='#111';g.font='bold 46px Arial';g.fillText('Supplement Facts',40,70);g.font='34px Arial';['Serving Size 1 Capsule','Ginkgo biloba leaf extract 120 mg','Valerian root 200 mg','St. John\\'s Wort extract 300 mg','Other ingredients: cellulose'].forEach((t,i)=>g.fillText(t,40,140+i*72));const b=await new Promise(r=>c.toBlob(r,'image/png'));const dt=new DataTransfer();dt.items.add(new File([b],'label.png',{type:'image/png'}));const i=document.querySelector('#photo-input');i.files=dt.files;i.dispatchEvent(new Event('change'));})()`);
  await until(() => ev(`/Ginkgo/i.test(document.querySelector('#text-form').elements.text.value)`), 120000, 'OCR text');
  const ocrText = await ev(`document.querySelector('#text-form').elements.text.value`);
  check('on-device OCR reads the photographed label into editable text', /valerian/i.test(ocrText) && /john/i.test(ocrText));
  await ev(`document.querySelector('#text-form').requestSubmit(); document.querySelector('#med-input').value='zolpidem, warfarin'; document.querySelector('#med-form').requestSubmit(); document.querySelector('#run-check').click();`);
  await until(() => ev(`[...document.querySelectorAll('.finding h4')].length>0`), 5000, 'ocr brief');
  check('photo → brief: valerian × zolpidem and ginkgo × warfarin raised; product marked as read from photo', await ev(`(()=>{const h=[...document.querySelectorAll('.finding.discuss h4')].map(x=>x.textContent).join('|');return /Valerian × zolpidem/.test(h)&&/Ginkgo × warfarin/.test(h)&&/Read from your photo/.test(document.querySelector('#product-list').textContent)})()`));
  await shot('ocr-brief');

  // Live NIH label search
  if (live) {
    await ev(`document.querySelector('#clear-all').click(); document.querySelector('#tab-search').click(); document.querySelector('#dsld-q').value='ginkgo biloba'; document.querySelector('#dsld-form').requestSubmit();`);
    await until(() => ev(`document.querySelectorAll('#dsld-results li').length>0`), 20000, 'NIH results');
    check('live NIH DSLD search returns label records', true);
    await ev(`document.querySelector('#dsld-results li button').click()`);
    await until(() => ev(`document.querySelectorAll('.product-card').length===1`), 20000, 'NIH label add');
    check('a live NIH label is added with its record number', await ev(`/NIH label #\\d+/.test(document.querySelector('.product-card').textContent)`));
    await ev(`document.querySelector('#med-input').value='Coumadin'; document.querySelector('#med-form').requestSubmit(); document.querySelector('#run-check').click();`);
    await until(() => ev(`!document.querySelector('#brief').hidden`), 5000, 'live brief');
    check('live NIH ginkgo label × Coumadin (brand of warfarin) raises the ginkgo statement', await ev(`[...document.querySelectorAll('.finding.discuss')].some(x=>/Ginkgo × Coumadin/.test(x.textContent))`));
    const nihReqs = report.requests.filter(r => r.url.includes('api.ods.od.nih.gov'));
    check('NIH requests carry only the label search or record id — never medicines', nihReqs.length > 0 && nihReqs.every(r => !/coumadin|warfarin|zolpidem|alprazolam/i.test(r.url + r.body)));
  }
  const foreign = report.requests.filter(r => !r.url.startsWith(base) && !r.url.startsWith('data:') && !r.url.startsWith('blob:') && !r.url.includes('api.ods.od.nih.gov'));
  check('no request leaves for any other host', foreign.length === 0);
  check('no medicine or condition text in any request', report.requests.every(r => !/warfarin|sertraline|zolpidem|alprazolam|metformin|surgery/i.test(r.url.replace(base, '') + r.body)));

  // Pharmacist evidence (recorded) and on-device AI research search, reached from the brief
  await goto(base + '/?example=mei');
  await until(() => ev(`document.querySelectorAll('#case-tabs button').length===5`), 15000, 'recorded cases');
  check('five recorded study-to-product comparisons load (labelled as replays)', await ev(`/replayed/.test(document.querySelector('.recording-note').textContent) && document.querySelectorAll('#case-detail table').length>0`));
  await ev(`document.querySelector('#brief .research').click()`);
  check('“Research this herb” fills the on-device research question from the brief', await ev(`/Ginkgo clinical trial/.test(document.querySelector('#live-form').elements.query.value)`));
  await ev(`document.querySelector('#live-form').elements.query.value='peppermint oil abdominal pain irritable bowel syndrome'; document.querySelector('#live-form button[value=ai]').click()`);
  await until(() => ev(`!document.querySelector('#live-results').hidden && document.querySelector('#live-results').dataset.method==='ai'`), 180000, 'on-device AI');
  const ai = await ev(`({n:document.querySelectorAll('#live-results article').length,scores:JSON.parse(document.querySelector('#live-results').dataset.scores),status:document.querySelector('#live-status').textContent})`);
  check('on-device neural reranker returns finite scores and keeps the question local', ai.n > 0 && ai.scores.every(Number.isFinite) && /No question was sent/.test(ai.status));
  check('no AI request leaves for any other host', report.requests.every(r => r.url.startsWith(base.replace(/\/check$/, '')) || r.url.startsWith('data:') || r.url.startsWith('blob:') || r.url.includes('api.ods.od.nih.gov')));

  // Accessibility & layout
  await goto(base + '/?example=ray');
  await ev(await readFile('node_modules/axe-core/axe.min.js', 'utf8'));
  const axe = await ev(`axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa']}}).then(r=>r.violations.map(v=>v.id+':'+v.nodes.length))`);
  report.axe = axe;
  check('axe WCAG 2 A/AA: zero violations with a full brief open', axe.length === 0);
  check('desktop: no horizontal overflow', await ev(`document.documentElement.scrollWidth<=innerWidth`));
  await send('Emulation.setDeviceMetricsOverride', {width: 390, height: 844, deviceScaleFactor: 2, mobile: true});
  await goto(base + '/?example=mei');
  check('390 px phone: no horizontal overflow with a full brief open', await ev(`document.documentElement.scrollWidth<=innerWidth+1`));
  await shot('mobile-brief');
  const csp = await ev(`sessionStorage.getItem('__csp')||'[]'`); report.csp_violations = JSON.parse(csp);
  check('Content-Security-Policy: zero violations on the final page', report.csp_violations.length === 0);
  check('no uncaught page exceptions', report.errors.length === 0);
  report.status = 'PASS';
} catch (e) { report.status = 'FAIL'; report.failure = e.message; console.error('FAIL', e.message); process.exitCode = 1; }
finally {
  report.finished = new Date().toISOString(); report.request_hosts = [...new Set(report.requests.map(r => { try { return new URL(r.url).host; } catch { return r.url.slice(0, 20); } }))]; delete report.requests;
  await writeFile('reports/checker_browser_qa_2026-11-12.json', JSON.stringify(report, null, 1) + '\n');
  try { ws?.close(); } catch {} browser.kill();
  console.log(report.status, report.checks.length, 'checks', report.errors.length ? 'errors: ' + report.errors.join(' | ') : '');
}

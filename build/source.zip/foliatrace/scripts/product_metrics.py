"""One source for release claims: machine-readable reports, never copied numbers."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]


def read(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def release_metrics():
    med = read('reports/ai_medicine_understanding_v2_2026-11-12.json')
    dev = read('reports/label_matching_dev_2026-11-12.json')
    hold = read('reports/label_matching_holdout_2026-11-12.json')
    kb = read('reports/safety_knowledge_verification.json')
    unit = read('reports/engine_tests_2026-11-12.json')
    public = read('reports/checker_browser_qa_public_2026-11-12.json')
    local = read('reports/checker_browser_qa_local_2026-11-12.json')
    for r in (unit, public, local):
        if r['status'] != 'PASS': raise ValueError('Release metrics require passing verification reports')
    library = read('sites/foliatrace-research/build/browser-library.json')
    botanical = dev['botanical_ingredient_rows'] + hold['botanical_ingredient_rows']
    hidden = dev['botanical_rows_inside_blends_without_own_amount'] + hold['botanical_rows_inside_blends_without_own_amount']
    return dict(med=med, held=med['held_out'], dev=dev, hold=hold, kb=kb, unit=unit, public=public, local=local, retrieval=read('reports/retrieval_external.json'),
                library=len(library), hidden=hidden, botanical=botanical, blend=f'{hidden / botanical:.0%}',
                labels=dev['labels_fetched'] + hold['labels_fetched'], public_checks=len(public['checks']), local_checks=len(local['checks']))

// Evaluate FoliaTrace name matching on real NIH DSLD labels.
// Ground truth: DSLD curators' declared Genus/Species on an ingredient row. The matcher sees only the
// ingredient name (+ forms), with the declared Genus/Species removed, then we compare.
// Usage: node scripts/evaluate_label_matching.mjs [--sample dev|holdout] [--per 24]
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {indexKnowledge, identify, fromDsldLabel} from '../frontend/demo/safety-engine.js';

const arg = (k, d) => { const i = process.argv.indexOf(k); return i > 0 ? process.argv[i + 1] : d; };
const sample = arg('--sample', 'dev'); const per = Number(arg('--per', '24'));
const offset = sample === 'dev' ? 0 : 60; // the held-out sample uses a later, non-overlapping results page
const kb = JSON.parse(await readFile('frontend/demo/safety-knowledge.json', 'utf8')); const idx = indexKnowledge(kb);
const cacheDir = '.runtime/dsld-cache'; await mkdir(cacheDir, {recursive: true});
const delay = ms => new Promise(r => setTimeout(r, ms));
async function getJson(url, file) {
  const path = `${cacheDir}/${file}.json`;
  if (existsSync(path)) return JSON.parse(await readFile(path, 'utf8'));
  // Polite pacing: NIH rate-limits bursts (HTTP 429). Back off exponentially when told to.
  for (let attempt = 0; attempt < 6; attempt++) {
    try {
      const r = await fetch(url, {headers: {'User-Agent': 'FoliaTrace-evaluation'}, signal: AbortSignal.timeout(15000)});
      if (r.ok) { const j = await r.json(); await writeFile(path, JSON.stringify(j)); await delay(1100); return j; }
      if (r.status === 429) { process.stderr.write(`429, backing off ${15 * 2 ** attempt}s\n`); await delay(15000 * 2 ** attempt); continue; }
    } catch {}
    await delay(1500 * (attempt + 1));
  }
  return null;
}
// Wait until NIH's rate limit has reset before starting (probe every 60 s, up to 2 h).
for (let i = 0; i < 120; i++) {
  try { const r = await fetch('https://api.ods.od.nih.gov/dsld/v9/label/33452', {signal: AbortSignal.timeout(15000)}); if (r.ok) break; process.stderr.write(`probe ${r.status} at ${new Date().toISOString()}\n`); } catch {}
  await delay(60000);
}
let fetchFailures = 0;
// Query terms: every covered herb plus generic botanical queries (so uncovered herbs appear too).
const queries = [...kb.herbs.map(h => h.name.replace(/\s*\/.*$/, '')), 'herbal blend', 'botanical', 'adaptogen', 'sleep support', 'immune support', 'women\'s health', 'liver support', 'energy'];
const ids = new Set();
for (const q of queries) {
  const s = await getJson(`https://api.ods.od.nih.gov/dsld/v9/search-filter?${new URLSearchParams({q, size: String(per), from: String(offset)})}`, `search-${sample}-${per}-${q.replace(/\W+/g, '_')}`);
  for (const h of s?.hits || []) ids.add(h._id);
}
const ownSet = sample === 'holdout' ? new Set() : null;
if (sample === 'holdout') { // drop any label that also appears in the dev sample
  for (const q of queries) { const s = await getJson(`https://api.ods.od.nih.gov/dsld/v9/search-filter?${new URLSearchParams({q, size: String(per), from: '0'})}`, `search-dev-${per}-${q.replace(/\W+/g, '_')}`); for (const h of s?.hits || []) ownSet.add(h._id); }
  for (const id of [...ids]) if (ownSet.has(id)) ids.delete(id);
}
import {levenshtein} from '../frontend/demo/safety-engine.js';
// Each herb's accepted (genus, species) pairs from its NCCIH Latin names.
const latinPairs = new Map([...idx.herbs.values()].map(h => [h.id, h.latin.map(l => l.toLowerCase().replace(/\(.*?\)|synonym/g, ' ').trim().split(/\s+/)).filter(p => p.length >= 2).map(([g, s]) => [g, s])]));
latinPairs.get('asian-ginseng').push(['panax', 'ginseng']);
const spp = s => !s || /^(spp?|sp\.?|species|x)$/.test(s);
function grade(genus, species, herbId) { // 'exact' | 'genus' | 'wrong'
  const g = genus.toLowerCase(), s = (species || '').toLowerCase();
  const pairs = latinPairs.get(herbId) || [];
  if (pairs.some(([pg, ps]) => pg === g && !spp(s) && levenshtein(ps, s, 2) <= 2)) return 'exact';
  if (pairs.some(([pg]) => pg === g)) return 'genus';
  return 'wrong';
}
function exactTruth(genus, species) { for (const [id] of latinPairs) if (grade(genus, species, id) === 'exact') return id; return null; }
let labels = 0, botanicalLabels = 0, labelsWithCovered = 0, blendLabels = 0, rows = 0, rowsInBlendNoAmount = 0;
const conf = {exact: 0, genus: 0, wrong: 0, missed: 0, correctly_unmatched: 0, ambiguous_with_true_candidate: 0, ambiguous_other: 0}; let graded = 0; const errors = []; const perHerb = {};
for (const id of ids) {
  const label = await getJson(`https://api.ods.od.nih.gov/dsld/v9/label/${id}`, `label-${id}`);
  if (!label) { fetchFailures++; if (fetchFailures > Math.max(5, ids.size * 0.02)) throw Error(`too many fetch failures (${fetchFailures}); sample would be biased — rerun later`); continue; }
  if (!label.ingredientRows) continue;
  labels++;
  const product = fromDsldLabel(label);
  const botan = product.ingredients.filter(i => i.category === 'botanical');
  if (!botan.length) continue;
  botanicalLabels++;
  if (product.ingredients.some(i => i.blend)) blendLabels++;
  let covered = false;
  for (const ing of botan) {
    rows++; if (ing.blend) rowsInBlendNoAmount++;
    if (!ing.genus) continue; // no curator genus to grade against
    const truth = exactTruth(ing.genus, ing.species);
    if (truth) covered = true;
    const nameOnly = {name: product.name, ingredients: [{text: [ing.name, (ing.text.split(' · ')[2] || '')].filter(Boolean).join(' · '), name: ing.name, category: 'botanical'}]};
    const found = identify(nameOnly, idx);
    const pred = found.find(f => f.herb)?.herb || null; const amb = found.find(f => f.ambiguous);
    graded++;
    const key = truth || '(not covered)'; perHerb[key] ??= {exact: 0, genus: 0, wrong: 0, missed: 0, n: 0}; perHerb[key].n++;
    if (amb && !pred) { const cand = idx.ambiguous.find(a => a.term === amb.ambiguous).candidates.map(c => c.herb); if (truth && cand.includes(truth)) conf.ambiguous_with_true_candidate++; else conf.ambiguous_other++; continue; }
    if (pred) {
      const g = grade(ing.genus, ing.species, pred); conf[g]++; perHerb[key][g]++;
      if (g !== 'exact') errors.push({label: id, ingredient: ing.name, declared: `${ing.genus} ${ing.species || ''}`.trim(), predicted: pred, grade: g});
    } else if (truth) { conf.missed++; perHerb[key].missed++; errors.push({label: id, ingredient: ing.name, declared: `${ing.genus} ${ing.species || ''}`.trim(), predicted: null, grade: 'missed', truth}); }
    else conf.correctly_unmatched++;
  }
  if (covered) labelsWithCovered++;
}
const predicted = conf.exact + conf.genus + conf.wrong;
const result = {
  sample, created: new Date().toISOString(), knowledge_base: kb.version, labels_selected: ids.size, label_fetch_failures: fetchFailures, labels_fetched: labels, labels_with_botanicals: botanicalLabels,
  botanical_ingredient_rows: rows, graded_rows_with_curator_genus: graded, confusion: conf,
  precision_exact_species: +(conf.exact / Math.max(1, predicted)).toFixed(4),
  precision_genus_or_better: +((conf.exact + conf.genus) / Math.max(1, predicted)).toFixed(4),
  wrong_genus_rate: +(conf.wrong / Math.max(1, predicted)).toFixed(4),
  recall_of_covered_species: +(conf.exact / Math.max(1, conf.exact + conf.missed)).toFixed(4),
  labels_with_a_covered_herb: labelsWithCovered, labels_with_blend_hidden_amounts: blendLabels,
  botanical_rows_inside_blends_without_own_amount: rowsInBlendNoAmount,
  method: 'Matcher sees ingredient name and forms only; the DSLD curator Genus/Species is removed and used as ground truth. exact = predicted NIH fact sheet lists the declared genus and species (species spelling within 2 edits); genus = same genus but a different or unspecified species; wrong = different genus; missed = declared species is covered but nothing was matched. Rows without a curator genus are not graded. ambiguous_with_true_candidate = the matcher refused to choose and listed the true species among its candidates.',
  selection: `DSLD search results (size ${per}, from ${offset}) for each covered herb name plus 8 generic botanical queries${sample === 'holdout' ? '; labels also present in the dev sample removed' : ''}. Search-ranked, not a random market sample.`,
  per_herb: perHerb, errors: errors.slice(0, 80),
};
await writeFile(`reports/label_matching_${sample}_2026-11-12.json`, JSON.stringify(result, null, 1) + '\n');
console.log(JSON.stringify({sample, labels, botanicalLabels, rows, graded, conf, exact: result.precision_exact_species, genusOrBetter: result.precision_genus_or_better, wrong: result.wrong_genus_rate, recall: result.recall_of_covered_species, blendLabels, rowsInBlendNoAmount, labelsWithCovered}, null, 1));
for (const e of errors.filter(e => e.grade !== 'genus').slice(0, 30)) console.log(' ', e.grade, '|', e.ingredient, '| declared', e.declared, '| pred', e.predicted);

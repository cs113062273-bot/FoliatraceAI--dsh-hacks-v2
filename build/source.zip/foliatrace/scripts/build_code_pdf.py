"""Render every first-party code file in the allow-listed source ZIP as a code PDF."""
import hashlib
import textwrap
from pathlib import Path
from zipfile import ZipFile
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib import colors
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/pdf/foliatrace-code.pdf'
EXT={'.py','.js','.mjs','.ps1','.html','.css','.sql'}


def main():
    archive=ROOT/'dist/dsh-v2/foliatrace-source.zip'
    with ZipFile(archive) as z:
        files=[(n,z.read(n)) for n in sorted(z.namelist()) if Path(n).suffix in EXT]
    OUT.parent.mkdir(parents=True,exist_ok=True)
    c=canvas.Canvas(str(OUT),pagesize=landscape(A4),pageCompression=1)
    c.setTitle('FoliaTrace - complete first-party source listing')
    c.setAuthor('FoliaTrace')
    width,height=landscape(A4);page=0;y=0;current='Source listing'
    def new_page():
        nonlocal page,y
        if page:c.showPage()
        page+=1;c.setFillColor(colors.HexColor('#24513d'));c.setFont('Helvetica-Bold',10)
        c.drawString(30,height-24,'FoliaTrace / source code')
        c.setFont('Helvetica',8);c.drawRightString(width-30,height-24,str(page))
        c.setStrokeColor(colors.HexColor('#bccdbd'));c.line(30,height-32,width-30,height-32)
        c.setFont('Helvetica',8);c.drawString(30,18,current[:150])
        c.setFillColor(colors.black);c.setFont('Courier',7);y=height-47
    new_page()
    intro=[
        'FoliaTrace - complete first-party source listing',
        f'{len(files)} code files from the accompanying allow-listed source archive.',
        'The archive also contains data, evaluation reports, README and AI disclosure.',
        'Third-party runtimes, model binaries, credentials, caches and saved user records are excluded.',
        'Non-ASCII code points are shown as reversible Python-style Unicode escapes.',
        'Long lines wrap visually; the original file bytes and hashes remain in source.zip.',
        'AI-assisted development by the entrant with OpenAI Codex and Anthropic Claude.',
        'Prior EthnoHack work is disclosed in README; this listing includes the complete packaged implementation.',
        f'Source archive SHA-256: {hashlib.sha256(archive.read_bytes()).hexdigest()}',
    ]
    for line in intro:
        c.drawString(30,y,line);y-=14
    for name,data in files:
        current=name.removeprefix('foliatrace/');new_page();c.bookmarkPage(current)
        c.addOutlineEntry(current,current,level=0)
        lines=[current,'SHA-256: '+hashlib.sha256(data).hexdigest(),'']
        text=data.decode('utf-8-sig')
        for number,line in enumerate(text.splitlines(),1):
            encoded=line.expandtabs(4).encode('ascii','backslashreplace').decode('ascii')
            wrapped=textwrap.wrap(encoded,width=165,replace_whitespace=False,drop_whitespace=False) or ['']
            lines.extend([f'{number:5d} '+wrapped[0],*['      '+s for s in wrapped[1:]]])
        for line in lines:
            if y<33:new_page()
            c.drawString(30,y,line);y-=9
    c.save()
    pages=len(PdfReader(OUT).pages)
    assert pages==page
    print(f'{OUT}: {len(files)} code files, {pages} pages')


if __name__=='__main__':main()

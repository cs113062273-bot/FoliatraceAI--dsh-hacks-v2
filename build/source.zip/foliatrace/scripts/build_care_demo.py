"""Build a privacy-separated, source-only public care demonstration.

No saved user records or local PubMed abstract cache are opened by this build.
The interactive preparation is browser-local; literature cards are labelled replays.
"""
from __future__ import annotations
import hashlib
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.common import now
from src.pipeline import Pipeline
from src.graph.store import GraphStore
from src.evidence.consultation import ConsultationInput, prepare_consultation
from src.evidence.product_labels import reference_labels, label_wording
from src.evidence.question_review import ResearchQuestion, run_question, canonical
from src.evidence.care_workspace import study_bridge


def wrapper(packet, origin):
    sha = hashlib.sha256(canonical(packet)).hexdigest()
    return {'id': sha[:24], 'sha256': sha, 'packet': packet, 'origin': origin}


def main():
    runtime = ROOT / '.runtime/public-care-build'
    runtime.mkdir(parents=True, exist_ok=True)
    pipeline = Pipeline(store=GraphStore(runtime / 'isolated.sqlite'), include_local_abstracts=False)
    pipeline.client.offline = True
    distributable = set()
    for name in ('papers.json', 'papers_extended.json'):
        records = json.loads((pipeline.data_dir / name).read_text(encoding='utf-8'))
        distributable.update(p['id'] for p in (records['papers'] if isinstance(records, dict) else records))
    assert all(not p.get('abstract') or p['id'] in distributable for p in pipeline.papers)
    labels = {s['label_id']: s for s in reference_labels()}
    scenarios = [
        ('mint', 'Mint capsules', None, None, 'digestive symptoms', ['abdominal pain', 'irritable bowel syndrome']),
        ('ginger', 'Ginger & nausea', 9936, 'Ginger root Ethanolic Extract', 'nausea', ['nausea', 'vomiting']),
        ('turmeric', 'Turmeric & joint symptoms', 9936, 'Turmeric root Supercritical CO2 Extract', 'joint symptoms', ['osteoarthritis', 'joint pain']),
        ('valerian', 'Valerian & sleep', 216782, 'Valerian', 'sleep', ['sleep quality', 'insomnia']),
        ('chamomile', 'Chamomile & sleep', 216782, 'Chamomile', 'sleep', ['sleep quality', 'insomnia']),
    ]
    cases = []
    for slug, title, label_id, ingredient_name, topic, terms in scenarios:
        if label_id:
            source = labels[label_id]
            product = {'name': source['raw']['fullName'], 'brand': source['raw'].get('brandName') or '',
                       'source_kind': 'PRODUCT_LABEL', 'source_text': label_wording(source['raw']),
                       'label_snapshot': source, 'reason_for_use': 'Fictional question about ' + topic}
        else:
            product = {'name': 'Mint capsules', 'plant_wording': 'Mint',
                       'source_text': 'Mint capsules; botanical species not stated.',
                       'dose': 'One capsule', 'frequency': 'Occasionally', 'preparation': 'capsules',
                       'reason_for_use': 'Fictional question about digestive symptoms'}
        prep = wrapper(prepare_consultation(pipeline, ConsultationInput(
            visit_label='Fictional public example: ' + title, products=[product])), 'LOCAL_CONSULTATION_PREPARATION')
        item = prep['packet']['products'][0]
        ingredient = next((r for r in item['label_ingredients'] if r['name'] == ingredient_name), None) if label_id else None
        name = (ingredient.get('research_lookup') or ingredient['lookup']) if ingredient else item['name_lookup']
        protocol = ResearchQuestion(question='Which human studies of ' + name + ' report ' + topic + '?',
                                   plant_name=name, source_text=ingredient['review_source_text'] if ingredient else product['source_text'],
                                   outcome_terms=terms, preparation='capsules' if not label_id else '', ranking='auto')
        review = wrapper(run_question(pipeline, protocol), 'LOCAL_QUESTION_REVIEW')
        packet = review['packet']
        rows = {(b['taxon_id'], r['id']): r for b in packet['branches'] for r in b['records']}
        leads = packet['overview']['top_studies']
        # A missing lead remains empty; unrelated papers do not fill the result.
        studies = []
        for lead in leads:
            row = rows[(lead['taxon_id'], lead['record_id'])]
            assert not row['paper'].get('abstract') or row['paper']['id'] in distributable
            bridge = study_bridge(prep, review, item['reported']['item_id'], row['id'], ingredient['key'] if ingredient else None)
            studies.append({'bridge': bridge, 'screening': row['screening'], 'study_types': row['study']['types'],
                            'licence': row['paper']['licence'], 'abstract': row['paper'].get('abstract') or '',
                            'paper_id': row['paper']['id']})
        cases.append({'id': slug, 'title': title, 'question': protocol.question,
                      'reported': item['reported'], 'candidates': ingredient['candidates'] if ingredient else item['candidates'],
                      'ingredient': ingredient_name, 'source_text': protocol.source_text,
                      'overview': {k: v for k, v in packet['overview'].items() if k not in ('selected_readings',)},
                      'coverage': packet['coverage'], 'studies': studies, 'review_sha256': review['sha256'],
                      'source_label': {'id': label_id, 'url': labels[label_id]['source_url'], 'sha256': labels[label_id]['sha256']} if label_id else None})
        print(slug, packet['overview']['endpoint_publications'], 'wording leads;', packet['coverage']['model'], flush=True)
    target = ROOT / 'sites/foliatrace-research/build'
    target.mkdir(parents=True, exist_ok=True)
    payload = {'created_at': now(), 'mode': 'RECORDED_SOURCE_ONLY_CARE_CASES',
               'pipeline_version': __import__('src').__version__, 'code_fingerprint': pipeline.code_fingerprint,
               'snapshot_sha256': pipeline.snapshot, 'local_private_abstracts_loaded': False,
               'abstracts_available': sum(bool(p.get('abstract')) for p in pipeline.papers),
               'cases': cases}
    (target / 'care-cases.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    library = [{k: p.get(k, '') for k in ('id', 'title', 'abstract', 'url', 'licence')}
               for p in pipeline.papers if p['id'] in distributable and p.get('abstract')]
    assert len(library) == 415 and len({p['id'] for p in library}) == len(library)
    (target / 'browser-library.json').write_text(json.dumps(library, ensure_ascii=False) + '\n', encoding='utf-8')
    shutil.copy2(ROOT / 'data/NOTICE.md', target / 'DATA-NOTICE.md')
    shutil.copy2(ROOT / 'LICENSE', target / 'CODE-LICENSE.txt')
    shutil.copy2(ROOT / 'reports/retrieval_external.json', target / 'retrieval-evaluation.json')
    from scripts.sync_public_demo import main as sync_app
    sync_app()  # checker app, OCR runtime, QR library, source archive, one-page PDF
    print('Built', len(cases), 'public cases at', target)


if __name__ == '__main__':
    main()

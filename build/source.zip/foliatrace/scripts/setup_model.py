"""Install a pinned, open MiniLM ONNX encoder without paid inference APIs."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json
from urllib.request import urlopen
from src.common import ROOT, digest, now, read_json, write_json
from src.ingestion.tls import tls_context

MODEL = "sentence-transformers/all-MiniLM-L6-v2"
LOCK = ROOT / "data" / "models.lock.json"


def main():
    target = ROOT / "models" / "minilm"
    target.mkdir(parents=True, exist_ok=True)
    if LOCK.exists():
        lock = read_json(LOCK)
    else:
        with urlopen(f"https://huggingface.co/api/models/{MODEL}?blobs=true", timeout=40, context=tls_context()) as response:
            data = json.load(response)
        if data.get("cardData", {}).get("license") != "apache-2.0":
            raise ValueError("Unexpected model licence")
        files = {x["rfilename"]: x for x in data["siblings"]}
        model_file = next(x for x in ["onnx/model_quint8_avx2.onnx", "onnx/model_qint8_avx512_vnni.onnx", "onnx/model.onnx"] if x in files)
        lock = {"model": MODEL, "revision": data["sha"], "licence": "Apache-2.0", "observed_at": now(), "purpose": "Sentence embeddings for retrieval, not clinical inference", "files": [{"remote": model_file, "local": "model.onnx", "upstream_sha256": files[model_file].get("lfs", {}).get("sha256")}, {"remote": "tokenizer.json", "local": "tokenizer.json", "upstream_sha256": None}]}
    for entry in lock["files"]:
        dest = target / entry["local"]
        expected = entry.get("sha256") or entry.get("upstream_sha256")
        if dest.exists() and expected and digest(dest.read_bytes()) == expected:
            print("verified:", entry["local"], flush=True)
            continue
        url = f"https://huggingface.co/{lock['model']}/resolve/{lock['revision']}/{entry['remote']}"
        with urlopen(url, timeout=120, context=tls_context()) as response:
            body = response.read(150_000_001)
            if len(body) > 150_000_000:
                raise ValueError("Model artifact exceeds download bound")
        checksum = digest(bytes(body))
        if expected and checksum != expected:
            raise ValueError("Pinned model artifact checksum mismatch")
        dest.write_bytes(body)
        entry.update({"sha256": checksum, "bytes": len(body), "url": url})
        print("installed:", entry["local"], len(body), flush=True)
    write_json(LOCK, lock)


if __name__ == "__main__":
    main()

"""Build the current one-page product overview without browser automation."""
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from product_metrics import release_metrics

ROOT=Path(__file__).resolve().parents[1]
TARGET=ROOT/'output/pdf/foliatrace-one-page.pdf'
GREEN=colors.HexColor('#24513d')
styles={
    'title':ParagraphStyle('title',fontName='Times-Bold',fontSize=34,leading=38,textColor=GREEN,spaceAfter=10),
    'lead':ParagraphStyle('lead',fontName='Helvetica',fontSize=15,leading=20,textColor=GREEN,spaceAfter=16),
    'heading':ParagraphStyle('heading',fontName='Helvetica-Bold',fontSize=12,leading=16,textColor=GREEN,spaceBefore=12,spaceAfter=5),
    'body':ParagraphStyle('body',fontName='Helvetica',fontSize=11,leading=15,textColor=colors.HexColor('#26392f'),spaceAfter=7),
    'small':ParagraphStyle('small',fontName='Helvetica',fontSize=9,leading=12,textColor=colors.HexColor('#526359'),spaceAfter=5),
}


def p(text,style='body'):
    return Paragraph(text,styles[style])


def page(canvas,doc):
    canvas.setFillColor(colors.HexColor('#f8f5ed'));canvas.rect(0,0,*A4,fill=1,stroke=0)
    canvas.setStrokeColor(GREEN);canvas.setLineWidth(2);canvas.line(42,A4[1]-32,A4[0]-42,A4[1]-32)
    canvas.setFont('Helvetica',8);canvas.setFillColor(GREEN)
    canvas.drawString(42,27,'FoliaTrace | v0.8 | 12 November 2026')
    canvas.drawRightString(A4[0]-42,27,'Product overview / 1')


def main():
    m=release_metrics(); h=m['held']; c=h['counts']; kb=m['kb']; hold=m['hold']
    TARGET.parent.mkdir(parents=True,exist_ok=True)
    story=[p('FoliaTrace','title'),p('Bring the bottle. Start a better conversation.','lead'),
        p('A person, a bottle, a medicine they cannot name','heading'),
        p('Mei, 72, takes warfarin and "her water pill". Her daughter buys a memory-and-joint supplement. FoliaTrace uses on-device language AI to suggest the medicine group and neural research ranking to find studies for her bottle and goals. Her pharmacist receives exact NIH warnings, visible uncertainties and source links.'),
        p('Three steps, one brief','heading')]
    cells=[]
    for title,text in [('1. The bottle','Search NIH-listed U.S. labels, paste ingredients, or photograph the panel and check the recognised text.'),('2. Your words','Enter a medicine name or describe it. AI proposes a group, or abstains. Add the purpose of your supplement.'),('3. The brief','NIH quotations, questions, label gaps and goal-specific research. QR handoff; print, download or choose what to share.')]:
        cells.append([p(title,'heading'),p(text)])
    table=Table([[cells[0],cells[1],cells[2]]],colWidths=[170,170,170]);table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#eaf0e8')),('BOX',(0,0),(-1,-1),.5,colors.HexColor('#bccdbd')),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),10)]));story += [table,
        p('AI does useful work; sources keep it accountable','heading'),
        p(f'MiniLM understands descriptions such as "my cholesterol pill"; inferred groups remain labelled AI and need exact-name confirmation. A cross-encoder ranks {m["library"]} open-access abstracts for each herb and each goal. Expand a lead to compare literal population, preparation and comparator wording with the bottle. Low-scoring results stay empty. "Ginseng" and other ambiguous species stay unresolved.'),
        p('Evidence you can check','heading'),
        p(f'<b>Language AI:</b> {c["correct_group"]}/{h["drug_phrases"]} medicine descriptions assigned correctly; <b>{c["wrong_group"]} wrong group assignments</b>; {c["correctly_unassigned"]} other/negated phrases unassigned ({h["phrases"]} fresh synthetic English phrases). Browser and Python decisions agree. <b>Labels:</b> {hold["precision_exact_species"]:.1%} exact-species precision on {hold["labels_fetched"]} unseen NIH labels. <b>Verification:</b> {m["public_checks"]} browser checks on each of the public build and local checker; {m["unit"]["passed"]} behavioral tests. Zero CSP and WCAG A/AA violations in these runs.'),
        p('One rule: every warning is NIH\'s own words','heading'),
        p(f'{kb["unique_verified_passages"]} NIH passages verified word-for-word; no generative model writes a warning. Proprietary blends, duplicates and unknowns remain visible. Health inputs and photos stay in the browser; the QR brief travels inside the URL fragment. Free, no account, no paid inference service.'),
        p('Try: foliatrace-research.civil-bell-5511.chatgpt.site  |  Full local app: scripts/start.ps1','heading'),
        p(f'Prepares a conversation; does not replace a pharmacist, give doses or certify safety. Covers {kb["herbs"]} herbs. Synthetic language tests and search-ranked labels; research relevance is development-calibrated. No pharmacist review, user study or clinical validation. Fictional examples. NIH quotations public domain; article rights retained. Codex/Claude assisted development; prior EthnoHack work disclosed. MIT code.','small')]
    SimpleDocTemplate(str(TARGET),pagesize=A4,rightMargin=42,leftMargin=42,topMargin=49,bottomMargin=40,title='FoliaTrace - supplement label to pharmacist brief',author='FoliaTrace').build(story,onFirstPage=page,onLaterPages=page)
    from pypdf import PdfReader
    assert len(PdfReader(TARGET).pages)==1,'Product overview must be one page'
    print(TARGET)


if __name__=='__main__':main()

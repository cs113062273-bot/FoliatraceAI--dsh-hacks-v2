"""Build the factual, one-page DSH project description from measured results."""
from pathlib import Path
import json
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle
from product_metrics import release_metrics

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / 'output/pdf/foliatrace-one-page.pdf'
GREEN = colors.HexColor('#24513d')
INK = colors.HexColor('#22382e')
WIDTH = A4[0] - 72
STYLES = {
    'title': ParagraphStyle('title', fontName='Times-Bold', fontSize=25, leading=28, textColor=GREEN, spaceAfter=4),
    'subtitle': ParagraphStyle('subtitle', fontName='Helvetica', fontSize=10.4, leading=14, textColor=INK, spaceAfter=7),
    'heading': ParagraphStyle('heading', fontName='Helvetica-Bold', fontSize=11, leading=14, textColor=GREEN, spaceBefore=7, spaceAfter=4),
    'body': ParagraphStyle('body', fontName='Helvetica', fontSize=9.6, leading=12.7, textColor=INK, spaceAfter=5),
    'cell': ParagraphStyle('cell', fontName='Helvetica', fontSize=9.1, leading=12, textColor=INK),
    'tablehead': ParagraphStyle('tablehead', fontName='Helvetica-Bold', fontSize=9.1, leading=12, textColor=colors.white),
    'small': ParagraphStyle('small', fontName='Helvetica', fontSize=8.2, leading=10.5, textColor=colors.HexColor('#53645b'), spaceAfter=4),
    'links': ParagraphStyle('links', fontName='Helvetica', fontSize=8.6, leading=11.5, textColor=GREEN, spaceBefore=5),
}


def p(text, style='body'):
    return Paragraph(text, STYLES[style])


def page(canvas, doc):
    canvas.setStrokeColor(GREEN)
    canvas.setLineWidth(1.2)
    canvas.line(36, A4[1] - 27, A4[0] - 36, A4[1] - 27)
    canvas.setFont('Helvetica', 7.5)
    canvas.setFillColor(colors.HexColor('#53645b'))
    canvas.drawString(36, 23, 'FoliaTrace AI | v0.8 | 13 November 2026')
    canvas.drawRightString(A4[0] - 36, 23, 'DSH Hacks V2 - Project description / 1')


def main():
    m = release_metrics()
    held, labels, kb = m['held'], m['hold'], m['kb']
    counts = held['counts']
    runs = json.loads((ROOT / 'reports/project_scenarios_2026-11-13.json').read_text(encoding='utf-8'))
    assert runs['completed'] == 4
    assert runs['scenarios'][-1]['handoff']['sameFindingsInFreshBrowser']
    assert runs['scenarios'][-1]['export']['medicinesExcluded']
    story = [
        p('FoliaTrace AI', 'title'),
        p('A browser tool that turns supplement labels and medicine descriptions into a source-linked pharmacist brief.', 'subtitle'),
        p('Problem, purpose and users', 'heading'),
        p('Older adults and caregivers may know a medicine only as "my cholesterol pill," while supplement labels contain ambiguous plant names, blends and repeated ingredients. FoliaTrace AI brings these details together before a pharmacy consultation. Users prepare the brief; pharmacists review the medicine-group suggestions, ingredient questions, NIH quotations and relevant studies.'),
        p('How to use the working prototype', 'heading'),
        p('<b>1.</b> Open <b>Check a bottle</b>: search NIH product labels, paste ingredients or upload a label photo and review the extracted text. <b>2.</b> Add medicine names, brands or descriptions, the supplement goal and relevant circumstances. <b>3.</b> Select <b>Build my brief</b>; inspect the matched source passages and ranked studies. <b>4.</b> Use <b>Hand to pharmacist (QR)</b>, Print / PDF or Download; select which personal details to include.'),
        p('AI technology and implementation', 'heading'),
        p('<b>Medicine language:</b> exact-name, brand and typo matching runs first. <b>all-MiniLM-L6-v2 sentence embeddings</b> compare unresolved descriptions with medicine-group prototypes using cosine similarity. The accepted suggestion remains beside the original wording for confirmation.'),
        p(f'<b>Research:</b> <b>BM25 retrieval</b> selects up to 20 candidates from {m["library"]} open-access abstracts. The <b>ms-marco-MiniLM-L6-v2 cross-encoder</b> reranks them for each herb and user goal; up to two leads per herb clear a development-calibrated relevance threshold. Leads display the study\'s population, preparation and comparator excerpts.'),
        p(f'<b>Evidence and delivery:</b> ingredient/medicine rules select from {kb["unique_verified_passages"]} verbatim NIH passages covering {kb["herbs"]} herbs. Optional <b>Tesseract LSTM OCR</b> reads photos. ONNX models run in browser workers; QR handoff encodes the brief in a compressed URL fragment.'),
        p('Four completed user workflows - input to observed result', 'heading'),
        p('Re-run on the public site on 13 November 2026. Profiles and photo label are fictional; the fourth workflow fetches a live NIH product record.', 'small'),
    ]
    rows = [[p('Scenario / input', 'tablehead'), p('Observed product output', 'tablehead')]]
    cases = [
        ('<b>Mei, 72</b><br/>Warfarin + "her water pill"; memory/joint blend with ginkgo, turmeric, garlic and ginseng.',
         'AI suggests a blood-pressure medicine group. Ginkgo/garlic medicine cards quote NIH passages for warfarin. Ginseng identity and blend-dose questions remain visible. Research separates ginkgo for memory from turmeric for joint pain.'),
        ('<b>Sam, 29</b><br/>Sertraline + birth control pill; St. John\'s wort, valerian and chamomile; mood/stress goal.',
         'Two medicine-specific NIH cards identify St. John\'s wort concerns for sertraline and birth control. Chamomile is presented as a species-identification question with candidate plants.'),
        ('<b>Ray, 61</b><br/>Metformin + "my cholesterol pill" + lisinopril; two products containing red yeast rice, goldenseal and green tea.',
         'AI maps the description to a statin group, adding the red yeast rice card missed by name matching. Goldenseal/metformin also appears. Green tea is flagged across both bottles; unrelated goldenseal research is withheld.'),
        ('<b>Own-bottle workflow</b><br/>Live NIH ginkgo label + photo; Coumadin, "zolpidm," "my blood pressure pill," ibuprofen; sleep goal.',
         'Coumadin resolves to warfarin; "zolpidm" to zolpidem. AI suggests a blood-pressure medicine group. Ginkgo/Coumadin and valerian/zolpidem cards appear, with duplicate ginkgo and unresolved ibuprofen. A fresh browser opens the same brief via QR link; the medicine-excluded download omits all four names.'),
    ]
    rows.extend([[p(a, 'cell'), p(b, 'cell')] for a, b in cases])
    table = Table(rows, colWidths=[WIDTH * .355, WIDTH * .645], hAlign='LEFT')
    table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BACKGROUND', (0, 0), (-1, 0), GREEN),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#f0f4ee'), colors.white]),
        ('LINEBELOW', (0, 1), (-1, -1), .35, colors.HexColor('#ccd7cc')),
        ('LEFTPADDING', (0, 0), (-1, -1), 8), ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    story += [table,
        p('Measured AI and label-recognition results', 'heading'),
        p(f'<b>Medicine language:</b> {counts["correct_group"]}/{held["drug_phrases"]} synthetic medicine descriptions assigned correctly, {counts["wrong_group"]} assigned to the wrong group and {counts["missed"]} left unassigned; all {counts["correctly_unassigned"]} negative/other phrases left unassigned. <b>Label matching:</b> {labels["labels_fetched"]} held-out NIH records, {labels["precision_exact_species"]:.1%} exact-species precision and {labels["precision_genus_or_better"]:.1%} genus-or-better precision.'),
        p('<link href="https://foliatrace-research.civil-bell-5511.chatgpt.site/" color="#24513d"><b>Try the product</b></link> - choose Mei, Sam or Ray to reproduce the first three workflows.<br/><link href="https://foliatrace-research.civil-bell-5511.chatgpt.site/source.zip" color="#24513d"><b>Source + evidence</b></link> - scenario inputs/results, evaluation datasets, model details and AI disclosure.', 'links'),
    ]
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    SimpleDocTemplate(str(TARGET), pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36,
                      title='FoliaTrace AI - purpose, technology and completed workflows', author='FoliaTrace AI').build(story, onFirstPage=page, onLaterPages=page)
    from pypdf import PdfReader
    assert len(PdfReader(TARGET).pages) == 1, 'Project description must be one page'
    print(TARGET)


if __name__ == '__main__':
    main()

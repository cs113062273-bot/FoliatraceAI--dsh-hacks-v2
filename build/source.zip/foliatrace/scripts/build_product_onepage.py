"""Build the current one-page product overview without browser automation."""
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from product_metrics import release_metrics

ROOT=Path(__file__).resolve().parents[1]
TARGET=ROOT/'output/pdf/foliatrace-one-page.pdf'
GREEN=colors.HexColor('#24513d')
styles={
    'title':ParagraphStyle('title',fontName='Times-Bold',fontSize=34,leading=38,textColor=GREEN,spaceAfter=10),
    'lead':ParagraphStyle('lead',fontName='Helvetica',fontSize=15,leading=20,textColor=GREEN,spaceAfter=16),
    'heading':ParagraphStyle('heading',fontName='Helvetica-Bold',fontSize=12,leading=16,textColor=GREEN,spaceBefore=12,spaceAfter=5),
    'body':ParagraphStyle('body',fontName='Helvetica',fontSize=11,leading=15,textColor=colors.HexColor('#26392f'),spaceAfter=7),
    'small':ParagraphStyle('small',fontName='Helvetica',fontSize=9,leading=12,textColor=colors.HexColor('#526359'),spaceAfter=5),
    'proof':ParagraphStyle('proof',fontName='Times-Bold',fontSize=28,leading=32,textColor=GREEN,spaceAfter=4),
    'proof_label':ParagraphStyle('proof_label',fontName='Helvetica',fontSize=9.5,leading=13,textColor=colors.HexColor('#26392f')),
}


def p(text,style='body'):
    return Paragraph(text,styles[style])


def page(canvas,doc):
    canvas.setFillColor(colors.HexColor('#f8f5ed'));canvas.rect(0,0,*A4,fill=1,stroke=0)
    canvas.setStrokeColor(GREEN);canvas.setLineWidth(2);canvas.line(42,A4[1]-32,A4[0]-42,A4[1]-32)
    canvas.setFont('Helvetica',8);canvas.setFillColor(GREEN)
    canvas.drawString(42,27,'FoliaTrace AI | v0.8 | 13 November 2026')
    canvas.drawRightString(A4[0]-42,27,'Product overview / 1')


def main():
    m=release_metrics(); h=m['held']; c=h['counts']; kb=m['kb']; hold=m['hold']
    TARGET.parent.mkdir(parents=True,exist_ok=True)
    story=[p('FoliaTrace AI','title'),p('Your words. Your bottle. Evidence your pharmacist can use.','lead'),
        p('Start with the words a person actually remembers','heading'),
        p('Ray calls it "my cholesterol pill." FoliaTrace AI interprets his description, connects his supplement ingredients to the relevant NIH quotation and prepares a brief for his pharmacist. His words, the suggested medicine group and the confirmation question stay together.'),
        p('From the label to the pharmacy','heading')]
    cells=[]
    for title,text in [('1. Add the bottle','Search NIH labels, paste ingredients or review text read from a photo.'),('2. Describe the medicines','Use names, brands or everyday descriptions. Add the goal for the supplement.'),('3. Bring the evidence','Share the brief by QR, print it or download the details you choose.')]:
        cells.append([p(title,'heading'),p(text)])
    table=Table([[cells[0],cells[1],cells[2]]],colWidths=[170,170,170]);table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#eaf0e8')),('BOX',(0,0),(-1,-1),.5,colors.HexColor('#bccdbd')),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),10)]));story += [table,
        p('On-device embeddings + cross-encoder reranking','heading'),
        p(f'MiniLM sentence embeddings match medicine descriptions to likely groups. BM25 finds candidate studies, and a MiniLM cross-encoder reranks them for the bottle and goal. The library contains {m["library"]} open-access abstracts. Each lead shows the study\'s own wording beside the bottle label.'),
        p('Measured performance','heading')]
    proof=[]
    for value,label in [
        (f'{c["correct_group"]}/{h["drug_phrases"]}',f'Medicine descriptions matched to the correct group, with {c["wrong_group"]} wrong assignments.<br/>{h["phrases"]} synthetic English phrases.'),
        (f'{hold["precision_exact_species"]:.1%}',f'Exact-species precision.<br/>{hold["labels_fetched"]} held-out NIH labels.'),
        (str(kb['unique_verified_passages']),f'NIH passages verified word for word.<br/>{kb["herbs"]} covered herbs.')]:
        proof.append([p(value,'proof'),p(label,'proof_label')])
    measured=Table([proof],colWidths=[170,170,170]);measured.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LINEABOVE',(0,0),(-1,0),1.2,colors.HexColor('#8da587')),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),12)]))
    story += [measured,Spacer(1,12),
        p('Medicine descriptions, goals and photos stay on your device. The models run in your browser.'),
        p('<link href="https://foliatrace-research.civil-bell-5511.chatgpt.site" color="#24513d">Open FoliaTrace AI</link>','heading'),
        p('<link href="https://foliatrace-research.civil-bell-5511.chatgpt.site/source.zip" color="#24513d">Source code, AI architecture and evaluation reports</link>','small')]
    SimpleDocTemplate(str(TARGET),pagesize=A4,rightMargin=42,leftMargin=42,topMargin=49,bottomMargin=40,title='FoliaTrace AI - supplement label to pharmacist brief',author='FoliaTrace AI').build(story,onFirstPage=page,onLaterPages=page)
    from pypdf import PdfReader
    assert len(PdfReader(TARGET).pages)==1,'Product overview must be one page'
    print(TARGET)


if __name__=='__main__':main()

"""Build the current one-page product overview without browser automation."""
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

ROOT=Path(__file__).resolve().parents[1]
TARGET=ROOT/'output/pdf/foliatrace-one-page.pdf'
GREEN=colors.HexColor('#24513d')
styles={
    'title':ParagraphStyle('title',fontName='Times-Bold',fontSize=34,leading=38,textColor=GREEN,spaceAfter=10),
    'lead':ParagraphStyle('lead',fontName='Helvetica',fontSize=15,leading=20,textColor=GREEN,spaceAfter=16),
    'heading':ParagraphStyle('heading',fontName='Helvetica-Bold',fontSize=12,leading=16,textColor=GREEN,spaceBefore=12,spaceAfter=5),
    'body':ParagraphStyle('body',fontName='Helvetica',fontSize=11,leading=15,textColor=colors.HexColor('#26392f'),spaceAfter=7),
    'small':ParagraphStyle('small',fontName='Helvetica',fontSize=9,leading=12,textColor=colors.HexColor('#526359'),spaceAfter=5),
}


def p(text,style='body'):
    return Paragraph(text,styles[style])


def page(canvas,doc):
    canvas.setFillColor(colors.HexColor('#f8f5ed'));canvas.rect(0,0,*A4,fill=1,stroke=0)
    canvas.setStrokeColor(GREEN);canvas.setLineWidth(2);canvas.line(42,A4[1]-32,A4[0]-42,A4[1]-32)
    canvas.setFont('Helvetica',8);canvas.setFillColor(GREEN)
    canvas.drawString(42,27,'FoliaTrace | v0.8 | 12 November 2026')
    canvas.drawRightString(A4[0]-42,27,'Product overview / 1')


def main():
    TARGET.parent.mkdir(parents=True,exist_ok=True)
    story=[p('FoliaTrace','title'),p('Bring the bottle. Start a better conversation.','lead'),
        p('The person','heading'),
        p('Mei, 72, takes warfarin. Her daughter buys her a "memory &amp; joint" supplement with ginkgo, garlic and "ginseng root". She will not mention it: only 1 in 3 herb and supplement users told a conventional provider (NHIS 2002), while 57.6% of U.S. adults use supplements (CDC NCHS, 2017-18). The NIH safety information exists, but getting from a label to the right sentence is the hard part.'),
        p('Three steps, one brief','heading')]
    cells=[]
    for title,text in [('1. The bottle','Search 200,000 NIH-listed U.S. labels, paste the label, or photograph it (on-device OCR).'),('2. Your medicines','Brand names, doses and typos are fine. Optional situation: pregnancy, surgery, diabetes...'),('3. The brief','Verbatim NIH sentences with links, the questions to ask, and what the label leaves unclear. QR handoff to the pharmacist.')]:
        cells.append([p(title,'heading'),p(text)])
    table=Table([[cells[0],cells[1],cells[2]]],colWidths=[170,170,170]);table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#eaf0e8')),('BOX',(0,0),(-1,-1),.5,colors.HexColor('#bccdbd')),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),10)]));story += [table,
        p('Names stay hypotheses','heading'),
        p('"Ginseng" can be Asian, American or "Siberian" ginseng - different plants. FoliaTrace never guesses: it lists each candidate species with the NIH statements that would apply. Proprietary blends, duplicates across products, uncovered botanicals and unrecognised medicines are listed instead of skipped. It never says "safe".'),
        p('Evidence you can check','heading'),
        p('<b>74</b> NIH (NCCIH) passages verified word-for-word by the build. On <b>787</b> search-sampled NIH labels, name-only matching agreed with the curator-declared species <b>92%</b> of the time (genus-or-better <b>99.7%</b>, recall <b>100%</b>). In that sample, <b>50%</b> of botanical ingredients had no individual amount (proprietary blends). <b>38</b> real-browser checks: live NIH search, photo to brief, QR round trip, injection, on-device AI, WCAG A/AA, phone layout, zero CSP violations.'),
        p('AI where it helps, not where it could harm','heading'),
        p('On-device LSTM OCR reads labels; an on-device cross-encoder ranks research for the pharmacist. Safety statements are deterministic matches to verified NIH text - no generative model writes a warning. Medicines and conditions never leave the browser; the QR brief travels inside the link. Free, no account, no paid API.'),
        p('Try: foliatrace-research.civil-bell-5511.chatgpt.site  |  Full local app: scripts/start.ps1','heading'),
        p('Prepares a conversation; does not replace a pharmacist, give doses or certify safety. Covers 25 common herbs; example people and labels are fictional. Sources: NIH NCCIH (public domain), NIH DSLD, CDC NCHS, Mehta et al. 2008. Codex and Claude assisted development; prior EthnoHack work disclosed. MIT code.','small')]
    SimpleDocTemplate(str(TARGET),pagesize=A4,rightMargin=42,leftMargin=42,topMargin=49,bottomMargin=40,title='FoliaTrace - supplement label to pharmacist brief',author='FoliaTrace').build(story,onFirstPage=page,onLaterPages=page)
    from pypdf import PdfReader
    assert len(PdfReader(TARGET).pages)==1,'Product overview must be one page'
    print(TARGET)


if __name__=='__main__':main()

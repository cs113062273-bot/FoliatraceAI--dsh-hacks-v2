"""Acquire a bounded, licensed addition to the browser research library.

Only CC BY/CC0 abstracts are redistributed. No full text, figures, health inputs,
or restricted abstracts. Rebuilds use the saved snapshot, never a live query.
"""
from __future__ import annotations
import hashlib
import json
import re
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from html import unescape
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# A small purpose-built set of human studies and reviews; mixtures remain labelled
# in their original titles/abstracts and are never treated as the person's product.
IDS = ['PMC11133624', 'PMC10221652', 'PMC11053596', 'PMC7847013', 'PMC8746505',
       'PMC13260694', 'PMC12436692', 'PMC10755896', 'PMC3948786']


def plain(text):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', unescape(text or ''))).strip()


def main():
    papers, omitted = [], []
    url = 'https://www.ebi.ac.uk/europepmc/webservices/rest/search?' + urllib.parse.urlencode(
        dict(query=' OR '.join(IDS), resultType='core', format='json', pageSize=50))
    cache = ROOT / '.runtime/care-additions-response.json'
    cache.parent.mkdir(parents=True, exist_ok=True)
    if cache.exists(): raw = cache.read_bytes()
    else:
        with urllib.request.urlopen(url, timeout=45) as response: raw = response.read()
        cache.write_bytes(raw)
    rows = json.loads(raw)['resultList']['result']
    for pmcid in IDS:
        matches = [x for x in rows if x.get('pmcid') == pmcid]
        r = max(matches, key=lambda x: len(x.get('abstractText', '')))
        licence = r.get('license', '').lower()
        if licence not in ('cc by', 'cc0') or not r.get('abstractText'):
            omitted.append(dict(id=pmcid, reason='No abstract or unsupported licence', licence=licence)); continue
        papers.append(dict(id=pmcid, title=plain(r['title']), abstract=plain(r['abstractText']),
                           url='https://europepmc.org/articles/' + pmcid, licence=licence,
                           authors=r.get('authorString', ''), year=r.get('pubYear'), doi=r.get('doi'),
                           acquisition_url=url, response_sha256=hashlib.sha256(raw).hexdigest()))
        print(pmcid, licence, flush=True)
        time.sleep(.5)
    payload = dict(created_at=datetime.now(timezone.utc).isoformat(),
                   selection='Bounded human-study/review additions for cognition, joint symptoms and lipids; not an exhaustive review.',
                   papers=papers, omitted=omitted)
    (ROOT / 'data/demo/care_research_additions.json').write_text(json.dumps(payload, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')


if __name__ == '__main__': main()

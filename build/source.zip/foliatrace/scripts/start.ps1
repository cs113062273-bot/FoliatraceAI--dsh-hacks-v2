param([switch]$CheckOnly, [switch]$Offline)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$pythonPath = Join-Path $projectRoot '.venv/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) {
    python -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 or newer is required.' }
}
& $pythonPath -c "import importlib.util, sys; sys.exit(not all(importlib.util.find_spec(name) for name in 'fastapi uvicorn sklearn rapidfuzz tokenizers onnxruntime'.split()))"
if ($LASTEXITCODE -ne 0) {
    & $pythonPath -m pip install -r requirements.lock
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
}
& $pythonPath scripts/validate_data.py
if ($LASTEXITCODE -ne 0) { throw 'Snapshot validation failed.' }
if (-not $CheckOnly) {
    if ($Offline) { $env:FOLIATRACE_OFFLINE = '1' }
    Write-Host 'Opening FoliaTrace at http://127.0.0.1:8000 (Ctrl+C to stop).'
    & $pythonPath app.py
    if ($LASTEXITCODE -ne 0) { throw 'FoliaTrace stopped with an error.' }
}

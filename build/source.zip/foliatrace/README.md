# FoliaTrace

**Bring the bottle. Start a better conversation.**

Mei is 72 and takes warfarin. Her daughter buys her a "memory & joint" supplement with ginkgo, garlic and "ginseng root". Nobody at the pharmacy hears about it: in a U.S. national survey only **1 in 3** herb and supplement users told a conventional provider ([Mehta et al. 2008](https://pmc.ncbi.nlm.nih.gov/articles/PMC2787410/)), while **57.6%** of U.S. adults use supplements ([CDC NCHS 2021](https://www.cdc.gov/nchs/products/databriefs/db399.htm)).

FoliaTrace reads a supplement label, matches every botanical ingredient to U.S. National Institutes of Health (NCCIH) fact sheets, checks them against the person's own medicines and situation, and produces a pharmacist brief: the exact NIH sentences, the questions to ask, and what the label leaves unclear. The pharmacist opens the same brief by scanning a QR code. No account, no server, no paid AI.

**▶ Try it: [FoliaTrace live](https://foliatrace-research.civil-bell-5511.chatgpt.site)** — tap *Mei, Sam* or *Ray* for a one-click check, or check your own bottle.

![FoliaTrace pharmacist brief](docs/assets/foliatrace-v08-brief.png)

## What it does

| Step | What happens | Where it runs |
|---|---|---|
| **The bottle** | Search ≈200,000 U.S. labels in the NIH Dietary Supplement Label Database, paste the Supplement Facts, or **photograph the label** (Tesseract OCR) | Live NIH API from the browser; OCR on the device |
| **Your medicines** | Generic or brand names, doses and typos ("Coumadin 5 mg", "warfrin") resolve to 134 medicines / 325 names; optional situation (pregnancy, surgery, diabetes…) | Browser |
| **The brief** | Each match quotes NIH verbatim with a link. Ambiguous names ("ginseng", "chamomile", "mint", "cohosh") stay open: every candidate species is listed with the statements that would apply. Proprietary blends, duplicates across products, uncovered botanicals and unrecognised medicines are listed instead of skipped | Browser |
| **The handoff** | QR code / link that carries the whole brief in the URL fragment (never sent to a server); printable two-page brief; download; "copy my questions"; choose what to share | Browser |
| **For the pharmacist** | On-device neural reranker over 415 open-access abstracts; recorded seven-dimension study-vs-product comparisons; the full local app adds saved versions, label-version comparison and reading decisions | Browser (WASM) / local Python |

FoliaTrace **never says "safe"**. When NIH names nothing for a combination the brief says so and repeats NIH's own caution that "some herbs and medicines interact in harmful ways."

## Evidence you can check

| Claim | Evidence | Reproduce |
|---|---|---|
| Every warning is a verbatim NIH sentence | 25 NCCIH pages downloaded; **74 quoted passages** verified word-for-word or the build fails | `python scripts/build_safety_knowledge.py` |
| Name matching works on real labels | On **787 search-sampled NIH labels** (535 graded botanical rows), the name-only matcher agreed with the curator-declared species **92.0%** of the time, genus-or-better **99.7%**, recall of covered species **100%**. [Report](reports/label_matching_dev_2026-11-12.json) | `node scripts/evaluate_label_matching.mjs --sample dev` |
| The problem is real in the data | In that sample, **1,024 of 2,043 botanical ingredients (50.1%)** sat inside proprietary blends with no individual amount | same report |
| The product works end to end | **38 real-browser checks** (Chrome via CDP): three people, live NIH search, photo → brief, QR round trip in a fresh browser, HTML-injection, persistence, on-device AI, axe WCAG 2 A/AA = 0 violations, 390 px phone, CSP = 0 violations | `node scripts/verify_checker.mjs` · [report](reports/checker_browser_qa_public_2026-11-12.json) |
| Engine logic | 11 unit tests (Siberian ≠ Asian ginseng, typo tolerance, blends, no invented interactions, OCR fuzzing) | `node --test tests/safety_engine.test.mjs` |
| Privacy | Medicines and conditions never appear in any network request (asserted in QA). NIH receives only label search words or a record ID. Strict Content-Security-Policy allows only this site and the NIH label API | QA report |

Details: [v0.8 release notes](docs/release_v08_2026-11-12.md) · [AI disclosure](docs/ai_disclosure.md) · [data attribution](data/NOTICE.md)

## Where AI is used

- **Label photos:** an LSTM text-recognition model (Tesseract, WebAssembly) reads the label on the device; tolerant name matching recovers common misreadings; the person reviews the text before it is used.
- **Research ranking:** a pinned cross-encoder reranks keyword candidates in a Web Worker (full-app SciFact evaluation: nDCG@10 0.812 → 0.866 over BM25).
- **Safety statements are deterministic** matches to verified NIH text. No generative model writes a warning — the place where a hallucination would hurt someone has none.

Development was substantially assisted by Codex and Claude; see the [AI disclosure](docs/ai_disclosure.md).

## Run it yourself

**Public build (static):** `python scripts/build_safety_knowledge.py && python scripts/sync_public_demo.py`, then serve `sites/foliatrace-research/build/`. The recorded evidence cases and literature library come from `python scripts/build_care_demo.py`.

**Complete local app** (Python 3.11+):

```powershell
.\scripts\start.ps1
```

Open http://127.0.0.1:8000 for saved consultation preparation and pharmacist evidence review, or **http://127.0.0.1:8000/check/** for the checker. `-Offline` disables network use (label search then falls back to typed or photographed labels).

## Scope

FoliaTrace prepares a conversation; it does not replace a pharmacist, give doses or certify that a combination is safe. It covers 25 commonly used herbs; other botanicals are flagged "not covered". A label states what a maker declares, not what a bottle contains — NIH itself notes products with herbs missing from the label. The example people and labels are fictional. Code is MIT; third-party sources keep their rights ([NOTICE](data/NOTICE.md)).

FoliaTrace began as an EthnoHack research workspace (an herbal-literature evidence engine) and was rebuilt for DSH Hacks V2 around a patient-and-pharmacist task.

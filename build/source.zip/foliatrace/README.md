# FoliaTrace AI

**Bring the bottle. Start a better conversation.**

FoliaTrace AI turns supplement labels and everyday medicine descriptions into a pharmacist brief. It brings ingredient identities, medicine-group suggestions and goal-specific research together with the exact source passages.

**[Open FoliaTrace AI](https://foliatrace-research.civil-bell-5511.chatgpt.site)** · [One-page overview](https://foliatrace-research.civil-bell-5511.chatgpt.site/one-page.pdf) · [Source code](https://foliatrace-research.civil-bell-5511.chatgpt.site/source.zip)

## From a bottle to a brief

1. **Add the label.** Search NIH product records, paste ingredients or read a photo with editable text recognition.
2. **Describe the medicines.** Enter a name, brand or everyday description such as “my cholesterol pill.” Language AI proposes a medicine group for confirmation.
3. **Review the evidence.** Get relevant NIH quotations, questions for the pharmacist, label gaps and studies ranked for each herb and goal.
4. **Share the brief.** Use a QR link, print it or download the details you choose to include.

**Core AI:** MiniLM sentence embeddings for medicine descriptions; BM25 retrieval and MiniLM cross-encoder reranking for research. Both neural models run in the browser, keeping health inputs on the device.

## Run locally

Use Python 3.11+ and Node 24. These commands install dependencies, download the pinned model assets and build the browser product:

```powershell
npm ci
python -m pip install -r requirements.lock
python scripts/setup_model.py
python scripts/setup_reranker.py
node scripts/build_browser_inference.mjs
python scripts/build_safety_knowledge.py
python scripts/build_care_demo.py
python scripts/sync_public_demo.py
.\scripts\start.ps1
```

Open `http://127.0.0.1:8000/check/`. The full local app adds saved consultations, version history and pharmacist reading decisions.

## Verify and explore

```powershell
npm test
node scripts/verify_checker.mjs http://127.0.0.1:8000/check
```

[AI architecture, measured results and development provenance](docs/ai_disclosure.md) · [Release notes](docs/release_v08_2026-11-12.md) · [Data and model attribution](data/NOTICE.md)

The source archive includes the application, build tools and evaluation reports. `scripts/package_dsh_submission.py` rebuilds it; the two PDF builders use `reportlab` and `pypdf`. Code is licensed under MIT.

# FoliaTrace AI

**Bring the bottle. Start a better conversation.**

Can't remember a medicine's name? Describe it. FoliaTrace AI uses on-device language AI to suggest its group and a second neural model to find research for the person's bottle and goals. It builds a pharmacist brief with exact NIH warnings, explicit uncertainties and source links. No account or paid AI API.

**[Try FoliaTrace AI](https://foliatrace-research.civil-bell-5511.chatgpt.site)** — choose Mei, Sam or Ray, or check your own bottle.

Mei, 72, takes warfarin and "her water pill". Her daughter buys a memory-and-joint supplement. Only one in three herb/supplement users disclosed their use to a conventional provider in NHIS 2002 ([Mehta et al. 2008](https://pmc.ncbi.nlm.nih.gov/articles/PMC2787410/)); 57.6% of U.S. adults used supplements in 2017–18 ([CDC NCHS](https://www.cdc.gov/nchs/products/databriefs/db399.htm)). The product connects the bottle, the person's own words and evidence a pharmacist can inspect.

![Pharmacist brief](docs/assets/foliatrace-v08-brief.png)

## What works

| Task | Behavior |
|---|---|
| Add a bottle | Live NIH DSLD label lookup, pasted ingredients, or on-device photo OCR with editable review |
| Describe medicines | Exact/brand/typo matching first; MiniLM semantic inference when a name is unknown. "My water pill" and "my cholesterol pill" become explicit AI hypotheses, never identified prescriptions. Negated, historical and supplement-only mentions stay unassigned |
| Get the brief | Ingredient identities and medicine groups match verified NIH text. Every warning quotes NIH verbatim. Ambiguous species, unknown medicines, missing amounts and duplicate botanicals remain visible |
| Find personal research | Split compound goals; filter herb candidates and explicit nonclinical/protocol title cues; neural cross-encoder ranks each herb/goal. Low-scoring results stay empty. Expand a live lead to compare literal population, preparation and comparator excerpts with the actual bottle |
| Hand to pharmacist | QR/link carries data in the URL fragment; browser-local print/download and selective sharing. Opening a shared link does not save it unless requested |
| Go deeper | Free-form on-device AI/keyword research and five labelled replays of the local app's seven-dimension study-to-product comparisons |

## Evidence you can reproduce

| Check | Measured result | Source |
|---|---|---|
| Language understanding v2 | 37/39 medicine descriptions assigned to the correct group (94.9%); 0 wrong group assignments, 2 left unknown; all 15 other/negated phrases left unassigned (54 synthetic English phrases total) | [Report](reports/ai_medicine_understanding_v2_2026-11-12.json); `python scripts/ai_medicine_groups.py` |
| Browser/Python agreement | Same group decisions on original 34 and fresh 54 phrases. Maximum cosine difference 0.008 / 0.013; int8 CPU/WASM kernels differ slightly | Browser QA reports |
| Research screening | 423 licensed open-access abstracts; raw-logit floor 2.0 selected on the three development examples. Title screening and source excerpts are deterministic. No held-out relevance accuracy claimed | [Development report](reports/ai_research_relevance_2026-11-12.json) |
| AI feature ablation | Same Ray input: the red yeast rice medicine card appears only when the language model supplies its measured group hypothesis; exact-name lookup alone leaves the description unknown | [Causal feature demonstration](reports/ai_feature_ablation_2026-11-12.json) |
| External research component | Full local pipeline on 188 annotated SciFact claims / 5,183 abstracts: nDCG@10 keywords 0.812, hybrid 0.826, hybrid + neural reranking 0.866. Untuned published development labels; not browser herbal-library accuracy | [Report](reports/retrieval_external.json); `acquire_scifact.py`, `evaluate_retrieval.py` |
| Verbatim warnings | 25 herbs, 74 unique NIH passages; build refuses a missing quotation | `python scripts/build_safety_knowledge.py --offline` |
| Real-label matching | 789 unseen NIH labels: 96.3% exact species, 99.3% genus-or-better precision, 100% recall of covered species | [Held-out report](reports/label_matching_holdout_2026-11-12.json) |
| Label uncertainty | 1,858/3,858 botanical rows (48%) across 1,576 labels had no individual amount | Label-matching dev/holdout reports |
| End-to-end behavior | 54/54 public-build and 54/54 local `/check/` real-browser checks; 20/20 behavioral unit tests; live NIH, photos, QR, inference cancellation, privacy, WCAG A/AA and phone layout | `npm test`; `node scripts/verify_checker.mjs` |

The language phrases are synthetic English examples, not patient data. The original v1 holdout is now a regression set; v2 uses a fresh frozen set. No pharmacist review, user study or clinical outcome is claimed.

## AI architecture

1. **Language understanding:** pinned `sentence-transformers/all-MiniLM-L6-v2`; sentence embeddings compared with short medicine-group prototypes; cosine ≥ 0.55 and runner-up margin ≥ 0.06, plus conservative exclusions. The exact medicine still needs confirmation.
2. **Research relevance:** pinned `cross-encoder/ms-marco-MiniLM-L6-v2`; up to twenty keyword candidates per herb/goal, reranked on-device. Scores are relevance logits, not benefit, safety or applicability probabilities.
3. **Photo convenience:** Tesseract LSTM OCR; text is editable before analysis.

Every warning remains a deterministic match to verified NIH text. No generative model writes a warning. Source-excerpt extraction uses text cues and literal offsets; it is not an additional AI model. Models and tokenizers are checksum-verified and self-hosted. Medicines, purposes, conditions and photos stay in the browser; NIH receives only the separate label query or record ID.

## Run and verify

Use Python 3.11+ and Node 24. The source archive excludes model binaries; install the pinned assets before building:

```powershell
npm ci
python -m pip install -r requirements.lock
python scripts/setup_model.py
python scripts/setup_reranker.py
node scripts/build_browser_inference.mjs
python scripts/build_safety_knowledge.py
python scripts/build_care_demo.py
python scripts/sync_public_demo.py
npm test
```

Serve `sites/foliatrace-research/build/` for the static product, or run `scripts/start.ps1` for the complete local app at `http://127.0.0.1:8000`; the same checker is mounted at `/check/`. First use downloads self-hosted models; once assets are cached, analysis needs no AI service. Live label lookup requires NIH connectivity.

```powershell
node scripts/verify_checker.mjs http://127.0.0.1:8015 --report=reports/checker_browser_qa_public_2026-11-12.json
node scripts/verify_checker.mjs http://127.0.0.1:8000/check --report=reports/checker_browser_qa_local_2026-11-12.json
```

`--no-live` skips only the live NIH checks. `python scripts/package_dsh_submission.py` creates the allow-listed source archive. [Release notes](docs/release_v08_2026-11-12.md) · [AI disclosure](docs/ai_disclosure.md) · [Attribution](data/NOTICE.md).

Submission artifacts: [one-page overview](output/pdf/foliatrace-one-page.pdf) and [complete code PDF](output/pdf/foliatrace-code.pdf). To rebuild them, install `reportlab` and `pypdf`, run `build_product_onepage.py`, `package_dsh_submission.py`, then `build_code_pdf.py`. The code PDF lists every first-party code file in the source ZIP with its hash; model/vendor binaries stay excluded.

## Scope and prior work

Prepares a pharmacist conversation; does not identify a prescription, recommend doses, replace professional review or certify safety. Coverage is limited to the covered herbs, and labels are manufacturer declarations. Both label samples are search-ranked, not representative market samples; curator names can themselves be misspelt. Fictional example people and products.

The project began as an EthnoHack herbal-literature workspace and was rebuilt for DSH Hacks V2 around the person-to-pharmacist task. Development was substantially assisted by Codex and Claude. Code MIT; third-party data/models retain their licences. Prior-work eligibility remains the organisers' decision.

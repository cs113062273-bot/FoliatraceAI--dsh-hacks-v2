from __future__ import annotations

from collections import Counter, defaultdict
import json
import re
import os
import time
from urllib.parse import quote
from src import __version__
from src.common import DATA, ROOT, digest, now, read_json
from src.nlp import Extractor
from src.nlp.extract import heading_gloss, heading_common_names, normalize, sentences, source_glosses
from src.taxonomy import Resolver
from src.retrieval.index import LiteratureIndex, design_rank
from src.evidence.classify import classify_study, relation_to_claim, citation_check, conflict_groups
from src.evidence.model import StudyModel
from src.evidence.comparability import comparability, gate_relation, summarize
from src.evidence.context import scope_study_preparation, index_historical_contexts, compare_historical_contexts, preparation_across_statements
from src.evidence.historical_names import historical_name_references
from src.evidence.counterfactual import counterfactuals
from src.evidence.chemistry import assay_leads
from src.evidence.identity_matrix import identity_matrix
from src.evidence.digest import research_digest
from src.evidence.regulatory import regulatory
from src.evidence.independent_use import independent_use
from src.ingestion.client import ScientificClient
from src.taxonomy.lexicon import fold, local_names
from src.taxonomy.open_world import reconcile_common_name, scientific_readings, on_demand_literature, taxon_from_record
from src.evidence.readings import active_reading_sets
from src.graph.store import GraphStore


def mention_topics(extracted, mention):
    """What the text says this named plant was used for."""
    return {c['id'] for claim in extracted['historical_claims'] if mention['id'] in claim['mention_ids'] and claim['statement_role'] == 'THERAPEUTIC_USE_RECORDED' for c in claim['conditions']}


class Pipeline:
    def __init__(self, *, data_dir=DATA, store=None, use_lexicon=True, include_local_abstracts=True):
        self.data_dir = data_dir
        # Public/demo builds must never inherit a developer's private abstract cache.
        self.include_local_abstracts = include_local_abstracts
        self.use_lexicon = use_lexicon
        self.manifest = read_json(data_dir / "acquisition.json")
        self.snapshot = digest((data_dir / "acquisition.json").read_bytes())
        for file in ("passages.json", "taxa.json", "papers.json", "compounds.json"):
            if self.manifest.get("files", {}).get(file, {}).get("sha256") != digest((data_dir / file).read_bytes()):
                raise ValueError(f"Snapshot checksum absent or mismatched: {file}")
        self.passages = read_json(data_dir / "passages.json")
        self.taxa = read_json(data_dir / "taxa.json")
        self.base_taxa_count = len(self.taxa)
        self.taxonomy_observations = []
        expansion_path = data_dir / 'taxa_extended.json'
        if expansion_path.exists():
            lock = read_json(ROOT / 'data/taxonomy_expansion.lock.json')
            if digest(expansion_path.read_bytes()) != lock['sha256']:
                raise ValueError('Extended scientific taxonomy snapshot checksum mismatch')
            expansion = read_json(expansion_path)
            original_ids = {t['id'] for t in self.taxa}
            self.taxa += [t for t in expansion['taxa'] if t['id'] not in original_ids]
            self.taxonomy_observations = expansion['observations']
            self.snapshot = digest(self.snapshot + lock['sha256'])
        self.load_core_taxa(data_dir)
        self.literature_size = {}
        self.papers = read_json(data_dir / "papers.json")
        extended_papers = data_dir / 'papers_extended.json'
        if extended_papers.exists():
            lock = read_json(ROOT / 'data/literature_expansion.lock.json')
            if digest(extended_papers.read_bytes()) != lock['sha256']:
                raise ValueError('Extended literature snapshot checksum mismatch')
            ids = {p['id'] for p in self.papers}
            self.papers += [p for p in read_json(extended_papers)['papers'] if p['id'] not in ids]
            self.snapshot = digest(self.snapshot + lock['sha256'])
        self.load_pubmed(data_dir)
        methods_path = data_dir / 'study_methods.json'
        if methods_path.exists():
            methods_lock = read_json(ROOT / 'data/study_methods.lock.json')
            if digest(methods_path.read_bytes()) != methods_lock['sha256']:
                raise ValueError('Study Methods snapshot checksum mismatch')
            methods = read_json(methods_path)['papers']
            for paper in self.papers:
                if paper['id'] in methods:
                    paper['methods_contexts'] = methods[paper['id']]['contexts']
                    paper['reported_results'] = methods[paper['id']].get('reported_results', [])
            self.snapshot = digest(self.snapshot + methods_lock['sha256'])
        # Name lists and independent records change what a reader is told.
        for lock in ('duke_ethnobotany', 'duke_chemistry', 'merrill_1903_names', 'ema_herbal', 'local_names_wikidata'):
            path = ROOT / f'data/{lock}.lock.json'
            if path.exists():
                self.snapshot = digest(self.snapshot + read_json(path)['sha256'])
        self.trial_readings = []
        readings_path = data_dir / 'trial_readings.json'
        if readings_path.exists():
            readings_lock = read_json(ROOT / 'data/trial_readings.lock.json')
            if digest(readings_path.read_bytes()) != readings_lock['sha256']:
                raise ValueError('Trial reading notes snapshot checksum mismatch')
            self.trial_readings = read_json(readings_path)['sets']
            self.snapshot = digest(self.snapshot + readings_lock['sha256'])
        self.compounds = read_json(data_dir / "compounds.json")
        self.taxmap = {t["id"]: t for t in self.taxa}
        self.scientific_genera = {normalize(name).split()[0] for t in self.taxa for name in [t['name']] + [a['name'] for a in t.get('aliases', []) if a['kind'] in ('ACCEPTED_NAME', 'SYNONYM', 'INPUT_SYNONYM_MATCH')] if name.strip()}
        for taxon in self.taxa:
            taxon['drug_names'] = sorted(regulatory().drug_names.get(taxon['id'], ()))
        self.papermap = {p["id"]: p for p in self.papers}
        self.extra_passages, self.mechanism_records = [], []
        for filename, lockname in [('fernie_passages.json', 'second_corpus.lock.json'), ('mechanisms.json', 'mechanisms.lock.json')]:
            path = data_dir / filename
            if path.exists():
                lock = read_json(ROOT / 'data' / lockname)
                if digest(path.read_bytes()) != lock['sha256']:
                    raise ValueError('Optional snapshot checksum mismatch: ' + filename)
                self.snapshot = digest(self.snapshot + lock['sha256'])
                if filename == 'fernie_passages.json':
                    self.extra_passages = read_json(path)
                else:
                    self.mechanism_records = read_json(path)['records']
        congeners_file = data_dir / "vernacular_congeners.json"
        self.congeners = None
        if congeners_file.exists():
            if self.manifest["files"].get("vernacular_congeners.json", {}).get("sha256") != digest(congeners_file.read_bytes()):
                raise ValueError("Snapshot checksum absent or mismatched: vernacular_congeners.json")
            self.congeners = read_json(congeners_file)
        self.extractor = Extractor(self.taxa)
        self.study_designs = {}
        self.client = ScientificClient(offline=os.environ.get('FOLIATRACE_OFFLINE', '').lower() in {'1', 'true', 'yes'})
        self.descriptions = {}
        descriptions_path = data_dir / 'taxon_descriptions.json'
        if descriptions_path.exists():
            self.descriptions = read_json(descriptions_path)['descriptions']
            self.snapshot = digest(self.snapshot + digest(descriptions_path.read_bytes()))
        self.resolver = Resolver(self.taxa, self.congeners)
        self.index = LiteratureIndex(self.papers, self.taxa)
        self.topic_cache = {}
        self.study_model = StudyModel.load(ROOT / ".cache" / "study_model.joblib")
        # The reader's vocabulary is code too: a changed use-term table must not return a cached reading.
        self.code_fingerprint = digest(b"".join(path.read_bytes() for path in sorted((ROOT / "src").rglob("*.py"))) + (ROOT / 'data/use_terms_i18n.json').read_bytes())
        model_path = ROOT / ".cache" / "study_model.joblib"
        encoder_manifest=ROOT/'data'/'models.lock.json'
        self.model_fingerprint = digest((model_path.read_bytes() if model_path.exists() else b'NOT_TRAINED')+(encoder_manifest.read_bytes() if encoder_manifest.exists() else b'NO_ENCODER_MANIFEST'))
        reranker_manifest = ROOT / 'data/reranker.lock.json'
        if reranker_manifest.exists():
            self.model_fingerprint = digest(self.model_fingerprint.encode() + reranker_manifest.read_bytes())
        self.withdrawals_path = ROOT / "data" / "withdrawals.json"
        self.store = store or GraphStore()

    def load_core_taxa(self, data_dir, derived=True):
        """Heading candidates, archaic names and the multilingual gazetteer, in that priority."""
        by_id = {t['id']: t for t in self.taxa}
        by_name = {t['name']: t for t in self.taxa}
        core_path = data_dir / 'taxa_core.json'
        if core_path.exists():
            lock = read_json(ROOT / 'data/core_taxa.lock.json')
            if digest(core_path.read_bytes()) != lock['sha256']:
                raise ValueError('Core taxonomy snapshot checksum mismatch')
            self.snapshot = digest(self.snapshot + lock['sha256'])
            for row in read_json(core_path)['taxa']:
                known = by_id.get(row['id']) or by_name.get(row['name'])
                if known:
                    names = {normalize(a['name']) for a in known['aliases']}
                    known['aliases'] = known['aliases'] + [a for a in row['aliases'] if normalize(a['name']) not in names]
                    known['occurrence_counts'] = row['occurrence_counts']
                else:
                    self.taxa.append(row)
                    by_id[row['id']] = by_name[row['name']] = row
        lexicon_path = ROOT / 'data/historical_names.json'
        if lexicon_path.exists() and self.use_lexicon:
            self.snapshot = digest(self.snapshot + digest(lexicon_path.read_bytes()))
        # Wikidata labels: species tagged as medicinal plants, then every EU monograph species and core species, then the
        # same species in more European languages; last, names field studies printed beside an identification.
        for name in ('taxa_gazetteer', 'regulator_names', 'core_species_names', 'more_language_names', 'field_study_names'):
            gazetteer_path, lock_path = data_dir / f'{name}.json', ROOT / 'data' / ('gazetteer.lock.json' if name == 'taxa_gazetteer' else f'{name}.lock.json')
            if not gazetteer_path.exists():
                continue
            lock = read_json(lock_path)
            if digest(gazetteer_path.read_bytes()) != lock['sha256']:
                raise ValueError(f'{gazetteer_path.name} snapshot checksum mismatch')
            self.snapshot = digest(self.snapshot + lock['sha256'])
            for row in read_json(gazetteer_path)['taxa']:
                url = f"https://www.wikidata.org/wiki/{row['wikidata']}" if row.get('wikidata') else f"https://www.gbif.org/species/{row['id'].split(':', 1)[1]}"
                names = [{'name': n['name'], 'kind': 'VERNACULAR', 'lang': n['lang'], 'url': n.get('url', url), **({'sources': n['sources']} if 'sources' in n else {})} for n in row['names'] if not n.get('everyday')]
                known = by_name.get(row['name']) or by_id.get(row['id'])
                if known:
                    present = {normalize(a['name']) for a in known['aliases']}
                    known['aliases'] = known['aliases'] + [n for n in names if normalize(n['name']) not in present]
                    continue
                if row['name'] in by_name:
                    continue
                taxon = {'id': row['id'], 'name': row['name'], 'scientific_name': row['name'], 'rank': 'SPECIES', 'family': 'Not in snapshot', 'genus': row['name'].split()[0], 'status': 'NOT_CHECKED', 'aliases': [{'name': row['name'], 'kind': 'ACCEPTED_NAME', 'url': url}] + names, 'licence': 'CC0-1.0' if row.get('wikidata') else 'Names from CC BY field studies; GBIF backbone', 'provenance': {'url': url}, 'gazetteer_only': True, 'scope': 'Wikidata medicinal-plant record; names are retrieval hypotheses.' if row.get('wikidata') else 'Local names a field study recorded; names are retrieval hypotheses.'}
                self.taxa.append(taxon)
                by_id[row['id']] = by_name[row['name']] = taxon
        redirects_path = data_dir / 'wikipedia_redirects.json'
        if redirects_path.exists():
            lock = read_json(ROOT / 'data/wikipedia_redirects.lock.json')
            if digest(redirects_path.read_bytes()) != lock['sha256']:
                raise ValueError('Wikipedia redirect snapshot checksum mismatch')
            self.snapshot = digest(self.snapshot + lock['sha256'])
            genera = defaultdict(set)
            for genus in {t['genus'] for t in self.taxa} | set(independent_use().genera):
                genera[fold(genus)].add(genus)
            for row in read_json(redirects_path)['names']:
                taxon = by_id.get(row['id'])
                # An everyday word ("Burgundy", a cultivar; "Robin") would turn prose into plants,
                # and a cultivar spelt like another genus ("Arnika", a sunflower) would misname it.
                if not taxon or row.get('everyday') or genera.get(fold(row['name']), {taxon['genus']}) - {taxon['genus']} or normalize(row['name']) in {normalize(a['name']) for a in taxon['aliases']}:
                    continue
                url = 'https://en.wikipedia.org/wiki/' + quote(row['article'].replace(' ', '_'))
                taxon['aliases'] = taxon['aliases'] + [{'name': row['name'], 'kind': row['kind'], 'lang': 'en', 'url': url}]
        everyday = ROOT / 'data/plant_names_i18n.json'
        if everyday.exists():
            self.snapshot = digest(self.snapshot + digest(everyday.read_bytes()))
            lexicon = read_json(everyday)
            for species, table in lexicon['names'].items():
                taxon = by_name.get(species)
                if not taxon and species in lexicon.get('gbif_keys', {}):
                    key = lexicon['gbif_keys'][species]
                    url = f'https://www.gbif.org/species/{key}'
                    taxon = {'id': f'gbif:{key}', 'name': species, 'scientific_name': species, 'rank': 'SPECIES', 'family': 'Not in snapshot', 'genus': species.split()[0], 'status': 'NOT_CHECKED', 'aliases': [{'name': species, 'kind': 'ACCEPTED_NAME', 'url': url}], 'licence': 'CC-BY-4.0', 'provenance': {'url': url}, 'gazetteer_only': True, 'scope': 'Everyday-name table; names are retrieval hypotheses.'}
                    self.taxa.append(taxon)
                    by_id[taxon['id']] = by_name[species] = taxon
                if not taxon:
                    continue
                present = {(normalize(a['name']), a.get('lang')) for a in taxon['aliases']}
                taxon['aliases'] = taxon['aliases'] + [{'name': name, 'kind': 'VERNACULAR', 'lang': language, 'url': 'data/plant_names_i18n.json'} for language, names in table.items() for name in names if (normalize(name), language) not in present]
        short_path = data_dir / 'short_names.json'
        if derived and short_path.exists():
            lock = read_json(ROOT / 'data/short_names.lock.json')
            if digest(short_path.read_bytes()) != lock['sha256']:
                raise ValueError('Short-name snapshot checksum mismatch')
            self.snapshot = digest(self.snapshot + lock['sha256'])
            for row in read_json(short_path)['names']:
                taxon = by_id.get(row['id'])
                if taxon and not row['everyday']:
                    taxon['aliases'] = taxon['aliases'] + [{'name': row['name'], 'kind': 'VERNACULAR', 'lang': row['lang'], 'url': row['url'], 'short_form_of': row['short_form_of']}]
        # Apply after every taxon source is loaded: historical trade names can
        # refer to species introduced by the global gazetteer, such as Cinchona.
        if lexicon_path.exists() and self.use_lexicon:
            for name, entry in read_json(lexicon_path)['names'].items():
                for species in entry['species']:
                    taxon = by_name.get(species)
                    if taxon and normalize(name) not in {normalize(a['name']) for a in taxon['aliases']}:
                        taxon['aliases'] = taxon['aliases'] + [{'name': name, 'kind': 'HISTORICAL_LEXICON', 'url': 'data/historical_names.json'}]

    def load_pubmed(self, data_dir):
        """Bibliographic records from the repository, abstracts from the local cache."""
        path = data_dir / 'papers_pubmed.json'
        if not path.exists():
            return
        lock = read_json(ROOT / 'data/pubmed.lock.json')
        if digest(path.read_bytes()) != lock['sha256']:
            raise ValueError('PubMed snapshot checksum mismatch')
        self.snapshot = digest(self.snapshot + lock['sha256'])
        local = ROOT / '.cache/literature/pubmed_abstracts.json'
        use_local = self.include_local_abstracts and local.exists()
        abstracts = read_json(local) if use_local else {}
        # Abstract availability/content changes the findings, even when the
        # bibliographic snapshot is unchanged. Never reuse a bibliographic-only
        # analysis after full abstracts have become available (or vice versa).
        self.snapshot = digest(self.snapshot + (digest(local.read_bytes()) if use_local else 'NO_LOCAL_PUBMED_ABSTRACTS'))
        present = {str(p.get('pmid')) for p in self.papers}
        snapshot = read_json(path)
        self.papers += [{**p, 'abstract': abstracts.get(p['pmid'], '')} for p in snapshot['papers'] if p['pmid'] not in present and not p.get('retracted')]
        self.literature_size = {row['taxon_id']: sum(tier['count'] for tier in row['tiers'].values()) for row in snapshot['searches']}

    def register_taxon(self, taxon):
        before = digest(json.dumps(self.taxmap.get(taxon['id']), sort_keys=True, ensure_ascii=False))
        if taxon['id'] not in self.taxmap:
            taxon['drug_names'] = sorted(regulatory().drug_names.get(taxon['id'], ()))
            self.taxa.append(taxon)
            self.taxmap[taxon['id']] = taxon
            self.resolver = Resolver(self.taxa, self.congeners)
        else:
            # An older name for a plant already held: the plant stays, the name is learned.
            known = self.taxmap[taxon['id']]
            held = {normalize(a['name']) for a in known['aliases']}
            older = [a for a in taxon['aliases'] if a['kind'] == 'SYNONYM' and normalize(a['name']) not in held]
            if older:
                known['aliases'] = known['aliases'] + older
                self.resolver = Resolver(self.taxa, self.congeners)
        held = self.taxmap[taxon['id']]
        self.scientific_genera.update(normalize(name).split()[0] for name in [held['name']] + [a['name'] for a in held.get('aliases', []) if a['kind'] in ('ACCEPTED_NAME', 'SYNONYM', 'INPUT_SYNONYM_MATCH')] if name.strip())
        # The gazetteer files some plants under a GBIF synonym key ("Hibiscus tiliaceus"); once the
        # accepted species is known, that entry's names join it and the duplicate leaves the lists.
        # Only a GBIF synonym record's own key counts: a same-named accepted species is a homonym, not a twin.
        usages = {a['usage'] for a in held['aliases'] if a['kind'] == 'SYNONYM' and a.get('usage')}
        twins = [t for t in self.taxa if t.get('gazetteer_only') and t['id'] != held['id'] and t['id'] in usages]
        for twin in twins:
            present = {normalize(a['name']) for a in held['aliases']}
            held['aliases'] = held['aliases'] + [a for a in twin['aliases'] if a['kind'] == 'VERNACULAR' and normalize(a['name']) not in present]
            self.taxa.remove(twin)
            self.taxmap[twin['id']] = held
        if twins:
            self.resolver = Resolver(self.taxa, self.congeners)
        if before != digest(json.dumps(held, sort_keys=True, ensure_ascii=False)):
            self.record_knowledge('taxon:' + held['id'], held)
        for twin in twins:
            self.record_knowledge('taxon:' + twin['id'], held)
        return held

    def record_knowledge(self, key, value):
        """Track live additions separately from the immutable bundled snapshot."""
        if not hasattr(self, '_knowledge_updates'):
            self._knowledge_updates = {}
        self._knowledge_updates[key] = digest(json.dumps(value, sort_keys=True, ensure_ascii=False))

    def knowledge_fingerprint(self):
        return digest(self.snapshot + json.dumps(getattr(self, '_knowledge_updates', {}), sort_keys=True))

    def candidate_for(self, taxon, wording):
        """A GBIF match for a word the snapshot lacks; labelled, ranked like any common-name match."""
        alias = next((a for a in taxon['aliases'] if normalize(a['name']) == normalize(wording)), {'name': wording, 'kind': 'VERNACULAR', 'url': taxon['provenance']['url']})
        return {'taxon_id': taxon['id'], 'name': taxon['name'], 'scientific_name': taxon['scientific_name'], 'rank': taxon['rank'], 'family': taxon['family'], 'score': .9, 'score_meaning': 'RANKING_FEATURE_NOT_PROBABILITY', 'confidence': 'LOW', 'reasons': [taxon.get('open_world', 'GBIF_LOOKUP')], 'matched_alias': alias, 'provenance': taxon['provenance'], 'licence': taxon['licence'], 'gazetteer_only': False}

    def read_name_lists(self, mentions, resolutions):
        """Names listed together describe one plant, so they are weighed together.

        One local name often covers several plants; five names of one entry rarely agree by chance.
        """
        lists = defaultdict(list)
        for mention, resolution in zip(mentions, resolutions):
            if mention.get('list_id') is not None or mention['method'] == 'RESEARCHER_SELECTED_NAME':
                lists[mention.get('list_id', 'selected')].append((mention, resolution, local_names().lookup(mention['text'])))
        for rows in lists.values():
            agreement = Counter(entry['id'] for _, _, found in rows for entry in found)
            agreement.update(c['taxon_id'] for _, resolution, _ in rows for c in resolution['candidates'])
            best = max(agreement.values(), default=0)
            for mention, resolution, found in rows:
                kept = [e for e in found if best < 2 or agreement[e['id']] == best][:5]
                known = {c['taxon_id'] for c in resolution['candidates']}
                for entry in kept:
                    taxon = self.register_taxon(taxon_from_record(entry, mention['text']))
                    if taxon['id'] not in known:
                        candidate = self.candidate_for(taxon, mention['text'])
                        candidate['reasons'] = ['RECORDED_LOCAL_NAME'] + candidate['reasons'][1:]
                        candidate['name_record'] = {k: entry.get(k) for k in ('source', 'printed', 'where', 'reference')}
                        resolution['candidates'].append(candidate)
                if resolution['candidates']:
                    resolution['candidates'].sort(key=lambda c: -agreement[c['taxon_id']])
                    resolution.update({'status': 'OPEN_WORLD_AMBIGUOUS' if len(resolution['candidates']) > 1 else 'PROVISIONAL', 'mention_id': mention['id'], 'list_agreement': {'names_agreeing': best, 'names_listed': len(rows)}})

    def widen_candidates(self, mentions, resolutions, use_synonyms):
        """Binomials the snapshot does not hold are checked with GBIF; non-plants are dropped."""
        rejected, looked_up = set(), 0
        for mention, resolution in zip(mentions, resolutions):
            if mention['method'] == 'APPROXIMATE_SPELLING_PROPOSAL' and not resolution['candidates']:
                rejected.add(mention['id'])
                continue
            # A snapshot common name can hide the plant a text means, so for a proposal or the
            # plant the text opens with ("boneset" is comfrey in the snapshot) it does not end the search.
            held = resolution['candidates']
            proposal = mention['method'] in ('PLANT_POSITION_PROPOSAL', 'LOCAL_NAME_PROPOSAL') or (bool(held) and mention is mentions[0])
            if proposal and all(c['reasons'][0] == 'EXACT_VERNACULAR' for c in held):
                # Position alone proves nothing: without a GBIF plant the word is dropped.
                taxa = reconcile_common_name(self.client, mention['text']) if looked_up < 8 else None
                looked_up += 1
                if not taxa:
                    if not held:
                        rejected.add(mention['id'])
                    continue
                for taxon in taxa:
                    self.register_taxon(taxon)
                known = {c['taxon_id'] for c in held}
                refreshed = held + [self.candidate_for(t, mention['text']) for t in taxa if t['id'] not in known]
                resolution.update({'status': 'OPEN_WORLD_AMBIGUOUS' if len(refreshed) > 1 else 'PROVISIONAL', 'candidates': refreshed, 'mention_id': mention['id']})
                if mention.get('heading_line'):
                    # "American Hellebore" as a whole is a plant; "hellebore" inside it is not a second one.
                    rejected |= {m['id'] for m in mentions if m is not mention and mention['start'] <= m['start'] and m['end'] <= mention['end']}
                continue
            # A binomial held only as a synonym may be a homonym of a species the snapshot lacks; one
            # held only by the gazetteer may be a GBIF synonym key ("Hibiscus tiliaceus", Talipariti).
            synonym_only = bool(held) and all(c['reasons'][0] == 'EXACT_SYNONYM' or c.get('gazetteer_only') for c in held)
            if (held and not synonym_only) or mention['method'] not in ('UNVERIFIED_BINOMIAL_PROPOSAL', 'PARENTHETICAL_BINOMIAL_PROPOSAL', 'SCIENTIFIC_BINOMIAL_PROPOSAL'):
                continue
            try:
                taxa = scientific_readings(self.client, mention.get('lookup') or mention['text'])
                looked_up += 1
            except Exception:
                resolution['open_world_lookup'] = 'NETWORK_UNAVAILABLE'
                continue
            if not taxa:
                if mention['method'] == 'UNVERIFIED_BINOMIAL_PROPOSAL' and not held:
                    rejected.add(mention['id'])
                continue
            for taxon in taxa:
                self.register_taxon(taxon)
            refreshed = self.resolver.resolve(mention.get('lookup') or mention['text'], use_synonyms=use_synonyms, method='exact')
            resolution.update({**refreshed, 'mention_id': mention['id']})
        return rejected, looked_up

    def plant_literature(self, taxon_ids):
        """What is known about a plant regardless of topic, so an unmatched topic is no dead end."""
        output = {}
        for taxon_id in taxon_ids:
            taxon = self.taxmap.get(taxon_id)
            if not taxon:
                continue
            rows = [self.index.papers[i] for i, label in self.index.documents_naming(taxon).items() if label == 'SCIENTIFIC_NAME']
            rows.sort(key=lambda row: (design_rank(row), -int(str(row.get('year') or 0)[:4] or 0)))
            output[taxon_id] = {'name': taxon['name'], 'publications': len(rows), 'human_studies': sum(design_rank(row) <= 2 for row in rows), 'leading': [{'id': row['id'], 'title': row['title'], 'year': row.get('year'), 'url': row['url'], 'types': row.get('publication_types', [])[:3]} for row in rows[:3]]}
        return output

    def topic_studies(self, taxon_id, condition_id):
        """All snapshot papers for one plant and topic, read the same way as a retrieved study."""
        key = (taxon_id, condition_id, len(self.papers))
        if key not in self.topic_cache:
            taxon, rows = self.taxmap[taxon_id], []
            for hit in self.index.matching(taxon, condition_id, genus=True):
                paper = hit['paper']
                design = self.study_designs.get(paper['id']) or self.study_designs.setdefault(paper['id'], classify_study(paper, self.study_model))
                rows.append({'paper': paper, 'study': design, 'study_identity': hit['taxon_match'], 'branch_scientific_names': [taxon['name']] + [a['name'] for a in taxon['aliases'] if a['kind'] in ('ACCEPTED_NAME', 'SYNONYM', 'INPUT_SYNONYM_MATCH')], 'relation': relation_to_claim(paper, taxon, condition_id, design, taxon_match=hit['taxon_match'], known_genera=self.scientific_genera)})
            self.topic_cache[key] = rows
        return self.topic_cache[key]

    def ensure_literature(self, candidate_ids, conditions=None):
        """A plant with no indexed paper is read from PubMed once; the response stays cached."""
        fetched, failed = [], False
        for taxon_id in candidate_ids[:8]:
            taxon = self.taxmap.get(taxon_id)
            if not taxon:
                continue
            topics = (conditions or {}).get(taxon_id, ())
            title_name = normalize(taxon['name'])
            untested = [c for c in topics if sum(design_rank(hit['paper']) <= 2 and title_name in normalize(hit['paper']['title']) for hit in self.index.matching(taxon, c)) < 3]
            if (sum(label == 'SCIENTIFIC_NAME' for label in self.index.documents_naming(taxon).values()) >= 3 and not untested):
                continue
            try:
                rows = [row for row in on_demand_literature(self.client, taxon, sorted(untested or topics)) if not row.get('retracted') and row['id'] not in self.papermap]
            except Exception:
                failed = True
                break
            self.papers += rows
            self.papermap.update({row['id']: row for row in rows})
            self.index.add(rows)
            for row in rows:
                self.record_knowledge('paper:' + row['id'], row)
            self.literature_size[taxon_id] = max(self.literature_size.get(taxon_id, 0), len(rows))
            fetched.append({'taxon_id': taxon_id, 'name': taxon['name'], 'publications': len(rows)})
        return {'plants_read_on_demand': fetched, 'status': 'NETWORK_UNAVAILABLE' if failed else 'OK'}

    def withdrawn(self):
        return set(read_json(self.withdrawals_path)["withdrawn_source_ids"]) if self.withdrawals_path.exists() else set()

    def analyze(self, text, *, source=None, method="hybrid", use_synonyms=True, citation_guard=True, branch_propagation=True, persist=True, name_to_inspect=None):
        if not text.strip() or len(text) > 50000:
            raise ValueError("Input must contain 1–50,000 characters")
        source = source or {"id": "user-provided", "title": "Researcher-provided text", "licence": "USER_RIGHTS_UNVERIFIED", "context": "User-provided passage; provenance and rights not independently verified", "url": None, "community": None}
        withdrawn = self.withdrawn()
        if source["id"] in withdrawn or source.get("source_id") in withdrawn:
            raise ValueError("Source is withdrawn from active analysis")
        def analysis_key():
            return digest(text + self.knowledge_fingerprint() + self.code_fingerprint + self.model_fingerprint + str(self.index.encoder.available) + repr((source, method, use_synonyms, citation_guard, branch_propagation, sorted(withdrawn), name_to_inspect)))[:24]
        cache_key = analysis_key()
        if persist:
            previous = self.store.get(cache_key)
            if previous:
                previous["cache_hit"] = True
                return previous
        start = time.perf_counter()
        section = source.get("id", "").startswith(("culpeper-", "fernie-section-", "fernie-subsection-"))
        extracted = self.extractor.extract(text, section_subject=section, requested_name=name_to_inspect)
        resolutions = []
        for mention in extracted["mentions"]:
            exact_proposal = mention['method'] in ('SOURCE_HEADING_SUBJECT', 'PARENTHETICAL_BINOMIAL_PROPOSAL', 'SCIENTIFIC_BINOMIAL_PROPOSAL', 'UNVERIFIED_BINOMIAL_PROPOSAL', 'RESEARCHER_SELECTED_NAME', 'MULTILINGUAL_NAME_PROPOSAL', 'CROSS_LANGUAGE_EXACT_NAME', 'APPROXIMATE_SPELLING_PROPOSAL', 'PLANT_POSITION_PROPOSAL')
            if mention['method'] == 'GENUS_NAME_PROPOSAL':
                exact_proposal = False
            resolution = self.resolver.resolve(mention.get('heading_name') or mention.get('lookup') or mention["text"], use_synonyms=use_synonyms, method='exact' if exact_proposal else 'full', forms=mention.get('forms'))
            resolution['candidates']=[c for c in resolution['candidates'] if c['taxon_id'] not in withdrawn]
            if not resolution['candidates'] and mention['method'] == 'SOURCE_HEADING_SUBJECT':
                # A heading may be a genus or a near spelling; candidates stay labelled as such.
                resolution = self.resolver.resolve(mention.get('heading_name') or mention['text'], use_synonyms=use_synonyms, method='full', forms=mention.get('forms'))
                resolution['candidates'] = [c for c in resolution['candidates'] if c['taxon_id'] not in withdrawn]
            if not resolution['candidates']:resolution['status']='UNRESOLVED'
            resolution["mention_id"] = mention["id"]
            resolutions.append(resolution)
        # Chapters are analysed offline; their binomials were reconciled when the snapshot was built.
        if not section:
            self.read_name_lists(extracted['mentions'], resolutions)
        rejected, gbif_lookups = (set(), 0) if section else self.widen_candidates(extracted['mentions'], resolutions, use_synonyms)
        extracted['local_names_not_in_any_list'] = list(dict.fromkeys(m['text'] for m in extracted['mentions'] if m['id'] in rejected and m.get('list_id') is not None))
        if rejected:
            extracted['mentions'] = [m for m in extracted['mentions'] if m['id'] not in rejected]
            resolutions = [r for r in resolutions if r['mention_id'] not in rejected]
            for claim in extracted['historical_claims']:
                claim['mention_ids'] = [m for m in claim['mention_ids'] if m not in rejected]
                # "Der Thee von Pfefferminze": once the rejected word is gone, one plant is left.
                if claim['relation_scope'] == 'MULTI_PLANT_CLAUSE_UNCERTAIN_RELATION' and len(claim['mention_ids']) == 1 and any(m['id'] == claim['mention_ids'][0] and claim['support']['start'] <= m['start'] < claim['support']['end'] for m in extracted['mentions']):
                    claim['relation_scope'] = 'SENTENCE'
            extracted['historical_claims'] = [c for c in extracted['historical_claims'] if c['mention_ids']]
        glosses = source_glosses(text, extracted['mentions'])
        if not section:
            # "Juniper berries (Juniperus communis)": the author names one plant twice, so one card carries both.
            for binomial_id, names in glosses.items():
                if not any(r.get('mention_id') == binomial_id and r['candidates'] for r in resolutions):
                    continue
                for gloss in names:
                    twins = [m for m in extracted['mentions'] if m['id'] != binomial_id and 'BINOMIAL' not in m['method'] and m['start'] < gloss['end'] and gloss['start'] < m['end']]
                    if not twins:
                        continue
                    gloss.update({'name': twins[0]['text'], 'start': twins[0]['start'], 'end': twins[0]['end']})
                    merged = {m['id'] for m in twins}
                    extracted['mentions'] = [m for m in extracted['mentions'] if m['id'] not in merged]
                    resolutions = [r for r in resolutions if r.get('mention_id') not in merged]
                    for claim in extracted['historical_claims']:
                        claim['mention_ids'] = list(dict.fromkeys(binomial_id if m in merged else m for m in claim['mention_ids']))
                        if claim['relation_scope'] == 'MULTI_PLANT_CLAUSE_UNCERTAIN_RELATION' and len(claim['mention_ids']) == 1:
                            claim['relation_scope'] = 'SENTENCE'
        # A pasted entry names its heading's plant in the first sentence; the heading takes that identity.
        glossed = heading_gloss(text, extracted['mentions'])
        if glossed:
            head, binomial = glossed
            target = next((r for r in resolutions if r.get('mention_id') == binomial['id'] and r['candidates']), None)
            named = next((r for r in resolutions if r.get('mention_id') == head['id']), None)
            if target and named:
                gloss = [{**c, 'reasons': ['NAMED_IN_SOURCE_FIRST_SENTENCE'] + c['reasons']} for c in target['candidates']]
                # In a book chapter the heading's own reading stays beside the author's binomial:
                # Fernie's "Common Primrose (Primula veris)" uses an older concept than today's name.
                kept = [c for c in named['candidates'] if c['taxon_id'] not in {g['taxon_id'] for g in gloss}] if section else []
                named.update({'status': 'AMBIGUOUS' if kept else target['status'], 'candidates': gloss + kept, 'glossed_by': binomial['text'], **({} if section else {'open_world_alternatives': []})})
                glosses.setdefault(binomial['id'], []).append({'name': head['text'], 'start': head['start'], 'end': head['end'], 'binomial': binomial['text']})
        if section:
            for clue in heading_common_names(text, extracted['mentions']):
                named = next((r for r in resolutions if r['mention_id'] == clue['mention_id']), None)
                if not named:
                    continue
                additions = {}
                for form in clue['lookup_forms']:
                    found = self.resolver.resolve(form, method='exact', use_synonyms=use_synonyms)
                    for candidate in found['candidates']:
                        if candidate['taxon_id'] in withdrawn:
                            continue
                        additions.setdefault(candidate['taxon_id'], {**candidate, 'reasons':['OPENING_SOURCE_COMMON_NAME'] + candidate['reasons'], 'source_common_name':{**clue, 'lookup':form}})
                if additions:
                    # Keep the generic heading's readings. This is local source
                    # context, never a learned alias affecting another passage.
                    current = {c['taxon_id']:c for c in named['candidates']}
                    genera = {c['name'].split()[0] for c in list(current.values()) + list(additions.values())}
                    for identifier, candidate in additions.items():
                        # A globally shared common name is not enough to jump
                        # between genera. Agreement with the heading, a unique
                        # lookup, or refinement within one genus can rank first;
                        # other readings stay visible without a score bonus.
                        candidate['source_common_name']['anchor'] = identifier in current or len(additions) == 1 or len(genera) == 1
                        if identifier in current:
                            current[identifier] = {**current[identifier], 'source_common_name':candidate['source_common_name'], 'reasons':list(dict.fromkeys(candidate['reasons'] + current[identifier]['reasons']))}
                        else:
                            current[identifier] = candidate
                    named['candidates'] = list(current.values())
                    named['source_common_names'] = [clue]
                    if len(current) > 1:
                        named['status'] = 'AMBIGUOUS'
        for resolution in resolutions:
            if resolution.get('mention_id') in glosses:
                resolution['source_names'] = glosses[resolution['mention_id']]
            if len(resolution['candidates']) >= 1:
                mention = next(m for m in extracted['mentions'] if m['id'] == resolution['mention_id'])
                matrix = identity_matrix(text, resolution['candidates'], self.taxmap, self.descriptions, region='GB' if section else None, prominence=self.literature_size, topics=mention_topics(extracted, mention), name=(mention.get('heading_name') or mention['text']).split()[0], wording=None if 'BINOMIAL' in mention['method'] else mention.get('heading_name') or mention.get('lookup') or mention['text'], english_name=extracted.get('language') == 'en' and 'MULTILINGUAL' not in mention['method'])
                resolution['identity_matrix'] = matrix
                order = {row['taxon_id']: index for index, row in enumerate(matrix['candidates'])}
                ratings = {row['taxon_id']: row for row in matrix['candidates']}
                for candidate in resolution['candidates']:
                    candidate['identity_rating'] = ratings.get(candidate['taxon_id'], {}).get('rating', 'NOT_ASSESSABLE')
                    candidate['identity_score'] = ratings.get(candidate['taxon_id'], {}).get('score')
                resolution['candidates'].sort(key=lambda c: order.get(c['taxon_id'], 99))
        conditions = {c["id"]: c for claim in extracted["historical_claims"] for c in claim["conditions"]}
        resolution_map = {r["mention_id"]: r for r in resolutions}
        branch_conditions = {}
        source_contexts = index_historical_contexts(extracted, resolutions)
        for claim in extracted["historical_claims"]:
            if claim.get('statement_role') != 'THERAPEUTIC_USE_RECORDED' or claim.get('practice') == 'NON_PLANT_REMEDY':
                continue
            # An uncertain subject stays labelled on the statement; it no longer hides the literature.
            for mention_id in claim["mention_ids"]:
                for c in resolution_map.get(mention_id, {}).get("candidates", []):
                    branch_conditions.setdefault(c["taxon_id"], set()).update(x["id"] for x in claim["conditions"])
        candidate_ids = list(branch_conditions)
        named = list(dict.fromkeys(c['taxon_id'] for r in resolutions for c in r['candidates']))
        # Chapters are served from the snapshot; only a researcher's own text reads PubMed live.
        literature_access = {'plants_read_on_demand': [], 'status': 'SNAPSHOT'} if section else self.ensure_literature(list(dict.fromkeys(candidate_ids + named)), branch_conditions)
        if not branch_propagation:
            candidate_ids = candidate_ids[:1]
        evidence, blocked = [], []
        for taxon_id in candidate_ids:
            taxon = self.taxmap[taxon_id]
            for condition_id in sorted(branch_conditions[taxon_id])[:14]:
                for hit in self.index.search(taxon, condition_id, method=method, limit=4):
                    paper = hit["paper"]
                    if paper["id"] in withdrawn:
                        continue
                    design = self.study_designs.get(paper["id"]) or self.study_designs.setdefault(paper["id"], classify_study(paper, self.study_model))
                    study = scope_study_preparation(paper, taxon, design)
                    relation = relation_to_claim(paper, taxon, condition_id, study, taxon_match=hit["taxon_match"], known_genera=self.scientific_genera)
                    citation = citation_check(paper, relation["supporting_text"], hit["taxon_match"], hit["condition_match"], self.papermap.get(paper["id"]))
                    if citation_guard and citation["status"] == "REJECTED":
                        blocked.append({"paper_id": paper["id"], "reasons": citation["errors"]})
                        continue
                    eid = f"evidence-{len(evidence)}"
                    safety = []
                    for sentence in sentences(paper["abstract"]):
                        if re.search(r"\badverse\b|\binteraction\b|\bcontraindicat|\bhepatotoxic|\btoxicity\b", sentence["text"], re.I):
                            safety.append({"supporting_text": sentence["text"], "interpretation": "PUBLISHED_ABSTRACT_SIGNAL_REQUIRES_REVIEW", "not_personalized_advice": True})
                    compound_mentions = [{**c,"supporting_text":match.group(),"support_start":match.start(),"support_end":match.end()} for c in self.compounds if (match:=re.search(r"\b" + re.escape(c["name"]) + r"\b", paper["abstract"], re.I))]
                    isolated_compound = any(c["name"].casefold() in paper["title"].casefold() for c in compound_mentions) and normalize(taxon["name"]) not in normalize(paper["title"])
                    if isolated_compound:
                        relation = {**relation, "relation": "INSUFFICIENT", "directness": "COMPOUND_STUDY_NOT_PLANT_PREPARATION", "rationale": "Title identifies an isolated compound intervention. Plant co-mention does not make this evidence for a historical whole-plant preparation."}
                    historical_contexts = compare_historical_contexts(source_contexts.get((taxon_id, condition_id), []), study, paper)
                    checks = comparability(paper, taxon, condition_id, study, relation, hit["taxon_match"], [], preparation_check=preparation_across_statements(historical_contexts))
                    if isolated_compound:
                        checks["checks"].append({"check": "intervention", "status": "FAIL", "detail": "Isolated compound, not a plant preparation"})
                        checks = summarize(checks["checks"])
                    relation = gate_relation(relation, checks)
                    evidence.append({"id": eid, "taxon_id": taxon_id, "condition_id": condition_id, "modern_hypothesis": {"id": f"hypothesis:{taxon_id}:{condition_id}", "question": f"Does a specified preparation of {taxon['name']} improve {conditions[condition_id]['label']} in humans?", "population": "HUMAN_HYPOTHESIS; study population must be checked", "preparation": "SOURCE_STATEMENTS_COMPARED_SEPARATELY; see historical_contexts", "historical_use_is_not_efficacy": True}, "identity_qualifier": "CONDITIONAL_ON_CANDIDATE_IDENTITY", "study_identity": hit["taxon_match"], "paper": paper, "study": study, "relation": relation, "comparability": checks, "historical_contexts": historical_contexts, "citation": citation, "retrieval": {k:v for k,v in hit.items() if k != "paper"}, "safety_signals": safety, "compound_co_mentions": compound_mentions, "strength_components": {"design": study["types"], "quality": "NOT_APPRAISED", "directness": relation["directness"], "identity": hit["taxon_match"], "sample_size_available": study["sample_size"] is not None, "citation": citation["status"], "replication": "NOT_ASSESSED"}})
        result = {"run_id": cache_key, "created_at": now(), "pipeline_version": __version__, "snapshot_sha256": self.snapshot, "source": source, "input": text, **extracted, "resolutions": resolutions, "conditions": list(conditions.values()), "evidence": evidence, "conflicts": conflict_groups(evidence), "blocked_citations": blocked, "cache_hit": False, "limitations": ["A modern-name match is not proof of a historical referent.", "Evidence is conditional on candidate taxon identity; common-name-only study identity remains uncertain.", "Abstract-only automated relations require review of intervention, population and outcome comparability.", "Retrieval is bounded by PubMed relevance order; no retrieved evidence is not evidence of no effect.", "Research use only. No clinical validation or treatment recommendations."], "configuration": {"retrieval": method, "synonyms": use_synonyms, "citation_guard": citation_guard, "branch_propagation": branch_propagation}, "models": {"encoder": "MiniLM ONNX" if self.index.encoder.available else "NOT_INSTALLED", "study_classifier": "TFIDF_LOGREG" if self.study_model.model is not None else "NOT_TRAINED"}}
        # Resolve/enrich may have added taxonomy or abstracts after cache lookup.
        # Store under the resulting knowledge state, so the next request can hit
        # it and older analyses cannot conceal newly acquired evidence.
        result['run_id'] = analysis_key()
        result['knowledge_sha256'] = self.knowledge_fingerprint()
        result['configuration']['requested_name'] = name_to_inspect
        result['literature_access'] = literature_access
        result['research_digest'] = research_digest(result, self.taxmap, self.topic_studies, self.literature_size)
        result['plant_literature'] = self.plant_literature(named)
        result["identity_counterfactuals"] = counterfactuals(result)
        result['historical_identity_references'] = historical_name_references(result, self.passages + self.extra_passages, self.taxa, withdrawn)
        result['study_reading_sets'] = active_reading_sets(self.trial_readings, candidate_ids, conditions, withdrawn)
        result['models']['reranker'] = 'MS_MARCO_MINILM_L6_ONNX_CPU' if self.index.reranker.available else 'NOT_INSTALLED'
        result["compound_assay_leads"] = assay_leads(evidence, self.mechanism_records, withdrawn)
        result["graph"] = self.make_graph(result)
        result["code_fingerprint"] = self.code_fingerprint
        result["model_fingerprint"] = self.model_fingerprint
        result["performance"] = {"latency_ms": round((time.perf_counter() - start) * 1000, 1), "network_requests_during_analysis": gbif_lookups + len(literature_access['plants_read_on_demand'])}
        if persist:
            self.store.put(result)
        return result

    def make_graph(self, result):
        nodes, edges = {}, []
        def node(id, kind, label, **metadata):
            nodes.setdefault(id, {"id": id, "kind": kind, "label": label, **metadata})
        def edge(a, p, b, provenance):
            edges.append({"id": f"edge-{len(edges)}", "subject": a, "predicate": p, "object": b, "provenance": provenance})
        source = result["source"]
        sp = {"source_id": source["id"], "url": source.get("url"), "licence": source["licence"], "location": source.get("title"), "method": self.extractor.version, "human_reviewed": False}
        node(source["id"], "HistoricalSource", source["title"], provenance=sp)
        for mention in result["mentions"]:
            node(mention["id"], "PlantMention", mention["text"], span=mention)
            edge(mention["id"], "MENTIONED_IN", source["id"], {**sp, "support": mention["text"], "start": mention["start"], "end": mention["end"]})
        for claim in result["historical_claims"]:
            node(claim["id"], "HistoricalClaim", claim["support"]["text"][:90], supporting_text=claim["support"]["text"], statement_role=claim.get('statement_role'))
            for mention in claim["mention_ids"]:
                predicate = {'THERAPEUTIC_USE_RECORDED': 'ATTESTED_USE', 'ADVERSE_EFFECT_RECORDED': 'REPORTED_ADVERSE_EFFECT'}.get(claim.get('statement_role'), 'CONTEXT_MENTION')
                if claim['relation_scope'] in ('MULTI_PLANT_CLAUSE_UNCERTAIN_RELATION', 'PARAGRAPH_CONTEXT_UNCERTAIN_RELATION'):
                    predicate = 'POSSIBLE_SUBJECT_OF'
                edge(mention, predicate, claim["id"], {**sp, "support": claim["support"]["text"], "relation_scope": claim["relation_scope"], 'statement_role': claim.get('statement_role')})
            for condition in claim["conditions"]:
                node(condition["id"], "Condition", condition["label"])
                edge(claim["id"], "LEXICAL_CONDITION_MAPPING", condition["id"], {**sp, "support": condition["original"], "mapping_status": condition["mapping_status"]})
            for field, kind, predicate in [("part", "PlantPart", "USES_PART"), ("preparation", "Preparation", "PREPARED_AS"), ("route", "Route", "ROUTE_REPORTED_AS")]:
                for value in claim[field]:
                    identifier = kind.lower() + ':' + normalize(value["text"])
                    node(identifier, kind, value["text"])
                    edge(claim["id"], predicate, identifier, {**sp, "support": value["text"], "start": value["start"], "end": value["end"]})
        for resolution in result["resolutions"]:
            for c in resolution["candidates"]:
                node(c["taxon_id"], "ModernTaxon", c["name"])
                edge(resolution["mention_id"], "CANDIDATE_IDENTITY", c["taxon_id"], {"source_id": c["taxon_id"], **c["provenance"], "licence": c["licence"], "matched_alias": c["matched_alias"], "reasons": c["reasons"], "method": self.resolver.version, "historical_identity_validated": False})
        question_source_links = set()
        for e in result["evidence"]:
            paper = e["paper"]
            node(paper["id"], "Publication", paper["title"], url=paper["url"], evidence_types=e["study"]["types"], methods_sources=paper.get('methods_contexts', []), reported_results=paper.get('reported_results', []))
            node(e["modern_hypothesis"]["id"], "ModernHypothesis", e["modern_hypothesis"]["question"])
            for context in e.get('historical_contexts', []):
                key = (context['claim_id'], e['modern_hypothesis']['id'])
                if key not in question_source_links:
                    edge(context['claim_id'], 'MOTIVATES_QUESTION_UNDER_CANDIDATE_IDENTITY', e['modern_hypothesis']['id'], {
                        **sp, 'support': context['support']['text'], 'start': context['support']['start'], 'end': context['support']['end'],
                        'candidate_taxon_id': e['taxon_id'], 'condition_id': e['condition_id'], 'link_basis': context['link_basis'],
                        'historical_use_is_not_efficacy': True,
                    })
                    question_source_links.add(key)
            ep = {"source_id": paper["id"], **paper["provenance"], "licence": paper["licence"], "support": e["relation"]["supporting_text"], "method": "abstract-relation-rules-0.2", "human_reviewed": False, "identity_qualifier": e["identity_qualifier"], "comparability": "UNREVIEWED"}
            edge(e["taxon_id"], "HAS_MODERN_QUESTION", e["modern_hypothesis"]["id"], ep)
            edge(e["modern_hypothesis"]["id"], e["relation"]["relation"], paper["id"], ep)
            for i, safety in enumerate(e["safety_signals"]):
                sid = f"safety:{paper['id']}:{i}"
                node(sid, "SafetySignal", safety["supporting_text"][:75])
                edge(paper["id"], "REPORTS_SAFETY_WORDING", sid, {**ep, "support": safety["supporting_text"], "interpretation": safety["interpretation"]})
            for compound in e["compound_co_mentions"]:
                cid = f"pubchem:{compound['cid']}"
                node(cid, "Compound", compound["name"], url=compound["url"])
                edge(paper["id"], "CO_MENTIONS_COMPOUND", cid, {**ep, "support": compound["supporting_text"], "start": compound["support_start"], "end": compound["support_end"], "does_not_assert_plant_contains_compound": True})
        for a in result.get('compound_assay_leads', []):
            cid, tid = f"pubchem:{a['cid']}", a['target']['target_chembl_id']
            node(cid, 'Compound', a['compound'], url=f"https://pubchem.ncbi.nlm.nih.gov/compound/{a['cid']}")
            node(a['id'], 'AssayMeasurement', f"{a['standard_type']} {a['standard_value']} {a['standard_units']}", url=a['url'], licence=a['licence'])
            node(tid, 'MolecularTarget', a['target']['pref_name'], organism=a['target']['organism'], target_type=a['target']['target_type'])
            ap = {'source_id': a['id'], 'url': a['url'], 'licence': a['licence'], 'method': 'exact-InChIKey-database-join', 'retrieved_at': a['provenance']['retrieved_at'], 'document_id': a['document_id'], 'support': a['assay_description'], 'scope': a['scope'], 'link_basis': a['link_basis']}
            edge(cid, 'HAS_REPORTED_ASSAY', a['id'], ap)
            edge(a['id'], 'MEASURED_AGAINST', tid, ap)
        return {"nodes": list(nodes.values()), "edges": edges}

    def search(self, query, kind=None):
        q = normalize(query)
        withdrawn=self.withdrawn()
        groups = [("HistoricalSource", self.passages + self.extra_passages, lambda x: x["title"] + " " + x["text"]), ("ModernTaxon", self.taxa, lambda x: x["name"] + " " + " ".join(a["name"] for a in x["aliases"])), ("Publication", self.papers, lambda x: x["title"] + " " + x["abstract"]), ("Compound", self.compounds, lambda x: x["name"])]
        hits = []
        for group, rows, text in groups:
            if kind and group != kind:
                continue
            for row in rows:
                if row.get("id") in withdrawn or row.get("source_id") in withdrawn:
                    continue
                if q in normalize(text(row)):
                    hits.append({"kind": group, "id": row.get("id", f"pubchem:{row.get('cid')}"), "label": row.get("title") or row.get("name"), "url": row.get("url")})
        return hits[:100]

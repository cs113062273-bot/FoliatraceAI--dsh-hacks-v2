from __future__ import annotations

import re
from rapidfuzz import fuzz, process
from src.nlp.extract import normalize


def spelling(value):
    return normalize(value).replace("camomile", "chamomile").replace("featherfew", "feverfew")


class Resolver:
    version = "candidate-ranker-0.4"

    def __init__(self, taxa, congeners=None):
        self.taxa = taxa
        self.taxon_ids = {t['id'] for t in taxa}
        self.by_id = {t['id']: t for t in taxa}
        # GBIF-derived name collisions outside the snapshot (data/demo/vernacular_congeners.json).
        # Absent data means the open-world check is reported as not run, never as passed.
        self.congeners = (congeners or {}).get("aliases")
        self.congener_rule = (congeners or {}).get("rule")
        self.alias_index, self.genus_vernacular, self.genus_index = {}, {}, {}
        for taxon in taxa:
            self.genus_index.setdefault(normalize(taxon['genus']), []).append(taxon)
            for alias in taxon['aliases']:
                # A common name learned from one reader's text must not narrow the next reader's:
                # those stay with GBIF, which lists every plant holding the name.
                if taxon.get('open_world') and alias['kind'] == 'VERNACULAR':
                    continue
                key = spelling(alias['name'])
                if alias['kind'] == 'GENUS_VERNACULAR':
                    self.genus_vernacular.setdefault(key, []).append((taxon, alias))
                self.alias_index.setdefault(key, []).append((taxon, alias))
        self.alias_keys = list(self.alias_index)

    def open_world(self, candidate):
        # Only common-name matches are exposed to name collisions; scientific names are not.
        if self.congeners is None or candidate["reasons"][0] not in ("EXACT_VERNACULAR", "FUZZY_NAME"):
            return []
        if candidate["matched_alias"].get("kind") != "VERNACULAR":
            return []
        entry = self.congeners.get(candidate["taxon_id"], {}).get(normalize(candidate["matched_alias"]["name"]))
        return [{**c, "via_alias": candidate["matched_alias"]["name"], "in_snapshot": False, "evidence_retrieved": False} for c in (entry or {}).get("congeners_in_region", []) if f"gbif:{c['gbif_key']}" not in self.taxon_ids]

    def scored(self, keys, *, method, use_synonyms):
        """Best alias per taxon among name forms; forms are spellings of one source name."""
        best = {}
        for key in keys:
            for taxon, alias in self.alias_index.get(key, ()):
                if not use_synonyms and alias['kind'] != 'ACCEPTED_NAME':
                    continue
                reason = 'EXACT_' + alias['kind']
                if taxon['id'] not in best or (best[taxon['id']][2].get('kind') == 'VERNACULAR' and alias['kind'] != 'VERNACULAR'):
                    best[taxon['id']] = (1.0, reason, alias)
        # A name accepted for one species and listed as a synonym of another is a homonym:
        # the accepted holder leads, the other stays in view rather than being swapped in.
        # Only a GBIF-checked holder counts: the gazetteer keeps some synonym keys under their own name.
        if any(reason == 'EXACT_ACCEPTED_NAME' and not self.by_id[k].get('gazetteer_only') and self.by_id[k].get('status', 'ACCEPTED') == 'ACCEPTED' for k, (_, reason, _) in best.items()):
            best = {k: (.95, 'EXACT_SYNONYM_HOMONYM', alias) if reason == 'EXACT_SYNONYM' else (score, reason, alias) for k, (score, reason, alias) in best.items()}
        if best or method != 'full':
            return best
        for key in keys[:1]:
            if len(key) < 5:
                continue
            for match, ratio, _ in process.extract(key, self.alias_keys, scorer=fuzz.ratio, score_cutoff=86, limit=8):
                if match[0] != key[0]:
                    continue
                for taxon, alias in self.alias_index[match]:
                    if use_synonyms or alias['kind'] == 'ACCEPTED_NAME':
                        score = ratio / 100 * 0.87
                        if taxon['id'] not in best or best[taxon['id']][0] < score:
                            best[taxon['id']] = (score, 'FUZZY_NAME', alias)
        return best

    def resolve(self, name, *, method="full", geography=None, use_synonyms=True, forms=None):
        keys = list(dict.fromkeys(spelling(value) for value in [*(forms or []), name] if value))
        normalized = keys[0]
        # "Figs" is listed only for a Bornean fig; the reader means the fig. Plural and singular both count.
        if re.fullmatch(r"[a-z]{2,}[^su]s", normalized):
            keys.append(normalized[:-1])
        abbreviation = re.fullmatch(r"([A-Z])\.\s+([a-z]+)", name)
        matches = {}
        if normalized in self.genus_vernacular and use_synonyms:
            matches = {taxon['id']: (.80, 'GENUS_VERNACULAR_ONLY', alias) for taxon, alias in self.genus_vernacular[normalized]}
        elif abbreviation:
            for taxon in self.taxa:
                if taxon['genus'].startswith(abbreviation[1]) and normalize(taxon['name']).split()[-1] == abbreviation[2]:
                    matches[taxon['id']] = (.96, 'ABBREVIATED_GENUS', {'name': taxon['name'], 'kind': 'ACCEPTED_NAME', 'url': taxon['provenance']['url']})
        else:
            matches = self.scored(keys, method=method, use_synonyms=use_synonyms)
            singular = {taxon['id'] for taxon, _ in self.alias_index.get(keys[-1], ())} if keys[-1] != normalized and keys[-1] == normalized[:-1] else set()
            if singular:
                # A plural listed as a name is rarer evidence than the singular everyone uses.
                matches = {k: (score * .95, reason, alias) if k not in singular and spelling(alias['name']) == normalized else (score, reason, alias) for k, (score, reason, alias) in matches.items()}
            if not matches and method != 'exact':
                for key in keys:
                    # Curated species first, then the most widely named; a genus never implies one species.
                    ranked = sorted(self.genus_index.get(key, ()), key=lambda t: (bool(t.get('gazetteer_only')), -len(t['aliases'])))
                    for taxon in ranked[:5]:
                        matches[taxon['id']] = (.80, 'GENUS_CONTEXT_ONLY', {'name': taxon['genus'], 'url': taxon['provenance']['url']})
        candidates = []
        for identifier, (best, reason, matched_alias) in matches.items():
            taxon = self.by_id[identifier]
            geo_note = None
            if geography:
                countries = taxon.get("verified_countries", [])
                geo_note = "NO_VERIFIED_RANGE_IN_SNAPSHOT" if not countries else "RANGE_MATCH" if geography in countries else "RANGE_CONFLICT_REQUIRES_REVIEW"
                if countries and geography not in countries and method == "full":
                    best *= 0.65
            candidates.append({"taxon_id": identifier, "name": taxon["name"], "scientific_name": taxon["scientific_name"], "rank": taxon["rank"], "family": taxon["family"], "score": round(best, 4), "score_meaning": "RANKING_FEATURE_NOT_PROBABILITY", "confidence": "HIGH" if reason in ("EXACT_ACCEPTED_NAME", "EXACT_SYNONYM", "EXACT_INPUT_SYNONYM_MATCH") else "MEDIUM" if reason.startswith("EXACT_") else "LOW", "reasons": [reason] + ([geo_note] if geo_note else []), "matched_alias": matched_alias, "provenance": taxon["provenance"], "licence": taxon["licence"], "regional_records": taxon.get('occurrence_counts'), "gazetteer_only": bool(taxon.get('gazetteer_only'))})
        # Curated and regionally recorded candidates first; equal name evidence is never a tie-break for identity.
        candidates.sort(key=lambda c: (-c["score"], c['gazetteer_only'], -((c.get('regional_records') or {}).get('GB', 0)), -len(self.by_id[c['taxon_id']]['aliases']), c["name"]))
        if method == "full" and candidates:
            best = candidates[0]["score"]
            candidates = [c for c in candidates if c["score"] >= best - 0.10]
        candidates = candidates[:5]
        alternatives = []
        for c in candidates:
            if c['matched_alias'].get('kind') == 'VERNACULAR' and (self.congeners is None or c['taxon_id'] not in self.congeners):
                c['reasons'].append('OPEN_WORLD_CHECK_NOT_AVAILABLE')
            found = self.open_world(c)
            if found:
                c["reasons"].append("OPEN_WORLD_CONGENERS_IN_REGION")
                alternatives.extend(found)
        if not candidates:
            status = "UNRESOLVED"
        elif all(any(reason.startswith("GENUS_") for reason in c["reasons"]) for c in candidates):
            status = "GENUS_ONLY"
        elif len(candidates) > 1 and candidates[0]["score"] - candidates[1]["score"] < .08:
            status = "AMBIGUOUS"
        elif alternatives:
            # The snapshot holds one species, but GBIF lists regional congeners with this name.
            status = "OPEN_WORLD_AMBIGUOUS"
        elif candidates[0]["confidence"] == "HIGH":
            status = "RESOLVED_MODERN_NAME"
        else:
            status = "PROVISIONAL"
        unique = list({a["gbif_key"]: a for a in alternatives}.values())
        coverage = any('OPEN_WORLD_CHECK_NOT_AVAILABLE' in c['reasons'] for c in candidates)
        check = ({"status": "PARTIAL" if coverage else "RUN", **(self.congener_rule or {})} if self.congeners is not None else {"status": "NOT_RUN"})
        return {"query": name, "status": status, "confidence_mode": "QUALITATIVE", "candidates": candidates, "open_world_alternatives": unique, "open_world_check": check, "unresolved_possible": status != "RESOLVED_MODERN_NAME", "limitation": "Modern-name reconciliation is not proof of historical botanical identity. Candidates limited to the local snapshot; open-world alternatives are names only, with no evidence retrieved. Expanded common names may lack regional collision data; see each candidate's reasons.", "method": method, "version": self.version}

"""Local plant names from published lists. A recorded name is a hypothesis, never an identification.

Sources: Dr. Duke's ethnobotanical records (USDA, CC0), Merrill's 1903 dictionary of Philippine
plant names and Dalziel's 1916 Hausa vocabulary (public domain), and Wikidata labels (CC0). All work offline, so a rate-limited service never changes an answer.
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict

from src.common import DATA, read_json
from src.evidence.independent_use import independent_use
from src.nlp.extract import normalize

MERRILL = DATA / 'merrill_1903_names.json'
WIDER = DATA / 'local_names_wikidata.json'
GAZETTEER = DATA / 'taxa_gazetteer.json'
SOUNDS = str.maketrans('eocjvzy', 'iukhbsi')


def fold(word):
    """Old orthographies of one sound: "Gomamila" and "gumamela", "cayanga" and "kayanga"."""
    key = normalize(word).replace('-', '').replace(' ', '').replace('qu', 'k').translate(SOUNDS)
    return re.sub(r'(.)\1+', r'\1', key)


# Devanagari, Bengali, Gurmukhi, Gujarati, Oriya, Tamil, Telugu, Kannada and Malayalam share one
# layout, so one table reads all nine: offset within the block to its usual English-style spelling.
BRAHMIC = range(0x0900, 0x0D80)
VOWELS = {0x05: 'a', 0x06: 'aa', 0x07: 'i', 0x08: 'ii', 0x09: 'u', 0x0A: 'uu', 0x0B: 'ri', 0x0E: 'e', 0x0F: 'e', 0x10: 'ai', 0x12: 'o', 0x13: 'o', 0x14: 'au'}
SIGNS = {0x3E: 'aa', 0x3F: 'i', 0x40: 'ii', 0x41: 'u', 0x42: 'uu', 0x43: 'ri', 0x46: 'e', 0x47: 'e', 0x48: 'ai', 0x4A: 'o', 0x4B: 'o', 0x4C: 'au'}
CONSONANTS = dict(zip(range(0x15, 0x3A), ['k', 'kh', 'g', 'gh', 'n', 'ch', 'chh', 'j', 'jh', 'n', 't', 'th', 'd', 'dh', 'n', 't', 'th', 'd', 'dh', 'n', 'n', 'p', 'ph', 'b', 'bh', 'm', 'y', 'r', 'r', 'l', 'l', 'zh', 'v', 'sh', 'sh', 's', 'h']))
MARKS = {0x01: 'n', 0x02: 'n', 0x03: 'h'}
CHILLU = {0x0D7A: 'n', 0x0D7B: 'n', 0x0D7C: 'r', 0x0D7D: 'l', 0x0D7E: 'l', 0x0D7F: 'k', 0x09CE: 't'}


def romanize(word):
    """Indian-script spelling in Latin letters, as nineteenth-century authors wrote it: भिंडी "bhindi"."""
    out, pending = [], False
    for char in word:
        code = ord(char)
        if code in CHILLU:
            out.append(CHILLU[code])
            pending = False
            continue
        if code not in BRAHMIC:
            if pending:
                out.append('a')
            out.append(char)
            pending = False
            continue
        offset = (code - 0x0900) % 0x80
        if offset in CONSONANTS:
            if pending:
                out.append('a')
            out.append(CONSONANTS[offset])
            pending = True
        elif offset in SIGNS:
            out.append(SIGNS[offset])
            pending = False
        elif offset == 0x4D:
            pending = False
        elif offset in VOWELS:
            if pending:
                out.append('a')
            out.append(VOWELS[offset])
            pending = False
        elif offset in MARKS:
            if pending:
                out.append('a')
            out.append(MARKS[offset])
            pending = False
    if pending and len(out) <= 1:
        out.append('a')
    # Hindi and its neighbours drop a closing inherent vowel: नीम is "nim".
    return ''.join(out)


def sounded(word):
    """One key for the ways colonial authors and modern scripts spell an Indian name: aspiration,
    voicing, vowel length and hyphens fall away. "Vendaik-káy" and வெண்டைக்காய் meet."""
    key = re.sub(r'[^a-z]', '', normalize(romanize(word)))
    key = key.replace('sh', 's').replace('ch', 'c').replace('w', 'v').replace('z', 'j').replace('ee', 'i').replace('oo', 'u')
    key = key.replace('h', '').translate(str.maketrans('gjdbeoy', 'kctpiui'))
    key = re.sub(r'(.)\1+', r'\1', key)
    return key[:-1] if len(key) > 4 and key.endswith('a') else key


SERBIAN = dict(zip('абвгдђежзијклљмнњопрстћуфхцчџш', ['a', 'b', 'v', 'g', 'd', 'đ', 'e', 'ž', 'z', 'i', 'j', 'k', 'l', 'lj', 'm', 'n', 'nj', 'o', 'p', 'r', 's', 't', 'ć', 'u', 'f', 'h', 'c', 'č', 'dž', 'š']))
# Where the noun stands in a two-word name: "Echter Baldrian", "Crna bazga", "Kara Mürver" end with it;
# "Guimauve officinale", "piantaggine maggiore" start with it, unless an adjective leads ("Grand plantain").
HEAD_LAST = {'de', 'hr', 'sr', 'bg', 'tr', 'nl', 'hu', 'sl', 'mk'}
# Polish, Czech, Slovak and Ukrainian botanical names put the noun first: "Pokrzywa zwyczajna".
HEAD_FIRST = {'fr', 'it', 'es', 'pt', 'ro', 'pl', 'cs', 'sk', 'uk'}
LEADING_ADJECTIVES = {'grand', 'grande', 'gros', 'grosse', 'petit', 'petite', 'vrai', 'vraie', 'faux', 'fausse', 'bon', 'bonne', 'gran', 'falso', 'falsa', 'vero', 'vera'}
# "liść bobkowy" is bay leaf: a part of a plant, or its tea, is never the plant's short name.
PART_WORDS = {normalize(w) for w in ('liść', 'liście', 'kwiat', 'korzeń', 'nasiona', 'owoc', 'ziele', 'herbata', 'list', 'listovi', 'cvijet', 'cvet', 'koren', 'korijen', 'seme', 'sjeme',
              'plod', 'čaj', 'kora', 'kůra', 'květ', 'kořen', 'semeno', 'cvet', 'thee', 'tea', 'blad', 'wortel', 'bloem', 'zaad', 'vrucht', 'levél', 'gyökér', 'virág', 'mag', 'termés',
              'feuille', 'fleur', 'racine', 'graine', 'fruit', 'foglia', 'fiore', 'radice', 'seme', 'frutto', 'hoja', 'flor', 'raíz', 'semilla', 'fruto', 'folha', 'raiz', 'semente',
              'blatt', 'blüte', 'wurzel', 'samen', 'frucht', 'frunză', 'floare', 'rădăcină', 'sămânță', 'fruct', 'yaprak', 'çiçek', 'kök', 'tohum', 'meyve', 'gjethe', 'lule', 'rrënjë',
              'fara', 'лист', 'цвет', 'корен', 'семе', 'плод', 'чай', 'чај', 'листя', 'квітка', 'корінь', 'φύλλο', 'άνθος', 'ρίζα', 'σπόρος', 'καρπός', 'τσάι')}
LINKING_WORDS = {'de', 'des', 'du', 'd', 'à', 'a', 'aux', 'au', 'di', 'del', 'della', 'dei', 'degli', 'da', 'dos', 'das', 'do', 'la', 'le', 'les', 'el', 'los', 'e', 'y', 'et', 'und', 'von', 'der', 'od', 'i', 'ili', 'van', 'het', 'en', 'z', 'ze', 'in', 'és', 'и', 'од'}


def serbian_latin(name):
    """Serbian is written in both scripts; field notes from Kosovo and Bosnia are mostly in Latin."""
    out = ''.join(SERBIAN.get(c.lower(), c) if c.lower() in SERBIAN else c for c in name)
    return out[:1].upper() + out[1:] if name[:1].isupper() else out


def short_forms(taxa):
    """The noun people write without its qualifier: "Baldrian" for "Echter Baldrian", "guimauve" for
    "Guimauve officinale", "bokvica" for "Женска боквица". A short form joins only when every plant
    that carries it shares one genus, or most do ("водена боквица" is water plantain), so it narrows
    to a group of species. A frequent word is screened out at build time (scripts/derive_short_names.py)."""
    found, written, spelled = defaultdict(set), defaultdict(set), set()
    genera = {normalize(t['genus']) for t in taxa}
    for taxon in taxa:
        names = [(a.get('lang'), a['name'], a.get('url')) for a in taxon['aliases'] if a['kind'] == 'VERNACULAR' and a.get('lang') not in (None, 'en', 'la')]
        for lang, name, _ in names:
            written[(lang, normalize(name))].add((taxon['id'], taxon['genus']))
        latin = [('hr', serbian_latin(name), url) for lang, name, url in names if lang == 'sr' and re.search('[а-ш]', name.lower())]
        for lang, name, url in names + latin:
            words = re.findall(r"[^\W\d_]+", name)
            forms = [name] if (lang, name, url) in latin else []
            # A Latin binomial filed as a local name ("Scirpus setaceus") has no local noun in it.
            if words and normalize(words[0]) in genera:
                continue
            # "Feuilleea julibrissin" is a Latin synonym under a French label: the epithet gives it away.
            if len(words) == 2 and words[1] == taxon['name'].split()[-1]:
                continue
            if lang in HEAD_LAST and len(words) == 2 and (lang != 'de' or words[1][:1].isupper()):
                forms.append(words[1])
            elif lang == 'de' and len(words) == 1 and '-' in name:
                forms.append(name.rsplit('-', 1)[1])
            elif lang in HEAD_FIRST and len(words) == 2 and not set(map(str.casefold, words)) & LINKING_WORDS:
                forms.append(words[1] if words[0].casefold() in LEADING_ADJECTIVES else words[0])
            for form in forms:
                # Four letters is a whole Slavic plant name ("rman", yarrow; "brin", juniper).
                if len(normalize(form)) >= 4 and normalize(form) not in PART_WORDS:
                    found[(lang, normalize(form))].add((taxon['id'], taxon['genus'], form, name, url))
                    if form is name and (lang, name, url) in latin:
                        # A Serbian name in Latin letters is the recorded name, not a shortening: "šipak" is
                        # rose hip in Serbian though Croatian "šipak" is pomegranate, so both readings stay.
                        spelled.add((lang, normalize(form), taxon['id']))
    by_id = {t['id']: t for t in taxa}
    out = []
    for (lang, key), rows in sorted(found.items()):
        holders = Counter(genus for _, genus in {row[:2] for row in rows} | written.get((lang, key), set()))
        genus, count = holders.most_common(1)[0]
        kept = [row for row in rows if row[1] == genus and count * 2 > sum(holders.values()) or (lang, key, row[0]) in spelled]
        for identifier, _, form, source, url in sorted(kept, key=str):
            if (key, lang) not in {(normalize(a['name']), a.get('lang')) for a in by_id[identifier]['aliases']} and not any(r['id'] == identifier and r['lang'] == lang and normalize(r['name']) == key for r in out[-20:]):
                out.append({'name': form, 'lang': lang, 'id': identifier, 'accepted': by_id[identifier]['name'], 'short_form_of': source, 'url': url})
    return out


class LocalNames:
    def __init__(self):
        self.exact, self.folded, self.sounds = defaultdict(dict), defaultdict(dict), defaultdict(dict)
        self.citations = {}
        if MERRILL.exists():
            body = read_json(MERRILL)
            self.citations['Merrill 1903'] = {'citation': body['citation'], 'url': body['url'], 'licence': body['licence']}
            for row in body['names']:
                self.add(row['name'], {'id': row['id'], 'name': row['accepted'], 'family': row['family'], 'records': 1, 'source': 'Merrill 1903', 'printed': row['name'], 'where': ', '.join(row['languages'])})
        if WIDER.exists():
            for row in read_json(WIDER)['names']:
                self.add(row['name'], {'id': row['id'], 'name': row['accepted'], 'family': row['family'], 'records': 1, 'source': row['source'], 'printed': row['name'], 'where': row['language']})
        if GAZETTEER.exists():
            # Hindi names stay out of prose matching; inside an author's name list they may be read.
            for taxon in read_json(GAZETTEER)['taxa']:
                for name in taxon['names']:
                    if name['lang'] == 'hi':
                        self.add(name['name'], {'id': taxon['id'], 'name': taxon['name'], 'family': taxon.get('family', 'Unknown'), 'records': 1, 'source': 'Wikidata', 'printed': name['name'], 'where': 'Hindi'})
        duke = independent_use()
        if duke.available:
            self.citations['Duke'] = {'citation': "Duke JA. Dr. Duke's Phytochemical and Ethnobotanical Databases. USDA Agricultural Research Service; 2016.", 'url': duke.citation['url'], 'licence': duke.citation['licence']}
            for key, plants in duke.names.items():
                for entry in plants.values():
                    self.add(entry['printed'], {'id': entry['id'], 'name': entry['name'], 'family': entry['family'], 'records': entry['records'], 'source': 'Duke', 'printed': entry['printed'], 'where': ', '.join(sorted(entry['places'])[:3]), 'reference': entry['reference']})

    def add(self, wording, entry):
        self.exact[normalize(wording)].setdefault(entry['id'], entry)
        key = fold(wording)
        if len(key) >= 5:
            self.folded[key].setdefault(entry['id'], entry)
        sound = sounded(wording)
        if len(sound) >= 3:
            self.sounds[sound].setdefault(entry['id'], entry)

    def lookup(self, wording):
        """Exact spelling first, then a folded spelling, then the spoken form of an Indian name."""
        found = self.exact.get(normalize(wording)) or self.folded.get(fold(wording)) or self.sounds.get(sounded(wording)) or {}
        return sorted(found.values(), key=lambda e: (-e['records'], e['name']))


_shared = None


def local_names():
    global _shared
    if _shared is None:
        _shared = LocalNames()
    return _shared

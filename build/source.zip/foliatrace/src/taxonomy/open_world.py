"""Names outside the bundled snapshot: reconcile with GBIF, then read PubMed on demand.

Every response is cached by the scientific client, so a later offline run reproduces the
same result. Without a network the mention stays visible and unresolved; nothing is guessed.
"""
from __future__ import annotations

import re
from urllib.parse import urlencode

from src.ingestion.pubmed import ESEARCH, HUMAN, fetch_records, name_clause
from src.nlp.extract import normalize, research_terms

BACKBONE = 'd7dddbf4-2cf0-4f39-9b2a-bb099caae36c'
GBIF = 'https://api.gbif.org/v1/'


def taxon_from_record(entry, wording):
    """A plant known from a name list, built offline from the list's own GBIF reconciliation."""
    page = f"https://www.gbif.org/species/{entry['id'].split(':')[1]}"
    return {'id': entry['id'], 'name': entry['name'], 'scientific_name': entry['name'], 'rank': 'SPECIES', 'family': entry['family'], 'genus': entry['name'].split()[0], 'status': 'ACCEPTED', 'aliases': [{'name': entry['name'], 'kind': 'ACCEPTED_NAME', 'url': page}, {'name': wording, 'kind': 'VERNACULAR', 'url': page}], 'licence': 'CC-BY-4.0', 'provenance': {'source': entry['source'], 'url': page}, 'open_world': 'PUBLISHED_NAME_LIST', 'scope': 'Named in a published list of local names; a name match is not a historical identification.'}


def taxon_from_key(client, key, *, via):
    record, provenance = client.json(f'{GBIF}species/{key}')
    if record.get('rank') != 'SPECIES' or record.get('kingdom') != 'Plantae':
        return None
    common, _ = client.json(f'{GBIF}species/{key}/vernacularNames?limit=100')
    names = sorted({v['vernacularName'] for v in common.get('results', []) if v.get('language') in ('eng', 'en') and 4 <= len(v.get('vernacularName', '')) <= 40})
    aliases = [{'name': record['canonicalName'], 'kind': 'ACCEPTED_NAME', 'url': f'https://www.gbif.org/species/{key}'}]
    aliases += [{'name': n, 'kind': 'VERNACULAR', 'url': f'{GBIF}species/{key}/vernacularNames?limit=100'} for n in names]
    return {'id': f'gbif:{key}', 'name': record['canonicalName'], 'scientific_name': record['scientificName'], 'rank': 'SPECIES', 'family': record.get('family', 'Unknown'), 'genus': record.get('genus', record['canonicalName'].split()[0]), 'status': record.get('taxonomicStatus', 'ACCEPTED'), 'aliases': aliases, 'licence': 'CC-BY-4.0', 'provenance': provenance, 'open_world': via, 'scope': 'Reconciled on demand with the GBIF backbone; a name match is not a historical identification.'}


def reconcile_scientific(client, name):
    """Exact Plantae species match. None means GBIF does not know this as a plant species."""
    match, _ = client.json(f'{GBIF}species/match?' + urlencode({'name': name, 'kingdom': 'Plantae', 'strict': 'true'}))
    if match.get('matchType') != 'EXACT' or match.get('kingdom') != 'Plantae' or match.get('rank') != 'SPECIES':
        return None
    key = match.get('acceptedUsageKey') or match.get('usageKey')
    taxon = taxon_from_key(client, key, via='GBIF_EXACT_SCIENTIFIC_NAME')
    if taxon and normalize(name) != normalize(taxon['name']):
        # The text keeps its own older name; it stays findable as a synonym of the accepted one.
        taxon['aliases'].append({'name': name, 'kind': 'SYNONYM', 'url': f'{GBIF}species/{key}', 'usage': f"gbif:{match['usageKey']}"})
    return taxon


def scientific_readings(client, name):
    """Every species a written binomial can mean, the accepted holder of the name first.

    "Artemisia ludoviciana" is Nuttall's sagebrush and also Besser's synonym of A. indica;
    "Holarrhena antidysenterica" is a synonym of two species, so GBIF's match gives up at family.
    """
    taxon = reconcile_scientific(client, name)
    body, _ = client.json(f'{GBIF}species/search?' + urlencode({'q': name, 'rank': 'SPECIES', 'datasetKey': BACKBONE, 'limit': 20}))
    rows = [r for r in body.get('results', []) if r.get('kingdom') == 'Plantae' and normalize(r.get('canonicalName', '')) == normalize(name)]
    keys = [r['key'] for r in rows if r.get('taxonomicStatus') == 'ACCEPTED'] + [r['acceptedKey'] for r in rows if r.get('acceptedKey')]
    found = [taxon] if taxon else []
    for key in dict.fromkeys(keys):
        if len(found) >= 3:
            break
        if f'gbif:{key}' in {t['id'] for t in found}:
            continue
        other = taxon_from_key(client, key, via='GBIF_SCIENTIFIC_NAME_HOMONYM')
        if other:
            if normalize(other['name']) != normalize(name):
                usage = next((r['key'] for r in rows if r.get('acceptedKey') == key), None)
                other['aliases'].append({'name': name, 'kind': 'SYNONYM', 'url': f'{GBIF}species/search?' + urlencode({'q': name, 'datasetKey': BACKBONE}), 'usage': f'gbif:{usage}' if usage else None})
            found.append(other)
    return found


def genus_members(client, word):
    match, _ = client.json(f'{GBIF}species/match?' + urlencode({'name': word, 'kingdom': 'Plantae', 'rank': 'GENUS', 'strict': 'true'}))
    if not (match.get('rank') == 'GENUS' and match.get('matchType') == 'EXACT' and match.get('kingdom') == 'Plantae'):
        return None
    species, _ = client.json(f'{GBIF}species/search?' + urlencode({'highertaxonKey': match['usageKey'], 'rank': 'SPECIES', 'status': 'ACCEPTED', 'datasetKey': BACKBONE, 'limit': 300}))
    rows = sorted(species.get('results', []), key=lambda r: -len(r.get('vernacularNames', [])))
    return [t for t in (taxon_from_key(client, r['key'], via='GBIF_GENUS_MEMBER') for r in rows[:3]) if t]


def reconcile_word(client, word):
    """A capitalised word may be a genus; otherwise an exact English common name. None means no plant."""
    if word[0].isupper():
        members = genus_members(client, word)
        if members:
            return members
    # Old print hyphenates what GBIF spells apart: "Couch-Grass".
    for wording in dict.fromkeys((word, word.replace('-', ' '))):
        body, _ = client.json(f'{GBIF}species/search?' + urlencode({'q': wording, 'qField': 'VERNACULAR', 'rank': 'SPECIES', 'highertaxonKey': 6, 'datasetKey': BACKBONE, 'status': 'ACCEPTED', 'limit': 40}))
        key = normalize(wording)
        exact = []
        # The most widely named species first: the search order alone hides the familiar plant.
        for row in sorted(body.get('results', []), key=lambda r: -len(r.get('vernacularNames', []))):
            names = {normalize(v.get('vernacularName', '')) for v in row.get('vernacularNames', []) if v.get('language') in ('eng', 'en', '')}
            if key in names or f'common {key}' in names:
                exact.append(row['key'])
        if exact:
            return [t for t in (taxon_from_key(client, k, via='GBIF_EXACT_COMMON_NAME') for k in exact[:3]) if t] or None
    return None


def reconcile_common_name(client, word):
    """Every plant a name can mean: the one an encyclopedia means first, then GBIF's holders.

    GBIF alone answers "couch grass" with Bermuda grass, an Australian usage; the plant a reader
    of an old herbal expects comes from the encyclopedia. None means neither route knows it.
    """
    found = {}
    for route in (reconcile_encyclopedia, reconcile_word):
        try:
            found.update({t['id']: t for t in route(client, word) or () if t['id'] not in found})
        except Exception:
            continue
    return list(found.values())[:5] or None


def reconcile_encyclopedia(client, word, languages=('en', 'es')):
    """An everyday name GBIF lacks: a Wikipedia redirect leads to the item, Wikidata to its taxon.

    "Ashwagandha" reaches Withania somnifera this way. GBIF still has the last word on the species.
    """
    # Wikipedia titles are sentence case and spelt apart; old print is neither.
    plain = word.replace('-', ' ')
    wordings = dict.fromkeys((word, plain, plain.capitalize()))
    for language in languages:
        for wording in wordings:
            body, _ = client.json(f'https://{language}.wikipedia.org/w/api.php?' + urlencode({'action': 'query', 'format': 'json', 'redirects': 1, 'prop': 'pageprops', 'ppprop': 'wikibase_item', 'titles': wording}), patient=False)
            for page in body.get('query', {}).get('pages', {}).values():
                item = page.get('pageprops', {}).get('wikibase_item')
                if not item:
                    continue
                # An article titled by its binomial needs no second source.
                title = page.get('title', '')
                for name in [title] if looks_scientific(title) else taxon_names(client, item):
                    taxon = reconcile_scientific(client, name) if looks_scientific(name) else None
                    if taxon:
                        taxon['open_world'] = 'WIKIPEDIA_REDIRECT_TO_GBIF_SPECIES'
                        taxon['aliases'].append({'name': word, 'kind': 'VERNACULAR', 'url': f'https://www.wikidata.org/wiki/{item}'})
                        return [taxon]
                    # "Gum plant" is a genus: its best-known species stand for the name.
                    members = genus_members(client, name) if re.fullmatch(r'[A-Z][a-z-]+', name) else None
                    if members:
                        return members
    return None


def taxon_names(client, item):
    """The taxon an item is, or the taxon its product comes from (kava the drink, its plant)."""
    def claims(entity):
        # One request per item: Wikidata limits rate, and a reader is waiting on this.
        body, _ = client.json('https://www.wikidata.org/w/api.php?' + urlencode({'action': 'wbgetentities', 'format': 'json', 'props': 'claims', 'ids': entity}), patient=False)
        found = body.get('entities', {}).get(entity, {}).get('claims', {})
        return lambda prop: [c['mainsnak']['datavalue']['value'] for c in found.get(prop, []) if 'datavalue' in c['mainsnak']]
    held = claims(item)
    names = held('P225')
    if names:
        return names
    for prop in ('P1582', 'P186'):
        for source in held(prop):
            names += claims(source['id'])('P225')
    return names


def on_demand_literature(client, taxon, conditions=(), *, limit=14):
    """Human studies first, then the recorded topics, then any study naming the plant."""
    clause = name_clause(taxon)
    identifiers = []
    words = list(dict.fromkeys(term for condition in conditions for term in research_terms(condition)[:4]))[:14]
    topical = ' AND (' + ' OR '.join(f'"{word}"[tiab]' for word in words) + ')' if words else ''
    # Trials often name only the genus ("Harpagophytum extract"), so the focused search keeps it.
    genus = f'{clause} OR "{taxon["name"].split()[0]}"[tiab]'
    for names, suffix, count in ((genus, topical + HUMAN, limit if words else 0), (clause, HUMAN, limit), (clause, topical, 10 if words else 0), (clause, '', 8)):
        if not count:
            continue
        body, _ = client.json(ESEARCH + '?' + urlencode({'db': 'pubmed', 'term': f'({names}){suffix}', 'retmode': 'json', 'retmax': count, 'sort': 'relevance'}))
        identifiers += [pmid for pmid in body.get('esearchresult', {}).get('idlist', []) if pmid not in identifiers]
    rows = fetch_records(client, identifiers)
    for row in rows:
        row.pop('pmid_key', None)
        row['taxon_ids'] = [taxon['id']]
    return rows


def looks_scientific(name):
    return bool(re.fullmatch(r'[A-Z][a-z-]+ [a-z-]+', name))

"""NIH label snapshots. Label claims and quantities are never actual patient use."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Literal
from urllib.parse import urlencode

from pydantic import BaseModel, ConfigDict, Field, model_validator
from src.common import ROOT, now
from src.evidence.question_review import canonical
from src.evidence.integrity import portable_numbers

BASE = 'https://api.ods.od.nih.gov/dsld/v9/'
SOURCE_SCOPE = 'US_LABEL_RECORD_NOT_VERIFIED_AGAINST_BOTTLE'


def source_hash(raw):
    return hashlib.sha256(canonical(raw)).hexdigest()


def ingredients(raw):
    """Flatten with JSON pointers, retaining parenthood and *own* quantities only."""
    result = []
    def walk(rows, path, parent=None, depth=0):
        if not isinstance(rows, list) or depth > 12:
            raise ValueError('Unsupported ingredient hierarchy')
        for i, row in enumerate(rows):
            pointer = path+'/'+str(i)
            if not isinstance(row, dict) or not isinstance(row.get('name'), str):
                raise ValueError('Ingredient name is missing')
            quantities = row.get('quantity') or []
            if not isinstance(quantities, list):
                raise ValueError('Ingredient quantities must be a list')
            if any(not isinstance(q,dict) or not isinstance(q.get('unit',''),(str,type(None))) or not isinstance(q.get('quantity'),(int,float,type(None))) for q in quantities):
                raise ValueError('Unsupported ingredient quantity')
            # NP = Not Provided in DSLD; its numeric placeholder is not zero dose.
            amount = [dict(q, amount_status='NOT_PROVIDED' if q.get('unit') in ('NP', None, '') or q.get('quantity') is None else 'LABEL_DECLARED') for q in quantities]
            notes = row.get('notes') or ''
            if not isinstance(notes,str) or not isinstance(row.get('forms') or [],list):
                raise ValueError('Unsupported ingredient notes or forms')
            if any(not isinstance(f,dict) or any(f.get(k) is not None and not isinstance(f[k],str) for k in ('name','prefix')) for f in row.get('forms') or []):
                raise ValueError('Unsupported ingredient form description')
            genus = re.search(r'\bGenus:\s*([A-Z][a-z]+)', notes)
            species = re.search(r'\bSpecies:\s*([a-z][a-z-]+)', notes)
            if not isinstance(row.get('category') or '',str) or not isinstance(row.get('ingredientGroup') or '',str):
                raise ValueError('Unsupported ingredient category or group')
            category = (row.get('category') or '').lower()
            lookup = (genus[1]+' '+species[1]) if genus and species else row.get('ingredientGroup') or row['name']
            result.append({'key':pointer, 'parent_key':parent, 'name':row['name'],
                           'category':category, 'notes':notes, 'forms':row.get('forms') or [],
                           'quantities':amount, 'lookup':lookup,
                           'plant_lookup_available':category=='botanical'})
            if len(result)>300:
                raise ValueError('This label exceeds the supported 300 ingredient rows')
            walk(row.get('nestedRows') or [],pointer+'/nestedRows',pointer,depth+1)
    walk(raw.get('ingredientRows') or [],'/ingredientRows')
    return result


def label_wording(raw):
    lines = [f"NIH DSLD label {raw['id']}: {raw['fullName']}",
             'Brand: '+str(raw.get('brandName') or 'Not stated'),
             'Label entered: '+str(raw.get('entryDate') or 'Not stated'),
             'Declared ingredients (label quantities, not actual use):']
    for row in ingredients(raw):
        quantities = ['not provided' if q['amount_status']=='NOT_PROVIDED' else f"{q.get('operator') or ''}{q['quantity']} {q['unit']} per {q.get('servingSizeQuantity')} {q.get('servingSizeUnit') or 'label serving'}" for q in row['quantities']]
        lines.append(row['key']+' '+row['name']+': '+('; '.join(quantities) or 'not provided'))
    lines.append('Full notes, forms, directions and serving data are preserved in the attached source snapshot. Bottle match not established.')
    wording='\n'.join(lines)
    if len(wording)>5000:
        raise ValueError('This label is too long for the consultation form; copy relevant original wording manually')
    return wording


def ingredient_source(raw, key):
    row=next((r for r in ingredients(raw) if r['key']==key),None)
    if row is None:raise ValueError('Ingredient is not in this label')
    return label_wording(raw)+'\nSelected ingredient: '+row['key']+' '+row['name']+'\nExact ingredient notes: '+row['notes']+'\nLabel SHA256: '+source_hash(raw)


class LabelSnapshot(BaseModel):
    model_config = ConfigDict(extra='forbid')
    label_id: int = Field(gt=0)
    sha256: str = Field(pattern=r'^[a-f0-9]{64}$')
    source_url: str
    retrieved_at: str = Field(max_length=80)
    access: str = Field(pattern=r'^(LIVE_OR_CACHED_NIH|BUNDLED_REFERENCE)$')
    raw: dict
    hash_scheme: Literal['NUMERIC_JSON_V1'] | None = None

    @model_validator(mode='after')
    def grounded(self):
        if self.hash_scheme=='NUMERIC_JSON_V1':self.raw=portable_numbers(self.raw)
        if self.source_url != BASE+'label/'+str(self.label_id):
            raise ValueError('Label source must be the fixed NIH endpoint')
        if self.raw.get('id') != self.label_id or not isinstance(self.raw.get('fullName'),str):
            raise ValueError('Label identifier or product name mismatch')
        if len(canonical(self.raw))>1_000_000 or source_hash(self.raw)!=self.sha256:
            raise ValueError('Label source checksum mismatch or size limit exceeded')
        ingredients(self.raw)
        return self


def snapshot(raw, retrieved_at=None, access='LIVE_OR_CACHED_NIH'):
    normal=portable_numbers(raw)
    return LabelSnapshot(label_id=raw['id'],sha256=source_hash(normal),source_url=BASE+'label/'+str(raw['id']),
                         retrieved_at=now() if retrieved_at is None else retrieved_at,access=access,raw=normal,hash_scheme='NUMERIC_JSON_V1').model_dump()


def summarize(raw):
    return {'label_id':raw['id'], 'name':raw['fullName'], 'brand':raw.get('brandName') or '',
            'entry_date':raw.get('entryDate'), 'off_market':raw.get('offMarket'),
            'upc':raw.get('upcSku'), 'version':raw.get('productVersionCode'),
            'form':(raw.get('physicalState') or {}).get('langualCodeDescription',''),
            'scope':SOURCE_SCOPE}


def reference_labels():
    folder=ROOT/'data'/'product_labels'
    manifest=json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
    result=[]
    for entry in manifest['labels']:
        raw=json.loads((folder/(str(entry['label_id'])+'.json')).read_text(encoding='utf-8'))
        if source_hash(raw)!=entry['sha256']:raise ValueError('Bundled label checksum mismatch')
        result.append(snapshot(raw,manifest['retrieved_at'],'BUNDLED_REFERENCE'))
    return result


def search_labels(client, query, mode='reference', offset=0, market='all'):
    if offset<0 or offset>200 or market not in ('all','on','off'):
        raise ValueError('Unsupported label page or market filter')
    if mode=='reference':
        rows=[s for s in reference_labels() if all(t in (s['raw']['fullName']+' '+str(s['raw'].get('brandName') or '')+' '+str(s['raw'].get('upcSku') or '')).casefold() for t in query.casefold().split())]
        rows=[s for s in rows if market=='all' or s['raw'].get('offMarket')==({'on':0,'off':1}[market])]
        return {'labels':[summarize(s['raw']) for s in rows[offset:offset+10]], 'access':'BUNDLED_REFERENCE',
                'coverage':'Six fixed US label records for reproducible examples; not a complete or current market search.',
                'total':len(rows),'offset':offset,'has_more':offset+10<len(rows),'market':market}
    if client.offline:
        raise ValueError('Live NIH search is disabled in offline mode. Use the reference examples or manual entry.')
    payload,meta=client.json(BASE+'search-filter?'+urlencode({'q':query,'size':10,'from':offset,
                       'status':{'all':2,'on':1,'off':0}[market],'sort_by':'entryDate','sort_order':'desc'}),max_bytes=2_000_000,patient=False)
    rows=[]
    for hit in payload.get('hits',[]):
        raw=dict(hit['_source'],id=int(hit['_id']))
        rows.append(summarize(raw))
    return {'labels':rows,'access':'LIVE_OR_CACHED_NIH','coverage':'At most 10 NIH matches per page, newest entry first; entry date is not a formulation date or bottle match. Market status describes the source record.',
            'source':meta,'offset':offset,'has_more':len(rows)==10 and offset<200,'market':market}


def compare_labels(left, right):
    """Compare declared text/quantities without inferring equivalence or potency."""
    left=LabelSnapshot.model_validate(left);right=LabelSnapshot.model_validate(right)
    def rows_by_identity(raw):
        rows=ingredients(raw);paths={};groups={}
        for row in rows:
            # Hierarchical names survive reordering; duplicates are kept as lists.
            parent=paths.get(row['parent_key'],())
            path=parent+(row['name'].strip().casefold(),)
            paths[row['key']]=path
            value={k:row[k] for k in ('name','category','notes','forms','quantities')}
            # Serving order and DV target order are source metadata, not component identity.
            value['quantities']=[{k:v for k,v in q.items() if k!='servingSizeOrder'} for q in value['quantities']]
            groups.setdefault(path,[]).append({'pointer':row['key'],'declared':value})
        return groups
    a=rows_by_identity(left.raw);b=rows_by_identity(right.raw);changes=[]
    for path in sorted(set(a)|set(b)):
        before=a.get(path,[]);after=b.get(path,[])
        av=sorted([r['declared'] for r in before],key=lambda v:canonical(v))
        bv=sorted([r['declared'] for r in after],key=lambda v:canonical(v))
        if av!=bv:
            changes.append({'ingredient_path':list(path),'status':'ADDED' if not before else 'REMOVED' if not after else 'CHANGED',
                            'before':before,'after':after})
    fields=('fullName','brandName','upcSku','productVersionCode','physicalState','servingSizes','otheringredients')
    metadata=[{'field':f,'before':left.raw.get(f),'after':right.raw.get(f)} for f in fields if left.raw.get(f)!=right.raw.get(f)]
    return {'left':summarize(left.raw),'right':summarize(right.raw),'source_sha256':[left.sha256,right.sha256],
            'ingredient_changes':changes,'label_field_changes':metadata,
            'same_selected_source':left.raw==right.raw,
            'scope':'DECLARED_LABEL_DIFFERENCES_NOT_BOTTLE_VERIFICATION_OR_CLINICAL_EQUIVALENCE',
            'limits':['Changed wording does not by itself prove a formulation change.',
                      'No detected difference does not establish chemical or clinical equivalence.',
                      'Blend totals are not assigned to individual ingredients; NP remains not provided.']}


def read_label(client, identifier, mode='reference'):
    if mode=='reference':
        match=next((s for s in reference_labels() if s['label_id']==identifier),None)
        if match is None:raise ValueError('Label is not in the bounded reference examples')
        return match
    raw,meta=client.json(BASE+'label/'+str(identifier),max_bytes=1_000_000,patient=False)
    return snapshot(raw,meta['retrieved_at'])

"""Which candidate fits what the author actually wrote?

Adapts the comparison matrix of Lardos et al. (J Ethnopharmacol 2023; PMC7615571): historical
features are scored against modern descriptions (+2 match, -2 conflict, 0 absent) and the total
gives a Strong (>=5), Moderate (3-4) or Weak (<=2) rating. Every point keeps the sentence it came
from. A rating ranks hypotheses for reading; it never establishes an identity.
"""
from __future__ import annotations

import math
import re
from functools import lru_cache

from src.common import DATA, read_json
from src.nlp.extract import normalize, sentences
from src.evidence.comparability import compiled, name_pattern
from src.evidence.independent_use import independent_use

COLOURS = {'yellow': r'yellow|golden|gold-coloured', 'white': r'white|whitish', 'purple': r'purple|purplish|violet-coloured|mauve', 'blue': r'blue|bluish', 'red': r'red|reddish|crimson|scarlet', 'pink': r'pink|pinkish|rose-coloured', 'green': r'green|greenish'}
FLOWER = r'flowers?|flowered|blossoms?|petals?|florets?|corolla|blooms?'
HABITS = {'tree': r'\b(?:a|great|tall|small|large|deciduous|evergreen)\s+(?:\w+\s+)?tree\b|\btree (?:growing|reaching|grows)\b', 'shrub': r'\bshrubs?\b|\b(?:a|as a|forms a)\s+(?:\w+\s+)?bush\b|\bbushy (?:plant|shrub|habit)\b', 'climber': r'\bclimb\w*|\btwin(?:es|ing)\b|\bvines?\b|\bscrambl\w*', 'creeping': r'\bcreep\w*|\bprostrate\b|\btrailing\b|\bmat-forming\b|\bstolon\w*', 'herb': r'\bherbaceous\b|\b(?:perennial|annual|biennial) (?:plant|herb)\b|\bperennial\b|\bannual\b|\bbiennial\b'}
EXCLUSIVE_HABITS = [{'tree', 'herb'}, {'shrub', 'herb'}]
HABITATS = {'woodland': r'woods?\b|woodlands?|forests?|thickets?|copses?|groves?', 'hedgerow': r'hedges?|hedgerows?|hedge-rows?', 'grassland': r'meadows?|pastures?|grasslands?', 'wetland': r'marsh\w*|bogs?\b|fens?\b|ditch\w*|streams?|rivers?|ponds?|watery|water-side|wet places|moist places|damp places|swamps?', 'coast': r'sea-?shores?|sea-?side|coasts?|coastal|maritime|salt-?marsh\w*|by the sea', 'arable': r'corn-?fields?|arable|waste places|waste ground|road-?sides?|way-?sides?|ruderal', 'garden': r'gardens?|cultivated', 'rocky': r'walls?\b|rocks?\b|rocky|stony', 'upland': r'mountains?|hills?\b|hillsides?|alpine|upland', 'heath': r'heaths?\b|moors?\b|moorland'}
HABITAT_SENTENCE = r'\b(?:grows?|growing|found|groweth|native|occurs?|common|wild|habitat|place|inhabit\w*|abounds?|plentiful|thrives?)\b'
MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december']
MONTH_PATTERN = r'\b(' + '|'.join(m.capitalize() for m in MONTHS) + r'|' + '|'.join(MONTHS[i] for i in (0, 1, 2, 3, 5, 6, 7, 8, 9, 10, 11)) + r')\b'
SUBJECT_OPENING = re.compile(r'\s*(?:it|they|this (?:herb|plant)|the (?:herb|plant|flowers?|leaves|stalks?|stems?|root|roots))\b', re.I)
ODOURS = {'aromatic': r'aromatic|fragrant|sweet-?scented|sweet smell|odorous', 'foetid': r'f[oe]+tid|stinking|disagreeable (?:odou?r|smell)|unpleasant (?:odou?r|smell)'}


@lru_cache(maxsize=4096)
def scan(text):
    """Description features with the sentence each one came from."""
    found = {'flower_colour': {}, 'habit': {}, 'habitat': {}, 'flowering': {}, 'odour': {}}
    for sentence in sentences(text):
        value = sentence['text']
        for colour, pattern in COLOURS.items():
            if compiled(rf'\b(?:{pattern})\b(?:\W+\w+){{0,4}}?\W+(?:{FLOWER})\b|\b(?:{FLOWER})\b(?:\W+\w+){{0,5}}?\W+(?:{pattern})\b').search(value) and not compiled(rf'\b(?:{pattern})\s+wine\b').search(value):
                found['flower_colour'].setdefault(colour, sentence)
        for habit, pattern in HABITS.items():
            if re.search(pattern, value, re.I):
                found['habit'].setdefault(habit, sentence)
        if re.search(HABITAT_SENTENCE, value, re.I):
            for habitat, pattern in HABITATS.items():
                if compiled(rf'\b(?:{pattern})').search(value):
                    found['habitat'].setdefault(habitat, sentence)
        if re.search(rf'\b(?:{FLOWER}|flowering|time\b)', value, re.I):
            for month in re.findall(MONTH_PATTERN, value):
                found['flowering'].setdefault(month.casefold(), sentence)
        for odour, pattern in ODOURS.items():
            if re.search(pattern, value, re.I):
                found['odour'].setdefault(odour, sentence)
    return found


def quote(sentence):
    return {'text': sentence['text'][:420], 'start': sentence['start'], 'end': sentence['end']}


def compare_set(feature, old, new, exclusive=True):
    shared = sorted(set(old) & set(new))
    if shared:
        return {'feature': feature, 'status': 'MATCH', 'points': 2, 'values': shared, 'historical': quote(old[shared[0]]), 'modern': quote(new[shared[0]])}
    if old and new and exclusive:
        first, second = next(iter(old)), next(iter(new))
        return {'feature': feature, 'status': 'CONFLICT', 'points': -2, 'values': [first, second], 'historical': quote(old[first]), 'modern': quote(new[second])}
    return None


def compare_months(old, new):
    if not old or not new:
        return None
    index = {m: i for i, m in enumerate(MONTHS)}
    old_months, new_months = {index[m] for m in old}, {index[m] for m in new}
    distance = min(min(abs(a - b), 12 - abs(a - b)) for a in old_months for b in new_months)
    first_old, first_new = sorted(old)[0], sorted(new)[0]
    status, points = ('MATCH', 2) if distance == 0 else ('PARTIAL', 1) if distance == 1 else ('CONFLICT', -2)
    return {'feature': 'flowering time', 'status': status, 'points': points, 'values': [first_old, first_new], 'historical': quote(old[first_old]), 'modern': quote(new[first_new])}


def habit_conflict(old, new):
    shared = compare_set('growth form', old, new, exclusive=False)
    if shared:
        return shared
    for pair in EXCLUSIVE_HABITS:
        left = next((h for h in pair if h in old), None)
        right = next((h for h in pair if h in new and h != left), None)
        if left and right:
            return {'feature': 'growth form', 'status': 'CONFLICT', 'points': -2, 'values': [left, right], 'historical': quote(old[left]), 'modern': quote(new[right])}
    return None


def author_named(text, taxon):
    for alias in taxon['aliases']:
        if alias['kind'] not in ('ACCEPTED_NAME', 'SYNONYM', 'INPUT_SYNONYM_MATCH'):
            continue
        match = compiled(name_pattern(alias['name'])).search(text)
        if match:
            start = max(0, match.start() - 110)
            return {'feature': "author's own Latin name", 'status': 'MATCH', 'points': 4, 'values': [alias['name']], 'alias_kind': alias['kind'], 'historical': {'text': text[start:match.end() + 90], 'start': start, 'end': match.end() + 90}, 'modern': {'text': f"{alias['name']} is a {alias['kind'].replace('_', ' ').lower()} of {taxon['name']}"}}
    return None


def regional(taxon, region):
    count = (taxon.get('occurrence_counts') or {}).get(region)
    if count is None:
        return None
    if count >= 100:
        return {'feature': 'recorded in the source region', 'status': 'MATCH', 'points': 1, 'values': [f'{count} GBIF records in {region}'], 'modern': {'text': f'GBIF lists {count} occurrence records for {region}. Modern records do not establish historical presence.'}}
    if count < 10:
        return {'feature': 'recorded in the source region', 'status': 'CONFLICT', 'points': -2, 'values': [f'{count} GBIF records in {region}'], 'modern': {'text': f'GBIF lists only {count} occurrence records for {region}. A cultivated or imported plant can still be meant.'}}
    return None


def recorded_use(taxon, topics):
    """The passage's uses against what other communities used this plant for; silence is not conflict."""
    records = independent_use()
    typical = [t for t in sorted(topics) if records.characteristic(taxon, t)]
    if not typical:
        return None
    reach = [records.reach(taxon, t) for t in typical]
    words = ', '.join(t.replace('condition:', '').replace('_', ' ') for t in typical[:3])
    return {'feature': 'use recorded elsewhere', 'status': 'MATCH', 'points': min(len(typical), 2), 'values': [words], 'modern': {'text': f"Dr. Duke's database lists {sum(r['records'] for r in reach)} records for {words}, more often than for most plants.", 'url': records.citation['url']}}


def weigh_shared_wording(rated, taxmap):
    """One written binomial reaching several species: the species that holds it as its accepted
    name, or failing that keeps the genus the author wrote, is the plainer reading."""
    named = [(r, row) for r in rated for row in r['rows'] if row['feature'] == "author's own Latin name"]
    if len(named) < 2:
        return
    holders = [r['name'] for r, row in named if row.get('alias_kind') == 'ACCEPTED_NAME']
    for r, row in named:
        if row.get('alias_kind') == 'ACCEPTED_NAME':
            continue
        written = row['values'][0]
        same_genus = [x['name'] for x, _ in named if x['name'].split()[0] == written.split()[0]]
        if holders:
            note = f"The same wording is the accepted name of {holders[0]}; for this species it is a synonym under another author, a homonym."
        elif same_genus and r['name'].split()[0] != written.split()[0]:
            note = f"The source wrote the genus {written.split()[0]}; this synonym places the plant in {r['name'].split()[0]}, while {same_genus[0]} keeps it."
        else:
            continue
        # No points: a well-studied homonym must not outrank the plant the wording names.
        row['points'] = 0
        row['modern'] = {**row['modern'], 'text': row['modern']['text'] + ' ' + note}
        r['score'] = sum(x['points'] for x in r['rows'])
        r['rating'] = rate(r['score'], r['rows'])


@lru_cache(maxsize=1)
def encyclopedia_names():
    path = DATA / 'wikipedia_redirects.json'
    found = {}
    for row in read_json(path)['names'] if path.exists() else []:
        if row['kind'] == 'VERNACULAR':
            found.setdefault(normalize(row['name']), {})[row['id']] = row
    return found


def recorded_name(taxon, wording):
    """Whether people who name plants for a living give this plant this name.

    A GBIF vernacular list holds every usage anywhere; "eyebright" reaches a Plumbago. An
    encyclopedia redirect and ethnobotanists' field records say which plant the name usually means.
    """
    if not wording:
        return None
    keys = dict.fromkeys(normalize(form) for form in (wording, wording.replace('-', ''), wording.replace('-', ' ')))
    points, notes, values = 0, [], []
    for key in keys:
        article = encyclopedia_names().get(key, {}).get(taxon['id'])
        if article and not values:
            points += 1
            values.append(wording)
            notes.append(f"English Wikipedia sends \"{article['name']}\" to the article on this species ({article['article']}).")
        holders = independent_use().names.get(key, {})
        # Duke may file the plant under a synonym ("Stachys officinalis" for Betonica officinalis).
        synonyms = {normalize(a['name']) for a in taxon['aliases'] if a['kind'] in ('ACCEPTED_NAME', 'SYNONYM')}
        mine = holders.get(taxon['id']) or next((h for h in holders.values() if normalize(h['name']) in synonyms), None)
        # Records from one country say how that country speaks: "ginseng" in Duke is American ginseng.
        if mine and mine['records'] >= 2 and len(mine['places']) >= 2 and mine['records'] == max(h['records'] for h in holders.values()) and not any('Duke' in n for n in notes):
            points += 1
            notes.append(f"Dr. Duke's ethnobotanical records use \"{mine['printed']}\" {mine['records']} times for this species, more than for any other.")
    if not points:
        return None
    return {'feature': 'name recorded for this plant', 'status': 'MATCH', 'points': points, 'values': [wording], 'modern': {'text': ' '.join(notes), 'url': 'https://doi.org/10.15482/USDA.ADC/1239279' if any('Duke' in n for n in notes) else None}}


def rate(score, rows):
    if not rows:
        return 'NOT_ASSESSABLE'
    return 'STRONG' if score >= 5 else 'MODERATE' if score >= 3 else 'WEAK'


def about_this_plant(row, name):
    """Herbals wander: a conflict only counts when the sentence describes the plant in question."""
    if row['status'] != 'CONFLICT' or 'historical' not in row or not name:
        return True
    quoted = row['historical']['text']
    return bool(re.search(rf'\b{re.escape(name)}', quoted, re.I) or SUBJECT_OPENING.match(quoted))


def reading_order(row, prominence):
    """A grounded source name outranks priors; ambiguous readings keep the existing model."""
    points = lambda feature:sum(signal['points'] for signal in row['rows'] if signal['feature'] == feature)
    grounded = bool(row.get('source_name_grounded')) and points("author's own Latin name") > 0
    return (grounded, bool(row.get('source_specific_name')), row['score'] + math.log10(1 + (prominence or {}).get(row['taxon_id'], 0)), points('name recorded for this plant'))


def descriptive_subjects(text, candidates, taxmap, wording):
    """A qualified name can identify the subject of a descriptive sentence.

    A chapter may describe both basil and wild basil. A colour belonging to a
    candidate-specific name is not a colour conflict for every other candidate.
    Shared names remain ambiguous; this does not resolve a historical identity.
    """
    inspected = normalize(wording or '')
    if not inspected:
        return []
    aliases = {}
    for candidate in candidates:
        for alias in (taxmap.get(candidate['taxon_id']) or {}).get('aliases', []):
            name = normalize(alias['name'])
            if alias['kind'] in ('ACCEPTED_NAME', 'SYNONYM', 'INPUT_SYNONYM_MATCH', 'VERNACULAR', 'HISTORICAL_LEXICON') and len(name) > len(inspected):
                aliases.setdefault(name, set()).add(candidate['taxon_id'])
    patterns = [(compiled(name_pattern(name)), ids) for name, ids in aliases.items()]
    scoped = []
    for sentence in sentences(text):
        # Look at the grammatical subject, before its descriptive verb, rather
        # than a different plant introduced later in the sentence.
        subject = re.split(r'\b(?:is|are|was|were|has|have|grows?|bears?|flowers?|belongs?|furnishes?)\b', sentence['text'], maxsplit=1, flags=re.I)[0][:120]
        holders = set().union(*(ids for pattern, ids in patterns if pattern.search(subject)))
        if holders:
            scoped.append((sentence['start'], sentence['end'], holders))
    return scoped


def identity_matrix(text, candidates, taxmap, descriptions, *, region=None, prominence=None, name=None, topics=(), wording=None, english_name=False):
    """Score every candidate of one name against the source text it occurs in."""
    historical = scan(text)
    subjects = descriptive_subjects(text, candidates, taxmap, wording)
    rated = []
    # "The Wild English thyme (Thymus serpyllum) belongs to…": once the entry opens by naming its
    # plant, a Latin name further on ("the garden Thyme, Thymus vulgaris") is another plant.
    defined = any('NAMED_IN_SOURCE_FIRST_SENTENCE' in c.get('reasons', []) for c in candidates)
    for candidate in candidates:
        taxon = taxmap.get(candidate['taxon_id'])
        if not taxon:
            continue
        description = (descriptions or {}).get(candidate['taxon_id'])
        modern = scan(description['text']) if description else None
        excluded = [(start, end) for start, end, holders in subjects if candidate['taxon_id'] not in holders]
        if excluded:
            masked = list(text)
            for start, end in excluded:
                masked[start:end] = ['\n' if ch == '\n' else ' ' for ch in text[start:end]]
            historical = scan(''.join(masked))
        else:
            historical = scan(text)
        rows = []
        named = author_named(text, taxon)
        if named and defined and 'NAMED_IN_SOURCE_FIRST_SENTENCE' not in candidate.get('reasons', []):
            named = {**named, 'points': 0, 'modern': {**named['modern'], 'text': named['modern']['text'] + '. The entry opens by naming another plant; this Latin name occurs later, for a plant the author sets beside it.'}}
        if named:
            rows.append(named)
        specific = candidate.get('source_common_name')
        if specific:
            anchored = specific.get('anchor', True)
            rows.append({'feature':"author's specific common name",'status':'MATCH' if anchored else 'CONTEXT_ONLY','points':2 if anchored else 0,'values':[specific['lookup']],
                         'historical':{'text':specific['name'],'start':specific['start'],'end':specific['end']},
                         'modern':{'text':f"The opening botanical subject uses {specific['name']!r}; {specific['lookup']!r} matches this candidate in the existing name snapshot. " + ("This source-local naming clue does not establish historical identity." if anchored else "The common name spans genera and does not agree with this heading's existing candidates. Retained as an alternative without ranking priority or bonus.")}})
        if modern:
            rows += [row for row in (compare_set('flower colour', historical['flower_colour'], modern['flower_colour']), habit_conflict(historical['habit'], modern['habit']), compare_set('habitat', historical['habitat'], modern['habitat'], exclusive=False), compare_months(historical['flowering'], modern['flowering']), compare_set('smell', historical['odour'], modern['odour'], exclusive=False)) if row]
        rows = [row for row in rows if about_this_plant(row, name)]
        place = regional(taxon, region) if region else None
        # English is not a source location. Only an explicitly supplied region
        # (including a known collection's region) contributes distribution evidence.
        if place:
            rows.append(place)
        used = recorded_use(taxon, topics)
        if used:
            rows.append(used)
        called = recorded_name(taxon, wording)
        if called:
            rows.append(called)
        score = sum(row['points'] for row in rows)
        grounded = bool(named) and ('NAMED_IN_SOURCE_FIRST_SENTENCE' in candidate.get('reasons', []) or any(a['kind'] in ('ACCEPTED_NAME','SYNONYM','INPUT_SYNONYM_MATCH') and normalize(a['name']) == normalize(wording or '') for a in taxon['aliases']))
        rated.append({'taxon_id': candidate['taxon_id'], 'name': candidate['name'], 'score': score, 'rating': rate(score, rows), 'rows': rows, 'source_name_grounded':grounded, 'source_specific_name':bool(specific and specific.get('anchor', True)), 'description_source': {k: description[k] for k in ('url', 'licence', 'title')} if description else None, 'scale': 'Strong >=5, Moderate 3-4, Weak <=2. Ranks hypotheses for reading; not an identification.'})
    weigh_shared_wording(rated, taxmap)
    rated.sort(key=lambda r: reading_order(r, prominence), reverse=True)
    best = rated[0]['score'] if rated else None
    separated = len(rated) > 1 and best - max(r['score'] for r in rated[1:]) >= 2
    return {'candidates': rated, 'leading': rated[0]['taxon_id'] if rated and (separated or len(rated) == 1) and best > 0 else None, 'separation': 'CLEAR' if separated else 'NOT_SEPARATED', 'method': 'DESCRIPTION_MATRIX_ADAPTED_FROM_LARDOS_2023', 'reading_order':"An explicit scientific identification of the inspected name takes priority, followed by the opening subject's specific common-name clues. A relative or later co-mention is not a definition. Other candidates retain the feature-total and publication prior. Source-local clues do not add dictionary aliases or establish historical identity. English alone does not establish a region. Rankings are conditional, not identity probabilities."}

"""Source-scoped, portable research decisions. These never alter model output."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator
from src.common import now


class HandoffRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    question: str = Field(min_length=5, max_length=600)
    claim_id: str | None = Field(None, max_length=120)
    candidate_ids: list[str] = Field(default_factory=list, max_length=30)
    decision: Literal['NEXT_READING', 'INSUFFICIENT_INFORMATION', 'EXCLUDE_FROM_THIS_QUESTION']
    reason: str = Field(min_length=5, max_length=3000)
    next_step: str = Field(min_length=5, max_length=2000)
    reviewer: str = Field(default='Local researcher', min_length=1, max_length=80)

    @model_validator(mode='after')
    def substantive(self):
        for key in ('question', 'reason', 'next_step', 'reviewer'):
            if len(getattr(self, key).strip()) < (1 if key == 'reviewer' else 5):
                raise ValueError(f'{key} must contain substantive text')
        if len(set(self.candidate_ids)) != len(self.candidate_ids):
            raise ValueError('Duplicate candidate assumptions')
        return self


class HandoffPacket(BaseModel):
    model_config = ConfigDict(extra='forbid')
    schema_version: Literal['foliatrace-handoff-1'] = 'foliatrace-handoff-1'
    created_at: str
    analysis_id: str = Field(pattern=r'^[a-f0-9]{24}$')
    snapshot_sha256: str = Field(pattern=r'^[a-f0-9]{64}$')
    code_fingerprint: str
    source: dict
    source_input: str = Field(max_length=50000)
    statement: dict | None
    assessment: HandoffRequest
    candidates: list[dict]
    studies: list[dict]
    researcher_reviews: list[dict]
    coverage: dict
    limitations: list[str]

    @model_validator(mode='after')
    def integrity(self):
        for key in ('id', 'title', 'licence'):
            if not isinstance(self.source.get(key), str) or not self.source[key]:
                raise ValueError('Source metadata missing: '+key)
        if len(self.candidates) > 100 or len(self.studies) > 2000:
            raise ValueError('Handoff record count exceeds limit')
        if not all(isinstance(c.get('taxon_id'), str) and isinstance(c.get('name'), str) for c in self.candidates):
            raise ValueError('Invalid candidate metadata')
        if self.statement:
            span = self.statement['support']
            start, end = span['start'], span['end']
            if not isinstance(start, int) or not isinstance(end, int) or not 0 <= start < end <= len(self.source_input) or self.source_input[start:end] != span['text']:
                raise ValueError('Statement/source span mismatch')
            if self.statement['id'] != self.assessment.claim_id:
                raise ValueError('Statement selection mismatch')
        elif self.assessment.claim_id:
            raise ValueError('Selected statement missing')
        ids = {c['taxon_id'] for c in self.candidates}
        if ids != set(self.assessment.candidate_ids):
            raise ValueError('Candidate assumptions mismatch')
        for study in self.studies:
            from src.api.contracts import Relation
            Relation.model_validate(study['relation'])
            paper = study['paper']
            for key in ('id', 'title', 'url', 'licence'):
                if not isinstance(paper.get(key), str):
                    raise ValueError('Invalid study metadata: '+key)
            if study['relation'].get('supporting_text') and study['relation']['supporting_text'] not in (paper.get('abstract') or ''):
                raise ValueError('Study quote is not in the retained abstract')
            for check in study['comparability']['checks']:
                if not isinstance(check.get('check'), str) or check.get('status') not in ('PASS', 'FAIL', 'PARTIAL', 'UNKNOWN'):
                    raise ValueError('Invalid automated study check')
            if study['citation'].get('status') == 'REJECTED':
                raise ValueError('Rejected citation in handoff')
            if study['taxon_id'] not in ids:
                raise ValueError('Study outside selected candidate assumptions')
            if study['identity_qualifier'] != 'CONDITIONAL_ON_CANDIDATE_IDENTITY':
                raise ValueError('Missing conditional identity scope')
            for context in study.get('historical_contexts', []):
                span = context['support']
                if self.source_input[span['start']:span['end']] != span['text']:
                    raise ValueError('Study/source context mismatch')
                if self.statement and span != self.statement['support']:
                    raise ValueError('Study belongs to another source statement')
        return self


def build_handoff(result, request: HandoffRequest):
    claims = {c['id']: c for c in result['historical_claims']}
    if request.claim_id and request.claim_id not in claims:
        raise ValueError('Selected source statement is not part of this analysis')
    statement = claims.get(request.claim_id)
    groups = [g for g in result['identity_counterfactuals']
              if not statement or set(g['mention_ids']) & set(statement['mention_ids'])]
    candidates = {b['taxon_id']: {'taxon_id': b['taxon_id'], 'name': b['name']}
                  for g in groups for b in g['branches']}
    if not set(request.candidate_ids) <= candidates.keys():
        raise ValueError('Candidate does not belong to this source statement')
    selected = [candidates[c] for c in request.candidate_ids]
    studies = []
    for record in result['evidence']:
        if record['taxon_id'] not in request.candidate_ids:
            continue
        contexts = [c for c in record.get('historical_contexts', [])
                    if not statement or c['support'] == statement['support']]
        if statement and not contexts:
            continue
        # Keep the original machine checks distinct from the question-specific judgement.
        studies.append({**{k: record[k] for k in ('id', 'taxon_id', 'condition_id', 'identity_qualifier', 'paper', 'study', 'relation', 'comparability', 'citation')}, 'historical_contexts': contexts})
    targets = {s['id'] for s in studies}
    reviews = [r for r in result.get('researcher_reviews', [])
               if (r['target_kind'] == 'evidence' and r['target_id'] in targets)
               or (r['target_kind'] == 'identity' and any(r['target_id'] == g['key']+'::'+c for g in groups for c in request.candidate_ids))]
    packet = HandoffPacket(
        created_at=now(), analysis_id=result['run_id'], snapshot_sha256=result['snapshot_sha256'],
        code_fingerprint=result['code_fingerprint'], source=result['source'], source_input=result['input'],
        statement=statement, assessment=request, candidates=selected, studies=studies,
        researcher_reviews=reviews,
        coverage={'scope': 'SELECTED_SOURCE_STATEMENT' if statement else 'WHOLE_SOURCE_READING',
                  'studies_in_handoff': len(studies), 'publications': len({s['paper']['id'] for s in studies}),
                  'abstracts_available': sum(bool(s['paper'].get('abstract')) for s in studies),
                  'literature_access': result.get('literature_access', {}),
                  'candidate_selection': 'RESEARCHER_ASSUMPTIONS_NOT_IDENTIFICATIONS'},
        limitations=list(dict.fromkeys(result['limitations'] + [
            'This is a research reading decision, not a treatment recommendation or a systematic review.',
            'The recorded question does not change automated retrieval or establish that a study answers it.',
            'No retrieved study is not evidence of no effect. Missing abstracts and unselected candidates remain outside this handoff.',
            'Check publisher and source rights before sharing. User-provided source rights are unverified.',
        ])))
    return packet.model_dump()


def canonical(packet):
    return json.dumps(packet, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')


class HandoffStore:
    def __init__(self, path: Path):
        self.path = path
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS handoffs(id TEXT PRIMARY KEY, saved_at TEXT NOT NULL, origin TEXT NOT NULL, sha256 TEXT NOT NULL, payload TEXT NOT NULL)')

    def connect(self):
        from contextlib import contextmanager
        @contextmanager
        def opened():
            db = sqlite3.connect(self.path, timeout=20)
            try:
                with db:
                    yield db
            finally:
                db.close()
        return opened()

    def put(self, packet, origin='LOCAL_ANALYSIS'):
        packet = HandoffPacket.model_validate(packet).model_dump()
        identifier = uuid.uuid4().hex
        saved_at = now()
        sha = hashlib.sha256(canonical(packet)).hexdigest()
        with self.connect() as db:
            db.execute('INSERT INTO handoffs VALUES(?,?,?,?,?)', (identifier, saved_at, origin, sha, canonical(packet).decode('utf-8')))
        return self.get(identifier)

    def get(self, identifier):
        with self.connect() as db:
            row = db.execute('SELECT id,saved_at,origin,sha256,payload FROM handoffs WHERE id=?', (identifier,)).fetchone()
        if not row:
            return None
        return dict(zip(('id', 'saved_at', 'origin', 'sha256'), row[:4]), packet=json.loads(row[4]))

    def list(self):
        with self.connect() as db:
            rows = db.execute("SELECT id,saved_at,origin,json_extract(payload,'$.assessment.question'),json_extract(payload,'$.source.title') FROM handoffs ORDER BY saved_at DESC LIMIT 100").fetchall()
        return [dict(zip(('id', 'saved_at', 'origin', 'question', 'source_title'), r)) for r in rows]


def handoff_markdown(packet):
    a = packet['assessment']
    lines = ['# FoliaTrace evidence handoff', '', a['question'], '',
             'Research reading only; not diagnosis, treatment advice or a systematic review.', '',
             '## Researcher decision', a['decision'], a['reason'], 'Next step: '+a['next_step'],
             'Recorded by: '+a['reviewer'], '', '## Source',
             str(packet['source'].get('title')), str(packet['source'].get('url') or 'No source URL supplied'),
             'Rights: '+str(packet['source'].get('licence')), '']
    if packet['statement']:
        span = packet['statement']['support']
        lines += [span['text'], f"Source offsets: {span['start']}–{span['end']} (Unicode code points)"]
    else:
        lines += ['Whole-source reading; no extracted statement selected.', packet['source_input']]
    lines += ['', '## Candidate assumptions, not established identities']
    lines += [c['name']+' · '+c['taxon_id'] for c in packet['candidates']] or ['No candidate selected; no species conclusion.']
    lines += ['', '## Studies and automatic checks']
    if not packet['studies']:
        lines += ['No matching study included. This does not establish no effect.']
    for s in packet['studies']:
        p = s['paper']
        lines += ['', '### '+p['title'], p['url'], 'Rights: '+str(p.get('licence')), 'Candidate: '+s['taxon_id'],
                  'Conditional on candidate identity. Automated relation: '+s['relation']['relation'],
                  'Automated checks: '+json.dumps(s['comparability'], ensure_ascii=False),
                  'Source comparison: '+json.dumps(s['historical_contexts'], ensure_ascii=False)]
        if s['relation'].get('supporting_text'):
            lines += ['Abstract wording: '+s['relation']['supporting_text']]
        if not p.get('abstract'):
            lines += ['Abstract unavailable; inspect the original publication.']
    lines += ['', '## Prior researcher reviews', json.dumps(packet['researcher_reviews'], ensure_ascii=False, indent=2),
              '', '## Coverage and limits', json.dumps(packet['coverage'], ensure_ascii=False, indent=2)]
    lines += packet['limitations']
    lines += ['', 'Analysis: '+packet['analysis_id'], 'Snapshot: '+packet['snapshot_sha256'],
              'Code: '+packet['code_fingerprint'], 'Recorded: '+packet['created_at']]
    return '\n\n'.join(lines)+'\n'

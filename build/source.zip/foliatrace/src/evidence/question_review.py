"""Question-driven medicinal-plant evidence screening; never a treatment verdict."""
from __future__ import annotations

import copy
import hashlib
import json
import re
import sqlite3
import uuid
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator
from src.common import now
from src.nlp.extract import CONDITIONS, normalize
from src.evidence.comparability import check_identity, check_population, check_design, check_comparator, check_preparation, name_pattern, compiled
from src.evidence.context import scope_study_preparation
from src.evidence.digest import combination
from src.evidence.classify import classify_study
from src.evidence.question_search import search_plan, fetch_public_studies
from src.evidence.integrity import portable_numbers
from src.evidence.overview import product_candidate_order, question_overview, publication_text
from src.evidence.question_provenance import ground_checks, validate_checks


class ResearchQuestion(BaseModel):
    model_config = ConfigDict(extra='forbid')
    question: str = Field(min_length=10, max_length=800)
    plant_name: str = Field(min_length=2, max_length=120)
    condition_id: str | None = Field(default=None,max_length=80)
    retrieval_scope: Literal['question','topic'] = 'question'
    source_mode: Literal['local','public','pubmed'] = 'local'
    reference_pmids: list[str] = Field(default_factory=list,max_length=10)
    population: Literal['human', 'any'] = 'human'
    preparation: str = Field(default='', max_length=120)
    comparator: Literal['controlled', 'placebo', 'any'] = 'controlled'
    intervention: Literal['single_plant', 'any'] = 'single_plant'
    outcome_terms: list[str] = Field(min_length=1, max_length=8)
    source_text: str = Field(default='', max_length=10000)
    source_url: str = Field(default='', max_length=1000)
    candidate_ids: list[str] = Field(default_factory=list, max_length=12)
    ranking: Literal['auto', 'bm25'] = 'auto'

    @model_validator(mode='after')
    def valid(self):
        self.question = self.question.strip()
        self.plant_name = self.plant_name.strip()
        self.condition_id = self.condition_id.removeprefix('condition:') if self.condition_id else None
        if self.condition_id is not None and self.condition_id not in CONDITIONS:
            raise ValueError('Choose a supported health research topic')
        if self.retrieval_scope=='topic' and self.condition_id is None:
            raise ValueError('Choose a broad topic when narrowing retrieval by topic')
        self.reference_pmids=list(dict.fromkeys(self.reference_pmids))
        if any(not re.fullmatch(r'[1-9]\d{0,9}',p) for p in self.reference_pmids):
            raise ValueError('Known PubMed references must be numeric identifiers, at most ten')
        if self.source_mode=='local' and self.reference_pmids:
            raise ValueError('Choose public literature lookup to retrieve known PubMed references, or clear the reference IDs')
        if len(self.question) < 10 or len(self.plant_name) < 2:
            raise ValueError('A substantive research question and plant name are required')
        self.outcome_terms = list(dict.fromkeys(t.strip() for t in self.outcome_terms))
        if any(not 3 <= len(t) <= 100 for t in self.outcome_terms):
            raise ValueError('Each literal outcome phrase must contain 3–100 characters')
        if self.source_url and not self.source_url.startswith(('https://', 'http://')):
            raise ValueError('Source reference must be an http(s) URL; it is not fetched')
        if len(set(self.candidate_ids)) != len(self.candidate_ids):
            raise ValueError('Duplicate candidate assumptions')
        return self


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf-8')


def wording_spans(paper, terms):
    """Literal evidence only. Missing wording never becomes an efficacy verdict."""
    found = []
    for field in ('title', 'abstract'):
        text = paper.get(field) or ''
        for term in terms:
            for match in re.finditer(r'(?<!\w)'+re.escape(term)+r'(?!\w)', text, re.I):
                found.append({'source_kind': 'PUBLICATION_'+field.upper(), 'text': match.group(),
                              'start': match.start(), 'end': match.end(), 'url': paper['url']})
    return found


def source_reading(paper, taxon, study, taxon_match, known_names, same_genus_names=None):
    checks = [check_identity(paper, taxon, taxon_match)]
    if checks[0]['status']=='FAIL':
        own={normalize(taxon['name']),*(normalize(a['name']) for a in taxon['aliases'])}
        genus=normalize(taxon['name'].split()[0])+' '
        possible=same_genus_names if same_genus_names is not None else [n for n in known_names if n.startswith(genus)]
        other_title_names=[n for n in possible if n not in own and compiled(name_pattern(n)).search(paper['title'])]
        if other_title_names and not set(study['types']) & {'REVIEW','SYSTEMATIC_REVIEW','META_ANALYSIS'}:
            match=compiled(name_pattern(sorted(other_title_names)[0])).search(paper['title'])
            checks[0]={**checks[0],'detail':'The title explicitly names another species in this genus, not the requested candidate: '+', '.join(sorted(other_title_names))+'. Check Methods and synonym interpretation before attributing it to this branch.',
                'spans':[{'source_kind':'PUBLICATION_TITLE','start':match.start(),'end':match.end(),'text':match.group(),'url':paper['url']}]}
            return checks,copy.deepcopy(study),True
        else:
            # A missing binomial is uncertainty; a different explicit intervention name is a conflict.
            checks[0]={**checks[0],'status':'UNKNOWN',
                       'detail':'The available source does not establish this candidate’s scientific identity. A common or genus name needs Methods verification; this alone is not a scope exclusion.'}
    study = scope_study_preparation(paper, taxon, copy.deepcopy(study))
    return checks,study,False


def screen_question(protocol, paper, taxon, study, taxon_match, known_names, same_genus_names=None,prepared=None):
    checks,study,conflict=copy.deepcopy(prepared if prepared is not None else source_reading(paper,taxon,study,taxon_match,known_names,same_genus_names))
    if conflict:
        return {'state':'OUTSIDE_REQUESTED_SCOPE','checks':checks,'scope_conflicts':['identity'],
                'note':'Other comparability checks were not applied after this explicit identity conflict. No efficacy conclusion follows.'},study
    if protocol.population == 'human':
        checks += [check_population(study), check_design(study)]
    if protocol.preparation:
        prep = check_preparation([{'text': protocol.preparation}], study)
        prep['detail'] = prep['detail'].replace('Historical:', 'Question:').replace('historical ', 'requested ')
        checks.append(prep)
    if protocol.comparator != 'any':
        comp = check_comparator(study, paper)
        if not set(study['types']) & {'REVIEW','SYSTEMATIC_REVIEW','META_ANALYSIS'}:
            pattern=r'\b(?:single[- ]arm|(?:uncontrolled|non[- ]controlled)\s+(?:(?:open[- ]label|pilot|clinical|prospective)\s+)*(?:trial|study|design)|without\s+(?:a\s+)?(?:control\s+(?:group|arm)|comparator(?:\s+(?:group|arm))?))\b'
            match=re.search(pattern,paper['title'],re.I)
            field='title'
            if not match:
                methods=re.search(r'\b(?:methods?|study design)\s*:\s*(.*?)(?=\b(?:results?|conclusions?)\s*:|$)',paper.get('abstract') or '',re.I|re.S)
                if methods:
                    found=re.search(pattern,methods[1],re.I)
                    if found:
                        start=methods.start(1)+found.start();end=methods.start(1)+found.end();field='abstract'
                        match=(start,end)
            if match:
                start,end=match if isinstance(match,tuple) else match.span()
                comp={'check':'comparator','status':'FAIL','detail':'The title or explicit Methods describes an uncontrolled/single-arm study. It does not meet this question’s required comparator.',
                      'spans':[{'source_kind':'PUBLICATION_'+field.upper(),'start':start,'end':end,'text':paper[field][start:end],'url':paper['url']}]}
        if protocol.comparator == 'placebo' and comp['status'] != 'FAIL':
            spans = wording_spans(paper, ['placebo'])
            comp = {'check': 'comparator', 'status': 'PARTIAL' if spans else 'UNKNOWN',
                    'detail': 'Placebo wording found; allocation and actual comparison still need reading.' if spans else 'A placebo comparison is not established from available text.',
                    'spans': spans}
        checks.append(comp)
    if protocol.intervention == 'single_plant':
        names = {normalize(taxon['name'])} | {normalize(a['name']) for a in taxon.get('aliases', [])}
        mixed = combination({'paper': paper, 'study': study}, names, known_names)
        checks.append({'check': 'single_plant', 'status': 'FAIL' if mixed else 'PARTIAL',
                       'detail': 'Combination or other-plant signal: cannot attribute the intervention to this plant alone.' if mixed else 'No combination signal was found; ingredient isolation and study arms still require Methods reading.'})
    spans = wording_spans(paper, protocol.outcome_terms)
    checks.append({'check': 'requested_outcome', 'status': 'PARTIAL' if spans else 'UNKNOWN',
                   'detail': 'Requested literal outcome wording occurs; endpoint definition and result attribution require reading.' if spans else 'None of your exact outcome phrases was found. Synonyms or full text may still be relevant.',
                   'spans': spans})
    if not paper.get('abstract'):
        checks.append({'check': 'abstract_access', 'status': 'UNKNOWN', 'detail': 'Bibliographic metadata only; no abstract available locally.'})
    failed = [c['check'] for c in checks if c['status'] == 'FAIL']
    state = 'OUTSIDE_REQUESTED_SCOPE' if failed else 'NEEDS_FULL_TEXT' if any(c['status'] == 'UNKNOWN' for c in checks) else 'PRIORITY_FOR_READING'
    return {'state': state, 'checks': checks, 'scope_conflicts': failed,
            'note': 'Reading priority is not eligibility confirmation, a risk-of-bias judgement or evidence of clinical benefit.'}, study


def run_question(pipeline, protocol: ResearchQuestion):
    resolution = pipeline.resolver.resolve(protocol.plant_name)
    all_candidates = product_candidate_order(resolution['candidates'], protocol.plant_name)
    known = {c['taxon_id'] for c in all_candidates}
    if not set(protocol.candidate_ids) <= known:
        raise ValueError('Selected species is not a candidate for this plant wording')
    candidates = [c for c in all_candidates if not protocol.candidate_ids or c['taxon_id'] in protocol.candidate_ids]
    if len(candidates) > 12:
        raise ValueError('This name has more than 12 candidates; use a more specific source name')
    withdrawn = pipeline.withdrawn()
    candidates = [c for c in candidates if c['taxon_id'] not in withdrawn]
    condition = 'condition:'+protocol.condition_id if protocol.condition_id else None
    index=pipeline.index;external=None;added_ids=set()
    if protocol.source_mode!='local':
        from src.ingestion.client import ScientificClient
        from src.retrieval.index import LiteratureIndex
        # Separate counters, shared durable cache. The original snapshot/index is not mutated.
        client=ScientificClient(cache=pipeline.client.cache,offline=pipeline.client.offline)
        acquired,external=fetch_public_studies(client,search_plan([pipeline.taxmap[c['taxon_id']] for c in candidates],protocol.outcome_terms,pipeline.index,protocol.reference_pmids))
        by_id={p['id']:p for p in pipeline.papers}
        added_ids={p['id'] for p in acquired if p['id'] not in by_id}
        by_id.update({p['id']:p for p in acquired})
        if acquired:
            index=LiteratureIndex(list(by_id.values()),pipeline.taxa,encoder=pipeline.index.encoder)
            index.reranker=pipeline.index.reranker
    query = ' '.join([protocol.question, protocol.preparation, *protocol.outcome_terms,
                      'human clinical trial' if protocol.population == 'human' else '',
                      protocol.comparator if protocol.comparator != 'any' else ''])
    # The protocol now changes the retrieval query and every record's screening.
    scores = index.bm25(query)
    known_names = {normalize(t['name']) for t in pipeline.taxa}
    knowledge_key=hashlib.sha256(canonical(sorted(known_names))).hexdigest()
    source_cache=getattr(pipeline,'question_source_cache',None)
    if source_cache is None:
        source_cache={};pipeline.question_source_cache=source_cache
    branches = []
    for candidate in candidates:
        taxon = pipeline.taxmap[candidate['taxon_id']]
        taxon_key=hashlib.sha256(canonical({k:taxon.get(k) for k in ('id','name','aliases','drug_names')})).hexdigest()
        same_genus_names=[n for n in known_names if n.startswith(normalize(taxon['name'].split()[0])+' ')]
        if protocol.retrieval_scope=='topic':
            hits=index.matching(taxon,condition,scores=scores,method='QUESTION_BM25',genus=True)
        else:
            # The endpoint question is no longer silently gated by historical topic vocabulary.
            named=dict(index.documents_naming(taxon))
            for i,_ in index.postings.get(normalize(taxon['name'].split()[0]),[]):
                named.setdefault(i,'COMMON_NAME_ONLY_IDENTITY_UNCERTAIN')
            hits=[{'paper':index.papers[i],'retrieval_score':float(scores[i]),'taxon_match':identity}
                  for i,identity in named.items()]
        if len(hits)>2000:raise ValueError('This name has more than 2000 records; narrow by a broad topic or use a more specific identity')
        rows_by_id = {r['paper']['id']: r for r in pipeline.topic_studies(taxon['id'], condition)} if condition else {}
        records = []
        for hit in hits:
            paper = hit['paper']
            if paper['id'] in withdrawn or paper.get('retracted'):
                continue
            original = rows_by_id.get(paper['id'])
            if original and not paper.get('question_acquisition'):
                design=original['study']
            elif not paper.get('question_acquisition'):
                design=pipeline.study_designs.get(paper['id'])
                if design is None:
                    design=classify_study(paper,pipeline.study_model);pipeline.study_designs[paper['id']]=design
            else:
                design=classify_study(paper,pipeline.study_model)
            paper_key=hashlib.sha256(canonical({k:paper.get(k) for k in ('id','title','abstract','publication_types','methods_contexts','url','licence')})).hexdigest()
            cache_key=(knowledge_key,taxon_key,paper_key,hit['taxon_match'],getattr(pipeline,'model_fingerprint',''))
            prepared=source_cache.get(cache_key)
            if prepared is None:
                prepared=source_reading(paper,taxon,design,hit['taxon_match'],known_names,same_genus_names)
                if len(source_cache)>=2048:source_cache.clear()
                source_cache[cache_key]=prepared
            screening, study = screen_question(protocol, paper, taxon, design, hit['taxon_match'], known_names,same_genus_names,prepared)
            ground_checks(paper, screening)
            records.append({'id': hashlib.sha256((taxon['id']+'|'+paper['id']).encode()).hexdigest()[:24],
                            'taxon_id': taxon['id'], 'paper': paper, 'study': study,
                            'screening': screening, 'topic_finding': original['relation'] if original else None,
                            'source_origin':'PUBLIC_QUESTION_ACQUISITION' if paper.get('question_acquisition') else 'LOCAL_SNAPSHOT',
                            'finding_scope': 'ORIGINAL_BROAD_TOPIC_READING_NOT_A_VERDICT_ON_THE_REQUESTED_ENDPOINT',
                            'retrieval_score': hit['retrieval_score'], 'ranking_method': 'QUESTION_BM25'})
        records.sort(key=lambda r: -r['retrieval_score'])
        reranked = 0
        if protocol.ranking == 'auto' and index.reranker.available and records:
            eligible=[r for r in records if r['screening']['state']!='OUTSIDE_REQUESTED_SCOPE']
            eligible.sort(key=lambda r:0 if any(c['check']=='requested_outcome' and c.get('spans') for c in r['screening']['checks']) else 1)
            subset = eligible[:12]
            ranked = index.reranker.score(query, [r['paper']['title']+' '+(r['paper'].get('abstract') or '') for r in subset]) if subset else []
            for row, score in zip(subset, ranked):
                row['retrieval_score'] = float(score)
                row['ranking_method'] = 'LOCAL_CROSS_ENCODER_WITH_RESEARCH_QUESTION'
            subset.sort(key=lambda r: -r['retrieval_score'])
            selected={r['id'] for r in subset}
            records = subset+[r for r in records if r['id'] not in selected]
            reranked = len(subset)
        order = {'PRIORITY_FOR_READING': 0, 'NEEDS_FULL_TEXT': 1, 'OUTSIDE_REQUESTED_SCOPE': 2}
        # Stable partition retains actual question-sensitive ranking within queues.
        records.sort(key=lambda r: (order[r['screening']['state']],
            0 if any(c['check']=='requested_outcome' and c.get('spans') for c in r['screening']['checks']) else 1))
        for position, row in enumerate(records, 1):
            row['reading_position'] = position
        branches.append({'taxon_id': taxon['id'], 'name': taxon['name'], 'identity_reasons': candidate['reasons'],
                         'records': records, 'reranked_records': reranked,
                         'counts': {state: sum(r['screening']['state'] == state for r in records) for state in order}})
    packet = {'schema': 'foliatrace-question-review-1', 'created_at': now(),
              'protocol': protocol.model_dump(), 'query_used': query,
              'source_reference': {'text': protocol.source_text, 'url': protocol.source_url,
                                   'rights': 'USER_RIGHTS_UNVERIFIED', 'fetched': False},
              'resolution_status': resolution['status'], 'candidate_count_before_selection': len(all_candidates),
              'branches': branches, 'code_fingerprint': pipeline.code_fingerprint,
              'snapshot_sha256': pipeline.snapshot,
              'quote_integrity': 'CHECKED_QUOTE_LOCATIONS_V1',
              'coverage': {'search_scope': 'LOCAL_SNAPSHOT_PLUS_BOUNDED_PUBLIC_SEARCH_NOT_SYSTEMATIC' if external else 'CURRENT_LOCAL_SNAPSHOT_NOT_EXHAUSTIVE_SYSTEMATIC_SEARCH',
                           'papers_in_snapshot': len(pipeline.papers),
                           'papers_searched':len(index.papers),'new_publication_ids':sorted(added_ids),
                           'retrieval_scope':protocol.retrieval_scope,
                           'rerank_limit_per_candidate':12,
                           'abstracts_available': sum(bool(p.get('abstract')) for p in index.papers),
                           'network_used': bool(external and external['network_used']),
                           **({'public_search':external} if external else {}),
                           'model': 'LOCAL_CROSS_ENCODER' if any(b['reranked_records'] for b in branches) else 'BM25_NO_MODEL_USED',
                           'all_matching_records_retained': True},
              'limitations': ['No treatment recommendation or automatic clinical efficacy verdict.',
                              'Literal endpoint wording is not semantic equivalence; missing wording is not evidence of no effect.',
                              'Species names do not establish the identity of a historical specimen or a product.',
                              'Population, preparation, ingredient isolation, endpoints and comparator allocation require source reading.',
                              'All matching local records, including scope conflicts, remain in the export. This is not an exhaustive systematic review.',
                              'Source and publisher rights apply to all exports, including privately cached abstracts.']}
    packet['overview'] = question_overview(branches, protocol, pipeline.trial_readings, withdrawn)
    packet['numeric_json_schema']='SAFE_NUMBERS_V1'
    packet=portable_numbers(packet)
    validate_packet(packet)
    return packet


def validate_packet(packet):
    if not isinstance(packet, dict):
        raise ValueError('Research review must be an object')
    if packet.get('schema') != 'foliatrace-question-review-1':
        raise ValueError('Unsupported research review schema')
    ResearchQuestion.model_validate(packet['protocol'])
    if not isinstance(packet['branches'], list) or len(packet['branches']) > 12:
        raise ValueError('Too many candidate branches')
    seen = set()
    for branch in packet['branches']:
        if not isinstance(branch['name'], str) or branch['taxon_id'] in seen:
            raise ValueError('Invalid or duplicate species branch')
        seen.add(branch['taxon_id'])
        if len(branch['records']) > 2000:
            raise ValueError('Too many study records')
        for row in branch['records']:
            if not isinstance(row['study'], dict) or not isinstance(row['screening'], dict):
                raise ValueError('Invalid study or screening record')
            if row['screening']['state'] not in ('OUTSIDE_REQUESTED_SCOPE','NEEDS_FULL_TEXT','PRIORITY_FOR_READING'):
                raise ValueError('Invalid reading queue')
            for key in ('id','title','url','licence'):
                if not isinstance(row['paper'][key], str):
                    raise ValueError('Invalid publication metadata')
            if row['taxon_id'] != branch['taxon_id']:
                raise ValueError('A study crossed its candidate identity branch')
            validate_checks(row['paper'], row['screening'])
    return packet


class ReadingDecision(BaseModel):
    model_config = ConfigDict(extra='forbid')
    record_id: str = Field(pattern=r'^[a-f0-9]{24}$')
    decision: Literal['KEEP_FOR_READING', 'EXCLUDE_FROM_QUESTION', 'NEEDS_FULL_TEXT']
    reason: str = Field(min_length=5, max_length=2000)
    reviewer: str = Field(default='Local researcher', min_length=1, max_length=80)

    @model_validator(mode='after')
    def substantive(self):
        if len(self.reason.strip())<5 or not self.reviewer.strip():
            raise ValueError('A substantive reason and recorder name are required')
        return self


class QuestionStore:
    def __init__(self, path: Path):
        self.path = path
        with self.connect() as db:
            db.executescript('CREATE TABLE IF NOT EXISTS health_reviews(id TEXT PRIMARY KEY, saved_at TEXT NOT NULL, origin TEXT NOT NULL, payload TEXT NOT NULL); CREATE TABLE IF NOT EXISTS health_review_decisions(seq INTEGER PRIMARY KEY AUTOINCREMENT, review_id TEXT NOT NULL, payload TEXT NOT NULL);')

    def connect(self):
        from contextlib import contextmanager
        @contextmanager
        def opened():
            db = sqlite3.connect(self.path, timeout=20)
            try:
                with db:
                    yield db
            finally:
                db.close()
        return opened()

    def put(self, packet, origin='LOCAL_QUESTION_REVIEW', decisions=()):
        validate_packet(packet)
        if len(canonical({'packet':packet,'decision_history':decisions}))>19_000_000:
            raise ValueError('Review is too large for portable export; narrow the candidate selection')
        identifier = uuid.uuid4().hex
        record_ids = {r['id'] for b in packet['branches'] for r in b['records']}
        for value in decisions:
            parsed = ReadingDecision.model_validate({k:v for k,v in value.items() if k != 'created_at'})
            if parsed.record_id not in record_ids:
                raise ValueError('Decision belongs to a different research review')
        with self.connect() as db:
            db.execute('INSERT INTO health_reviews VALUES(?,?,?,?)', (identifier, now(), origin, canonical(packet).decode()))
            for decision in decisions:
                db.execute('INSERT INTO health_review_decisions(review_id,payload) VALUES(?,?)', (identifier, canonical(decision).decode()))
        return self.get(identifier)

    def get(self, identifier):
        with self.connect() as db:
            row = db.execute('SELECT id,saved_at,origin,payload FROM health_reviews WHERE id=?', (identifier,)).fetchone()
            decisions = [json.loads(v[0]) for v in db.execute('SELECT payload FROM health_review_decisions WHERE review_id=? ORDER BY seq', (identifier,)).fetchall()]
        if row is None:
            return None
        payload = {'packet': json.loads(row[3]), 'decision_history': decisions}
        return {'id': row[0], 'saved_at': row[1], 'origin': row[2], **payload,
                'sha256': hashlib.sha256(canonical(payload)).hexdigest(),
                'first_result_sha256': hashlib.sha256(canonical(payload['packet'])).hexdigest()}

    def list(self):
        with self.connect() as db:
            return [dict(zip(('id','saved_at','origin','question','plant_name'), row)) for row in db.execute("SELECT id,saved_at,origin,json_extract(payload,'$.protocol.question'),json_extract(payload,'$.protocol.plant_name') FROM health_reviews ORDER BY saved_at DESC LIMIT 100")]

    def decide(self, identifier, decision):
        record = self.get(identifier)
        if not record:
            raise ValueError('Research review not found')
        if record['origin'] != 'LOCAL_QUESTION_REVIEW':
            raise ValueError('Imported reviews are read-only; run the question locally to make a current decision')
        if decision.record_id not in {r['id'] for b in record['packet']['branches'] for r in b['records']}:
            raise ValueError('Decision target is outside this question')
        with self.connect() as db:
            db.execute('INSERT INTO health_review_decisions(review_id,payload) VALUES(?,?)', (identifier, canonical({**decision.model_dump(), 'created_at': now()}).decode()))
        return self.get(identifier)


def review_markdown(record):
    p = record['packet'];q = p['protocol']
    lines = ['# FoliaTrace health research review', q['question'],
             'Origin: '+record['origin'], 'Research screening only; not a treatment verdict.',
             '## Protocol fixed before retrieval', json.dumps(q, ensure_ascii=False, indent=2),
             'Actual retrieval query: '+p['query_used'], '## Source reference',
             p['source_reference']['text'], p['source_reference']['url'], 'Rights: USER_RIGHTS_UNVERIFIED']
    overview = p.get('overview') or question_overview(p['branches'], ResearchQuestion.model_validate(q))
    lines += ['## Search overview', f"{overview['unique_publications']} unique publications; {overview['endpoint_publications']} with requested wording and no detected scope conflict; {overview['human_trial_signals']} with human-trial signals.",
              'Study signals are reading leads; eligibility and product applicability require professional review.']
    if overview.get('findings_summary'):
        lines += [overview['findings_summary']]
    for reading in overview['selected_readings']:
        lines += ['### Selected trial findings', reading['selection'], reading['takeaway'], reading['annotation']['method']]
        for note in reading['studies']:
            lines += [note['label'], note['publication']['url'], note['primary_outcome'], note['primary_result'], note['other_results']]
    current = {d['record_id']:d for d in record['decision_history']}
    for branch in p['branches']:
        lines += ['## Candidate assumption: '+branch['name'], branch['taxon_id']]
        for row in branch['records']:
            paper = row['paper'];decision = current.get(row['id'])
            lines += ['### '+publication_text(paper['title']), paper['url'], 'Rights: '+paper['licence'],
                      row['screening']['state'], json.dumps(row['screening'], ensure_ascii=False, indent=2)]
            if decision:
                lines += ['Researcher decision: '+decision['decision'], decision['reason']]
    lines += ['## Coverage', json.dumps(p['coverage'], ensure_ascii=False, indent=2), *p['limitations'],
              'First result SHA256: '+record['first_result_sha256'], '## Decision history', json.dumps(record['decision_history'], ensure_ascii=False, indent=2)]
    return '\n\n'.join(lines)+'\n'

"""Per-record comparability checks between a historical use and a modern abstract.

Each check answers one question a reviewer would ask before letting a paper bear on
"does a specified preparation of taxon X help condition Y in humans?". Checks keep
their own source spans. They explain the conservative relation; they never upgrade it.
"""
from __future__ import annotations

import re
from functools import lru_cache

from src.nlp.extract import research_terms, normalize

PASS, FAIL, PARTIAL, UNKNOWN = "PASS", "FAIL", "PARTIAL", "UNKNOWN"
HUMAN_DESIGNS = {"CLINICAL_TRIAL", "OBSERVATIONAL_HUMAN", "SYSTEMATIC_REVIEW", "META_ANALYSIS"}
PRECLINICAL = {"IN_VITRO", "IN_VIVO_ANIMAL"}
# Coarse preparation families. Matching families is a prompt for review, not equivalence.
PREPARATION_FAMILIES = {
    "aqueous": ["infusion", "tea", "decoction", "boiled", "aqueous", "distilled water", "syrup", "hydrolate", "hydrosol"],
    "oil": ["oil", "essential oil", "ointment"],
    "extract": ["extract", "ethanolic", "tincture", "standardized", "standardised"],
    "solid": ["powder", "capsule", "capsules", "tablet", "tablets", "dried"],
    "fresh": ["juice", "bruised", "fresh"],
}


def family(text):
    value = normalize(text)
    return next((name for name, words in PREPARATION_FAMILIES.items() if any(re.search(r"\b" + re.escape(w) + r"s?\b", value) for w in words)), None)


@lru_cache(maxsize=30_000)
def compiled(pattern):
    # Plant names produce thousands of patterns; re's own small cache would recompile them.
    return re.compile(pattern, re.I)


def span_in(abstract, pattern):
    match = compiled(pattern).search(abstract)
    return {"text": match.group(), "start": match.start(), "end": match.end()} if match else None


def name_pattern(name):
    # A stored scientific alias using the botanical hybrid marker x also matches ×.
    tokens = name.split()
    pattern = ''
    for index, token in enumerate(tokens):
        if index:
            pattern += r'\s*' if token.casefold() == 'x' or tokens[index - 1].casefold() == 'x' else r'\s+'
        pattern += '[x×]' if token.casefold() == 'x' else re.escape(token)
    return r'(?<!\w)' + pattern + r'(?!\w)'


def methods_span(context, pattern):
    span = span_in(context['text'], pattern)
    return {**span, 'source_kind': context.get('source_kind', 'FULL_TEXT_METHODS'), 'source_id': context['id'],
            'url': context['url'], 'licence': context['licence']} if span else None


def check_identity(paper, taxon, taxon_match):
    names = [taxon["name"]] + [a["name"] for a in taxon["aliases"] if a["kind"] in ("SYNONYM", "INPUT_SYNONYM_MATCH")]
    for name in names:
        found = span_in(paper["abstract"], name_pattern(name))
        if found:
            return {"check": "identity", "status": PASS, "detail": "Abstract names the candidate's scientific name", "span": found}
        found = span_in(paper['title'], name_pattern(name))
        if found:
            return {'check': 'identity', 'status': PASS, 'detail': "Title names the candidate's scientific name", 'span': {**found, 'source_kind': 'PUBLICATION_TITLE'}}
    for context in paper.get('methods_contexts', []):
        for name in names:
            found = methods_span(context, name_pattern(name))
            if found:
                return {'check': 'identity', 'status': PASS,
                        'detail': 'A licensed Methods excerpt names this candidate or a stored scientific synonym. This identifies study wording, not the historical plant.', 'span': found}
    return {"check": "identity", "status": FAIL, "detail": "Only a common name matches; the experimental species is not established for this branch", "span": None}


def check_population(study):
    status = study.get("population_status")
    if status == "HUMAN_TEXT_SIGNAL":
        population = (study.get('pico_source_spans') or {}).get('population')
        if population and population.get('reading_scope'):
            return {'check': 'population', 'status': PASS, 'detail': population['reading_scope'], 'span': population}
        return {"check": "population", "status": PASS, "detail": "Human participants mentioned", "span": (study.get("pico_source_spans") or {}).get("population")}
    if status == "ANIMAL_TEXT_SIGNAL":
        return {"check": "population", "status": FAIL, "detail": "Animal model only", "span": (study.get("pico_source_spans") or {}).get("population")}
    return {"check": "population", "status": UNKNOWN, "detail": "Population not stated in the abstract", "span": None}


def check_design(study):
    types = set(study["types"])
    if "STUDY_PROTOCOL" in types:
        return {"check": "design", "status": FAIL, "detail": "Protocol: no results yet"}
    if types & HUMAN_DESIGNS:
        return {"check": "design", "status": PASS, "detail": ", ".join(sorted(types & HUMAN_DESIGNS)).replace("_", " ").lower()}
    if types & PRECLINICAL:
        return {"check": "design", "status": FAIL, "detail": "Preclinical (" + ", ".join(sorted(types & PRECLINICAL)).replace("_", " ").lower() + ")"}
    if "REVIEW" in types:
        return {"check": "design", "status": PARTIAL, "detail": "Narrative review: secondary, not a systematic synthesis"}
    return {"check": "design", "status": UNKNOWN, "detail": "Study design not established"}


def check_comparator(study, paper=None):
    for context in (paper or {}).get('methods_contexts', []):
        found = methods_span(context, r'\buncontrolled\b|\bsingle[- ]arm\b|\bwithout\s+(?:a\s+)?(?:control|comparator)\b')
        if found:
            return {'check': 'comparator', 'status': FAIL,
                    'detail': 'Methods explicitly describe an uncontrolled or single-arm design. The observed change cannot isolate a treatment effect from time, co-interventions or placebo effects.', 'span': found}
    for context in (paper or {}).get('methods_contexts', []):
        value = context['text']
        if re.search(r'\b(?:face[- ]split|split[- ]face) design\b', value, re.I) and re.search(r'\bleft side\b', value, re.I) and re.search(r'\bright side\b', value, re.I):
            found = methods_span(context, r'\bEach participant applied [^.]+\.')
            if found:
                allocation = 'Fixed left/right allocation is explicitly stated; randomized allocation is not established.' if re.search(r'\bfixed\b', value, re.I) else 'Allocation and blinding require source review.'
                return {'check': 'comparator', 'status': PARTIAL,
                        'detail': 'Methods describe a within-person comparison of formulations applied to opposite sides of the face. ' + allocation + ' Formulation and ingredient attribution remain separate questions.', 'span': found}
    comparator = (study.get('pico_source_spans') or {}).get('comparator')
    if not comparator:
        return {'check': 'comparator', 'status': UNKNOWN,
                'detail': 'A comparator is not established from the abstract. Improvement over time alone does not establish a treatment effect.', 'span': None}
    return {'check': 'comparator', 'status': PARTIAL,
            'detail': f"Comparator wording '{comparator['text']}' occurs in the abstract. Its role, allocation, blinding and adequacy have not been appraised.", 'span': comparator}


def check_outcome(relation, condition_id):
    terms = research_terms(condition_id)
    finding = relation.get("reported_finding") or {}
    if finding.get("direction") not in (None, "NO_RESULT_STATEMENT"):
        return {"check": "outcome", "status": PASS, "detail": "A result sentence mentions the condition", "span": {"text": finding["supporting_text"]}}
    if relation.get("supporting_text"):
        return {"check": "outcome", "status": PARTIAL, "detail": "Condition mentioned, but not in a result statement", "span": {"text": relation["supporting_text"]}}
    return {"check": "outcome", "status": FAIL, "detail": "Condition not mentioned in the abstract" if terms else "No outcome terms for this condition"}


def check_preparation(historical, study):
    modern = (study.get("pico_source_spans") or {}).get("intervention_preparation")
    old = [p["text"] for p in historical]
    attribution = study.get('preparation_attribution') or {}
    if attribution.get('status') == 'COMMON_NAME_ONLY_PREPARATION_WORDING':
        return {'check': 'preparation', 'status': UNKNOWN, 'detail': f"The abstract mentions '{modern['text']}' near a common plant name. The study species is not established for this candidate; this is not a verified preparation match.", 'span': modern, 'requires_statement_review': True}
    if attribution.get('status') in ('CANDIDATE_PREPARATION_UNRESOLVED', 'MULTIPLE_CANDIDATE_FORMS'):
        detail = 'Several candidate-linked forms occur in the abstract; no single intervention is assigned.' if attribution['status'] == 'MULTIPLE_CANDIDATE_FORMS' else 'Preparation wording is not locally linked to this candidate species; the first preparation in the abstract is not assigned to it.'
        return {'check': 'preparation', 'status': UNKNOWN, 'detail': detail, 'span': None, 'requires_statement_review': True}
    if not old and not modern:
        return {"check": "preparation", "status": UNKNOWN, "detail": "Neither source states a preparation"}
    if not old:
        return {"check": "preparation", "status": UNKNOWN, "detail": f"This historical statement does not state a preparation; candidate-linked abstract wording is '{modern['text']}'", "span": modern}
    if not modern:
        return {"check": "preparation", "status": UNKNOWN, "detail": f"Historical: {', '.join(sorted(set(old)))}; study preparation not established", "span": None}
    old_families = {family(x) for x in old} - {None}
    new_family = family(modern["text"])
    if new_family and new_family in old_families:
        return {"check": "preparation", "status": PARTIAL, "detail": f"Same broad form ({new_family}): historical {', '.join(sorted(set(old)))} vs study '{modern['text']}'. Preparation process, dose and solvent are not established as equivalent.", "span": modern}
    if not old_families or not new_family:
        return {'check': 'preparation', 'status': UNKNOWN, 'detail': f"Historical {', '.join(sorted(set(old)))} vs study '{modern['text']}': one or both preparation forms are not classified.", 'span': modern}
    return {"check": "preparation", "status": FAIL, "detail": f"Different forms: historical {', '.join(sorted(set(old)))} vs study '{modern['text']}'", "span": modern}


def comparability(paper, taxon, condition_id, study, relation, taxon_match, historical_preparations, *, preparation_check=None):
    checks = [check_identity(paper, taxon, taxon_match), check_population(study), check_design(study), check_comparator(study, paper), check_outcome(relation, condition_id), preparation_check if preparation_check is not None else check_preparation(historical_preparations, study)]
    return summarize(checks)


def summarize(checks):
    blocking = next((c["check"] for c in checks if c["status"] == FAIL), None) or next((c["check"] for c in checks if c["status"] == UNKNOWN and (c["check"] != "preparation" or c.get('requires_statement_review'))), None)
    unresolved = [c["check"] for c in checks if c["status"] in (PARTIAL, UNKNOWN)]
    screening = "BLOCKED" if blocking else "NO_FAILURE_SOME_UNRESOLVED" if unresolved else "ALL_PASSED"
    return {"checks": checks, "first_blocking_check": blocking, "unresolved_checks": unresolved, "screening": screening, "passed": sum(c["status"] == PASS for c in checks), "total": len(checks), "note": "Automated screening. A PASS on every check would still need human review of dose, comparator and outcome definition."}


def gate_relation(relation, screen):
    """A failed or unknown check withholds a directional relation; checks never upgrade one."""
    blocking = screen["first_blocking_check"]
    if not blocking or relation["relation"] not in ("SUPPORTS", "CONTRADICTS", "MIXED"):
        return relation
    detail = next((c["detail"] for c in screen["checks"] if c["check"] == blocking), "")
    return {**relation, "relation": "INSUFFICIENT", "pre_comparability_relation": relation["relation"], "directness": "COMPARABILITY_BLOCKED", "rationale": f"The abstract-level relation was {relation['relation']}, but the {blocking} check does not pass ({detail}). It cannot answer the modern question for this branch."}


def not_assessed():
    """Marker for analyses stored before comparability screening existed; nothing is inferred."""
    return {"checks": [], "first_blocking_check": "NOT_ASSESSED_LEGACY_RECORD", "unresolved_checks": [], "screening": "NOT_ASSESSED_LEGACY_RECORD", "passed": 0, "total": 0, "note": "Saved before comparability screening existed. Re-run the analysis to screen this record."}

from __future__ import annotations

import re
from functools import lru_cache
from src.nlp.extract import LATIN_BINOMIAL, LATIN_EPITHET, NOT_GENUS, NOT_EPITHET, RESEARCH_TERMS, research_terms, normalize, sentences, has_research_topic_wording

ANIMAL_WORDS = r'\b(?:rodents?|rats?|mice|mouse|murine|hamsters?|gerbils?|guinea pigs?|zebrafish|fish|trout|carp|tilapia|salmon|broilers?|chickens?|hens?|quail|pigs?|piglets?|swine|sheep|lambs?|ewes?|cattle|calves|cows?|goats?|horses?|rabbits?|bees?|shrimp|dogs?|canine|cats?|feline|drosophila|caenorhabditis elegans)\b'
HUMAN_WORDS = r'\b(?:patients?|humans?|volunteers?|participants?|women|men|adults?|adolescents?|children|infants?|boys|girls)\b'
ANIMAL_PLANT_NAMES = re.compile(r"\b(?:horse[- ]chestnuts?|horse[- ]mints?|cat(?:['’]s|s['’]?)?\s+(?:claws?|whiskers)|goat(?:['’]s|s['’]?)?\s+rue|sheep(?:['’]s|s['’]?)?\s+sorrel|lamb(?:['’]s|s['’]?)?\s+quarters|dog[- ]roses?)\b", re.I)


def animal_signal(text):
    """Animal words inside a plant name do not identify experimental animals."""
    return re.search(ANIMAL_WORDS, ANIMAL_PLANT_NAMES.sub(lambda m:' ' * len(m.group()), text), re.I)


TYPE_RULES = [
    ("META_ANALYSIS", r"\bmeta[- ]analys(?:is|es)\b"),
    ("SYSTEMATIC_REVIEW", r"\bsystematic (?:literature )?review\b"),
    ("REVIEW", r"\b(?:this|a|the present|narrative|comprehensive|scoping) review\b"),
    ("IN_VITRO", r"\bin[- ]vitro\b|\bcell lines?\b|\bcultured cells\b"),
    ("IN_VIVO_ANIMAL", ANIMAL_WORDS),
    ("CLINICAL_TRIAL", r"\brandomi[sz]ed\b|\bdouble[- ]blind\b|\bplacebo[- ]controlled\b|\bclinical trial\b|\bsplit[- ]face (?:clinical )?study\b"),
    ("OBSERVATIONAL_HUMAN", r"\bcohort study\b|\bcase[- ]control study\b|\bcross[- ]sectional study\b"),
]
META_TYPES = {"Randomized Controlled Trial": "CLINICAL_TRIAL", "Controlled Clinical Trial": "CLINICAL_TRIAL", "Clinical Trial": "CLINICAL_TRIAL", "Clinical Trial, Phase II": "CLINICAL_TRIAL", "Clinical Trial, Phase III": "CLINICAL_TRIAL", "Clinical Trial, Phase IV": "CLINICAL_TRIAL", "Observational Study": "OBSERVATIONAL_HUMAN", "Meta-Analysis": "META_ANALYSIS", "Systematic Review": "SYSTEMATIC_REVIEW", "Review": "REVIEW"}


def classify_study(paper, model=None):
    title, abstract = paper["title"], paper["abstract"]
    metadata = {v for k, v in META_TYPES.items() if k in paper.get("publication_types", [])}
    # PubMed indexing occasionally tags a single trial as a meta-analysis; the text must agree.
    if abstract and not re.search(r"meta[- ]?analy|pooled|systematic", title + " " + abstract, re.I):
        metadata -= {"META_ANALYSIS"}
    metadata = sorted(metadata)
    signals = []
    # Do not promote trial/animal terms in a review's background to primary experiments.
    is_review = bool(set(metadata) & {"REVIEW", "SYSTEMATIC_REVIEW", "META_ANALYSIS"}) or bool(re.search(r"\breview\b|meta.analysis", title, re.I))
    for label, pattern in TYPE_RULES:
        for sentence in sentences(title + ". " + abstract):
            matched = animal_signal(sentence['text']) if label == 'IN_VIVO_ANIMAL' else re.search(pattern, sentence['text'], re.I)
            if matched:
                if is_review and label in ("IN_VITRO", "IN_VIVO_ANIMAL", "CLINICAL_TRIAL", "OBSERVATIONAL_HUMAN"):
                    continue
                signals.append({"type": label, "supporting_text": sentence["text"], "method": "TEXT_RULE"})
                break
    types = sorted(set(metadata + [s["type"] for s in signals])) or ["UNKNOWN"]
    animal = bool(animal_signal(title + ' ' + abstract))
    human = bool(re.search(HUMAN_WORDS, title + " " + abstract, re.I))
    methods = re.search(r'\bmethods?\s*:\s*(.*?)(?=\b(?:results?|conclusions?)\s*:|$)', abstract, re.I | re.S)
    method_text = methods.group(1) if methods else ' '.join(s['text'] for s in sentences(abstract) if re.search(r'\b(?:random\w*|allocated|assigned|divided|treated|administered|fed|enrolled|recruited)\b', s['text'], re.I))
    animal_methods = bool(animal_signal(method_text))
    human_methods = bool(re.search(HUMAN_WORDS, method_text, re.I))
    if animal_methods and not human_methods and not is_review:
        # A human disease in Background does not change the experimental population.
        human = False
    split_face = re.search(r'\bsplit[- ]face (?:clinical )?study\b', abstract, re.I) if not animal and not is_review else None
    human = human or bool(split_face)
    if animal and not human and not is_review:
        types = sorted((set(types) - {"UNKNOWN", "CLINICAL_TRIAL", "OBSERVATIONAL_HUMAN"}) | {"IN_VIVO_ANIMAL"})
    if "Clinical Trial Protocol" in paper.get("publication_types", []) or re.search(r"\bprotocol\b", title, re.I):
        types = ["STUDY_PROTOCOL"]
    prediction = model.predict(title + " " + abstract) if model else {"label": "NOT_TRAINED", "used": False}
    # Learned design predictions are triage proposals. A high internal score alone
    # must not promote an otherwise unverified article into human clinical evidence.
    if types == ["UNKNOWN"] and prediction.get("used"):
        prediction = {**prediction, "verification": "MODEL_PROPOSAL_ONLY_REQUIRES_REVIEW"}
    sample = re.search(r"\b(?:n\s*=\s*|(?:a total of\s+)?)(\d{2,5})\s+(patients|participants|subjects|volunteers)\b", abstract, re.I)
    pico = {}
    for key, pattern in [("population", r"\b(?:adult|healthy|older|elderly|female|male|pregnant)?\s*(?:patients|participants|volunteers|rats|mice)\b"), ("intervention_preparation", r"\b(?:aqueous|ethanolic|standardized|standardised)?\s*(?:extract|tea|infusion|oil|capsules?)\b"), ("comparator", r"\b(?:placebo|control group|standard care|usual care|active comparator|waiting[- ]list|untreated control)\b")]:
        match = re.search(pattern, abstract, re.I)
        pico[key] = {"text": match.group().strip(), "start": match.start() + len(match.group()) - len(match.group().lstrip()), "end": match.end()} if match else None
    if split_face and not pico['population']:
        pico['population'] = {'text': split_face.group(), 'start': split_face.start(), 'end': split_face.end(), 'reading_scope': 'Within-person design wording; participant eligibility, sample and allocation require Methods reading. Randomization is not inferred.'}
    return {"types": types, "signals": signals, "metadata_types": metadata, "local_model": prediction, "population_status": "HUMAN_TEXT_SIGNAL" if human else "ANIMAL_TEXT_SIGNAL" if animal else "UNDETERMINED", "sample_size": int(sample[1]) if sample else None, "sample_size_support": sample.group() if sample else None, "pico_source_spans": pico, "quality": "NOT_APPRAISED", "limitations": ["Automated design classification; no full clinical risk-of-bias appraisal."]}


# Introductory framing: what a plant "is used for" or "is known to do" is background, not a result.
BACKGROUND = re.compile(r"\b(?:is|are|has been|have been|has long been|have long been)\s+(?:a\s+|an\s+)?(?:\w+\s+){0,2}?(?:used|known|believed|considered|reputed|reported to|popular|employed)\b|\btraditionally\b|\bfolk (?:medicine|remed\w*)\b|\bfor centuries\b|\b(?:is|are) an? (?:\w+ ){0,2}(?:herb|plant|remedy|species|spice|shrub|tree)s?\b", re.I)
# Words that mark a sentence as the study's own result, anywhere in the abstract.
RESULT_CUE = re.compile(r"\b(?:results?|conclu\w*|we (?:found|observed|show\w*|demonstrat\w*)|found|showed|shown|demonstrat\w*|revealed|significant\w*|compared (?:with|to)|versus|than (?:placebo|controls?)|insufficient evidence|no evidence|did not|no difference)\b", re.I)
# Past-tense effect verbs count without an explicit cue only after the opening sentence.
EFFECT_VERB = re.compile(r"\b(?:reduced|improved|increased|decreased|alleviated|ineffective)\b", re.I)
BENEFIT_VERB = r"reduced|reducing|improved|improving|decreased|decreasing|alleviated|alleviating|relieved|relieving|ameliorated|attenuated|lowered|accelerated|promoted"
# Materials and assay vocabulary: "reduced swelling capacity" is a property, not a symptom.
NOT_A_SYMPTOM = r"(?!\s+(?:capacity|ratio|index|degree|rate|behaviou?r|propert\w+|kinetics))"


AIM_SENTENCE = re.compile(r"^(?:(?:background|objectives?|aims?|purpose|introduction|methods?|design|setting)\s*:|(?:the\s+)?(?:aim|objective|purpose|goal)s?\b|we (?:aimed|sought|investigated|evaluated|assessed)\b|this (?:study|trial|review) (?:aimed|sought|evaluated|assessed|investigated)\b|to (?:evaluate|assess|investigate|determine|examine|compare)\b)", re.I)
BENEFIT_STATEMENT = re.compile(r"\b(?:significant(?:ly)?\s+(?:\w+\s+){0,2}(?:reduc\w*|improv\w*|decreas\w*|lower\w*|alleviat\w*|better|greater|superior|positive|beneficial)|more effective than|superior to|better than placebo|as effective as|similar (?:effectiveness|efficacy) to|non-?inferior|(?:was|were|is|are|be|appears?(?: to be)?|seems?(?: to be)?)\s+(?:\w+\s+){0,2}(?:an?\s+)?(?:safe and )?(?:effective|efficacious|beneficial|useful|helpful)|effective (?:in|for|at|treatment|herb|remedy|option|alternative|agent|therapy)|improved (?:significantly|more)|greater (?:\w+\s+){0,3}(?:reduction|improvement|decrease)|(?:remarkable|marked|overall|clinically (?:meaningful|relevant)) improvements?|(?:modest|beneficial|positive) (?:\w+\s+)?(?:effect|activity|benefit)s?|(?:can|may|might|could) (?:\w+\s+)?(?:help )?(?:improve|reduce|relieve|alleviate|lower)|can be considered in the (?:prevention|treatment)|(?:results?|data|findings|evidence) (?:\w+\s+){0,2}supports?\b|efficacy (?:was|has been) (?:shown|demonstrated|confirmed))\b", re.I)
NO_EFFECT = r"(?:no|not|without)\s+(?:a\s+)?(?:statistically\s+)?(?:clinically\s+)?(?:significant(?:ly)?|effective|benefit|better|difference|effect|superior|improvement|meaningful|relevant)(?!\s+(?:\w+\s+)?(?:adverse|side|toxic\w*|safety|serious|harm\w*|complication\w*))|(?:did|does|do) not (?:improve|reduce|differ|show|significantly|support|appear to|prevent|relieve|alleviate|lower|yield|provide (?:\w+\s+){0,3}(?:benefit|evidence|relief|indication|improvement)|reveal|demonstrate|result in|affect|change|alter)|cannot (?:reduce|improve|relieve|alleviate|prevent)|ineffective|failed to (?:improve|reduce|show|provide|demonstrate|support)|no better than placebo|no more effective|lack of (?:efficacy|effect|benefit)|not (?:be )?supported|minimal beneficial effects?|no evidence (?:of|for|that) (?:\w+\s+){0,3}(?:effect|efficacy|benefit)"
# "More research is needed" closes most abstracts; it does not unsay the result before it.
FUTURE_WORK = re.compile(r"\b(?:more|further|additional|larger|future)\s+(?:\w+\s+){0,3}(?:studies|research|trials?|investigations?)\b", re.I)
WEAK_EVIDENCE = r"insufficient|inconclusive|limited evidence|not enough|no convincing evidence|conflicting|equivocal|(?:has|have) not been (?:established|proven|proved|confirmed)|remains? (?:unproven|unclear|uncertain)|uncertain whether"
# No inactive arm: "no difference between the groups" then means similar to the active drug.
INACTIVE_ARM = re.compile(r"\bplacebo\b|\bsham\b|\bcontrol group\b|\bcontrols\b|\busual care\b|\bno treatment\b|\buntreated\b", re.I)
GROUP_COMPARISON = re.compile(r"\b(?:between|among)\s+(?:the\s+)?(?:two\s+|both\s+|three\s+)?(?:study\s+|treatment\s+)?groups\b|\bboth groups\b", re.I)
VERDICT_SENTENCES = 3
# A closing sentence states the result in the present tense or a hedge. Earlier in an abstract the
# same wording is background or an aim, so these count only inside the verdict.
VERDICT_BENEFIT = re.compile(r"\b(?:(?:appear(?:s|ed)?|seem(?:s|ed)?) to (?:\w+\s+)?(?:lessen|decrease|reduce|improve|relieve|alleviate)|(?<!\ba )(?<!\bthe )(?:improves?|reduces?|alleviates?|relieves?|decreases?|lessens?|lowers|ameliorates?)\s+(?:\w+\s+){0,4}?(?:symptoms?|severity|scores?|pain|quality|function|intensity|frequency|duration|levels?)|provides? an effective|comparable (?:efficacy|effectiveness)|(?:possess\w*|show\w*|exert\w*|ha[sd]|have|produce[sd]?)\s+(?:\w+\s+){0,3}(?:favou?rable|beneficial|protective|therapeutic|clinically meaningful|positive)\s+(?:\w+\s+){0,2}effects?|(?:may|can|could) be (?:a |an )?(?:\w+\s+){0,3}(?:safe|effective|proper|suitable|appropriate|valuable|useful)\s+(?:\w+\s+){0,3}(?:drug|treatment|option|therapy|remedy|alternative|adjuvant)|supported by (?:sufficient|good|strong|moderate) evidence|promising evidences? for|can help|helps? (?:in )?(?:reliev|reduc|improv|alleviat)\w*)\b", re.I)
PRESENT_BENEFIT_VERB = r"reduces?|improves?|decreases?|alleviates?|relieves?|ameliorates?|attenuates?|lowers"
OPEN_QUESTION = re.compile(r"\b(?:whether|to determine|to assess|to evaluate|to confirm|is needed|are needed|warranted|claims?|viewed with caution)\b", re.I)
# Registration and funding lines close many abstracts and say nothing about the result.
ADMINISTRATIVE = re.compile(r"\b(?:trial registration|registered|registration (?:number|date)|clinicaltrials\.gov|prospero|funding|funded by|copyright|ethic\w* approval)\b|©", re.I)
CONCLUSION_LABEL = re.compile(r"\b(?:conclusions?(?:\s+(?:and|&)\s+(?:relevance|significance))?|interpretation|implications? for practice|authors' conclusions)\s*:", re.I)
ASSOCIATION_BENEFIT = re.compile(r"\bassociated with (?:a )?(?:lower|reduced|decreased) (?:risk|rate|incidence)\b(?!\s+of\s+(?:adverse|side|toxic|harm))", re.I)
# Analysis diagnostics are not treatment outcomes. They can be statistically
# null while the pooled treatment effect is beneficial (or harmful).
ANALYSIS_DIAGNOSTIC = re.compile(r"\b(?:no|not|without)\s+(?:a\s+)?(?:statistically\s+)?significant\s+(?:interaction|heterogeneity|publication bias|association (?:with|between) study|difference (?:between|across|among) (?:the )?subgroups)\b|\b(?:meta[- ]regression|heterogeneity|publication bias|interaction (?:with|between)|subgroup analys\w*)\b", re.I)
SAFETY_OUTCOME = re.compile(r'\b(?:adverse (?:events?|effects?|reactions?)|side effects?|tolerability|well tolerated|safe(?:ty)?|toxic(?:ity)?)\b', re.I)
WITHIN_GROUP = re.compile(r'\b(?:from|relative to|compared (?:with|to)|versus|vs\.?)\s+(?:the\s+)?baseline\b|\bwithin[- ]group\b', re.I)
MISSING_COMPARISON = re.compile(r'\bno\s+(?:between[- ]group|controlled|comparative)\s+(?:\w+\s+){0,2}comparison\b|\bno between[- ]group comparison\b', re.I)
BETWEEN_GROUP = re.compile(r'\b(?:than|versus|compared (?:with|to)|relative to)\s+(?:the\s+)?(?:placebo|controls?)\b|\bbetween[- ]group\b', re.I)


@lru_cache(maxsize=128)
def other_outcomes(terms):
    """Topic vocabulary excluding this endpoint; safety has its own screen."""
    target = set(terms)
    alternatives = {word for values in RESEARCH_TERMS.values() for word in values if word not in target}
    return re.compile(r'\b(?:' + '|'.join(re.escape(w) for w in sorted(alternatives, key=len, reverse=True)) + r')\b', re.I)


def outcome_scope(text, terms):
    if has_research_topic_wording(normalize(text), terms):
        return 'TARGET'
    if SAFETY_OUTCOME.search(text) or other_outcomes(tuple(terms)).search(text):
        return 'OTHER'
    return 'UNSPECIFIED'


def endpoint_clauses(sentence, terms):
    """Separate coordinated endpoint results without manufacturing new source text."""
    boundaries = list(re.finditer(r'\s+(?:but|whereas|while|however)\s+|[,;]\s*(?:and|but|whereas|while|however)\s+|\s+and\s+(?=(?:had|has|showed|was|were|did|there)\b)', sentence['text'], re.I))
    if not boundaries:
        return [sentence]
    starts = [0] + [m.end() for m in boundaries]
    ends = [m.start() for m in boundaries] + [len(sentence['text'])]
    parts = []
    for left, right in zip(starts, ends):
        segment = sentence['text'][left:right]
        left += len(segment) - len(segment.lstrip())
        right -= len(segment) - len(segment.rstrip())
        if left < right:
            parts.append({'text':sentence['text'][left:right], 'start':sentence['start'] + left, 'end':sentence['start'] + right})
    # An adjective/qualifier fragment belongs to the following endpoint:
    # "blood pressure ..., and had a beneficial, but not significant effect on
    # cognition" must keep "beneficial, but not significant" together.
    index = 0
    while index < len(parts) - 1:
        if outcome_scope(parts[index]['text'], terms) == 'UNSPECIFIED':
            left, right = parts[index]['start'], parts[index + 1]['end']
            parts[index:index + 2] = [{'text':sentence['text'][left - sentence['start']:right - sentence['start']], 'start':left, 'end':right}]
        else:
            index += 1
    # A clause without an endpoint can still refer to the same endpoint. Split
    # only when both sides independently name an outcome (including safety).
    if len(parts) > 1 and all(outcome_scope(p['text'], terms) != 'UNSPECIFIED' for p in parts):
        return parts
    return [sentence]


def botanical_mentions(text, known_genera=None):
    """Recognised genera distinguish binomials from phrases such as 'The number'."""
    return {normalize(n) for n in LATIN_BINOMIAL.findall(text)
            if LATIN_EPITHET.search(normalize(n).split()[-1]) and n.split()[0] not in NOT_GENUS and normalize(n).split()[-1] not in NOT_EPITHET
            and (known_genera is None or normalize(n).split()[0] in known_genera)}


def candidate_result_scope(paper, taxon, findings, known_genera=None):
    """A paper co-mention is not enough to assign another intervention's result."""
    if not taxon.get('name'):
        return findings, None
    scientific = {normalize(taxon['name'])} | {normalize(a['name']) for a in taxon.get('aliases', []) if a['kind'] in ('ACCEPTED_NAME', 'SYNONYM', 'INPUT_SYNONYM_MATCH')}
    genus = normalize(taxon.get('genus') or taxon['name'].split()[0])
    title = normalize(paper['title'])
    titled_species = {normalize(n) for n in LATIN_BINOMIAL.findall(paper['title']) if normalize(n).split()[0] == genus and LATIN_EPITHET.search(normalize(n).split()[-1]) and normalize(n).split()[-1] not in {'extract','extracts','oil','oils','tea','leaves','root','roots','herbal','herbs','species'}}
    if titled_species and not titled_species & scientific:
        return [], 'The title identifies a different species of this genus; a background co-mention cannot assign its result to this candidate.'
    names = scientific | {normalize(a['name']) for a in taxon.get('aliases', []) if a['kind'] == 'VERNACULAR' and len(a['name']) >= 4}
    wording = re.compile(r'\b(?:' + '|'.join(re.escape(n) for n in sorted(names,key=len,reverse=True)) + r')\b', re.I)
    other_titled_plants = botanical_mentions(paper['title'], known_genera) - scientific
    single_named_subject = wording.search(title) and not other_titled_plants
    assigned = []
    for finding in findings:
        text = finding[1]['text']
        explicit = wording.search(normalize(text))
        other_plants = botanical_mentions(text, known_genera) - scientific
        if explicit or single_named_subject and not other_plants:
            assigned.append(finding)
    if len(assigned) != len(findings):
        return assigned, 'The title does not anchor this candidate. Only result statements explicitly naming the candidate are assigned; generic or other-intervention findings remain unassigned.'
    return findings, None


def study_sentences(text):
    """Preserve decimal statistics inside modern result sentences and exact spans."""
    start = 0
    for boundary in re.finditer(r'\n+|[.!?;]+(?=\s|$)', text):
        # Botanical author initials and prose abbreviations belong to their
        # sentence. Splitting "Ginkgo biloba L. did not..." loses the subject
        # before the result can be assigned to an intervention.
        if boundary.group() == '.' and re.search(r'\b(?:[A-Z]|vs|Dr|Prof|Fig|al|e\.g|i\.e)\.$', text[:boundary.end()]):
            continue
        end = boundary.end()
        left = start + len(text[start:end]) - len(text[start:end].lstrip())
        if left < end and text[left:end].strip():
            yield {'text': text[left:end], 'start': left, 'end': end}
        start = end
    left = start + len(text[start:]) - len(text[start:].lstrip())
    if left < len(text):
        yield {'text': text[left:], 'start': left, 'end': len(text)}


def intervention_clauses(sentence, taxon, known_genera=None):
    """Keep contrasting, explicitly named interventions in separate source spans."""
    if not taxon.get('name'):
        return [sentence]
    names = {taxon['name']} | {a['name'] for a in taxon.get('aliases', []) if a['kind'] in ('ACCEPTED_NAME', 'SYNONYM', 'INPUT_SYNONYM_MATCH', 'VERNACULAR') and len(a['name']) >= 4}
    own = re.compile(r'\b(?:' + '|'.join(re.escape(n) for n in sorted(names, key=len, reverse=True)) + r')\b', re.I)
    boundaries = list(re.finditer(r'(?:[,;]\s*)?\b(?:whereas|while|but|however)\b[,:]?\s*', sentence['text'], re.I))
    if not boundaries:
        return [sentence]
    starts = [0] + [b.end() for b in boundaries]
    ends = [b.start() for b in boundaries] + [len(sentence['text'])]
    parts = []
    for left, right in zip(starts, ends):
        segment = sentence['text'][left:right]
        left += len(segment) - len(segment.lstrip())
        right -= len(segment) - len(segment.rstrip())
        if left < right:
            parts.append({'text': sentence['text'][left:right], 'start': sentence['start'] + left, 'end': sentence['start'] + right})
    def named(text):
        return bool(own.search(text) or botanical_mentions(text, known_genera))
    grouped = []
    for part in parts:
        if named(part['text']) or not grouped:
            grouped.append(part)
        else:
            # A qualifier such as "but was less effective than..." belongs to
            # the preceding intervention; it must not prevent the plant split.
            left, right = grouped[-1]['start'], part['end']
            grouped[-1] = {'text': sentence['text'][left - sentence['start']:right - sentence['start']], 'start': left, 'end': right}
    return grouped if sum(named(p['text']) for p in grouped) > 1 else [sentence]


def benefit_on_condition(text, terms):
    """A favourable effect verb must act on the condition itself, not anywhere in the sentence."""
    t = "|".join(re.escape(x) for x in sorted(terms, key=len, reverse=True))
    return re.search(rf"\b(?:{BENEFIT_VERB})\b(?:\W+\w+){{0,3}}?\W+(?:{t})\b{NOT_A_SYMPTOM}|\b(?:{t})\b{NOT_A_SYMPTOM}(?:\W+\w+){{0,5}}?\W+(?:was|were|is|are|been)\s+(?:\w+\s+)?(?:{BENEFIT_VERB})\b", text, re.I)


def stated_in_verdict(text, terms):
    """Present-tense or hedged wording of a benefit; only a closing sentence may use it."""
    if OPEN_QUESTION.search(text):
        return None
    t = "|".join(re.escape(x) for x in sorted(terms, key=len, reverse=True))
    return VERDICT_BENEFIT.search(text) or re.search(rf"(?<!\ba )(?<!\bthe )\b(?:{PRESENT_BENEFIT_VERB})\b(?:\W+\w+){{0,3}}?\W+(?:{t})\b{NOT_A_SYMPTOM}", text, re.I)


def reported_findings(relevant, opening_start=0, terms=(), active_comparator=False, verdict_start=None):
    """Result statements in condition-relevant sentences, before any comparability gate."""
    findings = []
    for sentence in relevant:
        text = sentence["text"]
        # Introductory therapeutic claims must not masquerade as the study's finding:
        # background framing is skipped, and the opening sentence needs an explicit cue.
        if BACKGROUND.search(text) or AIM_SENTENCE.search(text):
            continue
        if re.search(r'\b(?:before (?:the )?(?:intervention|treatment|randomi[sz]ation)|at (?:the )?baseline|pre[- ]treatment)\b', text, re.I) and not re.search(r'\b(?:after|following|from baseline|change|changes)\b', text, re.I):
            # Balanced groups before dosing say nothing about treatment effect.
            continue
        if ANALYSIS_DIAGNOSTIC.search(text) and not benefit_on_condition(text, terms) and not re.search(r'\b(?:versus|than|compared (?:with|to))\s+(?:the\s+)?(?:placebo|control)|\b(?:primary (?:outcome|endpoint)|hospitali[sz]ation|mortality|symptoms?)\b', text, re.I):
            continue
        in_verdict = verdict_start is not None and sentence["end"] > verdict_start and sentence["start"] > opening_start
        hedged = stated_in_verdict(text, terms) if in_verdict else None
        closing = in_verdict and (BENEFIT_STATEMENT.search(text) or re.search(NO_EFFECT, text, re.I) or hedged or re.search(WEAK_EVIDENCE, text, re.I))
        if not (closing or RESULT_CUE.search(text) or MISSING_COMPARISON.search(text) or (EFFECT_VERB.search(text) and sentence["start"] > opening_start)):
            continue
        insufficient = re.search(WEAK_EVIDENCE, text, re.I)
        negative = re.search(NO_EFFECT, text, re.I)
        association = ASSOCIATION_BENEFIT.search(text)
        if association and re.search(r'\b(?:not|no(?:\s+\w+){0,4})\s*$', text[:association.start()], re.I):
            association = None
        negative = negative or re.search(r'\bnot associated with (?:a )?(?:lower|reduced|decreased) (?:risk|rate|incidence)\b', text, re.I)
        positive = benefit_on_condition(text, terms) or BENEFIT_STATEMENT.search(text) or hedged or association or re.search(r'\b(?:significant benefit|more beneficial than (?:the )?placebo|(?:show(?:ed|ing)|reported|demonstrated)\s+(?:an?\s+)?improvements?\s+(?:compared|over))\b', text, re.I)
        if FUTURE_WORK.search(text) and not negative and not insufficient and not re.search(r"\b(?:significant|effective|improved|reduced)\b", text, re.I):
            continue
        active_arm_comparison = negative and re.search(r'\b(?:among|between)\s+(?:the\s+)?(?:(?:three|two|four|\d+|different)\s+)?(?:active|herbal)\s+(?:treatments?|mouthwashes|interventions?|groups?|arms?)\b', text, re.I)
        multiple_comparisons = negative and re.search(r'\b(?:whereas|while|but)\b.*\b(?:placebo|control)\b', text, re.I) and re.search(r'\b(?:between|among)\b.*\b(?:arms|groups|treatments|interventions)\b', text, re.I)
        if MISSING_COMPARISON.search(text) or ((negative or positive) and (WITHIN_GROUP.search(text) or re.search(r'\bboth\s+(?:active\s+)?(?:groups|treatments|arms)\b', text, re.I)) and not BETWEEN_GROUP.search(text)):
            findings.append(('INSUFFICIENT', {**sentence, 'comparison_note': 'A baseline change or an explicitly missing between-group comparison cannot establish a treatment-versus-comparator effect.'}))
        elif negative and active_comparator and (GROUP_COMPARISON.search(text) or re.search(r'\bno\s+(?:statistically\s+)?significant\s+difference\b|\bno difference\b', text, re.I)):
            findings.append(('INSUFFICIENT', {**sentence, 'comparison_note': 'No inactive arm is described; no difference from an active comparator is not a finding of no effect.'}))
        elif active_arm_comparison or multiple_comparisons:
            sentence = {**sentence, 'comparison_note': 'The sentence compares multiple arms or reports different comparisons. No single candidate-versus-control direction is inferred; read the complete result and its comparator.'}
            findings.append(('INSUFFICIENT', sentence))
        elif insufficient:
            findings.append(("INSUFFICIENT", sentence))
        elif negative and positive and re.search(r"\b(?:but|however|although|though|while|whereas|yet)\b", text, re.I):
            findings.append(("MIXED", sentence))
        elif negative:
            findings.append(("CONTRADICTS", sentence))
        elif positive:
            findings.append(("SUPPORTS", sentence))
    return findings


def relation_to_claim(paper, taxon, condition, study, *, taxon_match, require_identity=True, known_genera=None):
    """Conservative clause classifier. Relations address a modern question, not history."""
    terms = research_terms(condition)
    if "STUDY_PROTOCOL" in study["types"]:
        return {"relation": "INSUFFICIENT", "supporting_text": None, "rationale": "A study protocol is not a completed study result", "directness": "PROTOCOL_NO_RESULTS", "reported_finding": {"direction": "NO_RESULT_STATEMENT"}}
    relevant = []
    all_sentences = [part for sentence in study_sentences(paper['abstract']) for intervention in intervention_clauses(sentence, taxon, known_genera) for part in endpoint_clauses(intervention, terms)]
    opening = all_sentences[0]["start"] if all_sentences else 0
    conclusion = CONCLUSION_LABEL.search(paper["abstract"])
    for sentence in all_sentences:
        norm = normalize(sentence["text"])
        if has_research_topic_wording(norm, terms):
            relevant.append(sentence)
    # An abstract closes on its verdict, in Conclusions or in its last sentences, often without
    # repeating the topic words.
    closing = [s for s in all_sentences if not ADMINISTRATIVE.search(s["text"])]
    verdict_start = conclusion.start() if conclusion else closing[-VERDICT_SENTENCES]["start"] if len(closing) > VERDICT_SENTENCES else 0
    if relevant:
        known = {r["start"] for r in relevant}
        # Generic conclusions may refer back to this endpoint, but not across a
        # switch to another endpoint or to safety. A favourable anxiety result
        # must not reverse a null sleep result merely because it closes the abstract.
        last_scope = None
        for sentence in closing:
            scope = outcome_scope(sentence['text'], terms)
            if scope != 'UNSPECIFIED':
                last_scope = scope
            if sentence['end'] > verdict_start and sentence['start'] not in known and scope != 'OTHER' and last_scope == 'TARGET':
                relevant.append(sentence)
        relevant.sort(key=lambda s: s["start"])
    if not relevant:
        return {"relation": "IRRELEVANT", "supporting_text": None, "rationale": "No condition-specific supporting sentence in the available abstract", "directness": "UNDETERMINED", "reported_finding": {"direction": "NO_RESULT_STATEMENT"}}
    findings = reported_findings(relevant, opening, terms, active_comparator=not INACTIVE_ARM.search(paper["abstract"]), verdict_start=verdict_start)
    unassigned = findings
    findings, candidate_scope_note = candidate_result_scope(paper, taxon, findings, known_genera)
    # A null/uncertain conclusion does not erase an explicit conflicting result.
    # Retain all endpoint-specific statements and their exact source spans.
    comparative = [f for f in findings if not f[1].get('comparison_note')]
    findings = comparative or findings
    labels = {f[0] for f in findings}
    if "MIXED" in labels or {"SUPPORTS", "CONTRADICTS"} <= labels or {"SUPPORTS", "INSUFFICIENT"} <= labels and not {f[1].get('comparison_note') for f in findings} - {None}:
        reported = "MIXED"
    else:
        reported = "INSUFFICIENT" if "INSUFFICIENT" in labels else findings[-1][0] if findings else "NO_RESULT_STATEMENT"
    # The reported finding is what the abstract says about its own intervention and
    # population. It is kept visible even when it cannot answer the branch question.
    finding = {"direction": reported, "supporting_text": findings[-1][1]["text"], "start": findings[-1][1]["start"], "end": findings[-1][1]["end"]} if findings else {"direction": "NO_RESULT_STATEMENT"}
    comparison_notes = list(dict.fromkeys(s['comparison_note'] for _, s in findings if s.get('comparison_note')))
    if comparison_notes:
        finding['comparison_notes'] = comparison_notes
    if findings:
        finding['statements'] = [{'direction': direction, 'supporting_text': sentence['text'], 'start': sentence['start'], 'end': sentence['end'], **({'comparison_note':sentence['comparison_note']} if sentence.get('comparison_note') else {})} for direction, sentence in findings]
    if candidate_scope_note:
        finding['candidate_scope_note'] = candidate_scope_note
        finding['unassigned_statements'] = [{'direction':direction, 'supporting_text':sentence['text'], 'start':sentence['start'], 'end':sentence['end']} for direction,sentence in unassigned if (direction,sentence) not in findings]
    if require_identity and taxon_match != "SCIENTIFIC_NAME":
        return {"relation": "INSUFFICIENT", "supporting_text": relevant[-1]["text"], "rationale": "Common-name mention does not settle the experimental species for this candidate branch", "directness": "IDENTITY_UNCERTAIN", "reported_finding": finding}
    if not findings:
        return {"relation": "INSUFFICIENT", "supporting_text": relevant[-1]["text"], "rationale": candidate_scope_note or "Relevant wording is present but no explicit condition-specific result safely settles this question", "directness": "INTERVENTION_NOT_LINKED_TO_CANDIDATE" if candidate_scope_note else "ABSTRACT_ONLY", "reported_finding": finding}
    relation = reported
    support = findings[-1][1]["text"]
    if study.get('population_status')=='UNDETERMINED' and relation!='INSUFFICIENT':
        return {'relation':'INSUFFICIENT','reported_relation':relation,'supporting_text':support,'rationale':'An outcome statement is present but human population is not established in the available abstract.','directness':'POPULATION_UNDETERMINED','reported_finding':finding}
    preclinical = bool(set(study["types"]) & {"IN_VITRO", "IN_VIVO_ANIMAL"}) and not bool(set(study["types"]) & {"CLINICAL_TRIAL", "OBSERVATIONAL_HUMAN"})
    if preclinical and relation in ("SUPPORTS", "CONTRADICTS", "MIXED"):
        return {"relation": "INSUFFICIENT", "mechanistic_relation": relation, "supporting_text": support, "rationale": "Preclinical finding retained as indirect evidence; it cannot settle a human efficacy hypothesis", "directness": "PRECLINICAL_ONLY", "reported_finding": finding}
    if not set(study["types"]) & {"CLINICAL_TRIAL", "OBSERVATIONAL_HUMAN", "SYSTEMATIC_REVIEW", "META_ANALYSIS"} and relation != "INSUFFICIENT":
        return {"relation": "INSUFFICIENT", "reported_relation": relation, "supporting_text": support, "rationale": "Relevant findings are retained, but the abstract does not establish an adequately identified human-study design for an efficacy interpretation", "directness": "DESIGN_OR_POPULATION_UNCERTAIN", "reported_finding": finding}
    return {"relation": relation, "supporting_text": support, "rationale": ' '.join(comparison_notes) if comparison_notes else "Automated abstract-level, condition-specific result interpretation; preparation/population/outcome comparability requires human review. No-effect wording does not establish equivalence.", "directness": "ABSTRACT_ONLY_COMPARABILITY_UNREVIEWED", "reported_finding": finding}


def citation_check(paper, text, taxon_match, condition_match, canonical=None):
    errors = []
    if canonical is None:
        errors.append("NOT_IN_RETRIEVED_SNAPSHOT")
    elif any(paper.get(k) != canonical.get(k) for k in ("id", "pmid", "doi", "title", "abstract")):
        errors.append("SNAPSHOT_METADATA_MISMATCH")
    if not re.fullmatch(r"(?:PMC|PMID)\d+", paper.get("id", "")):
        errors.append("INVALID_PAPER_ID")
    if paper.get("pmid") and not re.fullmatch(r"\d+", str(paper["pmid"])):
        errors.append("INVALID_PMID")
    if paper.get("doi") and not re.fullmatch(r"10\.\d{4,9}/\S+", paper["doi"], re.I):
        errors.append("INVALID_DOI")
    if not paper.get("provenance", {}).get("url", "").startswith(("https://www.ebi.ac.uk/", "https://eutils.ncbi.nlm.nih.gov/")):
        errors.append("UNVERIFIED_METADATA_ORIGIN")
    if text and text not in paper["abstract"]:
        errors.append("SUPPORT_SPAN_NOT_IN_SOURCE")
    if paper.get("retracted"):
        errors.append("RETRACTED_SOURCE")
    return {"status": "REJECTED" if errors else "SOURCE_METADATA_AND_SPAN_CHECKED", "errors": errors, "identifier_present_in_retrieved_snapshot": canonical is not None and not errors, "exact_support_span": bool(text and text in paper["abstract"]), "taxon_scientific_match": taxon_match == "SCIENTIFIC_NAME", "condition_match": bool(condition_match), "entailment_status": "AUTOMATED_HEURISTIC_NOT_EXPERT_VERIFIED", "human_reviewed": False}


def conflict_groups(evidence):
    groups = []
    # Same branch/condition only; even then comparability is not automatically assumed.
    keys = {(e["taxon_id"], e["condition_id"]) for e in evidence}
    for taxon_id, condition_id in sorted(keys):
        rows = [e for e in evidence if e["taxon_id"] == taxon_id and e["condition_id"] == condition_id]
        labels = {e["relation"]["relation"] for e in rows}
        state = "POTENTIAL_CONFLICT_REQUIRES_COMPARABILITY_REVIEW" if {"SUPPORTS", "CONTRADICTS"} <= labels else "MIXED" if "MIXED" in labels else "INSUFFICIENT" if not rows or labels <= {"INSUFFICIENT", "IRRELEVANT"} else "NO_COMPARABLE_CONFLICT_ESTABLISHED"
        groups.append({"taxon_id": taxon_id, "condition_id": condition_id, "state": state, "evidence_ids": [e["id"] for e in rows], "limitation": "Preparation, dose, population and outcome may differ. Opposing abstract wording is a potential conflict, not a validated contradiction."})
    return groups

"""Conservative outcome-direction baseline; direction is separate from benefit."""
import re
from src.nlp.extract import sentences, normalize


def outcome_direction(evidence, outcome, *, aware=False):
    # XML/annotation hard wraps are formatting, not sentence boundaries.
    evidence = re.sub(r'\s+', ' ', evidence)
    words={w for w in normalize(outcome).split() if len(w)>3 and w not in {'change','improvement','reduction','levels','score','scores','number','total'}}
    ranked=[]
    for s in sentences(evidence):
        overlap=len(words & set(normalize(s['text']).split()))
        ranked.append((overlap,s))
    if not ranked:return {'code':None,'reason':'No evidence sentence'}
    _,sentence=max(ranked,key=lambda pair:(pair[0],pair[1]['start']))
    text=sentence['text']
    if re.search(r'no\s+(?:statistically\s+)?(?:significant|difference)|not\s+(?:statistically\s+)?significant|similar|comparable',text,re.I):code=0
    else:
        up=bool(re.search(r'\bincreas\w*|\bhigher\b|\bgreater\b',text,re.I))
        down=bool(re.search(r'\bdecreas\w*|\breduc\w*|\blower\b|\bless\b',text,re.I))
        code=1 if up and not down else -1 if down and not up else None
        if aware:
            desirable_named = bool(re.search(r'\bimprovement\b|\breduction\b|\bamelioration\b',outcome,re.I))
            explicit_benefit = bool(re.search(r'\badvantage\b|\bamelioration\b|\bimprov\w*',text,re.I))
            if desirable_named and explicit_benefit:code=1
            elif desirable_named and down and not up:code=1
    return {'code':code,'supporting_text':text,'reason':'Lexical outcome-direction baseline; benefit depends on outcome semantics, comparator and intervention. No clinical recommendation.'}

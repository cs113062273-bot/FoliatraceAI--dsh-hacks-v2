"""Readable question results without changing source screening or identity claims."""
from __future__ import annotations

import re
from html import unescape


def publication_text(value):
    return unescape(re.sub(r'<[^>]*>', '', value or ''))


def product_candidate_order(candidates, wording):
    """A disclosed consultation reading order, never an identity confidence score."""
    if re.fullmatch(r'mint(?:\s+(?:product|capsules?))?', wording.strip(), re.I):
        preferred = {'gbif:8707933': 0}  # Peppermint; the bundled supplement trial reading set.
        return sorted(candidates, key=lambda c: preferred.get(c['taxon_id'], 1))
    return list(candidates)


def question_overview(branches, protocol, reading_sets=(), withdrawn=()):
    """Count publications once; retain every candidate-specific check in the packet."""
    grouped = {}
    positions = {}
    def source_priority(pair):
        branch, row = pair
        identity = next((c['status'] for c in row['screening']['checks'] if c['check']=='identity'), 'UNKNOWN')
        return (identity != 'PASS', positions[(branch['taxon_id'],row['id'])], branch['taxon_id'])
    for branch in branches:
        for position, row in enumerate(branch['records'], 1):
            positions[(branch['taxon_id'],row['id'])] = position
            paper = row['paper']
            # Public acquisition uses canonical PubMed IDs. DOI catches mixed-source copies.
            key = ('pmid:' + str(paper['pmid'])) if paper.get('pmid') else (
                'doi:' + paper['doi'].lower().removeprefix('https://doi.org/') if paper.get('doi') else paper['id'])
            grouped.setdefault(key, []).append((branch, row))
    candidates = []
    for rows in grouped.values():
        valid = [(b, r) for b, r in rows if r['screening']['state'] != 'OUTSIDE_REQUESTED_SCOPE']
        if not valid:
            continue
        # BM25 values and cross-encoder logits have different units. Follow the
        # actual branch order, preferring a source-named identity over an
        # unresolved co-mention when a publication has multiple branches.
        b, row = min(valid, key=source_priority)
        checks = {c['check']: c for c in row['screening']['checks']}
        if not checks.get('requested_outcome', {}).get('spans'):
            continue
        trial = 'CLINICAL_TRIAL' in row['study']['types'] and (checks.get('population', {}).get('status') == 'PASS' or row['study'].get('population_status') == 'HUMAN_TEXT_SIGNAL')
        candidates.append({'paper_id': row['paper']['id'], 'record_id': row['id'],
                           'taxon_id': b['taxon_id'], 'candidate': b['name'],
                           'title': publication_text(row['paper']['title']), 'url': row['paper']['url'],
                           'human_trial_signal': trial, 'screening': row['screening']['state'],
                           'needs_confirmation': [c['check'] for c in checks.values() if c['status'] in ('UNKNOWN', 'PARTIAL')],
                           'score': row['retrieval_score'],
                           'reading_position': positions[(b['taxon_id'],row['id'])],
                           'scientific_identity_signal': checks.get('identity',{}).get('status')=='PASS'})
    candidates.sort(key=lambda r: (not r['human_trial_signal'], r['screening'] != 'PRIORITY_FOR_READING',
                                   not r['scientific_identity_signal'], r['reading_position'], r['paper_id']))
    overview = {'unique_publications': len(grouped), 'candidate_records': sum(len(b['records']) for b in branches),
                'endpoint_publications': len(candidates),
                'human_trial_signals': sum(r['human_trial_signal'] for r in candidates),
                'top_studies': candidates[:3], 'selected_readings': [],
                'ranking_basis':'Human-trial and scope checks, then scientific-name signals and saved branch reading order. Raw scores from different ranking models are not compared.'}
    # Only explicit IBS queries activate the selected IBS notes. A general pain query does not.
    query = ' '.join([protocol.question, *protocol.outcome_terms])
    ibs = bool(re.search(r'\birritable bowel syndrome\b|\bIBS\b', query, re.I))
    ids = {b['taxon_id'] for b in branches}
    excluded = set(withdrawn)
    for reading in reading_sets if ibs else ():
        if reading['id'] in excluded or not ids.intersection(reading['taxon_ids']):
            continue
        studies = []
        for note in reading['studies']:
            pub = note['publication']
            if {pub['id'], pub.get('pmid'), pub.get('pmcid')}.intersection(excluded):
                continue
            linked = [(b, r) for rows in grouped.values() for b, r in rows
                      if (r['paper'].get('pmid') == pub.get('pmid') or r['paper']['id'] == pub['id'])
                      and b['taxon_id'] in reading['taxon_ids']
                      and r['screening']['state'] != 'OUTSIDE_REQUESTED_SCOPE'
                      and any(c['check'] == 'requested_outcome' and c.get('spans') for c in r['screening']['checks'])]
            if linked:
                studies.append({**note, 'record_id': linked[0][1]['id'], 'taxon_id': linked[0][0]['taxon_id']})
        if studies:
            overview['selected_readings'].append({'title': reading['title'], 'selection': reading['selection'] + f" Showing {len(studies)} of {len(reading['studies'])} selected readings linked to this question.",
                'takeaway': reading['takeaway'], 'annotation': reading['annotation'], 'studies': studies})
            if reading['id'] == 'reading-set:peppermint-ibs-trials' and {s['pmid'] for s in studies} == {'26319955','31470006','34319275'}:
                overview['findings_summary'] = ('Among these three selected peppermint-oil trials, one reported a significant advantage on its primary symptom score; '
                    'two did not find significant differences on their primary endpoints. Formulations and endpoints differ.')
    return overview

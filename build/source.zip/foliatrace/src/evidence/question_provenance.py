"""Ground every displayed screening quote in its stored publication source."""
from __future__ import annotations


def grounded_span(paper, span):
    if not isinstance(span, dict):
        raise ValueError('A screening quote must be an object')
    start, end, text = span.get('start'), span.get('end'), span.get('text')
    if type(start) is not int or type(end) is not int or not isinstance(text, str) or not text:
        raise ValueError('A screening quote needs exact text and integer offsets')
    kind = span.get('source_kind')
    if kind in ('FULL_TEXT_METHODS', 'FULL_TEXT_METHODS_TABLE'):
        matches = [c for c in paper.get('methods_contexts', []) if c.get('id') == span.get('source_id')]
        if len(matches) != 1:
            raise ValueError('The quoted Methods source is not in this publication')
        context = matches[0]
        if (context.get('source_kind') or 'FULL_TEXT_METHODS') != kind:
            raise ValueError('The quoted Methods source type differs from its stored context')
        source, url, licence = context['text'], context['url'], context.get('licence')
    elif kind in ('PUBLICATION_TITLE', 'PUBLICATION_ABSTRACT', None):
        # Legacy untyped spans were abstract-relative. Retain that meaning when
        # both a title and abstract happen to contain the same quote at an offset.
        choices = [('PUBLICATION_ABSTRACT', paper.get('abstract') or ''),
                   ('PUBLICATION_TITLE', paper['title'])]
        matched = [(k, s) for k, s in choices if (kind is None or kind == k)
                   and 0 <= start < end <= len(s) and s[start:end] == text]
        if not matched:
            raise ValueError('Question evidence/source span mismatch')
        kind, source = matched[0]
        url, licence = paper['url'], paper.get('licence')
    else:
        raise ValueError('Unsupported screening quote source type')
    if not 0 <= start < end <= len(source) or source[start:end] != text:
        raise ValueError('Question evidence/source span mismatch')
    if span.get('url') is not None and span['url'] != url:
        raise ValueError('The quote URL differs from its stored source')
    if span.get('licence') is not None and span['licence'] != licence:
        raise ValueError('The quote rights differ from its stored source')
    return {**span, 'source_kind': kind, 'url': url,
            **({'licence': licence} if licence else {})}


def check_spans(check):
    spans = check.get('spans', [])
    if not isinstance(spans, list):
        raise ValueError('Screening quotes must be a list')
    values = list(spans)
    if check.get('span') is not None and check['span'] not in values:
        values.append(check['span'])
    return values


def ground_checks(paper, screening):
    for check in screening['checks']:
        check['spans'] = [grounded_span(paper, s) for s in check_spans(check)]
        if check.get('span') is not None:
            check['span'] = grounded_span(paper, check['span'])
    return screening


def validate_checks(paper, screening):
    for check in screening['checks']:
        for span in check_spans(check):
            grounded_span(paper, span)

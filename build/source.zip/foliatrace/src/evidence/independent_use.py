"""Independent ethnobotanical records from Dr. Duke's database (USDA, CC0).

A use reported in several unrelated places is a stronger research lead than the same use repeated
by one book: herbals copy each other, distant communities mostly do not. A record only says that a
use was reported, so nothing here can raise or lower a verdict about whether a plant works.
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict

from src.common import DATA, read_json
from src.nlp.extract import normalize

PATH = DATA / 'duke_ethnobotany.json'
CHEMISTRY = DATA / 'duke_chemistry.json'
# Duke's activity vocabulary, spelt as he spelt it, under the topics the statement reader uses.
TOPIC_ACTIVITIES = {
    'headache': ['Ache(Head)', 'Headache', 'Cephalalgia'],
    'migraine': ['Migraine', 'Hemicrania'],
    'sleep': ['Insomnia', 'Soporific', 'Hypnotic', 'Sedative'],
    'anxiety': ['Sedative', 'Tranquilizer', 'Anxiety'],
    'depression': ['Depression', 'Melancholy', 'Antidepressant'],
    'digestive_symptoms': ['Stomachic', 'Carminative', 'Ache(Stomach)', 'Dyspepsia', 'Colic', 'Digestive', 'Stomach', 'Gastritis', 'Abdomen', 'Intestine', 'Flatulence', 'Gastralgia', 'Gastroenteritis', 'Enteritis'],
    'diarrhoea': ['Diarrhea', 'Dysentery', 'Cholera', 'Enteritis'],
    'constipation': ['Purgative', 'Laxative', 'Aperient', 'Cathartic', 'Constipation'],
    'nausea_vomiting': ['Nausea', 'Vomiting', 'Antiemetic', 'Seasickness', 'Hyperemesis'],
    'pain': ['Anodyne', 'Analgesic', 'Neuralgia', 'Bruise', 'Pain', 'Ache(Back)'],
    'joint_gout': ['Rheumatism', 'Arthritis', 'Gout', 'Lumbago', 'Sciatica', 'Ache(Back)'],
    'inflammation': ['Inflammation', 'Swelling', 'Tumor', 'Antiphlogistic', 'Resolvent'],
    'fever': ['Fever', 'Malaria', 'Sudorific', 'Diaphoretic', 'Febrifuge', 'Ague'],
    'cough': ['Cough', 'Expectorant', 'Pertussis', 'Antitussive', 'Hoarseness'],
    'respiratory': ['Cold', 'Asthma', 'Bronchitis', 'Catarrh', 'Flu', 'Tuberculosis', 'Pectoral', 'Chest', 'Lung', 'Pneumonia', 'Phthisis', 'Grippe'],
    'wounds': ['Wound', 'Sore', 'Vulnerary', 'Ulcer', 'Trauma'],
    'burns': ['Burn', 'Scald'],
    'skin': ['Skin', 'Itch', 'Dermatosis', 'Scabies', 'Ringworm', 'Eczema', 'Erysipelas', 'Leprosy', 'Eruption', 'Pimple', 'Wart', 'Boil', 'Abscess', 'Carbuncle', 'Psoriasis', 'Acne'],
    'bleeding': ['Hemostat', 'Styptic', 'Hemorrhage', 'Hemoptysis', 'Epistaxis', 'Menorrhagia', 'Hematuria'],
    'oral_throat_care': ['Sore(Throat)', 'Throat', 'Stomatitis', 'Gargle', 'Dentifrice', 'Gingivitis', 'Mouthwash', 'Thrush', 'Tonsilitis', 'Pharyngitis', 'Pyorrhea'],
    'toothache': ['Ache(Tooth)', 'Odontalgia'],
    'eye': ['Eye', 'Ophthalmia', 'Conjunctivitis', 'Collyrium', 'Cataract', 'Blepharitis'],
    'ear': ['Ache(Ear)', 'Otitis', 'Deafness', 'Ear', 'Otalgia'],
    'epilepsy': ['Epilepsy', 'Convulsion'],
    'nervous': ['Spasm', 'Antispasmodic', 'Nervine', 'Nerves', 'Hysteria', 'Paralysis', 'Apoplexy', 'Cramp'],
    'liver_jaundice': ['Jaundice', 'Hepatitis', 'Liver', 'Bilious', 'Cholagogue', 'Gallstone'],
    'urinary': ['Diuretic', 'Dysuria', 'Bladder', 'Cystitis', 'Urogenital', 'Strangury', 'Urethritis'],
    'dropsy_oedema': ['Dropsy', 'Edema'],
    'memory_cognition': ['Memory', 'Amnesia', 'Senility'],
    'kidney_stones': ['Kidney', 'Gravel', 'Calculus', 'Lithontriptic', 'Stone'],
    'menstrual': ['Emmenagogue', 'Dysmenorrhea', 'Amenorrhea', 'Menorrhagia', 'Menopause'],
    'childbirth_lactation': ['Parturition', 'Puerperium', 'Lactogogue', 'Galactagogue'],
    'parasites': ['Vermifuge', 'Anthelminthic', 'Anthelmintic', 'Parasiticide', 'Taenicide', 'Taeniafuge'],
    'heart': ['Cardiotonic', 'Heart', 'Palpitation', 'Angina'],
    'poison_bites': ['Bite(Snake)', 'Bite(Bug)', 'Bite(Dog)', 'Bite(Scorpion)', 'Antidote', 'Alexiteric', 'Sting'],
    'scurvy': ['Scurvy', 'Antiscorbutic'],
    'haemorrhoids': ['Piles', 'Hemorrhoid', 'Hemorrhoids'],
    'plague_infection': ['Antiseptic', 'Bactericide', 'Plague', 'Infection'],
    'cancer': ['Cancer', 'Tumor'],
    'diabetes': ['Diabetes'],
    'venereal': ['Gonorrhea', 'Syphilis', 'Venereal', 'Leucorrhea', 'Clap'],
    'hypertension': ['Hypertension'],
    'anaemia': ['Anemia', 'Chlorosis'],
}
# Duke's chemical activities under the same topics, kept apart: a report that people used a plant
# for fever and an assay finding a chemical antipyretic are different kinds of knowledge.
COMPOUND_ACTIVITIES = {
    'headache': ['Antimigraine'],
    'migraine': ['Antimigraine', 'Serotoninergic'],
    'sleep': ['Sedative', 'Hypnotic', 'CNS-Depressant', 'Tranquilizer'],
    'anxiety': ['Anxiolytic', 'Tranquilizer', 'Sedative', 'GABA-ergic', 'GABA-Aminotransferase-Inhibitor'],
    'depression': ['Antidepressant', 'MAO-Inhibitor', 'Serotonin-Uptake-Inhibitor'],
    'digestive_symptoms': ['Carminative', 'Antiulcer', 'Spasmolytic', 'Digestive', 'Antigastric', 'Antigastritic', 'Stomachic', 'Antiflatulent'],
    'diarrhoea': ['Antidiarrheic', 'Antidysenteric', 'Amebicide', 'Antiamebic'],
    'constipation': ['Laxative', 'Purgative', 'Cathartic'],
    'nausea_vomiting': ['Antiemetic', 'Antinauseant'],
    'pain': ['Analgesic', 'Antinociceptive', 'Anesthetic', 'Antiallodynic', 'Antineuralgic'],
    'joint_gout': ['Antiarthritic', 'Antirheumatic', 'Antigout', 'Xanthine-Oxidase-Inhibitor', 'Antirheumatalgic', 'Antilumbago'],
    'inflammation': ['Antiinflammatory', 'Antiedemic', 'COX-2-Inhibitor', 'Cyclooxygenase-Inhibitor', 'Lipoxygenase-Inhibitor', 'Antiprostaglandin'],
    'fever': ['Antipyretic', 'Antimalarial', 'Antiplasmodial', 'Febrifuge'],
    'cough': ['Antitussive', 'Expectorant', 'Antipertussal'],
    'respiratory': ['Bronchodilator', 'Antiasthmatic', 'Antibronchitic', 'Antitubercular', 'Antiinfluenza', 'Decongestant', 'Mucolytic', 'Antihistaminic'],
    'wounds': ['Vulnerary', 'Cicatrizant', 'Antiulcer', 'Woundhealer'],
    'burns': ['Antiburn', 'Vulnerary'],
    'skin': ['Antieczemic', 'Antidermatitic', 'Antipsoriac', 'Antiacne', 'Antiseborrheic', 'Antierythemic'],
    'bleeding': ['Hemostat', 'Antihemorrhagic', 'Styptic'],
    'oral_throat_care': ['Antigingivitic', 'Antiplaque', 'Anticariogenic', 'Antipyorrheic', 'Antitonsilitic', 'Antistomatitic'],
    'toothache': ['Antiodontalgic', 'Dentifrice'],
    'eye': ['Antiglaucomic', 'Anticataract', 'Antimyopic', 'Antiophthalmic'],
    'epilepsy': ['Anticonvulsant', 'Antiepileptic'],
    'nervous': ['Antispasmodic', 'Myorelaxant', 'Neuroprotective', 'Antistroke', 'Anticonvulsant'],
    'liver_jaundice': ['Hepatoprotective', 'Cholagogue', 'Choleretic', 'Antihepatotoxic', 'Antihepatitic', 'Hepatotonic', 'Antijaundice', 'Antihepatitic'],
    'urinary': ['Diuretic', 'Antiprostatic', 'Antiprostatitic', 'Antiprostatadenomic', 'Uricosuric', 'Antinephritic', 'Anticystitic'],
    'dropsy_oedema': ['Diuretic', 'Antiedemic', 'Antidropsy'],
    'memory_cognition': ['Anticholinesterase', 'Memory-Enhancer', 'Cognitive', 'Antialzheimeran', 'Nootropic', 'Cholinergic'],
    'kidney_stones': ['Antilithic', 'Lithontriptic', 'Antinephrolytic'],
    'menstrual': ['Emmenagogue', 'Antidysmenorrheic', 'Antimenorrhagic', 'Estrogenic', 'Antimenopausal', 'Antiamenorrheic'],
    'childbirth_lactation': ['Lactagogue', 'Galactagogue', 'Oxytocic', 'Uterotonic'],
    'parasites': ['Anthelmintic', 'Nematicide', 'Vermifuge', 'Antiparasitic', 'Antiascariasis', 'Antischistosomal', 'Taenicide'],
    'heart': ['Cardiotonic', 'Antiarrhythmic', 'Cardioprotective', 'Antianginal', 'Hypocholesterolemic', 'Antiatherosclerotic', 'Antiischemic'],
    'poison_bites': ['Antiophidic', 'Antivenin', 'Antidote', 'Antivenomous'],
    'scurvy': ['Antiscorbutic'],
    'haemorrhoids': ['Antihemorrhoidal', 'Capillarifortificant', 'Vasoprotective'],
    'plague_infection': ['Antibacterial', 'Antiviral', 'Antiseptic', 'Antimicrobial'],
    'cancer': ['Antitumor', 'Cancer-Preventive', 'Antileukemic', 'Anticancer', 'Anticarcinogenic'],
    'diabetes': ['Hypoglycemic', 'Antidiabetic', 'Aldose-Reductase-Inhibitor', 'Insulinotonic', 'Insulin-Sparing'],
    'venereal': ['Antisyphilitic', 'Antigonorrheic', 'Antileukorrheic'],
    'hypertension': ['Hypotensive', 'ACE-Inhibitor', 'Antihypertensive', 'Calcium-Antagonist', 'Vasodilator'],
    'anaemia': ['Antianemic', 'Hematinic', 'Hematopoietic'],
}
ACTIVITY_TOPICS = defaultdict(list)
for topic, activities in TOPIC_ACTIVITIES.items():
    for activity in activities:
        ACTIVITY_TOPICS[activity].append(topic)
# Common words of English and of the reader's own vocabulary are never read as a local name.
NAME = re.compile(r"^[^\W\d_][^\W\d_' -]{3,}(?:[ '-][^\W\d_]+){0,3}$")


def topics_of(activity):
    """"Cancer(Breast)" files under cancer; "Ache(Head)" is listed whole because the root says nothing."""
    return ACTIVITY_TOPICS.get(activity) or ACTIVITY_TOPICS.get(activity.split('(')[0], [])


def place_group(place):
    """"Mexico(Seri)" and "Mexico" are one country; the bracket still names who reported it."""
    return place.split('(')[0].strip()


class IndependentUse:
    def __init__(self, path=PATH):
        self.available = path.exists()
        self.by_taxon, self.by_name, self.names = {}, {}, defaultdict(dict)
        self.topic_records, self.total_records = Counter(), 0
        self.genera, self.chemistry = defaultdict(list), None
        self.citation = None
        if not self.available:
            return
        body = read_json(path)
        self.citation = {'doi': body['doi'], 'url': f"https://doi.org/{body['doi']}", 'licence': body['licence']}
        for taxon in body['taxa']:
            topics = defaultdict(list)
            for record in taxon['records']:
                for topic in topics_of(record[0]):
                    topics[topic].append(record)
                name = normalize(record[2])
                if NAME.fullmatch(record[2]):
                    self.names[name].setdefault(taxon['id'], {'id': taxon['id'], 'name': taxon['name'], 'family': taxon['family'], 'records': 0, 'places': set(), 'printed': record[2], 'reference': record[3]})
                    entry = self.names[name][taxon['id']]
                    entry['records'] += 1
                    entry['places'] |= {record[1]} if record[1] else set()
            self.topic_records.update({topic: len(rows) for topic, rows in topics.items()})
            self.total_records += len(taxon['records'])
            row = {'id': taxon['id'], 'name': taxon['name'], 'records': len(taxon['records']), 'topics': dict(topics), 'poison_records': sum(r[0].startswith('Poison') for r in taxon['records'])}
            self.by_taxon[taxon['id']] = row
            self.by_name[taxon['name']] = row
            self.genera[taxon['name'].split()[0]].append(row)

    def plant(self, taxon):
        return self.by_taxon.get(taxon['id']) or self.by_name.get(taxon['name']) if self.available else None

    def reach(self, taxon, condition_id):
        """Records of one plant under one topic. None means the database says nothing either way."""
        row = self.plant(taxon)
        records = (row or {}).get('topics', {}).get(condition_id.replace('condition:', ''))
        if not records:
            return None
        places = Counter(place_group(r[1]) for r in records if r[1])
        return {'records': len(records), 'places': len(places), 'place_names': [p for p, _ in places.most_common(8)], 'activities': [a for a, _ in Counter(r[0] for r in records).most_common(4)], 'references': [r for r, _ in Counter(r[3] for r in records if r[3]).most_common(3)], 'source': self.citation}

    def relatives(self, taxon, condition_id):
        """Sister species used for the same thing: unrelated peoples converging on one lineage
        predicts bioactivity better than any single report (Saslis-Lagoudakis et al., PNAS 2012)."""
        topic = condition_id.replace('condition:', '')
        name = taxon.get('name', '')
        kin = [r for r in self.genera.get(name.split()[0] if name else '', ()) if r['name'] != name and r['topics'].get(topic)]
        if not kin:
            return None
        places = {place_group(record[1]) for row in kin for record in row['topics'][topic] if record[1]}
        return {'species': len(kin), 'places': len(places), 'names': [r['name'] for r in sorted(kin, key=lambda r: -len(r['topics'][topic]))[:3]]}

    def constituents(self, taxon, condition_id):
        """Distinctive chemicals with a recorded activity on this topic, in any assay and dose."""
        if self.chemistry is None:
            self.chemistry = {row['id']: row['topics'] for row in read_json(CHEMISTRY)['taxa']} if CHEMISTRY.exists() else {}
        found = self.chemistry.get(taxon.get('id'), {}).get(condition_id.replace('condition:', ''))
        if not found:
            return None
        return {'count': found['count'], 'rarest': [{'chemical': c.replace('-', ' ').capitalize(), 'activity': a} for c, a in found['rarest']], 'source': self.citation}

    def recorded_poisonous(self, taxon):
        """Three reports of poisoning are enough to put a safety warning before any research lead."""
        return (self.plant(taxon) or {}).get('poison_records', 0) >= 3

    def characteristic(self, taxon, condition_id):
        """Is this use typical of the plant? A much-recorded plant has a record of nearly everything."""
        row = self.plant(taxon)
        topic = condition_id.replace('condition:', '')
        records = len((row or {}).get('topics', {}).get(topic, ()))
        if records < 2 or not self.topic_records[topic]:
            return False
        return records / row['records'] >= 1.5 * self.topic_records[topic] / self.total_records


_shared = None


def independent_use():
    global _shared
    if _shared is None:
        _shared = IndependentUse()
    return _shared

"""Identity counterfactuals: what changes downstream if a name refers to another taxon.

For every historical name with candidates, each candidate is a branch. Branches are
compared on the evidence they retrieve, the designs and blocking checks behind it,
and the papers that only one branch reaches. A single-answer view is reconstructed so
the reader can see what it would silently drop.
"""
from __future__ import annotations

from collections import Counter

from src.nlp.extract import normalize


def name_groups(result):
    """Collapse repeated mentions of one name; keep every occurrence span."""
    groups = {}
    resolutions = {r["mention_id"]: r for r in result["resolutions"]}
    for mention in result["mentions"]:
        resolution = resolutions.get(mention["id"])
        if not resolution:
            continue
        name = mention.get("heading_name") or mention.get("lookup") or mention["text"]
        key = normalize(name).replace("camomile", "chamomile").replace("featherfew", "feverfew")
        # The names of one list that reach one plant are one question for the reader.
        listed = mention.get("list_id", mention.get("listed_in"))
        if listed is not None and len(resolution["candidates"]) == 1:
            key = f"list-{listed}-{resolution['candidates'][0]['taxon_id']}"
        group = groups.setdefault(key, {"key": key, "label": mention.get("heading_name") or mention["text"], "forms": mention.get("forms", []), "mention_ids": [], "occurrences": [], "status": resolution["status"], "candidates": resolution["candidates"], "open_world": resolution.get("open_world_alternatives", [])})
        group["mention_ids"].append(mention["id"])
        group.setdefault("source_names", []).extend(n for n in resolution.get("source_names", []) if n["name"] not in {x["name"] for x in group["source_names"]})
        group["occurrences"].append({"start": mention["start"], "end": mention["end"], "text": mention["text"]})
    for group in groups.values():
        names = list(dict.fromkeys(o["text"] for o in group["occurrences"]))
        if group["key"].startswith("list-") and len(names) > 1:
            group["label"] = f"{names[0]} and {len(names) - 1} more listed name{'s' if len(names) > 2 else ''}"
    claim_conditions = {}
    for claim in result["historical_claims"]:
        if claim.get('statement_role') != 'THERAPEUTIC_USE_RECORDED':
            continue
        for mention_id in claim["mention_ids"]:
            claim_conditions.setdefault(mention_id, set()).update(c["id"] for c in claim["conditions"])
    for group in groups.values():
        group["conditions"] = sorted({c for m in group["mention_ids"] for c in claim_conditions.get(m, set())})
        group["claim_ids"] = [c["id"] for c in result["historical_claims"] if set(c["mention_ids"]) & set(group["mention_ids"])]
    return list(groups.values())


def heading_forms(group):
    return group.get("forms") or []


def species_named(row):
    """Identity check status; None when the record was never screened (legacy analyses)."""
    check = next((c for c in (row.get("comparability") or {}).get("checks", []) if c["check"] == "identity"), None)
    return None if check is None else check["status"] == "PASS"


def blocking_key(row):
    """No blocking check is not a pass: partial or unknown checks are counted separately."""
    screen = row.get("comparability") or {}
    if screen.get("first_blocking_check"):
        return screen["first_blocking_check"]
    return "NONE_UNRESOLVED" if any(c["status"] != "PASS" for c in screen.get("checks", [])) else "NONE"


def branch_state(rows):
    if not rows:
        return "NO_EVIDENCE_IN_SNAPSHOT"
    if any(species_named(r) is None for r in rows):
        return "COMPARABILITY_NOT_ASSESSED"
    if not any(species_named(r) for r in rows):
        return "COMMON_NAME_ONLY_EVIDENCE"
    if any(r["relation"]["relation"] in ("SUPPORTS", "CONTRADICTS", "MIXED") for r in rows):
        return "SPECIES_SPECIFIC_FINDINGS"
    return "SPECIES_SPECIFIC_BUT_INSUFFICIENT"


def summarize_branch(candidate, rows):
    species = [r for r in rows if species_named(r)]
    return {
        "taxon_id": candidate["taxon_id"],
        "name": candidate["name"],
        "score": candidate["score"],
        "reasons": candidate["reasons"],
        "evidence_ids": [r["id"] for r in rows],
        "papers": sorted({r["paper"]["id"] for r in rows}),
        "species_specific_papers": sorted({r["paper"]["id"] for r in species}),
        "designs": dict(Counter(t for r in {r["paper"]["id"]: r for r in rows}.values() for t in r["study"]["types"])),
        "relations": dict(Counter(r["relation"]["relation"] for r in rows)),
        "blocking_checks": dict(Counter(blocking_key(r) for r in rows)),
        "reported_findings": dict(Counter((r["relation"].get("reported_finding") or {}).get("direction", "NO_RESULT_STATEMENT") for r in rows)),
        "state": branch_state(rows),
    }


def counterfactuals(result):
    out = []
    for group in name_groups(result):
        candidates = group["candidates"]
        if not candidates:
            out.append({**{k: group[k] for k in ("key", "label", "forms", "status", "mention_ids", "occurrences", "conditions", "claim_ids", "open_world", "source_names")}, "branches": [], "sensitivity": "NO_CANDIDATE", "single_answer_view": None, "pairs": []})
            continue
        branches = []
        for candidate in candidates:
            rows = [e for e in result["evidence"] if e["taxon_id"] == candidate["taxon_id"] and e["condition_id"] in group["conditions"]]
            branches.append(summarize_branch(candidate, rows))
        pairs = []
        for i, a in enumerate(branches):
            for b in branches[i + 1:]:
                pa, pb = set(a["papers"]), set(b["papers"])
                union = pa | pb
                pairs.append({"a": a["taxon_id"], "b": b["taxon_id"], "shared_papers": sorted(pa & pb), "only_a": sorted(pa - pb), "only_b": sorted(pb - pa), "jaccard": round(len(pa & pb) / len(union), 3) if union else None, "state_changes": a["state"] != b["state"]})
        top = branches[0]
        tie = len(candidates) > 1 and candidates[0]["score"] == candidates[1]["score"]
        hidden = [b for b in branches[1:]]
        union_papers = set().union(*(set(b["papers"]) for b in branches))
        union_species = set().union(*(set(b["species_specific_papers"]) for b in branches))
        other_species = set().union(set(), *(set(b["species_specific_papers"]) for b in hidden))
        # Papers the top branch reaches only through the shared common name, although they name another candidate.
        misattributed = sorted((set(top["papers"]) & other_species) - set(top["species_specific_papers"]))
        states = {b["state"] for b in branches}
        if len(branches) == 1 and not group["open_world"]:
            sensitivity = "SINGLE_CANDIDATE_IN_SNAPSHOT"
        elif len(branches) == 1:
            sensitivity = "OPEN_WORLD_ALTERNATIVES_NOT_RETRIEVED"
        elif len(states) > 1:
            sensitivity = "CONCLUSION_CHANGES_WITH_IDENTITY"
        elif any(p["only_a"] or p["only_b"] for p in pairs):
            sensitivity = "EVIDENCE_SET_CHANGES_WITH_IDENTITY"
        else:
            sensitivity = "STABLE_ACROSS_CANDIDATES"
        single = {
            "taxon_id": top["taxon_id"],
            "name": top["name"],
            "tie_broken_arbitrarily": tie,
            "selection_note": "Top candidate tied with the next; a single-answer system would pick by sort order" if tie else "Highest ranking feature; not a probability",
            "hidden_branches": [b["taxon_id"] for b in hidden],
            "hidden_papers": sorted(union_papers - set(top["papers"])),
            "hidden_species_specific_papers": sorted(union_species - set(top["species_specific_papers"]) - set(top["papers"])),
            "misattributed_papers": misattributed,
            "shown_papers": len(top["papers"]),
            "would_state": top["state"],
            "misleading_if": "Shown without the alternative branches" if len(branches) > 1 or group["open_world"] else None,
        }
        out.append({**{k: group[k] for k in ("key", "label", "forms", "status", "mention_ids", "occurrences", "conditions", "claim_ids", "open_world", "source_names")}, "branches": branches, "pairs": pairs, "sensitivity": sensitivity, "single_answer_view": single})
    return out

"""What the EMA herbal committee concluded for a plant and topic.

Shown beside the reading and never fed into it, so the committee's verdict stays an independent
check on the product. Traditional use is a regulatory class resting on long use; it is not a
finding that a plant does nothing.
"""
from __future__ import annotations

import re
from collections import defaultdict

from src.common import DATA, read_json

PATH = DATA / 'ema_herbal.json'
TOPIC_WORDING = {
    'sleep': r'sleep',
    'anxiety': r'mental stress|nervous tension|anxiety|stress',
    'depression': r'depressi|low mood',
    'digestive_symptoms': r'dyspep|digest|gastrointestinal|flatulen|bloating|stomach|irritable bowel|gastric|spasm',
    'diarrhoea': r'diarrh',
    'constipation': r'constipation',
    'nausea_vomiting': r'nausea|motion sickness|vomit',
    'cough': r'cough|expectorant|catarrh',
    'respiratory': r'\bcolds?\b|bronch|respiratory|sinus',
    'oral_throat_care': r'\bmouth\b|throat|\bgums?\b|\boral\b|pharyng',
    'wounds': r'wound|\bulcers?\b',
    'skin': r'\bskin\b|eczema|dermat|\bboils?\b|acne|itch',
    'burns': r'sunburn|\bburns?\b',
    'urinary': r'urinary|prostat|micturition|bladder',
    'kidney_stones': r'renal gravel|\bgravel\b',
    'menstrual': r'menstrua|menopaus|dysmenorrh|climacteric',
    'heart': r'cardiac|\bheart\b',
    'pain': r'\bpain\b|\baches?\b',
    'joint_gout': r'\bjoint|rheumat|arthr',
    'headache': r'headache',
    'haemorrhoids': r'h(?:a)?emorrhoid',
    'liver_jaundice': r'\bliver\b|\bbile\b|hepat',
    'memory_cognition': r'cognitive|dementia|memory',
}
PATTERNS = {topic: re.compile(wording, re.I) for topic, wording in TOPIC_WORDING.items()}


# "Chronic venous insufficiency, which is characterised by itching and pain": the words after
# "which" describe the condition and are not separate indications.
DESCRIPTION = re.compile(r',?\s+(?:which is|characterised by|such as).*$', re.I)
TOO_BROAD = {'passion', 'arctic', 'cherry', 'lime', 'rose', 'mallow', 'birch', 'wild strawberry'}
DRUG_PART = re.compile(r'\s+(?:leaf|leaves|root|herb|flower|fruit|seed|bark|oil|distillate|rhizome|cone berry|stalks|pods?)(?:\s+and\s+flower)?$', re.I)


def topics_in(indication):
    wording = DESCRIPTION.sub('', indication)
    return [topic for topic, pattern in PATTERNS.items() if pattern.search(wording)]


def drug_name(common):
    """Trials say "senna" or "psyllium" and not the species: "Psyllium seed" gives the word they use."""
    whole = re.sub(r'^(?:fresh|dried)\s+', '', common.split(',')[0].strip(), flags=re.I)
    short = DRUG_PART.sub('', whole)
    return whole if short.casefold() in TOO_BROAD else short


class Regulatory:
    def __init__(self, path=PATH):
        self.available = path.exists()
        self.by_taxon = defaultdict(dict)
        self.drug_names = defaultdict(set)
        if not self.available:
            return
        for plant in read_json(path)['plants']:
            for species in plant.get('species', []):
                if len(drug_name(plant['common'])) >= 5 and 'combination' not in plant['common'].casefold():
                    self.drug_names[species['id']] |= {drug_name(plant['common']), drug_name(plant['common']).replace('-', ' ')}
                for row in plant['indications']:
                    for topic in topics_in(row['indication']):
                        held = self.by_taxon[species['id']].get(topic)
                        # A monograph may hold both classes; the one needing trials is reported.
                        if not held or (row['class'] == 'WELL_ESTABLISHED' and held['class'] != row['class']):
                            self.by_taxon[species['id']][topic] = {'class': row['class'], 'indication': row['indication'], 'url': plant['url'], 'substance': plant['latin']}

    def conclusion(self, taxon_id, condition_id):
        return self.by_taxon.get(taxon_id, {}).get(condition_id.replace('condition:', ''))


_shared = None


def regulatory():
    global _shared
    if _shared is None:
        _shared = Regulatory()
    return _shared

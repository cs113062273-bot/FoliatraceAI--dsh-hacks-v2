"""Source-scoped clarification, product/study comparison and selective sharing.

These views never certify product contents or translate study signals into advice.
"""
from __future__ import annotations

import copy
import hashlib
from html import escape
from typing import Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, model_validator

from src.common import now
from src.evidence.question_review import canonical
from src.evidence.consultation_summary import handoff_summary, SCOPE
from src.nlp.extract import normalize


class ClarificationAnswer(BaseModel):
    model_config = ConfigDict(extra='forbid')
    item_id: str = Field(pattern=r'^[a-f0-9]{12,32}$')
    field: str = Field(min_length=1, max_length=80)
    status: Literal['ANSWER_RECORDED', 'ASK_PROFESSIONAL']
    note: str = Field(min_length=5, max_length=2000)
    source: Literal['PERSON_REPORTED', 'PACKAGING_REPORTED', 'PROFESSIONAL_NOTE']
    recorded_by: str = Field(min_length=1, max_length=80)

    @model_validator(mode='after')
    def substantive(self):
        if len(self.note.strip()) < 5 or not self.recorded_by.strip():
            raise ValueError('Record an answer or next question and who recorded it')
        return self


def validate_clarifications(packet):
    entries = packet.get('clarification_history', [])
    if not isinstance(entries, list) or len(entries) > 500:
        raise ValueError('Clarification history must contain at most 500 entries')
    products = {i['reported']['item_id']: i for i in packet['products']}
    for entry in entries:
        answer = ClarificationAnswer.model_validate({k: v for k, v in entry.items()
                                                    if k not in ('created_at', 'source_item_sha256')})
        item = products.get(answer.item_id)
        if item is None or entry.get('source_item_sha256') != item['item_sha256']:
            raise ValueError('Clarification belongs to another product version')
        if answer.field not in {q['field'] for q in item['clarification_questions']}:
            raise ValueError('Clarification does not match an original question')
        if not isinstance(entry.get('created_at'), str) or not entry['created_at']:
            raise ValueError('Clarification date is missing')


def add_clarification(record, answer):
    if record['origin'] != 'LOCAL_CONSULTATION_PREPARATION':
        raise ValueError('Imported records remain unverified; prepare a new local record first')
    packet = copy.deepcopy(record['packet'])
    item = next((i for i in packet['products'] if i['reported']['item_id'] == answer.item_id), None)
    if item is None or answer.field not in {q['field'] for q in item['clarification_questions']}:
        raise ValueError('Choose a clarification from this saved product')
    packet.setdefault('clarification_history', []).append({**answer.model_dump(), 'created_at': now(),
                                                         'source_item_sha256': item['item_sha256']})
    packet['created_at'] = now()
    validate_clarifications(packet)
    return packet


def review_context(record, review, item_id, ingredient_key=None):
    """One source-binding rule shared by comparison and evidence attachment."""
    if record['origin'] != 'LOCAL_CONSULTATION_PREPARATION' or review['origin'] != 'LOCAL_QUESTION_REVIEW':
        raise ValueError('Imported records must be rerun locally before creating a current evidence link')
    item = next((i for i in record['packet']['products'] if i['reported']['item_id'] == item_id), None)
    if item is None:
        raise ValueError('This product is not in the saved preparation')
    label = item['reported'].get('label_snapshot')
    ingredient = None
    if label:
        ingredient = next((r for r in item.get('label_ingredients', []) if r['key'] == ingredient_key), None)
        if ingredient is None:
            raise ValueError('Select the specific label ingredient before linking evidence')
        expected_name, expected_source = ingredient.get('research_lookup') or ingredient['lookup'], ingredient['review_source_text']
        candidates = ingredient['candidates']
    else:
        if ingredient_key is not None:
            raise ValueError('A manually recorded product has no attached label ingredient')
        expected_name, expected_source = item['name_lookup'], item['reported']['source_text']
        candidates = item['candidates']
    protocol = review['packet']['protocol']
    if normalize(protocol['plant_name']) != normalize(expected_name):
        raise ValueError('Evidence question name differs from this product or label ingredient')
    if protocol['source_text'] != expected_source:
        raise ValueError('The evidence question source differs from this product record; open a question from the saved product')
    taxa = {c['taxon_id'] for c in candidates}
    branches = {b['taxon_id'] for b in review['packet']['branches']}
    if not branches or not branches <= taxa:
        raise ValueError('The evidence question does not stay within this product\'s candidate identities')
    return item, ingredient


def study_bridge(record, review, item_id, record_id, ingredient_key=None):
    item, ingredient = review_context(record, review, item_id, ingredient_key)
    selected = [(b, r) for b in review['packet']['branches'] for r in b['records'] if r['id'] == record_id]
    if len(selected) != 1:
        raise ValueError('Choose a study from this evidence question')
    branch, row = selected[0]
    checks = {c['check']: c for c in row['screening']['checks']}
    reported = item['reported']
    protocol = review['packet']['protocol']
    dims = []
    def add(key, label, product, requested, check=None, caution=''):
        found = checks.get(check or key)
        dims.append({'key': key, 'label': label, 'product': product or 'Not provided',
                     'question_requirement': requested or 'Not specified',
                     'status': found['status'] if found else 'UNKNOWN',
                     'detail': found['detail'] if found else caution or 'Not established in the available study checks.',
                     'caution': caution, 'spans': found.get('spans', []) or ([found['span']] if found and found.get('span') else []) if found else []})
    add('identity', 'Plant identity', ingredient['name'] if ingredient else item['name_lookup'],
        branch['name'], caution='A study naming this candidate does not identify the contents of the bottle.')
    add('preparation', 'Form and preparation', reported['preparation'], protocol['preparation'],
        caution='A capsule is a product form, not proof of its extraction method or equivalence to a trial formulation.')
    add('amount', 'Actual amount and dose', reported['dose'], 'No equivalent-dose inference',
        caution='The reported amount is preserved. Dose, extract strength, serving basis and study dose have not been matched.')
    add('population', 'Study population', 'Individual clinical circumstances not assessed', protocol['population'],
        caution='Human-study signals do not establish applicability to this person.')
    add('single_plant', 'Single plant or mixture', 'Label formula retained' if ingredient else 'Complete formula not verified',
        protocol['intervention'], caution='A constituent finding cannot establish the effect of the whole commercial product.')
    add('comparator', 'Comparison group', 'Not a product characteristic', protocol['comparator'])
    add('requested_outcome', 'Outcome being investigated', reported['reason_for_use'], '; '.join(protocol['outcome_terms']),
        caution='Shared outcome wording is a reading lead, not a finding of benefit.')
    label = reported.get('label_snapshot')
    return {'schema': 'foliatrace-product-study-bridge-1', 'product_name': reported['name'],
            'product_sha256': item['item_sha256'], 'consultation_id': record['id'], 'review_id': review['id'],
            'record_id': row['id'], 'candidate': branch['name'], 'ingredient': ingredient['name'] if ingredient else None,
            'source_label': {'id': label['label_id'], 'url': label['source_url'], 'sha256': label['sha256']} if label else None,
            'paper': {k: row['paper'].get(k) for k in ('id', 'title', 'url')}, 'dimensions': dims,
            'unresolved': sum(d['status'] in ('UNKNOWN', 'PARTIAL') for d in dims),
            'scope_conflicts': [d['label'] for d in dims if d['status'] == 'FAIL'],
            'scope': 'Source comparison for professional reading. Product equivalence and clinical suitability are not established.'}


class ShareSelection(BaseModel):
    model_config = ConfigDict(extra='forbid')
    item_ids: list[str] = Field(default_factory=list, max_length=30)
    include_medicines: bool = False
    include_allergies: bool = False
    include_questions: bool = False
    include_reading: bool = False
    include_clarifications: bool = False


def share_projection(record, selection):
    """Build an allowlisted document. Omitted material never enters its payload."""
    packet = record['packet']
    products = {p['reported']['item_id']: p for p in packet['products']}
    if not selection.item_ids or len(set(selection.item_ids)) != len(selection.item_ids) or not set(selection.item_ids) <= products.keys():
        raise ValueError('Select one or more different products from this saved preparation')
    summary = handoff_summary(record)
    rows = {p['reported']['item_id']: s for p, s in zip(packet['products'], summary['products'])}
    result = {'schema': 'foliatrace-selected-handoff-1', 'title': 'Herbal-product conversation',
              'saved_at': record['saved_at'], 'origin': summary['origin'], 'scope': SCOPE,
              'sharing_scope': 'Selected information only. Omitted products, medicines or allergies must not be interpreted as absent.',
              'products': []}
    for key in selection.item_ids:
        # Explicit allowlist prevents future summary fields from becoming shared.
        fields = ('name','brand','use','actual_use','stated_preparation','reported_reason',
                  'source_text','label','ingredients','other_ingredients','clarifications')
        row = {field: copy.deepcopy(rows[key][field]) for field in fields}
        if selection.include_reading:
            row['reviews'] = copy.deepcopy(rows[key]['reviews'])
        if selection.include_clarifications:
            row['clarification_notes'] = [copy.deepcopy(n) for n in packet.get('clarification_history', []) if n['item_id'] == key]
        result['products'].append(row)
    if selection.include_medicines:
        result['other_medicines'] = {'status': summary['medicine_status'], 'details': summary['medicines']}
    if selection.include_allergies:
        result['allergies'] = {'status': summary['allergy_status'], 'details': summary['allergies']}
    if selection.include_questions:
        result['questions'] = summary['questions']
        result['next_questions'] = summary['next_questions']
    return result


def selected_html(projection):
    e = lambda v: escape(str(v), quote=True)
    def p(v): return '<p>'+e(v).replace('\n', '<br>')+'</p>'
    def h(v, level=2): return f'<h{level}>'+e(v)+f'</h{level}>'
    def link(url, title):
        try: parsed = urlsplit(url)
        except ValueError: return p(title)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname: return p(title)
        return '<p><a rel="noreferrer noopener" href="'+e(url)+'">'+e(title)+'</a></p>'
    out = ['<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
           '<title>FoliaTrace · Selected conversation handoff</title>',
           '<style>body{font:16px/1.55 system-ui;color:#193e32;max-width:780px;margin:36px auto;padding:0 24px}h1{font-size:32px}h2{margin-top:30px}p,li{overflow-wrap:anywhere}.scope{padding:16px;border:1px solid #d2ddd4;background:#f1f5ee}section{border-top:1px solid #d2ddd4;margin-top:24px;padding-top:12px}a{color:#17634c}small{color:#516258}@media print{body{font-size:10pt;margin:0}h2,h3{break-after:avoid}section{break-inside:auto}@page{size:A4;margin:15mm}}</style><body><main>',
           h('Your pharmacist conversation',1),p(projection['origin']),'<div class="scope">',p(projection['sharing_scope']),p(projection['scope']),'</div>',
           p('Prepared from saved information dated '+projection['saved_at'])]
    if 'questions' in projection:
        out += [h('Questions to discuss'), p(projection['questions'] or 'No additional question recorded')]
        out += [p(q) for q in projection.get('next_questions', [])]
    for key,title in [('other_medicines','Other medicines'),('allergies','Allergies / previous reactions')]:
        if key in projection: out += [h(title),p(projection[key]['status']),p(projection[key]['details'])]
    for row in projection['products']:
        out += ['<section>',h(row['name']),p(row['use']),p('Brand: '+(row['brand'] or 'Not provided'))]
        out += [p(k.replace('_',' ').capitalize()+': '+v) for k,v in row['actual_use'].items()]
        out += [p('Stated form: '+row['stated_preparation']),p('Reported reason: '+row['reported_reason'])]
        if row['label']:
            out += [link(row['label']['url'],'NIH label '+str(row['label']['id'])+' · bottle match not established'),h('Declared ingredients · not actual use',3)]
            for ing in row['ingredients']:
                out += [p(('Within blend: ' if ing['nested'] else '')+ing['name']+': '+('; '.join(ing['amounts']) or 'Individual amount not provided')),p(ing['forms']),p(ing['notes'])]
            other=row.get('other_ingredients') or {}
            out += [p('Other declared ingredients: '+(other.get('text') or '; '.join(i['name'] for i in other.get('ingredients',[])) or 'Not provided'))]
        else: out += [h('Original wording',3),p(row['source_text'] or 'Not provided')]
        out += [h('Still to clarify',3),'<ul>']+['<li>'+e(q)+'</li>' for q in row['clarifications']]+['</ul>']
        for note in row.get('clarification_notes',[]):
            out += [p(note['field']+' · '+note['status'].replace('_',' ').lower()+': '+note['note']),p('Source: '+note['source']+' · recorded by '+note['recorded_by']+' · '+note['created_at'])]
        for reading in row.get('reviews',[]):
            out += [h('Professional reading · not product approval',3),p(reading['question']),p(reading['coverage_note']),p(str(reading['unreviewed_records'])+' candidate/study records have no recorded human decision.')]
            if not reading['decisions']: out += [p('No human reading decision recorded.')]
            for decision in reading['decisions']:
                out += [link(decision['url'],decision['title']),p(decision['decision']+': '+decision['reason']),p('Recorded by: '+decision['reviewer'])]
        out += ['</section>']
    out += [p('Bring original packaging and the complete medicine list. This selected document is not a portable backup.'),'</main></body></html>']
    return '\n'.join(out)


def share_preview(record, selection):
    projection = share_projection(record, selection)
    return {'selection': selection.model_dump(), 'projection': projection,
            'sha256': hashlib.sha256(canonical(projection)).hexdigest(), 'html': selected_html(projection)}

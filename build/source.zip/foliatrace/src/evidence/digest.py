"""One readable line per plant and topic: what the human research in the snapshot reports.

Kept apart from the strict statement-level relation, which asks whether a study answers one
historical sentence. This asks what is known about the species and topic at all, so it reads
every paper naming both, not only the ones retrieved for the evidence table.
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict
from functools import lru_cache

from src.evidence.independent_use import independent_use
from src.evidence.regulatory import regulatory
from src.evidence.classify import animal_signal, study_sentences
from src.nlp.extract import LATIN_BINOMIAL, LATIN_EPITHET, RESEARCH_TERMS, SENSE_REQUIRED, normalize, research_terms, topic_pattern

HUMAN = {'CLINICAL_TRIAL', 'META_ANALYSIS', 'SYSTEMATIC_REVIEW', 'OBSERVATIONAL_HUMAN'}
SYNTHESIS = {'META_ANALYSIS', 'SYSTEMATIC_REVIEW'}
PRECLINICAL = {'IN_VITRO', 'IN_VIVO_ANIMAL'}
STATED = ('SUPPORTS', 'CONTRADICTS', 'MIXED', 'INSUFFICIENT')
DISPLAYED_STUDIES = 6
SYNTHESIS_WINDOW = 10

NOT_THE_PLANT = re.compile(r'\b(?:immunotherapy|allergen\w*|pollen allerg\w*|acupoint\w*|acupuncture|moxibustion|polyherbal|medicinal plants|plants? (?:used|for)|ethnobotan\w*|ethnomedicin\w*|phytochemi\w*|pharmacognos\w*|pre ?clinical|in vitro|animal (?:studies|models?)|\w+ induced (?:hyperalgesia|allodynia|flare|erythema))\b')
# Trial labels also cover livestock and fish: a randomized trout study is not a human study.
# Whether it harms or interacts is a different question from whether it works.
NOT_EFFICACY = re.compile(r'\b(?:adverse (?:events?|effects?|reactions?)|safety|toxicity|hepatotoxic\w*|pharmacokinetic\w*|interactions?|allerg\w*|poisoning|intoxication|case reports?)\b')
GENERAL_REVIEW = re.compile(r'\b(?:herbal|herbs?|botanicals?|natural|phytotherap\w*|phytomedicin\w*|nutraceuticals?|dietary supplements?|complementary|alternative|medicines?|remedies)\b')
# Who was studied, as opposed to what was measured: "dermatitis in patients with breast cancer".
POPULATION = re.compile(r'\b(?:(?:in|among|for|of|with)\s+(?:\w+\s+){0,4}?(?:patients?|women|men|adults|children|infants|subjects|survivors|people|individuals|volunteers|participants)\b|(?:during|undergoing|receiving|following)\b|\w+\s+patients\b).*$')
SUPPORTIVE_CARE = re.compile(r'\b(?:dermatitis|mucositis|stomatitis|xerostomia|nausea|vomiting|fatigue|neuropathy|hot (?:flash|flush)\w*|lymphedema|cachexia|radiation|radiotherapy|irradiation|(?:chemotherapy|radiotherapy|cancer|treatment)[ -](?:induced|related)|side effects)\b')
COMBINATION = re.compile(r'\b(?:plus|combin\w+|compound|formula\w*|mixture|herbal (?:tea|product|preparation|medicine)s?)\b|\+')
PREPARATION_WORDS = 'extracts?|oils?|roots?|leaf|leaves|flowers?|fruits?|berry|berries|seeds?|bark|herb|herbs|tea|tablets?|capsules?|cream|ointment|gel|tincture|syrup|species|for|in|and|on|as|with|of|the|versus|vs|or|to|preparations?|products?|supplements?|therapy|treatment|use|may|can|is|are|was|were|has|have|improves?|reduces?|does|did|not|spp'
OUTCOMES = None
HOLDERS = {}


def outcome_pattern():
    """Any topic wording, to tell a title with its own outcome from one naming only a population."""
    global OUTCOMES
    if OUTCOMES is None:
        OUTCOMES = topic_pattern(tuple(sorted({t for terms in RESEARCH_TERMS.values() for t in terms} | {'quality of life', 'cachexia', 'fatigue'})))
    return OUTCOMES


@lru_cache(maxsize=4096)
def strip_population(text):
    return POPULATION.sub('', text)


def targets_topic(text, pattern):
    """The topic is what the study measured, not only who took part."""
    if not pattern.search(text):
        return False
    remainder = strip_population(text)
    return bool(pattern.search(remainder)) or not outcome_pattern().search(remainder)


def name_pattern(names):
    return re.compile(r'\b(?:' + '|'.join(re.escape(name) for name in sorted(names, key=len, reverse=True)) + r')(?:s|es)?\b') if names else None


def on_subject(row, names, terms):
    """Counts as evidence for this plant and topic only if the study is about both.

    The plant must lead: in the title, or named repeatedly in an abstract whose title gives only a
    product code. The topic must be in the title or in the sentence reporting the result; elsewhere
    in the abstract it may be a secondary measure or a description of the participants.
    """
    title = normalize(row['paper']['title'])
    scientific = {normalize(n) for n in row.get('branch_scientific_names', ())}
    genera = {n.split()[0] for n in scientific}
    named_in_title = {normalize(n) for n in LATIN_BINOMIAL.findall(row['paper']['title']) if normalize(n).split()[0] in genera and LATIN_EPITHET.search(normalize(n).split()[-1]) and not re.fullmatch(PREPARATION_WORDS, normalize(n).split()[-1])}
    if named_in_title and not named_in_title & scientific:
        # A background mention of this species cannot inherit a study explicitly
        # titled for a different species of the same genus.
        return False
    if NOT_THE_PLANT.search(title):
        return False
    if NOT_EFFICACY.search(title) and not re.search(r'\b(?:efficacy|effectiveness)\b', title):
        return False
    wording = name_pattern(names)
    if not wording:
        return False
    absent = re.compile(r'\b(?:not (?:taking|receiving|using)|without|naive to|no (?:prior )?(?:use of|treatment with))\s+(?:' + '|'.join(re.escape(name) for name in names) + r')\b')
    if absent.search(title):
        return False
    finding = (row['relation'].get('reported_finding') or {}).get('supporting_text') or ''
    if not wording.search(title):
        # A title may give only a product code or another name; the abstract then has to name it.
        explicit_result = wording.search(normalize(finding)) and direction_of(row) in STATED
        focused_study = set(row['study']['types']) & ({'CLINICAL_TRIAL'} | SYNTHESIS) and (not GENERAL_REVIEW.search(title) or explicit_result)
        if not focused_study or not wording.search(normalize(row['paper']['abstract'])):
            return False
    pattern = topic_pattern(tuple(terms))
    if 'cancer' in terms and SUPPORTIVE_CARE.search(title):
        return False
    return targets_topic(title, pattern) or targets_topic(normalize(finding), pattern)


def combination(row, names, known):
    """Tested alongside another plant or as a mixture, so the result is not this plant's alone."""
    title = row['paper']['title']
    if COMBINATION.search(title.casefold()):
        return True
    other = {normalize(name) for name in re.findall(LATIN_BINOMIAL.pattern, title, re.I) if normalize(name) in known and normalize(name) not in names}
    if not other:
        return False
    # A title can name two separately tested ointments. An explicit allocation
    # to named preparation groups is evidence of separate arms, not a mixture.
    prep = r'(?:ointments?|extracts?|oils?|creams?|gels?|teas?|tinctures?|capsules?|tablets?)'
    own_form = re.compile(r'\b(?:' + '|'.join(re.escape(n) for n in names) + r')\s+' + prep + r'\b') if names else None
    other_form = re.compile(r'\b(?:' + '|'.join(re.escape(n) for n in other) + r')\s+' + prep + r'\b')
    allocation = re.compile(r'\b(?:two|2|three|3|four|4|separate|different)\s+(?:(?:active|case|treatment|intervention)\s+)?(?:groups|arms)\s+(?:including|receiv\w*|treated with)\b')
    for sentence in study_sentences(row['paper'].get('abstract') or ''):
        text = normalize(sentence['text'])
        match = allocation.search(text)
        if match and own_form and own_form.search(text[match.end():]) and other_form.search(text[match.end():]):
            return False
    return True


def direction_of(row):
    return (row['relation'].get('reported_finding') or {}).get('direction', 'NO_RESULT_STATEMENT')


def verdict(directions):
    """Favourable or not when two in three stated results agree; otherwise mixed or inconclusive."""
    positive, negative = directions['SUPPORTS'], directions['CONTRADICTS']
    uncertain = directions['MIXED'] + directions['INSUFFICIENT']
    stated = positive + negative + uncertain
    if not stated:
        return None
    if positive / stated >= 2 / 3:
        return 'HUMAN_FINDINGS_FAVOURABLE'
    if negative / stated >= 2 / 3:
        return 'HUMAN_NO_BENEFIT_REPORTED'
    return 'HUMAN_FINDINGS_MIXED'


def current_syntheses(rows):
    """An updated review replaces its earlier edition, and a decade-old synthesis no longer decides."""
    latest = {}
    for row in sorted(rows, key=lambda r: str(r['paper'].get('year') or 0)):
        latest[normalize(row['paper']['title'])] = row
    years = [int(str(r['paper'].get('year') or 0)[:4] or 0) for r in latest.values()]
    return [r for r, year in zip(latest.values(), years) if year >= max(years, default=0) - SYNTHESIS_WINDOW]


def unique_papers(rows):
    """Count records with the same DOI or PMID once, even across repositories."""
    seen, unique = set(), []
    for row in rows:
        paper = row['paper']
        keys = {('id', paper['id'])}
        doi = re.sub(r'^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)', '', str(paper.get('doi') or '').strip(), flags=re.I).casefold()
        if doi:
            keys.add(('doi', doi))
        pmid = paper.get('pmid') or (re.fullmatch(r'PMID(\d+)', str(paper['id']), re.I) or [None, None])[1]
        if pmid:
            keys.add(('pmid', str(pmid)))
        duplicate = bool(keys & seen)
        seen.update(keys)
        if not duplicate:
            unique.append(row)
    return unique


def synthesis_verdict(rows):
    """Conflicting reviews do not become independent majority votes for benefit."""
    labels = {direction_of(r) for r in rows} & set(STATED)
    if not labels:
        return None
    if labels == {'SUPPORTS'}:
        return 'HUMAN_FINDINGS_FAVOURABLE'
    if labels == {'CONTRADICTS'}:
        return 'HUMAN_NO_BENEFIT_REPORTED'
    return 'HUMAN_FINDINGS_MIXED'


def state_of(rows, names=(), terms=(), distinctive=(), known=frozenset()):
    """Reported direction across on-subject studies, by the strongest design that states one."""
    rows = unique_papers(rows)
    named = [r for r in rows if identified(r, distinctive)]
    focused = [r for r in named if on_subject(r, names, terms)]
    human = [r for r in focused if is_human(r)]
    isolated = [r for r in human if not combination(r, names, known)]
    # A broad review's explicitly attributed finding is evidence too. Its other
    # interventions have already been excluded by candidate/result screening.
    syntheses = [r for r in isolated if set(r['study']['types']) & SYNTHESIS]
    current = current_syntheses(syntheses)
    directions = Counter(direction_of(r) for r in human)
    isolated_directions = Counter(direction_of(r) for r in isolated)
    preclinical = [r for r in focused if set(r['study']['types']) & PRECLINICAL or animal_signal(r['paper']['title'])]
    basis = current if synthesis_verdict(current) else isolated
    basis_kind = 'CURRENT_SYNTHESES' if synthesis_verdict(current) else 'INDIVIDUAL_PLANT_STUDIES'
    if human:
        synthesised = synthesis_verdict(current)
        state = synthesised or verdict(isolated_directions) or 'HUMAN_STUDIED_RESULT_UNCLEAR'
        # Two small trials are a reason to look further, not a finding: Cochrane calls most such
        # records insufficient. "Favourable" needs a current synthesis or three favourable trials.
        favourable_trials = sum(direction_of(r) == 'SUPPORTS' and 'CLINICAL_TRIAL' in r['study']['types'] for r in isolated)
        if state == 'HUMAN_FINDINGS_FAVOURABLE' and not synthesised and favourable_trials < 3:
            state = 'HUMAN_FINDINGS_EARLY'
        if not isolated:
            basis_kind = 'COMBINATION_ONLY'
            basis = human
    elif preclinical:
        state = 'PRECLINICAL_ONLY'
    elif named:
        state = 'SPECIES_NAMED_NO_TESTED_RESULT'
    elif rows:
        state = 'COMMON_NAME_ONLY'
    else:
        state = 'NO_STUDY_RETRIEVED'
    if not human:
        basis_kind, basis = ('PRECLINICAL_ONLY', preclinical) if preclinical else ('NO_ELIGIBLE_HUMAN_RESULT', [])
    basis_directions = Counter(direction_of(r) for r in basis)
    assessment = {'kind': basis_kind, 'paper_ids': [r['paper']['id'] for r in basis],
                  'records': [{'paper_id':r['paper']['id'],'title':r['paper']['title'],'year':r['paper'].get('year'),'url':r['paper']['url'],'direction':direction_of(r),'design':r['study']['types']} for r in basis],
                  'directions': dict(basis_directions), 'review_window_years': SYNTHESIS_WINDOW,
                  'conflicting_results': bool(basis_directions['SUPPORTS'] and basis_directions['CONTRADICTS']),
                  'uncertain_results': bool(basis_directions['MIXED'] or basis_directions['INSUFFICIENT']),
                  'scope': 'Automated reading of retrieved abstracts for this species and topic. Reviews may share trials; their number is not a count of independent replications. Preparations, populations and endpoints can differ. Not a risk-of-bias appraisal or pooled effect estimate.'}
    return state, {'human_studies': len(human), 'isolated_plant_studies':len(isolated), 'syntheses': len(syntheses), 'preclinical_studies': len(preclinical), 'favourable': directions['SUPPORTS'], 'no_benefit': directions['CONTRADICTS'], 'mixed': directions['MIXED'] + directions['INSUFFICIENT'], 'publications': len(rows), 'assessment_basis': assessment}


def is_human(row):
    return bool(set(row['study']['types']) & HUMAN) and 'STUDY_PROTOCOL' not in row['study']['types'] and row['study'].get('population_status') != 'ANIMAL_TEXT_SIGNAL' and not animal_signal(row['paper']['title'])


def genus_alone(title, genus):
    """"Crataegus extract" means the leading species; "Crataegus pinnatifida" means another one."""
    return bool(re.search(rf'\b{genus}\b(?!\s+(?!(?:{PREPARATION_WORDS})\b)[a-z]{{3,}})', title))


def identified(row, distinctive):
    """A scientific name, or a common name that only this species holds in the snapshot."""
    if row.get('study_identity') == 'SCIENTIFIC_NAME':
        return True
    title = normalize(row['paper']['title'])
    if any(re.search(r'\b' + re.escape(name) + r'(?:s|es)?\b', title) for name in distinctive if ' ' in name or not name.istitle()):
        return True
    return any(genus_alone(row['paper']['title'], name) for name in distinctive if name.istitle())


def study_card(row, names, known):
    finding = row['relation'].get('reported_finding') or {}
    return {'paper_id': row['paper']['id'], 'title': row['paper']['title'], 'year': row['paper'].get('year'), 'url': row['paper']['url'], 'design': row['study']['types'], 'finding': finding.get('supporting_text'), 'finding_statements': finding.get('statements', []), 'direction': finding.get('direction'), 'combination': combination(row, names, known), 'identity': row.get('study_identity')}


def human_order(row):
    """Syntheses first, then trials; a stated result ahead of none; recent ahead of old."""
    types = set(row['study']['types'])
    return (0 if types & SYNTHESIS else 1 if 'CLINICAL_TRIAL' in types else 2, direction_of(row) not in STATED, -int(str(row['paper'].get('year') or 0)[:4] or 0))


def human_studies(rows, names, terms, distinctive):
    return sorted([r for r in unique_papers(rows) if identified(r, distinctive) and on_subject(r, names, terms) and is_human(r)], key=human_order)


def best_study(rows, names=(), terms=(), distinctive=(), known=frozenset()):
    """The strongest on-subject study that states a result; a review without one is not shown first."""
    human = [r for r in human_studies(rows, names, terms, distinctive) if direction_of(r) in STATED]
    if human:
        return study_card(human[0], names, known)
    focused = [r for r in rows if identified(r, distinctive) and on_subject(r, names, terms) and set(r['study']['types']) & PRECLINICAL]
    return study_card(max(focused, key=lambda r: (direction_of(r) in STATED, str(r['paper'].get('year')))), names, known) if focused else None


def common_name_holders(taxmap):
    """Who holds each English common name, rebuilt when an on-demand plant joins."""
    holders = defaultdict(set)
    for taxon in taxmap.values():
        for alias in taxon.get('aliases', []):
            if alias.get('lang', 'en') == 'en' and alias['kind'] in ('VERNACULAR', 'HISTORICAL_LEXICON'):
                holders[normalize(alias['name'])].add(taxon['id'])
    return holders, frozenset(normalize(t['name']) for t in taxmap.values())


def outside_knowledge(taxon, condition_id):
    """What other sources say beside the studies. None of it can change a stated direction."""
    records = independent_use()
    return {'independent_use': records.reach(taxon, condition_id), 'relatives': records.relatives(taxon, condition_id), 'constituents': records.constituents(taxon, condition_id), 'recorded_poisonous': records.recorded_poisonous(taxon), 'regulatory': regulatory().conclusion(taxon['id'], condition_id)}


def research_digest(result, taxmap=None, studies=None, literature_size=None):
    """Group studies by candidate and topic for the workspace summary and the evidence map."""
    taxmap = taxmap or {}
    sizes = literature_size or {}
    holders, known = common_name_holders(taxmap)
    genera = {normalize(t.get('name', '').split()[0]) for t in taxmap.values() if t.get('name')}

    def leads_name(taxon_id, name):
        """Literature volume never identifies a species holding an ambiguous name."""
        return holders[name] == {taxon_id}

    def leads_genus(taxon_id):
        # A genus-only paper leaves every species hypothesis open, including
        # genera for which the current snapshot happens to contain one species.
        return False

    def plant_names(taxon_id):
        aliases = (taxmap.get(taxon_id) or {}).get('aliases', [])
        drugs = {normalize(n) for n in (taxmap.get(taxon_id) or {}).get('drug_names', ()) if normalize(n) not in genera}
        genus = {normalize((taxmap.get(taxon_id) or {}).get('name', taxon_id)).split()[0]} if leads_genus(taxon_id) else set()
        return {normalize(a['name']) for a in aliases if a.get('lang', 'en') == 'en' and len(a['name']) >= 4 and a['kind'] != 'INPUT_SYNONYM_MATCH' and normalize(a['name']) not in genera} | {normalize((taxmap.get(taxon_id) or {}).get('name', taxon_id))} | genus | drugs

    def distinctive_names(taxon_id):
        aliases = (taxmap.get(taxon_id) or {}).get('aliases', [])
        genus = {(taxmap.get(taxon_id) or {}).get('name', taxon_id).split()[0]} if leads_genus(taxon_id) else set()
        return {normalize(a['name']) for a in aliases if a.get('lang', 'en') == 'en' and a['kind'] in ('VERNACULAR', 'HISTORICAL_LEXICON') and len(a['name']) >= 4 and normalize(a['name']) not in SENSE_REQUIRED | genera and leads_name(taxon_id, normalize(a['name']))} | genus | {normalize(n) for n in (taxmap.get(taxon_id) or {}).get('drug_names', ()) if normalize(n) not in genera}

    names = {c['taxon_id']: c['name'] for r in result['resolutions'] for c in r['candidates']}
    labels = {c['id']: c['label'] for c in result['conditions']}
    statements = Counter()
    for claim in result['historical_claims']:
        if claim['statement_role'] == 'THERAPEUTIC_USE_RECORDED' and not claim.get('negated') and claim.get('practice') != 'NON_PLANT_REMEDY':
            for condition in {c['id'] for c in claim['conditions']}:
                statements[condition] += 1
    rows = []
    for taxon_id in dict.fromkeys(e['taxon_id'] for e in result['evidence']):
        wording, distinctive = plant_names(taxon_id), distinctive_names(taxon_id)
        for condition_id in dict.fromkeys(e['condition_id'] for e in result['evidence'] if e['taxon_id'] == taxon_id):
            group = studies(taxon_id, condition_id) if studies else [e for e in result['evidence'] if e['taxon_id'] == taxon_id and e['condition_id'] == condition_id]
            terms = research_terms(condition_id)
            state, counts = state_of(group, wording, terms, distinctive, known)
            listed = [study_card(r, wording, known) for r in human_studies(group, wording, terms, distinctive)]
            rows.append({'taxon_id': taxon_id, 'taxon': names.get(taxon_id, taxon_id), 'condition_id': condition_id, 'topic': labels.get(condition_id, condition_id), 'state': state, **outside_knowledge(taxmap.get(taxon_id) or {'id': taxon_id, 'name': names.get(taxon_id, taxon_id)}, condition_id), **counts, 'historical_statements': statements[condition_id], 'best_study': best_study(group, wording, terms, distinctive, known), 'studies': listed[:DISPLAYED_STUDIES], 'combination_only': bool(listed) and all(s['combination'] for s in listed)})
    weight = {'HUMAN_FINDINGS_FAVOURABLE': 0, 'HUMAN_FINDINGS_EARLY': 1, 'HUMAN_FINDINGS_MIXED': 1, 'HUMAN_NO_BENEFIT_REPORTED': 2, 'HUMAN_STUDIED_RESULT_UNCLEAR': 3, 'PRECLINICAL_ONLY': 4, 'SPECIES_NAMED_NO_TESTED_RESULT': 5, 'COMMON_NAME_ONLY': 6}
    rows.sort(key=lambda r: (weight.get(r['state'], 9), -r['human_studies'], -r['historical_statements']))
    return rows


def topic_digest(pipeline, taxon, condition_id):
    """The same reading for a plant and topic outside any chapter, used by evaluation."""
    fake = {'resolutions': [{'candidates': [{'taxon_id': taxon['id'], 'name': taxon['name']}]}], 'conditions': [{'id': condition_id, 'label': condition_id}], 'historical_claims': [], 'evidence': [{'taxon_id': taxon['id'], 'condition_id': condition_id}]}
    return research_digest(fake, pipeline.taxmap, pipeline.topic_studies, pipeline.literature_size)[0]

from __future__ import annotations

from collections import Counter
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from src.common import ROOT
from .classify import META_TYPES


def metadata_label(paper):
    types = paper.get("publication_types", [])
    for key in ["Meta-Analysis", "Systematic Review", "Randomized Controlled Trial", "Clinical Trial", "Clinical Trial, Phase III", "Clinical Trial, Phase II", "Review"]:
        if key in types:
            return META_TYPES[key]
    return None


class StudyModel:
    def __init__(self, model=None):
        self.model = model

    def fit(self, papers):
        rows = [(p["title"] + " " + p["abstract"], metadata_label(p)) for p in papers if metadata_label(p)]
        counts = Counter(y for _, y in rows)
        allowed = {k for k, n in counts.items() if n >= 3}
        rows = [(x, y) for x, y in rows if y in allowed]
        if len(allowed) < 2:
            return {"trained": False, "reason": "Fewer than two adequately supported metadata-labelled classes", "counts": dict(counts)}
        self.model = make_pipeline(TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_features=15000, sublinear_tf=True), LogisticRegression(max_iter=1500, class_weight="balanced", random_state=20261102))
        self.model.fit([x for x, y in rows], [y for x, y in rows])
        return {"trained": True, "n": len(rows), "counts": dict(Counter(y for _, y in rows)), "label_tier": "SILVER_PUBLICATION_METADATA", "model": "TFIDF_LOGISTIC_REGRESSION", "seed": 20261102}

    def predict(self, text):
        if self.model is None:
            return {"label": "NOT_TRAINED", "used": False}
        values = self.model.predict_proba([text])[0]
        idx = int(values.argmax())
        # No probabilities displayed or claimed calibrated. This threshold is a
        # disclosed abstention heuristic, not an empirical confidence guarantee.
        return {"label": str(self.model.classes_[idx]), "used": bool(values[idx] >= .6), "selection_rule": "internal logistic score >=0.6; uncalibrated; no probability display", "version": "tfidf-logreg-0.2"}

    def save(self, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix('.tmp')
        joblib.dump(self.model, temporary)
        temporary.replace(path)

    @classmethod
    def load(cls, path):
        # Only load application-created local model, never uploaded pickle files.
        return cls(joblib.load(path)) if path.exists() else cls()

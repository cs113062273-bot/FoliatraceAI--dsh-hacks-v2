"""Stable JSON numbers for newly generated records crossing Python and browser JSON."""
import math

MAX_SAFE_INTEGER=2**53-1


def portable_numbers(value):
    if value is None or isinstance(value,(str,bool)):
        return value
    if isinstance(value,int):
        if abs(value)>MAX_SAFE_INTEGER:raise ValueError('A source number exceeds the exact browser JSON integer range; record its original wording manually')
        return value
    if isinstance(value,float):
        if not math.isfinite(value):raise ValueError('Non-finite source numbers cannot be exported as portable JSON')
        if value.is_integer():
            return portable_numbers(int(value))
        return value
    if isinstance(value,(list,tuple)):return [portable_numbers(v) for v in value]
    if isinstance(value,dict):return {k:portable_numbers(v) for k,v in value.items()}
    raise ValueError('Unsupported portable JSON value')

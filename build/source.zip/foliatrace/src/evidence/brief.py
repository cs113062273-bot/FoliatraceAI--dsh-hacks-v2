"""Research hand-off derived from active records, never an efficacy recommendation.

No new scientific inference is made here. Every reading-list entry points to an
existing evidence record; review decisions annotate rather than rewrite it.
"""
from collections import Counter
import re
from urllib.parse import urlsplit, quote
from src.evidence.readings import active_reading_sets


def research_brief(result):
    reviews = {(r['target_kind'], r['target_id']): r for r in result.get('researcher_reviews', [])}
    names = []
    for group in result.get('identity_counterfactuals', []):
        candidates = [{
            'taxon_id': b['taxon_id'], 'name': b['name'],
            'review': reviews.get(('identity', f"{group['key']}::{b['taxon_id']}")),
        } for b in group['branches']]
        accepted = [c for c in candidates if (c['review'] or {}).get('decision') == 'ACCEPT']
        state = ('CONFLICTING_ACCEPTS' if len(accepted) > 1 else
                 'ONE_ACCEPT_RECORDED' if accepted else 'IDENTITY_REVIEW_NEEDED')
        ids = {eid for b in group['branches'] for eid in b['evidence_ids']}
        rows = [e for e in result['evidence'] if e['id'] in ids]
        claims = [c for c in result['historical_claims'] if c['id'] in group['claim_ids']]
        actions = []
        if not candidates:
            actions.append({'kind': 'EXPAND_IDENTITY_SEARCH', 'text': 'Look beyond the bundled taxonomy snapshot. No candidate here does not mean the historical plant is unknown.', 'evidence_ids': []})
        elif state == 'CONFLICTING_ACCEPTS':
            actions.append({'kind': 'RECONCILE_IDENTITY_REVIEWS', 'text': 'More than one candidate is accepted. Check whether the source names several plants or whether these reviews conflict; keep the branches separate.', 'evidence_ids': []})
        elif not accepted:
            actions.append({'kind': 'REVIEW_HISTORICAL_IDENTITY', 'text': 'Check the source description, edition and historical context against the candidate names. Record a judgement with a reason before attaching studies to this plant.', 'evidence_ids': []})
        else:
            actions.append({'kind': 'CHECK_RECORDED_IDENTITY', 'text': f"A researcher accepted {accepted[0]['name']}. Read the recorded reason; this judgement has not changed the automated results or established historical identity.", 'evidence_ids': []})
        if group['open_world']:
            actions.append({'kind': 'EXTEND_TAXON_COVERAGE', 'text': 'Investigate the additional GBIF name-sharing species below. Their studies were not retrieved; modern occurrence records do not establish the historical referent.', 'evidence_ids': []})
        uncertain = [c for c in claims if c.get('negated') or c.get('relation_scope') in ('MULTI_PLANT_CLAUSE_UNCERTAIN_RELATION', 'PARAGRAPH_CONTEXT_UNCERTAIN_RELATION')]
        if uncertain:
            actions.append({'kind': 'CHECK_SOURCE_CLAUSE', 'text': 'Re-read the marked clauses and surrounding paragraphs: negation, several plants or a change of subject may prevent assigning this use to one plant. Literature linked through an uncertain subject stays conditional on that reading.', 'claim_ids': [c['id'] for c in uncertain], 'evidence_ids': []})
        needs_identity = [e['id'] for e in rows if not any(c['check'] == 'identity' and c['status'] == 'PASS' for c in (e.get('comparability') or {}).get('checks', []))]
        if needs_identity:
            actions.append({'kind': 'VERIFY_STUDY_SPECIES', 'text': 'Verify the organism in the full text of the linked records. A shared common name or an unscreened record does not establish the study species.', 'evidence_ids': needs_identity})
        named = [e['id'] for e in rows if e['id'] not in needs_identity]
        if named:
            actions.append({'kind': 'APPRAISE_STUDY_SCOPE', 'text': 'Read the species-named studies and check population, intervention, preparation, outcome and study quality. Passing a lexical species check is not evidence of efficacy.', 'evidence_ids': named})
        if not rows or group['open_world'] or any(not b['evidence_ids'] for b in group['branches']):
            actions.append({'kind': 'SEARCH_BEYOND_SNAPSHOT', 'text': 'Search additional literature for the empty or uncovered candidate branches. This bundled snapshot is not a systematic review; no retrieved record is not a negative result.', 'evidence_ids': []})
        reading = []
        for e in rows:
            checks = (e.get('comparability') or {}).get('checks', [])
            reading.append({
                'evidence_id': e['id'], 'taxon_id': e['taxon_id'],
                'taxon_name': next(c['name'] for c in candidates if c['taxon_id'] == e['taxon_id']),
                'condition_id': e['condition_id'],
                'paper': {k: e['paper'].get(k) for k in ('id', 'title', 'url', 'year', 'licence')},
                'species_check': next((c['status'] for c in checks if c['check'] == 'identity'), 'NOT_ASSESSED'),
                'failed_checks': [c['check'] for c in checks if c['status'] == 'FAIL'],
                'unresolved_checks': [c['check'] for c in checks if c['status'] not in ('PASS', 'FAIL')],
                'screening': (e.get('comparability') or {}).get('screening', 'NOT_ASSESSED'),
                'final_relation': e['relation']['relation'],
                'historical_contexts': e.get('historical_contexts', []),
                'study_preparation': (e['study'].get('pico_source_spans') or {}).get('intervention_preparation'),
                'preparation_attribution': e['study'].get('preparation_attribution'),
                'methods_sources': [context for context in e['paper'].get('methods_contexts', []) if any((c.get('span') or {}).get('source_id') == context['id'] for c in checks) or context['id'] in e['study'].get('preparation_attribution', {}).get('methods_context_ids', [])],
                'reported_results': e['paper'].get('reported_results', []),
                'automated_endpoint_statements': (e['relation'].get('reported_finding') or {}).get('statements', []),
                'candidate_result_scope': {k:v for k,v in (e['relation'].get('reported_finding') or {}).items() if k in ('candidate_scope_note','unassigned_statements')},
                'comparison_notes': (e['relation'].get('reported_finding') or {}).get('comparison_notes', []),
                'review': reviews.get(('evidence', e['id'])),
            })
        # Triage only: species-named first, rejected last, then date. Not an evidence-quality score.
        reading.sort(key=lambda r: ((r['review'] or {}).get('decision') == 'REJECT', r['species_check'] != 'PASS', -int(r['paper'].get('year') or 0), r['evidence_id']))
        names.append({
            'key': group['key'], 'label': group['label'], 'status': group['status'],
            'source_names': [n['name'] for n in group.get('source_names', [])],
            'opening_name_clues': [clue for resolution in result.get('resolutions', []) if resolution['mention_id'] in group['mention_ids'] for clue in resolution.get('source_common_names', [])],
            'historical_identity_references': result.get('historical_identity_references', {}).get(group['key'], []),
            'identity_review_state': state, 'candidates': candidates,
            'source_claims': [{'id': c['id'], 'text': c['support']['text'], 'start': c['support']['start'], 'end': c['support']['end'], 'preparation': c.get('preparation', []), 'part': c.get('part', []), 'route': c.get('route', []), 'relation_scope': c.get('relation_scope'), 'statement_role': c.get('statement_role', 'LEGACY_ROLE_NOT_SCREENED'), 'negated': bool(c.get('negated'))} for c in claims],
            'next_actions': actions, 'reading_list': reading,
            'trial_readings': active_reading_sets(result.get('study_reading_sets', []), [c['taxon_id'] for c in candidates], group['conditions']),
            'open_world': group['open_world'], 'single_answer_risk': group['single_answer_view'],
            'relation_counts': dict(Counter(e['relation']['relation'] for e in rows)),
            'compound_assays': [a for a in result.get('compound_assay_leads', []) if any(link['evidence_id'] in ids for link in a['linked_evidence'])],
        })
    return {
        'schema_version': '1.4', 'run_id': result['run_id'],
        'source': result['source'], 'snapshot_sha256': result['snapshot_sha256'], 'knowledge_sha256': result.get('knowledge_sha256'),
        'code_fingerprint': result['code_fingerprint'],
        'scope': 'Automated research hand-off from active source, candidate and abstract records. Actions are verification tasks, not treatment advice or validated research findings.',
        'reading_order': 'Species-named records first, researcher-rejected records last, then newest year; not a ranking of scientific quality.',
        'names': names,
        'research_assessments': [{k: row.get(k) for k in ('taxon_id', 'taxon', 'condition_id', 'topic', 'state', 'human_studies', 'isolated_plant_studies', 'assessment_basis')} for row in result.get('research_digest', [])],
        'limitations': result['limitations'],
    }


def _text(value):
    """Keep source/user text literal in Markdown, including attempted headings/links."""
    return re.sub(r'([\\`*_{}\[\]<>#!|])', r'\\\1', ' '.join(str(value or '').split()))


def _url(value):
    value = str(value or '')
    try:
        parts = urlsplit(value)
        if parts.scheme in ('https', 'http') and parts.netloc and not any(ord(c) < 32 for c in value):
            return quote(value, safe='/:#?&=%+@!$;,~-._')
    except ValueError:
        pass
    return ''


def brief_markdown(brief):
    source = brief['source']
    lines = ['# FoliaTrace research brief', '', brief['scope'], '',
             f"Source: {_text(source.get('title'))}", f"Source ID: {_text(source.get('id'))}",
             f"Edition/date: {_text(source.get('date') or 'not established')}",
             f"Source rights: {_text(source.get('licence'))}"]
    if url := _url(source.get('url')):
        lines.append(f"[Original source]({url})")
    lines += ['', f"Run: {brief['run_id']}", f"Snapshot: {brief['snapshot_sha256']}", f"Code: {brief['code_fingerprint']}", '', brief['reading_order']]
    if not brief['names']:
        lines += ['', 'No plant name recognised in this snapshot. Check the source manually or expand coverage; no historical identity or efficacy conclusion follows.']
    for name in brief['names']:
        lines += ['', f"## {_text(name['label'])}", '', f"Identity state: {_text(name['status'])}", f"Review state: {_text(name['identity_review_state'])}", '', '### Source statements', '']
        if name.get('source_names'):
            lines[-2:-2] = [f"Named in this source: {_text(', '.join(name['source_names']))} (the author's own pairing with this name)", '']
        for claim in name['source_claims']:
            lines += [f"> {_text(claim['text'])}", f"Claim {_text(claim['id'])}; role {_text(claim.get('statement_role', 'LEGACY_ROLE_NOT_SCREENED'))}; scope {_text(claim['relation_scope'])}; negation flagged: {claim['negated']}", '']
            if 'start' in claim:
                lines.append(f"Original source span: {claim['start']}–{claim['end']}. Preparation: {_text(', '.join(p['text'] for p in claim.get('preparation', [])) or 'not stated')}; part: {_text(', '.join(p['text'] for p in claim.get('part', [])) or 'not stated')}; route: {_text(', '.join(p['text'] for p in claim.get('route', [])) or 'not stated')}.")
        if not name['source_claims']:
            lines.append('No use statement extracted for this name.')
        lines += ['', '### Candidate identities', '']
        if name.get('opening_name_clues'):
            lines += ['Source-local opening names; name-list matches remain conditional, not historical identifications.']
            for clue in name['opening_name_clues']:
                lines += [f"> {_text(clue['name'])}", f"Original input span {clue['start']}–{clue['end']}; lookup forms: {_text('; '.join(clue['lookup_forms']))}."]
            lines.append('')
        for c in name['candidates']:
            lines.append(f"- {_text(c['name'])} ({_text(c['taxon_id'])})")
            if r := c['review']:
                lines.append(f"  Researcher review: {_text(r['decision'])}; {_text(r['reason'])}; {_text(r['reviewer'])}; {_text(r['created_at'])}")
                if r.get('carried_forward'):
                    lines.append(f"  Retained from analysis {_text(r['origin_run_id'])}; exact source wording, name occurrences and candidate identity match. This is the original judgement, not a new review.")
        for c in name['open_world']:
            lines.append(f"- Outside snapshot: {_text(c['name'])}; studies not retrieved. GBIF https://www.gbif.org/species/{int(c['gbif_key'])}")
        if references := name.get('historical_identity_references'):
            lines += ['', '### Historical name wording in other sources', '', 'Matching headings are reading links, not evidence that the two authors meant the same plant. Candidate ranking is unchanged.']
            for reference in references:
                source = reference['source']
                lines += ['', f"{_text(source['title'])}; {_text(source.get('collection'))}; {_text(source.get('date'))}; {_text(source['licence'])}."]
                if url := _url(source.get('url')):
                    lines.append(f'[Original historical source]({url})')
                for excerpt in reference['excerpts']:
                    lines += [f"> {_text(excerpt['text'])}", f"Source input span {excerpt['start']}–{excerpt['end']}; text SHA256 {_text(reference['text_sha256'])}."]
                    for wording in excerpt['names']:
                        lines.append(f"Name wording “{_text(wording['text'])}”; exact {_text(wording['alias_kind'])} spelling for {_text(wording['candidate_name'])} ({_text(wording['candidate_id'])}) in the bundled taxonomy. Read negation and contrasts in the quote.")
                if not reference['excerpts']:
                    lines.append('Matching chapter heading, but no current candidate scientific-name spelling was found. This does not establish absence of a historical identification.')
        risk = name['single_answer_risk']
        if risk and (risk['hidden_branches'] or name['open_world']):
            lines += ['', f"Single-answer reconstruction: {len(risk['hidden_papers'])} publications hidden, {len(risk['misattributed_papers'])} potentially misattributed. This is a reconstruction of choosing one branch, not a measured competitor error rate."]
        for reading_set in name.get('trial_readings', []):
            lines += ['', '### Selected controlled-trial reading comparison', '', _text(reading_set['title']),
                      _text(reading_set['takeaway']), '', _text(reading_set['selection']),
                      _text(reading_set['annotation']['method']), _text(reading_set['annotation']['licence']), _text(reading_set['annotation']['rights_scope']),
                      'Topical reading notes only: not a historical identity decision or an automated efficacy relation.', '']
            for study in reading_set['studies']:
                publication = study['publication']
                url = _url(publication['url'])
                lines.append(f"#### {_text(study['label'])}")
                lines.append(f"[{_text(publication['title'])}]({url})" if url else _text(publication['title']))
                lines.append(f"Authors: {_text(publication['authors'])}. PMID {_text(publication['pmid'])}; DOI {_text(publication['doi'])}.")
                for key, label in [('population', 'Population'), ('design', 'Design'), ('intervention', 'Formulation'), ('comparator', 'Comparator'), ('follow_up', 'Follow-up'), ('primary_outcome', 'Primary endpoint'), ('primary_result', 'Primary result'), ('other_results', 'Other results'), ('reading_question', 'Reading question')]:
                    lines.append(f"- {label}: {_text(study[key])}")
                lines.append('')
        lines += ['', '### Next research tasks', '']
        for i, a in enumerate(name['next_actions'], 1):
            lines.append(f"{i}. {_text(a['text'])}")
            if a['evidence_ids']:
                lines.append('   Records: ' + ', '.join(_text(eid) for eid in a['evidence_ids']))
        lines += ['', '### Reading and verification queue', '']
        if not name['reading_list']:
            lines.append('No records retrieved in this snapshot.')
        printed_methods = set()
        printed_results = set()
        printed_aims = set()
        for r in name['reading_list']:
            p = r['paper']
            title = _text(re.sub(r'</?(?:i|b|em|strong|sup|sub)>', '', p['title'], flags=re.I))
            citation = f"[{title}]({url})" if (url := _url(p['url'])) else title
            lines += [f"- {citation} ({_text(p['year'])}; {_text(p['id'])}; {_text(p['licence'])})",
                      f"  Record {_text(r['evidence_id'])}; candidate {_text(r['taxon_name'])}; question {_text(r['condition_id'])}.",
                      f"  Species check: {_text(r['species_check'])}; final relation: {_text(r['final_relation'])}.",
                      f"  Failed checks: {_text(', '.join(r['failed_checks']) or 'none recorded')}; unresolved: {_text(', '.join(r['unresolved_checks']) or 'none recorded')}; screening: {_text(r['screening'])}."]
            if r.get('preparation_attribution'):
                lines.append(f"  Candidate-linked preparation wording: {_text((r.get('study_preparation') or {}).get('text') or 'not established')}; status {_text(r['preparation_attribution']['status'])}. This wording does not confirm the administered intervention or isolate its effect.")
            for note in r.get('comparison_notes', []):
                lines.append('  Comparator reading: ' + _text(note))
            for statement in r.get('automated_endpoint_statements', []):
                lines += [f"  Automated endpoint reading: {_text(statement['direction'])}; abstract span {statement['start']}-{statement['end']}.", f"  > {_text(statement['supporting_text'])}"]
            scope = r.get('candidate_result_scope') or {}
            if scope.get('candidate_scope_note'):
                lines.append('  Candidate linkage: ' + _text(scope['candidate_scope_note']))
            for statement in scope.get('unassigned_statements', []):
                lines += [f"  Source finding not assigned to this candidate (abstract span {statement['start']}-{statement['end']}):", f"  > {_text(statement['supporting_text'])}"]
            if r.get('preparation_attribution'):
                forms = r['preparation_attribution'].get('forms', [])
                if forms:
                    chosen = next((f for f in forms if f['start'] == (r.get('study_preparation') or {}).get('start')), forms[0])
                    kind = 'Methods table transcription' if chosen.get('source_kind') == 'FULL_TEXT_METHODS_TABLE' else 'Abstract'
                    lines.append(f"  {kind} context: “{_text(chosen['context']['text'])}” (local span {chosen['context']['start']}–{chosen['context']['end']}).")
            for context in r.get('reported_results', []):
                if context['id'] in printed_results:
                    lines.append(f"  Author-reported Results already quoted above: {_text(context['id'])}.")
                    continue
                printed_results.add(context['id'])
                url = _url(context['url'])
                lines += [f"  Author-reported Results, for this study's own intervention and population ({_text(context['licence'])}; {_text(context['id'])}):",
                          f"  > {_text(context['text'])}", f"  [Original Results section]({url})" if url else '  Results source URL unavailable.',
                          '  This passage is not a condition-specific relation label or proof that the historical preparation works. Read the design and comparator checks above.']
            if r.get('historical_contexts'):
                for context in r['historical_contexts']:
                    lines.append(f"  Source statement {_text(context['claim_id'])} (span {context['support']['start']}–{context['support']['end']}): {_text(context['preparation_comparison']['detail'])}")
                    if indication := context.get('indication_comparison'):
                        historical = ', '.join(dict.fromkeys(span['text'] for span in indication['historical_wording'])) or 'not established by this word screen'
                        modern = ', '.join(dict.fromkeys(span['text'] for span in indication['study_wording'])) or 'not established by this word screen'
                        lines.append(f"  Indication wording, not diagnostic equivalence: historical {_text(historical)}; study {_text(modern)}. {_text(indication['detail'])}")
                        if (aim := indication.get('study_aim')) and p['id'] not in printed_aims:
                            printed_aims.add(p['id'])
                            lines.append(f"  Stated study aim (original abstract span {aim['start']}–{aim['end']}): {_text(aim['text'])}")
            else:
                lines.append('  No statement-level preparation comparison was stored in this analysis; reanalyze the source to obtain one.')
            for context in r.get('methods_sources', []):
                if context['id'] in printed_methods:
                    lines.append(f"  Methods source already quoted above: {_text(context['id'])}.")
                    continue
                printed_methods.add(context['id'])
                url = _url(context['url'])
                lines += [f"  Methods source: {_text(context['section'])}; {_text(context['licence'])}; {_text(context['id'])}.",
                          f"  > {_text(context['text'])}", f"  [Original Methods section]({url})" if url else '  Methods source URL unavailable.']
            if review := r['review']:
                lines.append(f"  Researcher review: {_text(review['decision'])}; {_text(review['reason'])}; {_text(review['reviewer'])}; {_text(review['created_at'])}")
                if review.get('carried_forward'):
                    lines.append(f"  Retained from analysis {_text(review['origin_run_id'])}; exact source wording, species, condition and publication match. This is the original judgement, not a new review.")
        if name.get('compound_assays'):
            lines += ['', '### Compound assay leads', '', 'ChEMBL-derived assay fields in this section retain CC BY-SA 3.0. Attribution: ChEMBL team, EMBL-EBI and the original document IDs below. A publication co-mention is not proof of plant composition; an isolated-molecule assay is not clinical efficacy.', '']
            for a in name['compound_assays']:
                url = _url(a['url'])
                lines += [f"- {_text(a['compound'])} against {_text(a['target']['pref_name'])}: {_text(a['standard_type'])} {_text(a['standard_relation'])} {_text(a['standard_value'])} {_text(a['standard_units'])}.", f"  {_text(a['assay_id'])}; {_text(a['document_id'])}; {_text(a['licence'])}.", f"  [Measurement record]({url})" if url else '  Measurement URL unavailable.']
    if brief.get('research_assessments'):
        lines += ['', '## Research summaries and their sources', '']
        for row in brief['research_assessments']:
            basis = row.get('assessment_basis') or {}
            lines += [f"### {_text(row['taxon'])}: {_text(row['topic'])}",
                      f"Reported state: {_text(row['state'])}. Basis: {_text(basis.get('kind', 'LEGACY_NOT_RECORDED'))}.",
                      f"Human studies: {_text(row['human_studies'])}; studies without another named plant ingredient: {_text(row.get('isolated_plant_studies'))}.",
                      _text(basis.get('scope', ''))]
            for record in basis.get('records', []):
                title, url = _text(record['title']), _url(record['url'])
                citation = f'[{title}]({url})' if url else title
                lines.append(f"- {citation} ({_text(record.get('year'))}; {_text(record['paper_id'])}): {_text(record['direction'])}.")
            lines.append('')
    lines += ['', '## Limits', ''] + ['- ' + _text(x) for x in brief['limitations']]
    return '\n'.join(lines) + '\n'

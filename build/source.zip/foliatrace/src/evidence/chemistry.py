"""Assay leads attached only through publication compound co-mentions."""


def assay_leads(evidence, records, withdrawn=()):
    withdrawn, found = set(withdrawn), {}
    if 'chembl' in withdrawn:
        return []
    for e in evidence:
        for c in e.get('compound_co_mentions', []):
            for a in records:
                if a['cid'] != c['cid'] or {a['id'], a['molecule_chembl_id'], a['target']['target_chembl_id']} & withdrawn:
                    continue
                row = found.setdefault(a['id'], {**a, 'linked_evidence': [], 'link_basis': 'COMPOUND_CO_MENTION_IN_RETRIEVED_PUBLICATION; NOT_VERIFIED_PLANT_CONSTITUENT'})
                row['linked_evidence'].append({'evidence_id': e['id'], 'paper_id': e['paper']['id'], 'candidate_taxon_id': e['taxon_id'], 'supporting_text': c['supporting_text']})
    return list(found.values())

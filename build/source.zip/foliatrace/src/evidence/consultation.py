"""Prepare incomplete herbal-product information for a clinician conversation."""
from __future__ import annotations
import hashlib
import json
import re
import sqlite3
import uuid
from pathlib import Path
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator
from src.common import now
from src.nlp.extract import normalize
from src.evidence.question_review import canonical
from src.evidence.overview import product_candidate_order
from src.evidence.product_labels import LabelSnapshot, ingredients, label_wording, ingredient_source, snapshot as label_snapshot


class ProductItem(BaseModel):
    model_config = ConfigDict(extra='forbid')
    item_id: str = Field(default_factory=lambda:uuid.uuid4().hex, pattern=r'^[a-f0-9]{12,32}$')
    name: str = Field(min_length=2, max_length=200)
    source_kind: Literal['PRODUCT_LABEL', 'PERSON_REPORTED'] = 'PERSON_REPORTED'
    use_status: Literal['NOT_ESTABLISHED','REPORTED_CURRENT_USE','REPORTED_PAST_USE'] = 'NOT_ESTABLISHED'
    source_text: str = Field(default='', max_length=5000)
    plant_wording: str = Field(default='', max_length=120)
    brand: str = Field(default='', max_length=200)
    dose: str = Field(default='', max_length=200)
    frequency: str = Field(default='', max_length=200)
    route: str = Field(default='', max_length=200)
    last_taken: str = Field(default='', max_length=200)
    preparation: str = Field(default='', max_length=200)
    reason_for_use: str = Field(default='', max_length=500)
    label_snapshot: LabelSnapshot | None = None

    @model_validator(mode='after')
    def grounded(self):
        if len(self.name.strip()) < 2:
            raise ValueError('Product name must contain substantive text')
        if self.plant_wording and normalize(self.plant_wording) not in normalize(self.name+' '+self.source_text):
            raise ValueError('Plant wording must occur in the product name or its recorded source')
        if self.label_snapshot:
            raw=self.label_snapshot.raw
            if self.source_kind!='PRODUCT_LABEL' or self.name!=raw['fullName'] or self.brand!=(raw.get('brandName') or '') or self.source_text!=label_wording(raw):
                raise ValueError('Attached label wording, name and brand must match the source snapshot; remove it before manual editing')
        return self


class ConsultationInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    visit_label: str = Field(min_length=2, max_length=160)
    prepared_by: Literal['PATIENT_OR_CARER', 'HEALTHCARE_PROFESSIONAL'] = 'PATIENT_OR_CARER'
    products: list[ProductItem] = Field(min_length=1, max_length=30)
    other_medicines_status: Literal['NOT_PROVIDED', 'NONE_REPORTED', 'LIST_PROVIDED'] = 'NOT_PROVIDED'
    other_medicines: str = Field(default='', max_length=6000)
    allergies_status: Literal['NOT_PROVIDED', 'NONE_REPORTED', 'DETAILS_PROVIDED'] = 'NOT_PROVIDED'
    allergies: str = Field(default='', max_length=2000)
    questions_for_professional: str = Field(default='', max_length=2000)

    @model_validator(mode='after')
    def complete_states(self):
        if len(self.visit_label.strip()) < 2:
            raise ValueError('A visit label is required; a patient name is not needed')
        if len({p.item_id for p in self.products}) != len(self.products):
            raise ValueError('Product identifiers must be unique; different products must not be merged')
        if self.other_medicines_status == 'LIST_PROVIDED' and not self.other_medicines.strip():
            raise ValueError('Record the medicine list or choose information not provided')
        if self.other_medicines_status != 'LIST_PROVIDED' and self.other_medicines.strip():
            raise ValueError('Medicine details need the list provided status')
        if self.allergies_status == 'DETAILS_PROVIDED' and not self.allergies.strip():
            raise ValueError('Record the reported allergy details or choose information not provided')
        if self.allergies_status != 'DETAILS_PROVIDED' and self.allergies.strip():
            raise ValueError('Allergy details need the details provided status')
        return self


def item_fingerprint(item):
    return hashlib.sha256(canonical(item)).hexdigest()


def prepare_consultation(pipeline, request: ConsultationInput):
    products = []
    for item in request.products:
        original = item.model_dump(exclude_none=True)
        lookup = item.plant_wording or item.name
        resolution = pipeline.resolver.resolve(lookup)
        candidates = []
        label_rows=[]
        if item.label_snapshot:
            for row in ingredients(item.label_snapshot.raw):
                row['candidates']=[]
                row['review_source_text']=ingredient_source(item.label_snapshot.raw,row['key'])
                if row['plant_lookup_available']:
                    resolved=pipeline.resolver.resolve(row['lookup'])
                    explicit_species = ('Genus:' in row['notes'] and 'Species:' in row['notes']) or re.fullmatch(r'[A-Z][a-z]+ [a-z][a-z-]+',row['lookup'])
                    if not resolved['candidates'] and row['lookup'] != row['name'] and not explicit_species:
                        alternative = pipeline.resolver.resolve(row['name'])
                        if alternative['candidates']:
                            row['research_lookup'] = row['name']
                            resolved = alternative
                    row['candidates']=[{'taxon_id':c['taxon_id'],'name':c['name'],'reasons':c['reasons'],
                         'reference_url':'https://www.gbif.org/species/'+c['taxon_id'].removeprefix('gbif:') if c['taxon_id'].startswith('gbif:') else None}
                         for c in product_candidate_order(resolved['candidates'],row['lookup']) if c['taxon_id'] not in pipeline.withdrawn()]
                label_rows.append(row)
            resolution={'status':'LABEL_INGREDIENT_BRANCHES','candidates':[c for row in label_rows for c in row['candidates']]}
        for candidate in product_candidate_order(resolution['candidates'],lookup):
            if candidate['taxon_id'] in pipeline.withdrawn():
                continue
            if any(c['taxon_id']==candidate['taxon_id'] for c in candidates):continue
            candidates.append({'taxon_id': candidate['taxon_id'], 'name': candidate['name'],
                               'reasons': candidate['reasons'],
                               'reference_url': 'https://www.gbif.org/species/'+candidate['taxon_id'].removeprefix('gbif:') if candidate['taxon_id'].startswith('gbif:') else None})
        missing = [key for key in ('dose','frequency','route','last_taken','preparation') if not getattr(item,key).strip()]
        tasks = [{'field': key, 'question': {'dose':'What amount is actually used each time? Copy the stated unit.',
                                           'frequency':'How often is this product actually used?',
                                           'route':'How is the product used?',
                                           'last_taken':'When was the last use?',
                                           'preparation':'What form does the label state: tea, oil, extract, capsule or something else?'}[key]} for key in missing]
        if item.use_status=='NOT_ESTABLISHED':
            tasks.insert(0,{'field':'use_status','question':'Is this product actually being used now, used in the past, or only mentioned? Its use status has not been established.'})
        if not item.source_text.strip():
            tasks.insert(0, {'field':'source_text','question':'Bring the bottle or package and copy the exact ingredient label; this record has no source wording yet.'})
        if len(candidates) != 1:
            tasks.insert(0, {'field':'identity','question':'Ask the pharmacist to check the ingredient label and its botanical name. '+('Several plants share this wording.' if candidates else 'No plant candidate was established from this wording.')})
        else:
            tasks.insert(0, {'field':'identity','question':'Check the candidate against the actual ingredient label. A name match does not verify what is in this product.'})
        products.append({'reported': original, 'item_sha256': item_fingerprint(original),
                         'name_lookup': lookup, 'name_status': resolution['status'],
                         'identity_status': 'NOT_VERIFIED_AGAINST_PRODUCT', 'candidates': candidates,
                         **({'label_ingredients':label_rows} if item.label_snapshot else {}),
                         'missing_reported_fields': missing, 'clarification_questions': tasks})
    return {'schema':'foliatrace-consultation-prep-1', 'created_at':now(), 'intake':request.model_dump(),
            'products':products, 'linked_evidence':[], 'code_fingerprint':pipeline.code_fingerprint,
            'snapshot_sha256':pipeline.snapshot,
            'scope':'CONSULTATION_PREPARATION_NOT_COMPLETED_MEDICATION_RECONCILIATION',
            'summary':{'products':len(products), 'products_with_several_candidates':sum(len(p['candidates'])>1 for p in products),
                       'products_without_candidate':sum(not p['candidates'] for p in products),
                       'missing_reported_fields':sum(len(p['missing_reported_fields']) for p in products)},
            'next_visit_questions': (["Provide the full prescription, over-the-counter and supplement list." ] if request.other_medicines_status == 'NOT_PROVIDED' else [])+(["Ask about allergies and previous adverse reactions; no information was provided here."] if request.allergies_status == 'NOT_PROVIDED' else []),
            'limits':['This record preserves reported information; product contents, doses and clinical safety have not been verified.',
                      'No drug interaction check, diagnosis, safety clearance or recommendation to start, stop or change a product is performed.',
                      'Candidate species are hypotheses from a name reference, not identification of the bottle or its ingredients.',
                      'The clinician or pharmacist must review the original products, complete medication list and relevant clinical context.',
                      'Consultation details stay in this local installation. Optional live NIH lookup sends only the separate product search text. Exports can contain health information and publisher-owned study text; choose what to share.'],
            'workflow_sources':[{'title':'NCCIH: Talk with your health care providers','url':'https://www.nccih.nih.gov/health/know-science/how-medications-and-supplements-can-interact/talk-with-your-health-care-providers'},
                                {'title':'AHRQ: Your Medicine, Be Smart. Be Safe.','url':'https://www.ahrq.gov/questions/resources/your-meds/index.html'}]}


def validate_consultation(packet):
    if not isinstance(packet,dict):raise ValueError('Consultation preparation must be an object')
    if packet.get('schema') != 'foliatrace-consultation-prep-1':
        raise ValueError('Unsupported consultation preparation schema')
    intake = ConsultationInput.model_validate(packet['intake'])
    expected = {p.item_id:p.model_dump(exclude_none=True) for p in intake.products}
    for original in packet['intake']['products']:
        if 'use_status' not in original:
            expected[original['item_id']].pop('use_status',None)
    if len(packet['products']) != len(expected):
        raise ValueError('Product count does not match intake')
    seen = set()
    for item in packet['products']:
        key = item['reported']['item_id']
        if key in seen or expected.get(key) != item['reported'] or item_fingerprint(item['reported']) != item['item_sha256']:
            raise ValueError('Product source wording changed or duplicated')
        if item['identity_status'] != 'NOT_VERIFIED_AGAINST_PRODUCT':
            raise ValueError('Name candidates must not be represented as verified products')
        attachment=expected[key].get('label_snapshot')
        if attachment:
            rows=ingredients(attachment['raw']);actual=item.get('label_ingredients',[])
            if len(rows)!=len(actual) or any({k:v for k,v in a.items() if k not in ('candidates','review_source_text','research_lookup')}!=b or a.get('review_source_text')!=ingredient_source(attachment['raw'],b['key']) for a,b in zip(actual,rows)):
                raise ValueError('Label ingredient projection differs from its original source')
            for a,b in zip(actual,rows):
                if 'research_lookup' in a and (not b['plant_lookup_available'] or a['research_lookup']!=b['name']):
                    raise ValueError('Alternate research wording must be the original botanical ingredient name')
        seen.add(key)
    for link in packet['linked_evidence']:
        if link['item_id'] not in expected:
            raise ValueError('Linked evidence has no product in this record')
        from src.evidence.question_review import validate_packet
        validate_packet(link['review']['packet'])
        if link['source_item_sha256'] != item_fingerprint(expected[link['item_id']]):
            raise ValueError('Linked evidence refers to changed product wording')
        product=next(p for p in packet['products'] if p['reported']['item_id']==link['item_id'])
        if expected[link['item_id']].get('label_snapshot'):
            ingredient=next((r for r in product.get('label_ingredients',[]) if r['key']==link.get('ingredient_key')),None)
            if ingredient is None or link.get('source_label_sha256')!=expected[link['item_id']]['label_snapshot']['sha256']:
                raise ValueError('Linked evidence has no matching ingredient or label version')
            taxa={c['taxon_id'] for c in ingredient['candidates']}
            if not {b['taxon_id'] for b in link['review']['packet']['branches']} <= taxa:
                raise ValueError('Evidence branches do not match the selected label ingredient')
            protocol=link['review']['packet']['protocol']
            if protocol['source_text']!=ingredient['review_source_text'] or normalize(protocol['plant_name'])!=normalize(ingredient.get('research_lookup') or ingredient['lookup']):
                raise ValueError('Evidence source does not match the selected ingredient')
        else:
            protocol = link['review']['packet']['protocol']
            if protocol['source_text'] != product['reported']['source_text'] or normalize(protocol['plant_name']) != normalize(product['name_lookup']):
                raise ValueError('Evidence source does not match the manually recorded product')
            if not {b['taxon_id'] for b in link['review']['packet']['branches']} <= {c['taxon_id'] for c in product['candidates']}:
                raise ValueError('Evidence branches do not match the manually recorded product')
    from src.evidence.care_workspace import validate_clarifications
    validate_clarifications(packet)
    return packet


class ConsultationStore:
    def __init__(self,path:Path):
        self.path=path
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS consultation_preparations(id TEXT PRIMARY KEY,saved_at TEXT NOT NULL,origin TEXT NOT NULL,payload TEXT NOT NULL)')

    def connect(self):
        from contextlib import contextmanager
        @contextmanager
        def opened():
            db=sqlite3.connect(self.path,timeout=20)
            try:
                with db:yield db
            finally:db.close()
        return opened()

    def put(self,packet,origin='LOCAL_CONSULTATION_PREPARATION'):
        validate_consultation(packet)
        if len(canonical(packet))>19_000_000:raise ValueError('Preparation is too large for portable export; retain fewer evidence reviews per snapshot')
        identifier=uuid.uuid4().hex
        with self.connect() as db:
            db.execute('INSERT INTO consultation_preparations VALUES(?,?,?,?)',(identifier,now(),origin,canonical(packet).decode()))
        return self.get(identifier)

    def get(self,identifier):
        with self.connect() as db:row=db.execute('SELECT id,saved_at,origin,payload FROM consultation_preparations WHERE id=?',(identifier,)).fetchone()
        if not row:return None
        packet=json.loads(row[3]);record={'id':row[0],'saved_at':row[1],'origin':row[2],'packet':packet,'sha256':hashlib.sha256(canonical(packet)).hexdigest()}
        if any(p.get('label_snapshot') and not p['label_snapshot'].get('hash_scheme') for p in packet['intake']['products']):
            import copy
            draft=copy.deepcopy(packet['intake']);detached=False
            for product in draft['products']:
                source=product.get('label_snapshot')
                if not source or source.get('hash_scheme'):continue
                try:
                    upgraded=label_snapshot(source['raw'],source['retrieved_at'],source['access'])
                    product['label_snapshot']=upgraded;product['source_text']=label_wording(upgraded['raw'])
                except ValueError:
                    # Keep the original human-readable wording, never round an unsafe source number.
                    product.pop('label_snapshot');detached=True
            record['draft_intake']=draft
            record['draft_notice']='A new draft uses browser-safe numeric formatting; save it as a new snapshot. The original record and its hashes are unchanged.'+(' An unsupported legacy numeric attachment is detached in the draft; original wording and the saved source remain available.' if detached else '')
        return record

    def list(self):
        with self.connect() as db:
            return [dict(zip(('id','saved_at','origin','visit_label'),r)) for r in db.execute("SELECT id,saved_at,origin,json_extract(payload,'$.intake.visit_label') FROM consultation_preparations ORDER BY saved_at DESC LIMIT 100")]


def consultation_markdown(record):
    p=record['packet'];q=p['intake'];lines=['# Herbal product consultation preparation',q['visit_label'],'Origin: '+record['origin'],
        'Reported information for a healthcare conversation. This is not a completed medication reconciliation or clinical safety assessment.',
        '## Other medicines',q['other_medicines_status'],q['other_medicines'],'## Allergies and previous reactions',q['allergies_status'],q['allergies']]
    for item in p['products']:
        r=item['reported'];lines+=['## '+r['name'],'Information source: '+r['source_kind'],'Reported use status: '+r.get('use_status','NOT_ESTABLISHED'),'Exact recorded wording:',r['source_text'] or 'Not provided']
        for key in ('brand','dose','frequency','route','last_taken','preparation','reason_for_use'):
            lines+=[key.replace('_',' ').capitalize()+': '+(r[key] or 'NOT PROVIDED')]
        if r.get('label_snapshot'):
            label=r['label_snapshot'];raw=label['raw']
            lines+=['### Selected label record (bottle match not established)',label['source_url'],
                'Source SHA256: '+label['sha256'],'Retrieved: '+label['retrieved_at']+' / '+label['access'],
                'Label entered: '+str(raw.get('entryDate'))+'; off-market flag: '+str(raw.get('offMarket')),
                'Label serving sizes (not actual use): '+json.dumps(raw.get('servingSizes',[]),ensure_ascii=False)]
            for ingredient in item.get('label_ingredients',[]):
                lines += [ingredient['key']+' '+ingredient['name'],ingredient['notes']]
                for amount in ingredient['quantities']:
                    lines += ['Individual label amount: NOT PROVIDED (DSLD NP placeholder; not zero).' if amount['amount_status']=='NOT_PROVIDED'
                              else 'Own label amount: '+str(amount.get('operator') or '')+str(amount['quantity'])+' '+amount['unit']+' per '+str(amount.get('servingSizeQuantity'))+' '+str(amount.get('servingSizeUnit') or 'label serving')]
            lines+=['Other declared ingredients (source wording): '+json.dumps(raw.get('otheringredients') or {},ensure_ascii=False)]
            lines+=['Full original label JSON, including directions and other ingredients, is included in the portable backup.']
        lines+=['Candidate names, not verified product ingredients:']+[c['name']+' '+str(c.get('reference_url') or '') for c in item['candidates']]
        if not item['candidates']:lines+=['No candidate established; bring original packaging.']
        lines+=['Clarification questions:']+[t['question'] for t in item['clarification_questions']]
        for link in p['linked_evidence']:
            if link['item_id']==r['item_id']:
                from src.evidence.question_review import review_markdown
                lines+=['### Professional evidence reading', 'Selected ingredient: '+link.get('ingredient_key','manually recorded product'),review_markdown(link['review'])]
    lines+=['## Questions for the professional',q['questions_for_professional'],*p['next_visit_questions'],'## Scope and sources',*p['limits']]
    lines += [s['title']+' '+s['url'] for s in p['workflow_sources']]
    return '\n\n'.join(lines)+'\n'

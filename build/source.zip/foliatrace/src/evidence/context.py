"""Keep a study's intervention and each historical statement attached to their source.

These lexical links are reading aids, not botanical identification or causal inference.
In particular, the first preparation in a multi-ingredient abstract is not necessarily
the preparation of the candidate plant.
"""
from copy import deepcopy
import re

from src.evidence.comparability import check_preparation, compiled, family, UNKNOWN, name_pattern


PREPARATIONS = re.compile(
    r"\b(?:(?:aqueous|ethanolic|standardized|standardised|essential)\s+)?"
    r"(?:hydrolates?|hydrosols?|decoctions?|tinctures?|ointments?|emulsions?|"
    r"infusions?|extracts?|capsules?|tablets?|powders?|creams?|teas?|oils?)\b", re.I
)
CLAUSE_BOUNDARY = re.compile(r"[,;:!?/&+]|\n\s*\n|\b(?:and|whereas|while|but|versus|vs)\b", re.I)
UNCERTAIN_SCOPES = {'MULTI_PLANT_CLAUSE_UNCERTAIN_RELATION', 'PARAGRAPH_CONTEXT_UNCERTAIN_RELATION'}

# Bounded word groups for reading the original indication, not disease codes or
# an anatomical ontology. A shared group never establishes a shared endpoint.
SITE_WORDING = {
    'mouth_teeth_gums': r'\b(?:mouthwash(?:es)?|mouth|teeth|tooth|dental|gingiv\w*|periodont\w*|gums)\b',
    'stomach_bowel': r'\b(?:stomach\w*|bowels?|intestin\w*|gastrointestin\w*|abdom\w*|gastric|colonic|ileocolonic)\b',
    'joints_sinews': r'\b(?:joints?|sinews?|tendons?|articular|arthritis|arthritic)\b',
    'skin': r'\b(?:skin|cutaneous|dermal|dermat\w*)\b',
    'lungs': r'\b(?:lungs?|pulmonary|bronch\w*)\b',
    'womb': r'\b(?:womb|uterus|uterine)\b',
    'kidney_bladder': r'\b(?:kidneys?|renal|bladder)\b',
    'eyes': r'\b(?:eyes|ocular|ophthalm\w*)\b',
}


def site_wording(text, source_kind, offset=0):
    """Keep literal source offsets; neither infer a diagnosis nor an outcome."""
    return sorted([
        {'group': group, 'text': match.group(), 'start': offset + match.start(),
         'end': offset + match.end(), 'source_kind': source_kind}
        for group, pattern in SITE_WORDING.items() for match in re.finditer(pattern, text, re.I)
    ], key=lambda span: (span['start'], span['end']))


def compare_indication_wording(context, paper):
    historical = site_wording(context['support']['text'], 'HISTORICAL_INPUT', context['support']['start'])
    aim = next(({'text': match.group(), 'start': match.start(), 'end': match.end(), 'source_kind': 'PUBLICATION_ABSTRACT'}
                for match in re.finditer(r'[^.!?\n]+(?:[.!?]+|$)', paper['abstract'])
                if len(match.group().strip()) >= 40 and re.search(r'\b(?:aim(?:ed|s)?|objectives?)\b', match.group(), re.I)), None)
    # The title and abstract are kept separate so their offsets remain checkable.
    modern = site_wording(paper['title'], 'PUBLICATION_TITLE') + (
        site_wording(aim['text'], 'PUBLICATION_ABSTRACT', aim['start']) if aim else site_wording(paper['abstract'], 'PUBLICATION_ABSTRACT'))
    old_groups, new_groups = {s['group'] for s in historical}, {s['group'] for s in modern}
    shared = old_groups & new_groups
    status = ('SOME_SITE_WORDING_OVERLAPS' if shared else 'DIFFERENT_EXPLICIT_SITE_WORDING') if historical and modern else 'SITE_WORDING_NOT_ESTABLISHED_ON_BOTH_SIDES'
    return {
        'status': status, 'historical_wording': historical, 'study_wording': modern,
        'shared_groups': sorted(shared), 'publication_id': paper['id'], 'study_aim': aim,
        'study_wording_scope': 'TITLE_AND_EXPLICIT_ABSTRACT_AIM' if aim else 'TITLE_AND_ABSTRACT; no explicit aim sentence found',
        'detail': ('The source statement and this publication name different site word groups. Read the specific indication and endpoint; a shared search topic does not establish equivalence.'
                   if status == 'DIFFERENT_EXPLICIT_SITE_WORDING' else
                   'Some site words overlap, but the indication, population and measured endpoint still need comparison.' if shared else
                   'This limited word screen does not establish comparable sites on both sides. Read the exact statement and publication.'),
        'method': 'LITERAL_SITE_WORD_GROUPS_NOT_DIAGNOSTIC_OR_OUTCOME_EQUIVALENCE',
        'scope': 'Title/abstract words can describe background, mixtures or secondary outcomes. Absence from these groups does not establish absence from the source. No efficacy relation is changed.',
    }


def occurrences(text, name):
    return list(compiled(name_pattern(name)).finditer(text))


def scope_study_preparation(paper, taxon, study):
    """Prefer nearby candidate-linked wording; withhold a single form if unresolved.

    Common-name-only signals stay separate from scientific-name-grounded signals.
    Links cannot cross coordination or clause boundaries. Every proposed form keeps
    exact abstract offsets and its surrounding source window.
    """
    study = deepcopy(study)
    abstract = paper['abstract']
    scientific = [taxon['name']] + [a['name'] for a in taxon['aliases'] if a['kind'] in ('SYNONYM', 'INPUT_SYNONYM_MATCH')]
    grounded_abstract = any(occurrences(paper['title'] + ' ' + abstract, name) for name in scientific)
    grounded_methods = any(occurrences(context['text'], name) for context in paper.get('methods_contexts', []) for name in scientific)
    grounded = grounded_abstract or grounded_methods
    anchors = []
    names = scientific + [a['name'] for a in taxon['aliases']]
    for name in dict.fromkeys(names):
        for match in occurrences(abstract, name):
            anchors.append((match.start(), match.end(), name, name in scientific))
    proposals, linked = [], []
    for match in PREPARATIONS.finditer(abstract):
        context_start, context_end = max(0, match.start() - 60), min(len(abstract), match.end() + 100)
        proposal = {'text': match.group(), 'start': match.start(), 'end': match.end(),
                    'context': {'text': abstract[context_start:context_end], 'start': context_start, 'end': context_end}}
        proposals.append(proposal)
        nearby = []
        for start, end, name, is_scientific in anchors:
            left, right = (end, match.start()) if end <= match.start() else (match.end(), start)
            if right < left or right - left > 100:
                continue
            between = abstract[left:right]
            if CLAUSE_BOUNDARY.search(between):
                continue
            # Do not jump across a complete sentence to attach an unrelated form.
            if re.search(r'\.\s+[A-Z]', between):
                continue
            nearby.append((not is_scientific, right - left, start, end, name))
        if not nearby:
            continue
        _, distance, start, end, name = min(nearby)
        context_start = max(0, min(start, match.start()) - 60)
        context_end = min(len(abstract), max(end, match.end()) + 100)
        linked.append({**proposal, 'candidate_wording': name,
                       'name_span': {'text': abstract[start:end], 'start': start, 'end': end},
                       'distance': distance,
                       'context': {'text': abstract[context_start:context_end], 'start': context_start, 'end': context_end}})
    for context in paper.get('methods_contexts', []):
        if context.get('source_kind') != 'FULL_TEXT_METHODS_TABLE' or context.get('reading_role') != 'INTERVENTION_FORMULATIONS':
            continue
        source = {k: context[k] for k in ('id', 'url', 'licence')}
        source = {'source_kind': context['source_kind'], 'source_id': source['id'], 'url': source['url'], 'licence': source['licence']}
        for row in context.get('rows', []):
            anchor = next(((name, match) for name in scientific for match in occurrences(row['text'], name)), None)
            if not anchor:
                continue
            name, name_match = anchor
            for match in PREPARATIONS.finditer(row['text']):
                linked.append({
                    'text': match.group(), 'start': row['start'] + match.start(), 'end': row['start'] + match.end(),
                    **source, 'candidate_wording': name,
                    'name_span': {'text': name_match.group(), 'start': row['start'] + name_match.start(), 'end': row['start'] + name_match.end(), **source},
                    'distance': abs(name_match.start() - match.start()),
                    'context': {'text': row['text'], 'start': row['start'], 'end': row['end'], **source},
                })
    forms = {family(p['text']) or p['text'].casefold() for p in linked}
    status = ('CANDIDATE_LINKED_WORDING' if grounded else 'COMMON_NAME_ONLY_PREPARATION_WORDING') if len(forms) == 1 else 'MULTIPLE_CANDIDATE_FORMS' if forms else 'CANDIDATE_PREPARATION_UNRESOLVED'
    representative = min(linked, key=lambda p: (p.get('source_kind') != 'FULL_TEXT_METHODS_TABLE', p['distance'])) if len(forms) == 1 else None
    study.setdefault('pico_source_spans', {})['intervention_preparation'] = (
        {k: representative[k] for k in ('text', 'start', 'end', 'source_kind', 'source_id', 'url', 'licence') if k in representative} if representative else None
    )
    study['preparation_attribution'] = {
        'status': status, 'candidate_taxon_id': taxon['id'], 'forms': linked,
        'scientific_grounding_scope': 'TITLE_OR_ABSTRACT' if grounded_abstract else 'FULL_TEXT_METHODS' if grounded_methods else 'COMMON_NAME_ONLY',
        'other_preparation_wording': [p for p in proposals if not any(p['start'] == x['start'] and not x.get('source_kind') for x in linked)],
        'method': 'CANDIDATE_NAME_AND_LOCAL_PREPARATION_WORDING_WITH_ATTRIBUTED_FORMULATION_TABLE_ROWS',
        'methods_context_ids': sorted({paragraph['id'] for table in paper.get('methods_contexts', [])
                                      if table.get('source_kind') == 'FULL_TEXT_METHODS_TABLE'
                                      and any(form.get('source_id') == table['id'] for form in linked)
                                      for paragraph in paper.get('methods_contexts', [])
                                      if paragraph['section'] == table.get('referenced_from_methods_section')}),
        'note': 'Lexical association only. A named preparation may be one ingredient of a mixture; dose, intervention and causal attribution need source review.',
    }
    return study


def index_historical_contexts(extracted, resolutions):
    """Join exact stored statements through their mention/candidate/topic records."""
    mentions = {m['id']: m for m in extracted['mentions']}
    candidates = {r['mention_id']: {c['taxon_id'] for c in r['candidates']} for r in resolutions}
    indexed = {}
    for claim in extracted['historical_claims']:
        if claim.get('statement_role') != 'THERAPEUTIC_USE_RECORDED':
            continue
        taxa = {taxon for mid in claim['mention_ids'] for taxon in candidates.get(mid, set())}
        for taxon in taxa:
            for condition in {c['id'] for c in claim['conditions']}:
                indexed.setdefault((taxon, condition), []).append({
                    'claim_id': claim['id'], 'support': dict(claim['support']),
                    'plant_wording': [dict(mentions[mid]) for mid in claim['mention_ids'] if taxon in candidates.get(mid, set()) and mid in mentions],
                    'condition_wording': [dict(c) for c in claim['conditions'] if c['id'] == condition],
                    'preparation': deepcopy(claim['preparation']), 'part': deepcopy(claim['part']),
                    'route': deepcopy(claim['route']), 'dosage_expressions': deepcopy(claim['dosage_expressions']),
                    'relation_scope': claim['relation_scope'], 'statement_role': claim['statement_role'],
                    'subject_uncertain': claim['relation_scope'] in UNCERTAIN_SCOPES, 'possible_subjects': claim.get('possible_subjects', []),
                    'negated': bool(claim.get('negated')),
                    'link_basis': 'STORED_MENTION_CANDIDATE_AND_LEXICAL_TOPIC; not a confirmed historical identity or diagnostic equivalence',
                })
    return indexed


def compare_historical_contexts(contexts, study, paper):
    return [{**deepcopy(context), 'preparation_comparison': check_preparation(context['preparation'], study),
             'indication_comparison': compare_indication_wording(context, paper)} for context in contexts]


def preparation_across_statements(contexts):
    checks = [c['preparation_comparison'] for c in contexts]
    if not checks:
        return {'check': 'preparation', 'status': UNKNOWN, 'detail': 'No eligible source statement is linked to this candidate and topic.', 'requires_statement_review': True}
    if len(checks) == 1:
        return {**checks[0], 'claim_ids': [contexts[0]['claim_id']]}
    same = len({(c['status'], c['detail']) for c in checks}) == 1
    if same:
        return {**checks[0], 'claim_ids': [c['claim_id'] for c in contexts]}
    # Do not let one statement's oil stand in for a different statement with no form.
    return {'check': 'preparation', 'status': UNKNOWN,
            'detail': 'The linked historical statements have different or unstated preparations. Inspect each original statement; no pooled preparation comparison is assigned.',
            'requires_statement_review': True, 'claim_ids': [c['claim_id'] for c in contexts]}

"""A readable conversation handoff; full source records remain in JSON/Markdown."""
from __future__ import annotations

from html import escape
from urllib.parse import urlsplit

STATUSES = {'NOT_PROVIDED':'Not provided — ask the person',
            'NONE_REPORTED':'None explicitly reported — not independently verified',
            'LIST_PROVIDED':'List reported below', 'DETAILS_PROVIDED':'Details reported below'}
USE = {'NOT_ESTABLISHED':'Use not established', 'REPORTED_CURRENT_USE':'Current use reported',
       'REPORTED_PAST_USE':'Past use reported'}
DECISIONS = {'KEEP_FOR_READING':'Keep for further reading',
             'EXCLUDE_FROM_QUESTION':'Exclude from this question', 'NEEDS_FULL_TEXT':'Need full text or more information'}
SCOPE = 'Preparation for a healthcare conversation. Product contents, actual use and clinical safety have not been verified. No interaction check or recommendation to start, stop or change a product.'


def quantity_text(amount):
    if amount['amount_status']=='NOT_PROVIDED':return 'Individual amount not provided (NP; not zero)'
    return str(amount.get('operator') or '')+str(amount['quantity'])+' '+amount['unit']+' per '+str(amount.get('servingSizeQuantity'))+' '+str(amount.get('servingSizeUnit') or 'label serving')


def handoff_summary(record):
    packet=record['packet'];intake=packet['intake'];products=[]
    for item in packet['products']:
        reported=item['reported'];reviews=[]
        for entry in packet['linked_evidence']:
            if entry['item_id']!=reported['item_id']:continue
            review=entry['review'];latest={d['record_id']:d for d in review['decision_history']}
            rows={r['id']:r for b in review['packet']['branches'] for r in b['records']}
            decisions=[]
            for key,decision in latest.items():
                row=rows.get(key)
                if row is None:continue
                decisions.append({'title':row['paper']['title'],'url':row['paper']['url'],
                    'candidate_taxon_id':row['taxon_id'],'decision':DECISIONS[decision['decision']],
                    'reason':decision['reason'],'reviewer':decision['reviewer']})
            ingredient=next((r['name'] for r in item.get('label_ingredients',[]) if r['key']==entry.get('ingredient_key')),None)
            coverage=review['packet']['coverage'];external=coverage.get('public_search')
            note=('Public lookup: '+external['status'].replace('_',' ').lower()+' · '+external.get('provider','public source')+'. Bounded records only; inspect the full review for exact queries and failures.' if external else 'Local snapshot only; not an exhaustive literature search.')
            reviews.append({'question':review['packet']['protocol']['question'],'ingredient':ingredient,'coverage_note':note,
                            'source_review_id':review['id'],'record_count':len(rows),
                            'unreviewed_records':sum(key not in latest for key in rows),'decisions':decisions})
        label=reported.get('label_snapshot')
        products.append({'name':reported['name'],'brand':reported['brand'],'use':USE.get(reported.get('use_status'),'Use not established'),
            'actual_use':{k:reported[k] or 'Not provided' for k in ('dose','frequency','route','last_taken')},
            'stated_preparation':reported['preparation'] or 'Not provided','reported_reason':reported['reason_for_use'] or 'Not provided',
            'source_text':reported['source_text'],
            'label':{'id':label['label_id'],'url':label['source_url'],'sha256':label['sha256'],
                     'retrieved_at':label['retrieved_at'],'entry_date':label['raw'].get('entryDate'),
                     'market_status':'Off-market record' if label['raw'].get('offMarket')==1 else 'On-market record' if label['raw'].get('offMarket')==0 else 'Not stated'} if label else None,
            'ingredients':[{'name':r['name'],'nested':r['parent_key'] is not None,'notes':r['notes'],
                            'forms':'; '.join(' '.join(str(f[k]) for k in ('prefix','name') if f.get(k)) for f in r.get('forms',[])),
                            'amounts':[quantity_text(q) for q in r['quantities']]} for r in item.get('label_ingredients',[])],
            'other_ingredients':label['raw'].get('otheringredients') if label else None,
            'clarifications':[q['question'] for q in item['clarification_questions']],
            'clarification_notes':[n for n in packet.get('clarification_history',[]) if n['item_id']==reported['item_id']],
            'reviews':reviews})
    return {'title':intake['visit_label'],'record_id':record['id'],'saved_at':record['saved_at'],
            'origin':'Local reported preparation' if record['origin']=='LOCAL_CONSULTATION_PREPARATION' else 'Imported preparation — sources and clinical content unverified',
            'scope':SCOPE,'medicine_status':STATUSES[intake['other_medicines_status']], 'medicines':intake['other_medicines'],
            'allergy_status':STATUSES[intake['allergies_status']], 'allergies':intake['allergies'],
            'questions':intake['questions_for_professional'],'next_questions':packet['next_visit_questions'],'products':products}


def summary_markdown(record):
    s=handoff_summary(record)
    lines=['# Pharmacist conversation handoff',s['title'],s['origin'],s['scope'],
           'Record: '+s['record_id']+' · '+s['saved_at'],
           '## Questions to discuss',s['questions'] or 'No question recorded',*s['next_questions'],
           '## Other medicines',s['medicine_status'],s['medicines'],
           '## Allergies and previous reactions',s['allergy_status'],s['allergies']]
    for product in s['products']:
        lines+=['## '+product['name'],product['use'],'Brand: '+(product['brand'] or 'Not provided')]
        lines += [k.replace('_',' ').capitalize()+': '+v for k,v in product['actual_use'].items()]
        lines += ['Stated preparation: '+product['stated_preparation'],'Reported reason: '+product['reported_reason']]
        if product['label']:
            label=product['label'];lines+=['Selected NIH label '+str(label['id'])+' — bottle match not established',label['url'],
                'Entered: '+str(label['entry_date'])+' · '+label['market_status'],'Acquired: '+label['retrieved_at'],
                'Source SHA256: '+label['sha256'],'Declared ingredients — label quantities, not actual use:']
            for ingredient in product['ingredients']:
                lines+=['- '+('Within blend: ' if ingredient['nested'] else '')+ingredient['name']+': '+('; '.join(ingredient['amounts']) or 'Amount not provided'),ingredient['notes']]
                if ingredient['forms']:lines+=['Declared forms: '+ingredient['forms']]
            other=product['other_ingredients'] or {};lines+=['Other declared ingredients: '+(other.get('text') or '; '.join(r['name'] for r in other.get('ingredients',[])) or 'Not provided')]
        else:lines+=['Original wording:',product['source_text'] or 'Not provided']
        lines+=['Clarify before assessment:']+['- '+q for q in product['clarifications']]
        for note in product['clarification_notes']:
            lines += ['Recorded clarification — '+note['field']+': '+note['note'],
                      note['status']+' · '+note['source']+' · '+note['recorded_by']+' · '+note['created_at'],
                      'Original reported fields are preserved; this note is not independent verification.']
        for review in product['reviews']:
            lines+=['### Professional reading — not a clinical conclusion',review['question'],
                'Ingredient: '+str(review['ingredient'] or 'Manually recorded product'),
                review['coverage_note'],
                str(review['record_count'])+' candidate/study records screened; '+str(review['unreviewed_records'])+' have no recorded human reading decision.']
            if not review['decisions']:lines+=['No professional reading decision recorded. Automated screening is not approval.']
            for decision in review['decisions']:
                lines+=[decision['decision']+': '+decision['title'],decision['url'],
                        'Reason: '+decision['reason'],'Recorded by: '+decision['reviewer']]
    lines+=['## Full source record','This summary omits unreviewed abstracts and earlier decision events. The portable JSON and full report preserve original labels, all screened records and decision history.','Bring original packaging and the complete medicine list.']
    return '\n\n'.join(lines)+'\n'


def summary_html(record):
    s=handoff_summary(record)
    def e(v):return escape(str(v),quote=True)
    def paragraph(text,cls=''):return '<p'+(' class="'+cls+'"' if cls else '')+'>'+e(text).replace('\n','<br>')+'</p>'
    def source(url,title):
        try:parsed=urlsplit(url)
        except ValueError:return paragraph(title+' — URL not a supported web reference')
        if parsed.scheme not in ('https','http') or not parsed.hostname:return paragraph(title+' — URL not a supported web reference')
        return '<p><a href="'+e(url)+'" rel="noreferrer noopener">'+e(title)+'</a></p>'
    def heading(text,level=2):return f'<h{level}>'+e(text)+f'</h{level}>'
    out=['<!doctype html><html lang="en"><meta charset="utf-8">',
         '<title>'+e(s['title'])+' · FoliaTrace handoff</title>',
         '<style>body{font:16px/1.5 system-ui,sans-serif;color:#162b26;background:white;max-width:900px;margin:32px auto;padding:0 20px}h1{font-size:28px}h2{margin-top:28px;font-size:21px}h3{font-size:17px}p,li,dd{overflow-wrap:anywhere}a{color:#155b47}dl{display:grid;grid-template-columns:minmax(100px,1fr) minmax(0,3fr);gap:6px 18px}dt{font-weight:600}dd{margin:0}.notice{border-left:4px solid #8a5d16;background:#fff6e3;padding:12px}.source{font-size:13px}.ingredient{border-left:2px solid #cad7cf;padding-left:12px}.product{border-top:1px solid #cad7cf;margin-top:24px;padding-top:8px}.print-help{color:#52645c}@media print{body{font-size:10pt;max-width:none;margin:0;padding:0}.print-help{display:none}h2,h3{break-after:avoid}a{color:inherit}.notice{background:none;border:1px solid #aaa}a[href]::after{content:" (" attr(href) ")";font-size:8pt}@page{size:A4;margin:15mm}}</style>',
         '<body><main>',heading('Pharmacist conversation handoff',1),paragraph(s['title']),paragraph(s['origin'],'notice'),paragraph(s['scope'],'notice'),
         paragraph('Print or save a PDF using your browser’s print command. This standalone handoff contains reported health information; choose what to share.','print-help'),
         paragraph('Record '+s['record_id']+' · '+s['saved_at'],'source'),heading('Questions to discuss'),paragraph(s['questions'] or 'No question recorded')]
    out += [paragraph(q) for q in s['next_questions']]
    out += [heading('Other medicines'),paragraph(s['medicine_status']),paragraph(s['medicines']),heading('Allergies / previous reactions'),paragraph(s['allergy_status']),paragraph(s['allergies'])]
    for product in s['products']:
        out+=['<section class="product">',heading(product['name']),paragraph(product['use']),'<dl>']
        facts={'Brand':product['brand'] or 'Not provided',**{k.replace('_',' ').capitalize():v for k,v in product['actual_use'].items()},'Stated preparation':product['stated_preparation'],'Reported reason':product['reported_reason']}
        out += ['<dt>'+e(k)+'</dt><dd>'+e(v)+'</dd>' for k,v in facts.items()];out+=['</dl>']
        if product['label']:
            label=product['label'];out+=[source(label['url'],'NIH label '+str(label['id'])+' — bottle match not established'),
                paragraph('Entered: '+str(label['entry_date'])+' · '+label['market_status']+' · acquired '+label['retrieved_at'],'source'),
                paragraph('Source SHA256: '+label['sha256'],'source'),heading('Declared ingredients — not actual use',3)]
            for ingredient in product['ingredients']:
                out+=['<div class="ingredient">',paragraph(('Within blend: ' if ingredient['nested'] else '')+ingredient['name']),paragraph('; '.join(ingredient['amounts']) or 'Amount not provided'),paragraph(ingredient['notes'],'source'),'</div>']
                if ingredient['forms']:out+=[paragraph('Declared forms: '+ingredient['forms'])]
            other=product['other_ingredients'] or {};out+=[paragraph('Other ingredients: '+(other.get('text') or '; '.join(r['name'] for r in other.get('ingredients',[])) or 'Not provided'))]
        else:out+=[heading('Original recorded wording',3),paragraph(product['source_text'] or 'Not provided')]
        out+=[heading('Clarify before assessment',3),'<ul>']+['<li>'+e(q)+'</li>' for q in product['clarifications']]+['</ul>']
        for note in product['clarification_notes']:
            out += [heading('Recorded clarification · '+note['field'],3),paragraph(note['note']),
                    paragraph(note['status']+' · '+note['source']+' · '+note['recorded_by']+' · '+note['created_at'],'source'),
                    paragraph('Original fields remain as reported. This note is not independent verification.','source')]
        for review in product['reviews']:
            out+=[heading('Professional reading — not a clinical conclusion',3),paragraph(review['question']),paragraph('Ingredient: '+str(review['ingredient'] or 'Manually recorded product')),
                paragraph(review['coverage_note'],'source'),
                paragraph(str(review['record_count'])+' candidate/study records screened; '+str(review['unreviewed_records'])+' have no recorded human reading decision.')]
            if not review['decisions']:out+=[paragraph('No professional reading decision recorded. Automated screening is not approval.')]
            for decision in review['decisions']:
                out+=[source(decision['url'],decision['decision']+': '+decision['title']),paragraph('Reason: '+decision['reason']),paragraph('Recorded by: '+decision['reviewer'],'source')]
        out+=['</section>']
    out+=[heading('Full source record'),paragraph('This concise handoff omits unreviewed abstracts and earlier decision events. Keep the portable JSON or full report for complete original labels, screened records and reading history.'),paragraph('Bring original packaging and the complete medicine list.'),'</main></body></html>']
    return '\n'.join(out)

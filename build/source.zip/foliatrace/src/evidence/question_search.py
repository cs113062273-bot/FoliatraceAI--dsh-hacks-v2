"""Bounded Europe PMC lookup of PubMed-indexed records, using public terms only."""
from __future__ import annotations
import html
import re
import time
from urllib.parse import urlencode
from src.nlp.extract import SENSE_REQUIRED, NEVER_A_PLANT, normalize
from src.retrieval.index import tokens

SEARCH='https://www.ebi.ac.uk/europepmc/webservices/rest/search'


def public_term(value):
    text=' '.join(re.sub(r'[\x00-\x1f"\[\]\\]', ' ', value).split())
    if not text:raise ValueError('A substantive public outcome phrase is required')
    return 'TITLE_ABS:"'+text+'"'


def public_names(taxon,index=None):
    names=[taxon['name']]+[a['name'] for a in taxon['aliases'] if a['kind']=='SYNONYM' and re.fullmatch(r'[A-Z][a-z-]+ [a-z-]+',a['name'])][:3]
    common=[a['name'] for a in taxon['aliases'] if a['kind']=='VERNACULAR' and a.get('lang','en')=='en' and a['name'].isascii() and (len(a['name'])>=7 or ' ' in a['name']) and normalize(a['name']) not in SENSE_REQUIRED|NEVER_A_PLANT]
    def frequency(name):
        if index is None:return 0
        parts=tokens(name)
        if not parts:return 0
        rows=index.postings.get(min(parts,key=lambda w:index.df.get(w,0)),[])
        pattern=re.compile(r'\b'+re.escape(normalize(name))+r'\b')
        return sum(bool(pattern.search(index.texts[i])) for i,_ in rows)
    scored=[(frequency(n),n) for n in set(common)]
    usable=[n for count,n in sorted(scored,key=lambda v:(-v[0],len(v[1]),v[1])) if count or index is None][:2]
    return list(dict.fromkeys(names+taxon.get('drug_names',[])[:2]+usable))


def search_plan(taxa,outcomes,index=None,reference_pmids=()):
    if len(taxa)>3:raise ValueError('Public lookup supports at most three candidate identities; use an exact scientific name')
    endpoints=' OR '.join(public_term(t) for t in outcomes)
    plans=[]
    for t in taxa:
        names=public_names(t,index)
        plans.append({'taxon_id':t['id'],'name':t['name'],'names_used':names,
            'term':'SRC:MED AND ('+' OR '.join(public_term(n) for n in names)+') AND ('+endpoints+')',
            'orders':[{'sort':'relevance','limit':12},{'sort':'pub_date','limit':8}]})
    if reference_pmids:
        plans.append({'taxon_id':'REFERENCE_PMIDS','name':'Known PubMed reference identifiers','names_used':[],
            'term':'SRC:MED AND ('+' OR '.join('EXT_ID:'+p for p in reference_pmids)+')',
            'orders':[{'sort':'identifiers','limit':len(reference_pmids)}]})
    return plans


def plain(value):
    value=re.sub(r'</h[1-6]>|</label>', ': ', value or '',flags=re.I)
    return ' '.join(html.unescape(re.sub(r'<[^>]*>',' ',value)).split())


def paper_from_record(row,meta,candidate):
    if not isinstance(row,dict) or not isinstance(row.get('title'),str):raise ValueError('Invalid publication record')
    identifier=str(row['id'])
    if row.get('source')!='MED' or not identifier.isdigit():raise ValueError('Source returned a record outside the PubMed-indexed scope')
    type_list=row.get('pubTypeList') or {}
    if not isinstance(type_list,dict):raise ValueError('Invalid publication types')
    types=type_list.get('pubType',[]);original=row.get('abstractText') or ''
    if not isinstance(types,list) or any(not isinstance(t,str) for t in types) or not isinstance(original,str):
        raise ValueError('Invalid publication types or abstract text')
    return {'id':'PMID'+identifier,'pmid':identifier,'doi':row.get('doi'),'pmcid':row.get('pmcid'),
        'title':plain(row['title']),'original_title':plain(row['title']),'abstract':plain(original),
        'abstract_source_markup':original,'year':int(row['pubYear']) if str(row.get('pubYear','')).isdigit() else None,
        'authors':row.get('authorString') or '','publication_types':types,
        'licence':'EUROPE_PMC_RECORD_ABSTRACT_RIGHTS_WITH_PUBLISHER','source_id':'europe_pmc',
        'url':'https://pubmed.ncbi.nlm.nih.gov/'+identifier+'/',
        'provenance':meta,'abstract_rights':'LOCAL_CACHE_NOT_REDISTRIBUTED',
        'retracted':row.get('isRetracted') in ('Y',True) or any('retract' in t.lower() for t in types),
        'question_acquisition':{'provider':'Europe PMC / PubMed-indexed record','source':meta,'candidate_search':candidate,
             'text_scope':'Plain text rendered from source markup; quoted offsets refer to the stored plain text.'}}


def fetch_public_studies(client,plans):
    papers={};queries=[];errors=[];retracted=[];deadline=time.monotonic()+30;before=client.stats.get('requests',0)
    for plan in plans:
        entry={**plan,'searches':[],'returned_ids':[]};queries.append(entry)
        for order in plan['orders']:
            query=plan['term']+(' sort_date:y' if order['sort']=='pub_date' else '')
            url=SEARCH+'?'+urlencode({'query':query,'format':'json','resultType':'core','pageSize':order['limit']})
            try:
                remaining=deadline-time.monotonic()
                if remaining<=0:raise TimeoutError('The 30-second public lookup budget ended; local and received records remain available')
                body,meta=client.json(url,max_bytes=2_000_000,patient=False,timeout=min(8,remaining))
                if 'errMsg' in body or 'error' in body:raise ValueError('Europe PMC rejected the query')
                rows=body['resultList']['result']
                if not isinstance(rows,list) or len(rows)>order['limit']:raise ValueError('Invalid or unbounded source response')
                ids=[]
                for row in rows:
                    paper=paper_from_record(row,meta,plan['taxon_id']);papers[paper['id']]=paper;ids.append(paper['pmid'])
                    if paper['retracted']:retracted.append(paper['id'])
                entry['searches'].append({'order':order['sort'],'source':meta,'hit_count':body.get('hitCount'),
                                           'returned_ids':ids,'query_translation':body.get('request',{}).get('queryString')})
                entry['returned_ids']+= [k for k in ids if k not in entry['returned_ids']]
                if plan['taxon_id']=='REFERENCE_PMIDS':
                    requested={v for v in re.findall(r'EXT_ID:(\d+)',plan['term'])}
                    missing=requested-set(ids)
                    if missing:errors.append({'taxon_id':plan['taxon_id'],'stage':'reference','detail':'Requested identifiers not returned: '+', '.join(sorted(missing))})
            except (OSError,RuntimeError,ValueError,KeyError,TypeError) as error:
                errors.append({'taxon_id':plan['taxon_id'],'stage':'search','detail':str(error)[:300]})
    return list(papers.values()),{'provider':'Europe PMC (PubMed-indexed records)',
        'status':'NO_RESOLVED_CANDIDATES' if not plans else 'PARTIAL' if errors and papers else 'UNAVAILABLE' if errors else 'BOUNDED_SEARCH_COMPLETED',
        'queries':queries,'errors':errors,'received_records':len(papers),'excluded_retracted_ids':sorted(set(retracted)),
        'network_used':client.stats.get('requests',0)>before,
        'scope':'At most 12 relevance and 8 publication-date records per candidate, at most three candidates, plus up to ten explicitly supplied PubMed references. Exact title/abstract terms; not an exhaustive systematic search. Cached acquisition dates are retained.',
        'sent_fields':['CURATED_PLANT_NAMES','EXACT_PUBLIC_OUTCOME_PHRASES','EXPLICIT_PUBLIC_REFERENCE_IDS'],
        'not_sent':['FREE_TEXT_QUESTION','PRODUCT_SOURCE_TEXT','CONSULTATION_DETAILS','MEDICINES','ALLERGIES']}

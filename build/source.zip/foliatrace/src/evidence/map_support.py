"""Statement-bound support for the chapter-plant research map.

The map follows the same mention links as the workspace. A chapter title alone
never lends another plant's sentence to every plant listed in that title.
"""
LEAD_WEIGHT = {'PRECLINICAL_ONLY': 3, 'SPECIES_NAMED_NO_TESTED_RESULT': 1, 'NO_STUDY_RETRIEVED': 1}


def chapter_subjects(result):
    mentions = {m['id']: m for m in result['mentions']}
    return {r['mention_id']: r for r in result['resolutions'] if mentions.get(r['mention_id'], {}).get('method') == 'SOURCE_HEADING_SUBJECT' and r['candidates']}


def statement_subjects(claim, result):
    """Primary heading candidates actually reached by this statement's links.

    Primary means the map's stated identity assumption, not an identification.
    Uncertain links remain inspectable but cannot inflate the lead score.
    """
    heading = chapter_subjects(result)
    heading_ids = {r['candidates'][0]['taxon_id'] for r in heading.values()}
    resolutions = {r['mention_id']: r for r in result['resolutions']}
    linked = {identifier: resolutions[identifier] for identifier in claim['mention_ids'] if resolutions.get(identifier, {}).get('candidates')}
    subject_ids = {r['candidates'][0]['taxon_id'] for r in linked.values()}
    direct = claim['relation_scope'] == 'SENTENCE' and len(subject_ids) == 1 and not set(linked) & set(heading)
    single_heading = claim['relation_scope'] == 'SOURCE_SECTION_HEADING' and len({r['candidates'][0]['taxon_id'] for r in heading.values()}) == 1
    attribution = 'EXPLICIT_SINGLE_PLANT' if direct else 'SINGLE_HEADING_SUBJECT' if single_heading else 'UNCERTAIN_SOURCE_LINK'
    return {identifier: {'attribution': attribution, 'eligible_for_priority': direct or single_heading, 'mention_ids': [mid for mid, r in linked.items() if r['candidates'][0]['taxon_id'] == identifier], 'identity_candidates': list({c['taxon_id']: {'taxon_id': c['taxon_id'], 'name': c['name']} for r in linked.values() if r['candidates'][0]['taxon_id'] == identifier for c in r['candidates']}.values())} for identifier in subject_ids & heading_ids}


def priority(row, state, outside):
    """Expose each actual contribution; uncertain historical links contribute zero."""
    records = row['direct_statements']
    books = len(row['priority_books'])
    components = {'source_statements': records, 'additional_books': 2 * max(0, books - 1), 'independent_places': min((outside.get('independent_use') or {}).get('places', 0), 12), 'related_species': min((outside.get('relatives') or {}).get('species', 0), 3), 'research_state_weight': LEAD_WEIGHT.get(state, 0), 'poison_divisor': 2 if outside.get('recorded_poisonous') else 1}
    base = sum(components[k] for k in ('source_statements', 'additional_books', 'independent_places', 'related_species'))
    score = components['research_state_weight'] * base // components['poison_divisor']
    if not records or state == 'NO_STUDY_RETRIEVED' and records < 3:
        score = 0
    return score, components

"""Literal cross-source identity reading, separate from candidate ranking.

Only matching chapter headings (with two declared spelling variants) are joined.
An author's scientific-name wording is not transferred to another author's plant.
"""
import re
from src.nlp.extract import normalize
from src.common import digest
from src.evidence.comparability import name_pattern
from src.nlp.headings import heading_names


def heading_key(text):
    return normalize(text).replace('camomile', 'chamomile').replace('featherfew', 'feverfew')


def heading_keys(title):
    """Every spelling of every plant a heading announces."""
    return {heading_key(form) for name in heading_names(title) for form in name['forms']}


def historical_name_references(result, passages, taxa, withdrawn=()):
    taxmap = {taxon['id']: taxon for taxon in taxa}
    output = {}
    keys_by_passage = {passage['id']: heading_keys(passage['title']) for passage in passages}
    for group in result['identity_counterfactuals']:
        keys = {heading_key(group['label'])} | {heading_key(form) for form in group.get('forms', [])}
        references = []
        for passage in passages:
            if (passage['id'] == result['source'].get('id') or
                    {passage['id'], passage.get('source_id')} & set(withdrawn) or
                    not (keys_by_passage[passage['id']] & keys)):
                continue
            text = passage['title'] + '\n\n' + passage['text']
            names = []
            for branch in group['branches']:
                taxon = taxmap.get(branch['taxon_id'])
                if not taxon:
                    continue
                for alias in taxon['aliases']:
                    if alias['kind'] not in ('ACCEPTED_NAME', 'SYNONYM', 'INPUT_SYNONYM_MATCH'):
                        continue
                    for match in re.finditer(name_pattern(alias['name']), text, re.I):
                        names.append({'text': match.group(), 'start': match.start(), 'end': match.end(),
                                      'candidate_id': taxon['id'], 'candidate_name': taxon['name'],
                                      'alias_kind': alias['kind'], 'matched_alias': alias['name']})
            unique = {}
            for name in names:
                unique[(name['start'], name['end'], name['candidate_id'])] = name
            names = sorted(unique.values(), key=lambda name: (name['start'], -name['end']))
            windows = []
            for name in names:
                boundary = text.rfind('\n\n', 0, name['start'])
                paragraph_start = boundary + 2 if boundary >= 0 else 0
                paragraph_end = text.find('\n\n', name['end'])
                if paragraph_end < 0:
                    paragraph_end = len(text)
                start, end = max(paragraph_start, name['start'] - 220), min(paragraph_end, name['end'] + 240)
                if start > paragraph_start:
                    space = text.find(' ', start, name['start'])
                    if space >= 0:
                        start = space + 1
                if end < paragraph_end:
                    space = text.rfind(' ', name['end'], end)
                    if space >= 0:
                        end = space
                if windows and start <= windows[-1][1]:
                    windows[-1][1] = max(windows[-1][1], end)
                else:
                    windows.append([start, end])
            excerpts = [{'text': text[start:end], 'start': start, 'end': end,
                         'names': [name for name in names if start <= name['start'] and name['end'] <= end]}
                        for start, end in windows]
            references.append({
                'source': {field: passage.get(field) for field in ('id', 'title', 'collection', 'date', 'url', 'licence', 'source_id')},
                'input': text, 'text_sha256': digest(text), 'excerpts': excerpts,
                'matched_heading': passage['title'], 'heading_rule': 'NORMALIZED_HEADING_NAME_AND_ORTHOGRAPHIC_FORMS',
                'status': 'SCIENTIFIC_NAME_WORDING_PRESENT' if excerpts else 'MATCHING_HEADING_NO_CANDIDATE_SCIENTIFIC_NAME_FOUND',
                'scope': 'Another source uses this heading and contains the quoted name wording. Read its contrasts and context; it does not identify the plant in the current source or change candidate ranks or study relations.',
            })
        output[group['key']] = references
    return output

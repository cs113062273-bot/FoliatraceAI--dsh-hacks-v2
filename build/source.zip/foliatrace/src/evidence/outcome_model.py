"""Local supervised outcome-direction proposals, always conditional on a PICO question."""
from pathlib import Path
import joblib
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression


LABELS = {-1: 'DECREASED', 0: 'NO_SIGNIFICANT_DIFFERENCE', 1: 'INCREASED'}


def model_input(evidence, outcome, intervention='', comparator=''):
    # Explicit fields keep the task relative to the requested outcome and comparison.
    # Word/character models can learn direction language without a runtime LLM.
    return f"OUTCOME: {outcome}\nINTERVENTION: {intervention}\nCOMPARATOR: {comparator}\nEVIDENCE: {evidence}"


def make_model(c=1.0, *, characters=True):
    features = [('words', TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=35000, sublinear_tf=True))]
    if characters:
        features.append(('characters', TfidfVectorizer(analyzer='char_wb', ngram_range=(3, 5), min_df=3, max_features=45000, sublinear_tf=True)))
    return Pipeline([('features', FeatureUnion(features)), ('classifier', LogisticRegression(C=c, max_iter=600, class_weight='balanced', random_state=20261021, solver='liblinear'))])


class OutcomeModel:
    def __init__(self, model=None, metadata=None):
        self.model, self.metadata = model, metadata or {}

    @classmethod
    def load(cls, path, metadata=None):
        path = Path(path)
        return cls(joblib.load(path), metadata) if path.exists() else cls()

    def predict(self, evidence, outcome, intervention, comparator):
        if self.model is None:
            return {'status': 'NOT_TRAINED', 'direction': None, 'scope': 'No learned outcome model installed. Run scripts/train_outcome_model.py.'}
        value = model_input(evidence, outcome, intervention, comparator)
        code = int(self.model.predict([value])[0])
        return {'status': 'MODEL_PROPOSAL_REQUIRES_REVIEW', 'direction_code': code, 'direction': LABELS[code], 'method': self.metadata.get('selected_method', 'TFIDF_LOGISTIC'), 'model_corpus_sha256': self.metadata.get('corpus_sha256'), 'scope': 'Direction of the requested outcome for the specified intervention versus comparator, on supplied evidence. Direction is not clinical benefit or historical-use validation. No calibrated probability is claimed.'}

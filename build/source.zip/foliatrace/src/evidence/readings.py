"""Selected factual reading notes, kept separate from automated evidence relations."""
from copy import deepcopy


def active_reading_sets(sets, taxon_ids, condition_ids, withdrawn=()):
    taxa, conditions, excluded = set(taxon_ids), set(condition_ids), set(withdrawn)
    result = []
    for item in sets:
        if item['id'] in excluded or not taxa.intersection(item['taxon_ids']) or not conditions.intersection(item['condition_ids']):
            continue
        item = deepcopy(item)
        item['studies'] = [s for s in item['studies'] if not {s['publication']['id'], s['publication'].get('pmcid'), s['publication']['pmid']}.intersection(excluded)]
        if item['studies']:
            result.append(item)
    return result

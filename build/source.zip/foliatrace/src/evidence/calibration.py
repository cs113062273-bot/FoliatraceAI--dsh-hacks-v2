"""Held-out study-design calibration; never a historical identity probability."""
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import softmax


def temperature_scale(probabilities, temperature):
    return softmax(np.log(np.clip(probabilities,1e-9,1)) / temperature,axis=1)


def fit_temperature(probabilities, expected):
    def loss(t):
        p=temperature_scale(probabilities,t)
        return -np.log(np.clip(p[np.arange(len(expected)),expected],1e-9,1)).mean()
    return float(minimize_scalar(loss,bounds=(.3,5),method='bounded').x)


def calibration_metrics(probabilities, expected, bins=10):
    confidence=probabilities.max(axis=1);correct=probabilities.argmax(axis=1)==expected
    onehot=np.eye(probabilities.shape[1])[expected]
    rows=[];ece=0.0
    for i in range(bins):
        selected=(confidence>=i/bins)&(confidence<(i+1)/bins if i<bins-1 else confidence<=1)
        n=int(selected.sum())
        acc=float(correct[selected].mean()) if n else None
        conf=float(confidence[selected].mean()) if n else None
        if n:ece+=n/len(expected)*abs(acc-conf)
        rows.append({'lower':i/bins,'upper':(i+1)/bins,'n':n,'accuracy':acc,'mean_confidence':conf})
    return {'n':len(expected),'multiclass_brier':float(((probabilities-onehot)**2).sum(axis=1).mean()),'ece_10_bins':float(ece),'reliability_bins':rows,'limitation':'Small silver-labelled study-design split; not historical identity, clinical efficacy or expert calibration.'}

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from src.common import ROOT, now, digest


def review_anchors(analysis):
    """Match a judgement's source and question without using ranked row IDs."""
    source = analysis.get('source', {})
    source_key = digest(json.dumps({
        'source': {k: source.get(k) for k in ('id', 'title', 'url', 'date', 'context')},
        'text': analysis.get('input'),
    }, sort_keys=True, ensure_ascii=False))
    anchors = {}
    for group in analysis.get('identity_counterfactuals', []):
        occurrences = tuple(sorted((o['start'], o['end'], o['text']) for o in group['occurrences']))
        for branch in group['branches']:
            target = ('identity', f"{group['key']}::{branch['taxon_id']}")
            anchors[target] = (source_key, 'identity', group['key'], occurrences, branch['taxon_id'], branch['name'])
    for row in analysis.get('evidence', []):
        paper_key = digest(json.dumps({k: row['paper'].get(k) for k in
                           ('id', 'title', 'abstract', 'doi', 'year', 'licence')},
                           sort_keys=True, ensure_ascii=False))
        anchors[('evidence', row['id'])] = (source_key, 'evidence', row['taxon_id'], row['condition_id'], paper_key)
    return anchors


class GraphStore:
    def __init__(self, path=None):
        self.path = path or ROOT / ".cache" / "foliatrace.sqlite"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript("""
              CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, created_at TEXT NOT NULL, pipeline TEXT NOT NULL, snapshot TEXT NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)));
              CREATE TABLE IF NOT EXISTS graph_nodes(run_id TEXT NOT NULL REFERENCES runs(id) ON DELETE CASCADE, id TEXT NOT NULL, kind TEXT NOT NULL, label TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(run_id,id));
              CREATE TABLE IF NOT EXISTS graph_edges(run_id TEXT NOT NULL REFERENCES runs(id) ON DELETE CASCADE, id TEXT NOT NULL, subject TEXT NOT NULL, predicate TEXT NOT NULL, object TEXT NOT NULL, source_id TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(run_id,id));
              CREATE INDEX IF NOT EXISTS edge_subject ON graph_edges(run_id,subject,predicate);
              CREATE INDEX IF NOT EXISTS edge_object ON graph_edges(run_id,object,predicate);
              CREATE TABLE IF NOT EXISTS reviews(run_id TEXT NOT NULL REFERENCES runs(id) ON DELETE CASCADE, target_kind TEXT NOT NULL CHECK(target_kind IN ('identity','evidence')), target_id TEXT NOT NULL, decision TEXT NOT NULL CHECK(decision IN ('ACCEPT','REJECT','INSUFFICIENT_INFORMATION')), reason TEXT NOT NULL, reviewer TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(run_id,target_kind,target_id));
            """)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=20)
        try:
            db.execute("PRAGMA foreign_keys=ON")
            # sqlite3.Connection.__exit__ commits/rolls back but does not close.
            # Close deterministically so isolated Windows builds can remove the DB.
            with db:
                yield db
        finally:
            db.close()

    def put(self, analysis):
        with self.connect() as db:
            kept = db.execute("SELECT * FROM reviews WHERE run_id=?", (analysis["run_id"],)).fetchall()
            db.execute("DELETE FROM runs WHERE id=?", (analysis["run_id"],))
            db.execute("INSERT INTO runs VALUES(?,?,?,?,?)", (analysis["run_id"], now(), analysis["pipeline_version"], analysis["snapshot_sha256"], json.dumps(analysis, ensure_ascii=False)))
            for node in analysis["graph"]["nodes"]:
                db.execute("INSERT INTO graph_nodes VALUES(?,?,?,?,?)", (analysis["run_id"], node["id"], node["kind"], node["label"], json.dumps(node, ensure_ascii=False)))
            ids = {n["id"] for n in analysis["graph"]["nodes"]}
            for edge in analysis["graph"]["edges"]:
                if edge["subject"] not in ids or edge["object"] not in ids or not edge.get("provenance"):
                    raise ValueError("Graph edge lacks referenced object or provenance")
                db.execute("INSERT INTO graph_edges VALUES(?,?,?,?,?,?,?)", (analysis["run_id"], edge["id"], edge["subject"], edge["predicate"], edge["object"], edge["provenance"]["source_id"], json.dumps(edge, ensure_ascii=False)))
            db.executemany("INSERT INTO reviews VALUES(?,?,?,?,?,?,?)", kept)

    def get(self, run_id):
        with self.connect() as db:
            row = db.execute("SELECT payload FROM runs WHERE id=?", (run_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def put_review(self, run_id, review):
        # Researcher judgements are kept apart from automated output; one current decision per target.
        with self.connect() as db:
            db.execute("INSERT INTO reviews VALUES(?,?,?,?,?,?,?) ON CONFLICT(run_id,target_kind,target_id) DO UPDATE SET decision=excluded.decision, reason=excluded.reason, reviewer=excluded.reviewer, created_at=excluded.created_at", (run_id, review["target_kind"], review["target_id"], review["decision"], review["reason"], review["reviewer"], now()))

    def delete_review(self, run_id, target_kind, target_id):
        analysis = self.get(run_id)
        with self.connect() as db:
            # Clear the judgement for this exact source/target across rankings;
            # an older copy must not reappear immediately after removal.
            matches = self._matching_reviews(db, analysis) if analysis else []
            targets = {(row['run_id'], row['target_kind'], row['target_id']) for target, row in matches
                       if target == (target_kind, target_id)}
            targets.add((run_id, target_kind, target_id))
            db.executemany('DELETE FROM reviews WHERE run_id=? AND target_kind=? AND target_id=?', targets)

    def _matching_reviews(self, db, analysis):
        current = review_anchors(analysis)
        targets = {}
        for target, anchor in current.items():
            targets.setdefault(anchor, []).append(target)
        rows = db.execute("""
            SELECT r.run_id,r.target_kind,r.target_id,r.decision,r.reason,r.reviewer,r.created_at,n.payload
            FROM reviews r JOIN runs n ON n.id=r.run_id
            WHERE json_extract(n.payload,'$.source.id')=? AND json_extract(n.payload,'$.input')=?
            ORDER BY r.created_at DESC,r.run_id
        """, (analysis['source']['id'], analysis['input'])).fetchall()
        origins, matches = {}, []
        for row in rows:
            origin_id, kind, target_id, decision, reason, reviewer, created_at, payload = row
            if origin_id not in origins:
                origins[origin_id] = current if origin_id == analysis['run_id'] else review_anchors(json.loads(payload))
            anchor = origins[origin_id].get((kind, target_id))
            for target in targets.get(anchor, []):
                matches.append((target, {'run_id': origin_id, 'target_kind': kind, 'target_id': target_id,
                                        'decision': decision, 'reason': reason, 'reviewer': reviewer, 'created_at': created_at}))
        return matches

    def reviews(self, run_id, analysis=None):
        analysis = analysis or self.get(run_id)
        if not analysis:
            return []
        with self.connect() as db:
            matches = self._matching_reviews(db, analysis)
        current = {}
        for target, row in matches:
            if target in current:
                continue
            current[target] = {**{k: row[k] for k in ('decision', 'reason', 'reviewer', 'created_at')},
                               'target_kind': target[0], 'target_id': target[1],
                               'origin_run_id': row['run_id'], 'carried_forward': row['run_id'] != run_id,
                               'match_basis': 'EXACT_SOURCE_AND_RESEARCH_TARGET',
                               'kind': 'RESEARCHER_REVIEW_NOT_SOURCE_OR_MODEL_OUTPUT'}
        return sorted(current.values(), key=lambda row: row['created_at'])

    def neighborhood(self, run_id, focus=None, predicate=None, source_id=None, limit=100):
        where, params = ["run_id=?"], [run_id]
        if focus:
            where.append("(subject=? OR object=?)")
            params.extend([focus, focus])
        if predicate:
            where.append("predicate=?")
            params.append(predicate)
        if source_id:
            where.append("source_id=?")
            params.append(source_id)
        with self.connect() as db:
            rows = db.execute("SELECT payload FROM graph_edges WHERE " + " AND ".join(where) + " ORDER BY id LIMIT ?", (*params, limit)).fetchall()
            edges = [json.loads(r[0]) for r in rows]
            ids = {e[x] for e in edges for x in ("subject", "object")}
            nodes = [json.loads(r[0]) for r in db.execute("SELECT payload FROM graph_nodes WHERE run_id=?", (run_id,)) if json.loads(r[0])["id"] in ids]
        return {"nodes": nodes, "edges": edges}

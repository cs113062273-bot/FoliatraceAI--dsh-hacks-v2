"""Source acquisition, rights and snapshot manifests."""

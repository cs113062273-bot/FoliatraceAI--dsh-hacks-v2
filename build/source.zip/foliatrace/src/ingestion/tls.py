"""Use operating-system trust stores on Windows; certificate verification stays enabled."""
import os
import ssl


def tls_context():
    if os.name == "nt":
        import truststore
        return truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    return ssl.create_default_context()

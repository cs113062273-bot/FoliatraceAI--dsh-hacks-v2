"""PubMed access shared by the literature snapshot and on-demand lookups for new plants."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from urllib.parse import urlencode

from src.nlp.extract import SENSE_REQUIRED, NEVER_A_PLANT, normalize

ESEARCH = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi'
EFETCH = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi'
HUMAN = ' AND ("randomized controlled trial"[pt] OR "clinical trial"[pt] OR "meta-analysis"[pt] OR "systematic review"[pt])'
PRECLINICAL = ' AND ("animals"[mh:noexp] OR "in vitro techniques"[mh]) NOT "humans"[mh:noexp]'
REVIEW = ' AND "review"[pt] NOT "systematic review"[pt]'


def tiers():
    return [('human', HUMAN, 24), ('review', REVIEW, 5), ('preclinical', PRECLINICAL, 8), ('any', '', 6)]


def name_clause(taxon):
    """Scientific names, plus a distinctive common name when it cannot mean something else."""
    names = [taxon['name']]
    names += [a['name'] for a in taxon['aliases'] if a['kind'] == 'SYNONYM' and re.fullmatch(r'[A-Z][a-z-]+ [a-z-]+', a['name'])][:3]
    common = [a['name'] for a in taxon['aliases'] if a['kind'] == 'VERNACULAR' and a.get('lang', 'en') == 'en']
    usable = [n for n in common if normalize(n) not in SENSE_REQUIRED and normalize(n) not in NEVER_A_PLANT and (' ' in n or len(n) >= 7) and n.isascii()]
    names += taxon.get('drug_names', [])[:2] + sorted(usable, key=len)[:2]
    return ' OR '.join(f'"{n}"[tiab]' for n in dict.fromkeys(names))


def text_of(node):
    return ' '.join(''.join(node.itertext()).split()) if node is not None else ''


def parse_articles(xml_text):
    rows = []
    for item in ET.fromstring(xml_text).findall('PubmedArticle'):
        citation = item.find('MedlineCitation')
        article = citation.find('Article')
        pmid = citation.findtext('PMID')
        abstract = ' '.join(((node.get('Label') + ': ') if node.get('Label') else '') + text_of(node) for node in article.findall('Abstract/AbstractText'))
        types = [text_of(t) for t in article.findall('PublicationTypeList/PublicationType')]
        ids = {i.get('IdType'): i.text for i in item.findall('PubmedData/ArticleIdList/ArticleId')}
        year = citation.findtext('.//PubDate/Year') or (re.search(r'\d{4}', citation.findtext('.//PubDate/MedlineDate') or '') or [None])[0] if article is not None else None
        authors = ', '.join(f"{a.findtext('LastName')} {a.findtext('Initials') or ''}".strip() for a in article.findall('AuthorList/Author') if a.findtext('LastName'))[:300]
        rows.append({'pmid_key': pmid, 'id': f'PMID{pmid}', 'pmid': pmid, 'doi': ids.get('doi'), 'pmcid': ids.get('pmc'), 'title': text_of(article.find('ArticleTitle')), 'original_title': text_of(article.find('ArticleTitle')), 'abstract': abstract, 'year': year, 'authors': authors, 'publication_types': types, 'licence': 'PUBMED_RECORD_RIGHTS_WITH_PUBLISHER', 'source_id': 'pubmed', 'url': f'https://pubmed.ncbi.nlm.nih.gov/{pmid}/', 'provenance': {'url': EFETCH + '?' + urlencode({'db': 'pubmed', 'id': pmid})}, 'retracted': any('Retract' in t for t in types), 'abstract_rights': 'LOCAL_CACHE_NOT_REDISTRIBUTED'})
    return rows


def fetch_records(client, pmids):
    if not pmids:
        return []
    url = EFETCH + '?' + urlencode({'db': 'pubmed', 'id': ','.join(pmids), 'retmode': 'xml'})
    text, _ = client.get(url, max_bytes=60_000_000)
    return parse_articles(text)

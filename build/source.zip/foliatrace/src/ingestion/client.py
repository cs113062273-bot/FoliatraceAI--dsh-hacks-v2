from __future__ import annotations

import json
import time
import threading
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from src.common import ROOT, digest, now, read_json, write_json
from src.ingestion.tls import tls_context


class ScientificClient:
    """Bounded, persistent GET cache. Cache hits make offline reruns deterministic."""
    _throttle_lock = threading.Lock()
    _last_by_host = {}

    def __init__(self, cache: Path | None = None, offline=False, interval=0.4):
        self.cache = cache or ROOT / ".cache" / "scientific"
        self.cache.mkdir(parents=True, exist_ok=True)
        self.offline, self.interval = offline, interval
        self.last_request = 0.0
        self.stats = {"hits": 0, "requests": 0, "errors": 0}

    def get(self, url: str, *, max_bytes=10_000_000, patient=True, timeout=35) -> tuple[str, dict]:
        allowed = {"www.gutenberg.org", "www.ebi.ac.uk", "api.gbif.org", "pubchem.ncbi.nlm.nih.gov", "huggingface.co", "api.crossref.org", "www.wikidata.org", "verifier.globalnames.org", "query.wikidata.org", "en.wikipedia.org", "es.wikipedia.org", "eutils.ncbi.nlm.nih.gov", "api.ods.od.nih.gov"}
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname not in allowed:
            raise ValueError("Source URL is not in the scientific acquisition allowlist")
        path = self.cache / f"{digest(url)}.json"
        if path.exists():
            record = read_json(path)
            if digest(record["body"]) != record["sha256"]:
                raise ValueError("Cached response checksum mismatch")
            self.stats["hits"] += 1
            return record["body"], record["metadata"]
        if self.offline:
            raise RuntimeError(f"Offline cache miss: {url}")
        for attempt in range(3):
            with self._throttle_lock:
                last = self._last_by_host.get(parsed.hostname,0)
                time.sleep(max(0,self.interval-(time.monotonic()-last)))
                self._last_by_host[parsed.hostname]=time.monotonic()
            self.stats["requests"] += 1
            try:
                request = Request(url, headers={"User-Agent": "FoliaTrace/0.5 (noncommercial research prototype; bounded requests)", "Accept": "application/sparql-results+json, application/json, */*"})
                with urlopen(request, timeout=timeout, context=tls_context()) as response:
                    final = urlparse(response.url)
                    if final.scheme != "https" or final.hostname not in allowed:
                        raise ValueError("Redirect outside scientific source allowlist")
                    raw = response.read(max_bytes + 1)
                    if len(raw) > max_bytes:
                        raise ValueError("Response exceeds acquisition bound")
                    text = raw.decode("utf-8-sig")
                metadata = {"url": url, "retrieved_at": now(), "sha256": digest(text), "bytes": len(raw)}
                write_json(path, {"body": text, "sha256": digest(text), "metadata": metadata})
                return text, metadata
            except (URLError, TimeoutError) as exc:
                retry_after = exc.headers.get("retry-after", "") if isinstance(exc, HTTPError) else ""
                if retry_after.isdigit() and int(retry_after) > 60:
                    raise RuntimeError("Server requested long retry delay; acquisition stopped") from exc
                if isinstance(exc, HTTPError) and exc.code < 500 and exc.code != 429:
                    self.stats["errors"] += 1
                    raise
                # A reader is waiting: a rate limit ends this route instead of holding the page.
                if attempt == 2 or not patient:
                    self.stats["errors"] += 1
                    raise
                time.sleep(min(int(retry_after) if 'retry_after' in locals() and retry_after.isdigit() else 2 ** attempt, 60))
        raise RuntimeError("Acquisition attempts exhausted")

    def json(self, url, **kwargs):
        text, meta = self.get(url, **kwargs)
        return json.loads(text), meta

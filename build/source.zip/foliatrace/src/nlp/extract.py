from __future__ import annotations

import bisect
import json
import re
import unicodedata
from functools import lru_cache
from pathlib import Path

from rapidfuzz import fuzz, process

from src.nlp.headings import heading_names


@lru_cache(maxsize=200_000)
def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text).casefold().replace("æ", "ae").replace("œ", "oe").replace("×", " x ")
    return " ".join(re.sub(r"[^\w]+", " ", "".join(c for c in text if not unicodedata.combining(c))).split())


@lru_cache(maxsize=256)
def topic_pattern(terms):
    parts = []
    for term in terms:
        word = normalize(term)
        tail = r'(?!\s+(?:capacity|capacities|ratio|ratios|behaviour|behavior|kinetics)\b)' if word in ('swelling', 'swellings') else ''
        parts.append(re.escape(word) + tail)
    return re.compile(r'\b(?:' + '|'.join(parts) + r')\b')


def has_research_topic_wording(text, terms):
    """Modern-paper lexical screening; material swelling is not symptom wording.

    Other occurrences remain eligible, and this does not classify diagnoses.
    Historical extraction retains the original words and its separate rules.
    """
    return bool(topic_pattern(tuple(terms)).search(normalize(text)))


def normalized_offsets(text):
    chars, mapping = [], []
    for index, char in enumerate(text):
        value = normalize(char)
        if not value:
            value = " "
        for c in value:
            if c == " " and (not chars or chars[-1] == " "):
                continue
            chars.append(c)
            mapping.append(index)
    return "".join(chars), mapping


# Transparent historical/modern lexical hypotheses. No historical term is declared
# medically equivalent; the mapping is a retrieval aid and is labelled as such.
CONDITIONS = {
    "headache": ["headache", "head-ache", "head ache", "headaches", "head-ach", "headach", "pains in the head", "pain in the head", "griefs and pains of the head"],
    "migraine": ["migraine", "migraines", "megrim", "hemicrania"],
    "sleep": ["sleep", "sleeping", "insomnia", "sleeplessness", "sleepless", "wakefulness", "provokes sleep", "procures sleep", "cause sleep", "causes sleep", "induce sleep", "induces sleep", "promotes sleep", "to sleep", "poor sleep", "sleep problems", "trouble sleeping"],
    "anxiety": ["anxiety", "anxious", "nervous excitement", "restlessness", "troublesome cares", "wearisomnesse", "weariness"],
    "depression": ["depression", "depressive", "melancholy", "melancholia"],
    "digestive_symptoms": ["digestion", "indigestion", "stomach", "stomacke", "colic", "colick", "cholic", "bowels", "irritable bowel", "dyspepsia", "flatulence", "flatulent", "wind", "griping", "torments of the belly", "heartburn"],
    "diarrhoea": ["diarrhoea", "diarrhea", "diarrhoeas", "flux", "fluxes", "bloody flux", "dysentery", "looseness of the bowels", "lask", "cholera"],
    "constipation": ["constipation", "costiveness", "costive", "opens the belly", "loosens the belly", "purgative", "cathartic", "aperient", "laxative"],
    "nausea_vomiting": ["vomiting", "nausea", "sea-sickness", "seasickness", "provocation to vomit"],
    "pain": ["pain", "pains", "paine", "paines", "aches", "ache", "stitches", "griefs", "bruises"],
    "joint_gout": ["gout", "goute", "gowt", "sciatica", "rheumatism", "rheumatic", "arthritis", "joint-pains", "pains in the joints", "hip-gout", "lumbago"],
    "inflammation": ["inflammation", "inflammations", "swelling", "swellings", "tumours"],
    "fever": ["fever", "fevers", "feuers", "feauers", "ague", "agues", "febrifuge", "tertian", "quartan", "malaria", "malarial", "diaphoretic", "sudorific"],
    "cough": ["cough", "coughs", "coughes", "cough-mixture", "whooping cough", "hoarseness", "expectorant"],
    "respiratory": ["asthma", "shortness of breath", "cold", "influenza", "shortwinded", "wheezing", "wheezings", "consumption", "phthisis", "catarrh", "catarrhal", "colds", "a cold", "bronchitis", "bronchial", "stuffing of the chest", "croup", "pleurisy", "lungs", "pneumonia", "tuberculosis"],
    "wounds": ["wound", "wounds", "ulcer", "ulcers", "sore", "sores", "cuts", "cankers", "abrasions"],
    "burns": ["burn", "burns", "burnings", "scald", "scalds", "scalding", "scaldings"],
    "skin": ["itch", "scab", "scabs", "eczema", "tetter", "tetters", "ringworm", "freckles", "erysipelas", "saint anthony's fire", "st. anthony's fire", "scurf", "leprosy", "boils", "warts", "chilblains", "pimples", "morphew", "rash", "rashes", "skin diseases", "skin complaints", "dermatitis", "psoriasis", "acne"],
    "bleeding": ["bleeding", "stanch", "stanches", "staunch", "spitting of blood", "nose-bleed", "bleeding at the nose", "hemorrhage", "haemorrhage", "fluxes of blood", "bloody"],
    "oral_throat_care": ["gargle", "gargles", "gargled", "gargling", "sore mouth", "sore mouths", "sore throat", "sore throats", "mouthwash", "mouthwashes", "gingival", "gingivitis", "dental plaque", "periodontal", "periodontitis", "quinsy"],
    "toothache": ["toothache", "tooth-ache", "aching teeth", "pain of the teeth", "pains of the teeth", "carious tooth"],
    "eye": ["dimness of the sight", "dimness of sight", "sore eyes", "inflamed eyes", "ophthalmia", "eye-wash", "weak eyes", "the eyes", "pin or web"],
    "ear": ["earache", "ear-ache", "deafness", "pains in the ears", "noise in the ears"],
    "epilepsy": ["epilepsy", "falling sickness", "falling-sickness", "convulsions", "fits"],
    "nervous": ["palsy", "palsies", "hysteria", "hysterical", "cramps", "cramp", "apoplexy", "swoonings", "faintings", "nervous"],
    "liver_jaundice": ["jaundice", "liver", "livers", "liver complaints", "bile", "bilious", "gall-stones", "gallstones", "biliary", "hepatitis"],
    "urinary": ["provokes urine", "provoke urine", "diuretic", "strangury", "stoppage of urine", "bladder", "reins", "urinary", "urethritis", "cystitis", "dysuria"],
    "dropsy_oedema": ["dropsy", "dropsies", "dropsical"],
    "memory_cognition": ["memory", "the senses", "the wits", "weak brain", "forgetfulness", "dementia"],
    "kidney_stones": ["the stone", "stone in the kidneys", "stone in the bladder", "gravel", "kidneys", "kidney stone", "kidney stones", "kidney-stones", "renal calculi", "urinary calculi", "bladder stones"],
    "menstrual": ["courses", "menses", "menstruation", "menstrual", "the mother", "monthly", "suppressed periods", "emmenagogue", "amenorrhoea", "dysmenorrhoea"],
    "childbirth_lactation": ["childbirth", "after-birth", "afterbirth", "travail", "lactation", "nursing mothers", "delivery of women"],
    "parasites": ["worms", "wormes", "worm", "tapeworm", "vermin", "vermifuge", "anthelmintic"],
    "heart": ["palpitation", "palpitations", "heart disease", "the heart"],
    "poison_bites": ["bites", "stings", "venomous", "venom", "poison", "poisons", "snake-bite", "snake-bites", "snakebite", "snakebites", "biting of serpents", "biting of adders", "stinging of", "serpents"],
    "scurvy": ["scurvy", "scorbutic"],
    "haemorrhoids": ["piles", "haemorrhoids", "hemorrhoids"],
    "plague_infection": ["plague", "pestilence", "infection", "contagion", "scarlet fever", "putrid"],
    "cancer": ["cancer", "cancerous"],
    "diabetes": ["diabetes", "diabetic"],
    "venereal": ["syphilis", "syphilitic", "antisyphilitic", "gonorrhoea", "gonorrhea", "venereal", "leucorrhoea", "leucorrhea", "the whites"],
    "hypertension": ["hypertension", "high blood pressure", "blood pressure"],
    "anaemia": ["anaemia", "anemia", "chlorosis"],
}

# What a modern paper calls the same retrieval topic. Kept apart from historical wording:
# "ague" or "the mother" never occur in a trial, and "stomach" in a trial is not a symptom.
RESEARCH_TERMS = {
    "headache": ["headache", "headaches", "tension-type headache", "migraine", "migraines"],
    "migraine": ["migraine", "migraines"],
    "sleep": ["insomnia", "sleep quality", "sleep disorder", "sleep disorders", "sleep", "sleeping"],
    "anxiety": ["anxiety", "anxiolytic", "perceived stress", "psychological stress"],
    "depression": ["depression", "depressive", "antidepressant"],
    "digestive_symptoms": ["dyspepsia", "irritable bowel", "functional gastrointestinal", "gastrointestinal symptoms", "digestion", "indigestion", "bloating", "flatulence", "heartburn", "gastritis", "peptic ulcer", "colic", "abdominal pain"],
    "diarrhoea": ["diarrhea", "diarrhoea", "dysentery"],
    "constipation": ["constipation", "laxative"],
    "nausea_vomiting": ["nausea", "vomiting", "emesis", "antiemetic"],
    "pain": ["pain", "analgesic", "analgesia", "antinociceptive", "nociception"],
    "joint_gout": ["gout", "arthritis", "osteoarthritis", "rheumatoid", "sciatica", "low back pain", "joint pain"],
    "inflammation": ["inflammation", "inflammatory", "anti-inflammatory", "swelling", "swellings", "edema"],
    "fever": ["fever", "antipyretic", "malaria", "febrile"],
    "cough": ["cough", "antitussive", "pertussis"],
    "respiratory": ["asthma", "bronchitis", "respiratory", "common cold", "upper respiratory", "influenza", "sinusitis", "tuberculosis", "copd"],
    "wounds": ["wound", "wounds", "wound healing", "ulcer", "ulcers"],
    "burns": ["burn", "burns", "burn wound"],
    "skin": ["dermatitis", "eczema", "psoriasis", "acne", "skin", "warts", "erysipelas"],
    "bleeding": ["bleeding", "hemorrhage", "haemorrhage", "hemostatic", "haemostatic", "menorrhagia", "epistaxis"],
    "oral_throat_care": ["gingivitis", "periodontal", "periodontitis", "dental plaque", "mouthwash", "mouthwashes", "mouth rinse", "sore throat", "pharyngitis", "tonsillitis", "oral mucositis", "stomatitis", "aphthous", "gingival", "plaque"],
    "toothache": ["toothache", "dental pain", "tooth pain"],
    "eye": ["eye", "eyes", "ocular", "conjunctivitis", "ophthalmic", "blepharitis"],
    "ear": ["otitis", "earache", "tinnitus", "hearing"],
    "epilepsy": ["epilepsy", "seizure", "seizures", "anticonvulsant"],
    "nervous": ["spasm", "spasmolytic", "antispasmodic", "stroke", "neuroprotective", "muscle cramp"],
    "liver_jaundice": ["hepatoprotective", "liver disease", "liver injury", "liver fibrosis", "fatty liver", "hepatic steatosis", "cirrhosis", "jaundice", "hepatitis", "gallstones", "biliary", "cholestasis"],
    "urinary": ["diuretic", "diuresis", "urinary", "cystitis", "lower urinary tract", "prostatic hyperplasia"],
    "dropsy_oedema": ["edema", "oedema", "fluid retention", "ascites", "heart failure"],
    "memory_cognition": ["memory", "cognition", "cognitive", "dementia", "alzheimer"],
    "kidney_stones": ["kidney stone", "kidney stones", "nephrolithiasis", "urolithiasis", "renal"],
    "menstrual": ["dysmenorrhea", "dysmenorrhoea", "menstrual", "premenstrual", "amenorrhea", "menopause", "menopausal", "hot flashes", "hot flushes", "climacteric"],
    "childbirth_lactation": ["labor", "labour", "lactation", "breast milk", "postpartum", "childbirth"],
    "parasites": ["anthelmintic", "helminth", "worm", "worms", "nematode", "antiparasitic"],
    "heart": ["heart", "cardiac", "cardiovascular", "cardioprotective", "arrhythmia", "hypertension", "blood pressure", "angina"],
    "poison_bites": ["antivenom", "snake bite", "snakebite", "antidote", "insect bite", "venom"],
    "scurvy": ["scurvy", "vitamin c", "ascorbic"],
    "haemorrhoids": ["hemorrhoids", "haemorrhoids", "hemorrhoidal"],
    "plague_infection": ["antimicrobial", "antibacterial", "antiviral", "infection", "infections"],
    "cancer": ["cancer", "tumor", "tumour", "carcinoma", "antitumor", "anticancer"],
    "diabetes": ["diabetes", "diabetic", "glycemic", "glycaemic", "hyperglycemia", "blood glucose", "insulin resistance"],
    "venereal": ["syphilis", "gonorrhea", "gonorrhoea", "leucorrhea", "leucorrhoea", "vaginitis", "urethritis"],
    "hypertension": ["hypertension", "blood pressure"],
    "anaemia": ["anemia", "anaemia", "hemoglobin", "haemoglobin"],
}


def research_terms(condition):
    key = condition.replace("condition:", "")
    return RESEARCH_TERMS.get(key) or CONDITIONS.get(key) or [key.replace("_", " ")]


PARTS = ["roots", "root", "leaves", "leaf", "flowers", "flower", "bark", "seeds", "seed", "berries", "berry", "fruit", "fruits", "tops", "stalk", "stalks", "petals", "bulb", "bulbs", "tubers", "peel", "peels", "rind", "rinds", "gum", "resin", "whole plant", "herb"]
PREPARATIONS = ["decoction", "infusion", "distilled water", "powder", "powdered", "ointment", "essential oil", "oil", "syrup", "tea", "boiled", "bruised", "dried", "extract", "juice", "tincture", "poultice", "liniment", "lozenge", "lozenges", "conserve", "gargle", "gargles", "lotion", "vinegar", "draught", "plaster", "salve", "fomentation", "electuary", "bath", "clyster", "posset", "cordial", "essence", "wine", "ale", "broth", "jujubes", "balls", "honey", "steeped", "macerated", "wash"]
ROUTES = ["gargle", "gargles", "gargled", "gargling", "outwardly", "inwardly", "applied", "anoint", "anointed", "drank", "drunk", "drink", "swallowed", "worn", "bathed", "chewed", "inhaled", "taken"]

# English words that are also plant names. Lower-case use needs a botanical neighbour.
SENSE_REQUIRED = {"date", "dates", "rue", "sage", "balm", "mint", "lime", "pink", "flag", "dock", "rush", "rushes", "rose", "roses", "ash", "bay", "box", "elder", "may", "mace", "orange", "violet", "olive", "mustard", "pepper", "broom", "reed", "nut", "plum", "cane", "gum", "tea", "coffee", "corn", "wheat", "oak", "pine", "fern", "moss", "grass", "weed", "wort", "bean", "pea", "hop", "hops", "fig", "vine", "cotton", "thrift", "heather", "sorrel", "savory", "hemp", "aloe", "lily", "iris", "reeds", "melon", "lemon", "apple", "pear", "peach", "cherry", "rice", "barley", "oats"}
NEVER_A_PLANT = {"drop", "drops", "common", "tree", "plant", "herb", "flower", "wild", "bitter", "sweet", "water", "fire", "sun", "moon", "bread", "butter", "milk", "lady", "love", "wood", "field", "stone", "gold", "silver", "star", "bell", "bloom", "blood", "bird", "fish", "cat", "dog", "horse", "bear", "mouse", "rat", "snake", "wolf", "goat", "sheep", "pig", "cow", "bull", "lion", "fox", "wool", "soap", "needle", "thorn", "spring", "summer", "winter", "autumn", "cure", "blue", "red", "white", "black", "green", "yellow", "purple", "great", "little", "small", "large", "true", "false", "good", "bad", "old", "new", "medicine", "health", "heal", "healing", "poison", "grace", "hope", "joy", "life", "death", "night", "day", "mother", "father", "king", "queen", "monk", "bishop", "pope", "cross", "church", "dropsy", "colic", "cough", "fever", "gout", "worm", "worms", "staff", "bath", "wine", "beer", "oil", "gall", "salt", "sugar", "honey", "pitch", "tar", "resin", "bark", "root", "seed", "leaf", "stem", "fruit", "berry", "nuts", "sand", "clay", "mud", "rock", "hill", "beach", "river", "lake", "marsh", "mountain", "smaller", "larger", "medicinal plant", "medicinal plants"}
BOTANICAL_NEIGHBOUR = re.compile(r"\b(?:leaf|leaves|root|roots|oil|tree|trees|juice|flowers?|seeds?|bark|peels?|rinds?|herbs?|plants?|decoction|infusion|syrup|berries|fruit|ointment|tincture|tops|stalks?|boiled|bruised|gargle|tea|essence|powder|mixed|together)\b", re.I)
GROWING_OR_COOKING = re.compile(r'\b(?:grow(?:s|ing|n)?|garden|cultivat\w*|harvest\w*|soup|stew|salad|recipe|cooking)\b', re.I)
PERSON_PLANT_NAMES = {'basil', 'rosemary', 'rose', 'heather', 'sage', 'olive', 'violet', 'iris', 'lily', 'holly', 'jasmine', 'daisy', 'willow', 'hazel', 'fern', 'poppy', 'rue'}
PERSON_ROLE = r'(?:friend|neighbou?r|colleague|sister|brother|mother|father|daughter|son|wife|husband|aunt|uncle|cousin|nurse|doctor|teacher|student|patient|researcher)'
PLACE_AFTER = re.compile(r'^[-\s]+(?:county|city|province|township|district|street|avenue|road|valley|island|hill|mountain|river)\b', re.I)
PLACE_BEFORE = re.compile(r'\b(?:city|county|province|township|district|island|valley)\s+of\s+(?:the\s+)?$', re.I)
PLACE_PREFIXES = {'san', 'santa', 'santo', 'saint', 'st'}


def person_name_context(before, after):
    """Local grammatical roles outrank nearby tea or symptoms in another phrase."""
    if re.search(r'\b(?:mr|mrs|ms|dr|prof)\.?\s*$|\b(?:told|called|asked|thanked|met|emailed|visited)\s*$|\b(?:my|her|his|our|your)\s+' + PERSON_ROLE + r'\s*$', before, re.I):
        return True
    if re.match(r"['’]s\s+(?:" + PERSON_ROLE + r"|headache|cough|appointment|blood pressure|" + '|'.join(sorted(PERSON_PLANT_NAMES)) + r")\b", after, re.I):
        return True
    if re.match(r'\s*,?\s*(?:(?:is|was)\s+)?(?:my|her|his|our|your|an?)\s+' + PERSON_ROLE + r'\b', after, re.I):
        return True
    # A coordinated pair can share the same human predicate.
    predicate = re.sub(r'^\s+and\s+[A-Z][a-z]+\b', '', after)
    if re.match(r'\s+(?:told|called|asked|said|wrote|emailed|visited|attended|discussed|spoke|walked|thanked|replied|reported|explained|studies|studied|lives|lived|recommends|recommended|slept|arrived|went|and\s+(?:I|he|she|they)\b)', predicate, re.I):
        return True
    if re.match(r'\s+(?:works?|worked)\s+(?:at\s+(?:the\s+)?(?:hospital|school|university|company|shop)|as\s+an?\s+' + PERSON_ROLE + r')\b', predicate, re.I):
        return True
    if re.match(r'\s+(?:gave|gives)\s+(?:me|you|him|her|us|them|my\s+' + PERSON_ROLE + r'|' + '|'.join(sorted(PERSON_PLANT_NAMES)) + r')\b', predicate, re.I):
        return True
    if re.match(r'\s+(?:had|has)\s+(?:trouble sleeping|a headache|an appointment|a meeting)\b|\s+(?:was|is)\s+(?:diagnosed|admitted|hospitali[sz]ed)\b|\s+(?:was|is)\s+prescribed\s+(?:medicine|medication|tablets|antibiotics|an?\s+drug)\b', after, re.I):
        return True
    # "gave Rosemary a cup" identifies a recipient, not a botanical ingredient.
    return bool(re.search(r'\b(?:gave|give|given|offered|brought|sent)\s*$', before, re.I) and re.match(r'\s+(?:an?|some|her|his|their)\b', after, re.I))
NON_BOTANICAL_SENSE = re.compile(r"\b(?:(?:malate|carbonate|phosphate|oxalate|salts?|muriate|sulphate|citrate|chloride|nitrate|acetate|tannate) of lime|cotton[- ]wool|adulterating pepper|lime[- ]water|the elder (?:pliny|cato|brother|son)|elder (?:brother|sister|son|daughter)|(?:rose|rises?) (?:up|from|to|above)|(?:he|she|it|they|which|who) rose|(?:that|this|what|recent|early|later|elizabethan|ancient|modern|expected|same|late|earlier) date|to date|up to date|of (?:a )?date|in dock|sovereign balm|like balm|in a box|pink[- ](?:white|tinted|tinged)|tinged with pink|french flag|like a flag)\b", re.I)
CUE_STOP = {'mix', 'take', 'boil', 'steep', 'leaves', 'leaf', 'root', 'roots', 'flower', 'flowers', 'seeds', 'seed', 'bark', 'herb', 'plant', 'fruit', 'fruits', 'berries', 'syrup', 'juice', 'decoction', 'infusion', 'tincture', 'powder', 'extract', 'plaster', 'plasters', 'ointment', 'poultice', 'headache', 'cough', 'fever', 'pain', 'pains', 'water', 'herbal', 'this', 'that', 'these', 'those', 'their', 'strong', 'warm', 'cold', 'fresh', 'dried', 'boiled', 'common', 'plant', 'plants', 'such', 'other', 'some', 'many', 'most', 'each', 'both', 'which', 'large', 'whole', 'wine', 'honey', 'milk', 'sugar', 'salt', 'traditional', 'medicinal', 'local', 'garden', 'essential', 'green', 'dry', 'young', 'first', 'same', 'itself', 'much', 'several', 'various', 'certain', 'ancient', 'modern', 'people', 'children', 'women', 'patients', 'informants', 'healers', 'villagers', 'cottagers', 'often', 'also', 'sometimes', 'usually', 'always', 'never', 'there', 'where', 'while', 'being', 'having', 'made', 'taken', 'given', 'applied', 'used', 'drunk', 'eaten', 'hard', 'soft', 'hairy', 'narrow', 'broad', 'tall', 'long', 'short', 'bruised', 'powdered', 'infused', 'macerated', 'crushed', 'pounded', 'chewed'}
CUE_NAME = [re.compile(r"\b([A-Z][a-z]{3,})\s+(?:is|are|was|were)\s+(?:\w+\s+)?(?:applied|used|taken|drunk|given|eaten|chewed|rubbed|bound|boiled|prescribed|employed|administered|smoked|inhaled|steeped|carried|worn|hung)\b"), re.compile(r"(?<![^\W\d_])([^\W\d_]{4,})\s+(?:decoction|infusion|tincture|tea|root|roots|leaves|leaf|flowers|bark|seeds|paste|juice|ointment|poultice|extract|syrup|powder|tops|fruit|berries|salve|gel|capsules)\b"), re.compile(r"\b(?:uses?|used|gives?|gave|drinks?|drank|takes?|took|applies|apply|chews?|prescribes?)\s+((?:[^\W\d_]+\s+){0,2}[^\W\d_]{4,})\s+(?:for|against|to treat|to relieve)\b"), re.compile(r"\b(?:decoction|infusion|tincture|tea|juice|leaves|root|roots|flowers|bark|seeds|sprig|sprigs|bunch|handful|bundle|fruits?)\s+of\s+(?:the\s+)?([A-Za-z]{4,})\b")]
# Texts name a plant outright: "commonly known as Yerba Santa", a line opening "American Elm.", a
# closing "(American Mint)". As with every position, GBIF decides whether it is a plant at all.
CUE_NAME += [re.compile(r"\b(?:known|called|named)(?: as)?\s+(?:the\s+)?([A-Z][a-z]+(?:[ -][A-Z][a-z]+|-[a-z]+){0,2})"), re.compile(r"^[ \t]*([A-Z][a-z]+(?: [A-Z][a-z-]+){1,2})\.(?=\s)", re.M), re.compile(r"\(([A-Z][a-z]+(?: [A-Z][a-z-]+){1,2})\)")]
CONTINUATION = re.compile(r"^\W*(?:as also|also|and also|and)\b", re.I)
INGREDIENT_POSITION = re.compile(r"\b(?:with|and|or|to|like|than|of)\s+(?:\w+\s+){0,2}$", re.I)
PLANT_PART_SUFFIX = re.compile(r"[-–](?:flowers?|leaf|leaves|berry|berries|root|roots|bark|seeds?|tree|tea|juice)\b", re.I)
NOT_A_NAME_START = {'the', 'this', 'that', 'these', 'those', 'their', 'its', 'his', 'her', 'our', 'some', 'many', 'much', 'more', 'most', 'other', 'each', 'both', 'all', 'any', 'one', 'two', 'three', 'fresh', 'dried', 'dry', 'raw', 'hot', 'cold', 'warm', 'boiled', 'crushed', 'ground', 'herbal', 'plant', 'plants', 'medicine', 'medicines', 'remedies', 'cough', 'black', 'green', 'white', 'red', 'wild', 'sweet', 'bitter', 'large', 'small'}
CUE_BEFORE = re.compile(r"\b(?:decoction|infusion|tincture|syrup|juice|oil|leaves|leaf|root|roots|flowers?|seeds?|bark|fruits?|berries|tea|extract|powder|ointment|poultice|water|essence|conserve|wine|herb)\s+of\s+(?:the\s+)?$", re.I)
# "Rue is good against poison", "Sage is singular good for the head": an herbal states a virtue.
VIRTUE_AFTER = re.compile(r"\s+(?:is|are)\s+(?:(?:very|singular|singularly|also|much|most|exceeding|excellent|especially)\s+)?(?:good|profitable|effectual|available|excellent|helpful|a remedy|a cure)\s+(?:for|against|to|in)\b", re.I)
CUE_AFTER = re.compile(r"^\s+(?:leaves|leaf|root|roots|flowers?|seeds?|bark|fruits?|berries|tea|oil|juice|ointment|tincture|decoction|infusion|seedes?|leaues|rootes?|flowres?|barke|juyce|iuyce|oyle)\b", re.I)
LANGUAGE_DATA = json.loads((Path(__file__).resolve().parents[2] / 'data' / 'use_terms_i18n.json').read_text(encoding='utf8'))
SERBIAN_CYRILLIC = dict(zip(['lj', 'nj', 'dž', *'abvgdđežzijklmnoprstćufhcčš'], ['љ', 'њ', 'џ', *'абвгдђежзијклмнопрстћуфхцчш']))


def serbian_cyrillic(term):
    """Serbian is written in both scripts, letter for letter: "mučnin" is "мучнин"."""
    return re.sub('lj|nj|dž|.', lambda m: SERBIAN_CYRILLIC.get(m.group(), m.group()), term.casefold())


# Serbian Cyrillic text reads the Croatian and Serbian Latin terms, spelled in Cyrillic.
for _table in [*LANGUAGE_DATA['conditions'].values(), LANGUAGE_DATA['preparations']]:
    if 'hr' in _table and 'sr' not in _table:
        _table['sr'] = [serbian_cyrillic(term) for term in _table['hr']]
LOWERCASE_FUNCTION = {'with', 'from', 'into', 'upon', 'over', 'under', 'about', 'after', 'before', 'them', 'they', 'then', 'than', 'when', 'what', 'were', 'have', 'been', 'will', 'would', 'should', 'could', 'very', 'more', 'less', 'only', 'even', 'just', 'like', 'made', 'good', 'great', 'little', 'small', 'well', 'best', 'better', 'poor', 'rich'}
ABBREVIATION = re.compile(r"(?:\b(?:St|Dr|Mr|Mrs|Sir|Prof|cf|viz|vol|No|Fig|sp|spp|var|subsp|ssp|e\.g|i\.e|L)|\b[A-Z])$")


OWN_LETTERS = {'pl': r'[ąęłśźż]', 'cs': r'[řůě]', 'sk': r'[ľĺŕ]', 'hu': r'[őű]', 'ro': r'[ășțţ]', 'tr': r'[ğı]'}


# Short sources often have only one function word; these independent lexical
# clues help break ties. Exact name lookup also works across language boundaries.
LANGUAGE_HINTS = {
    'de': {'hilft', 'getrunken', 'bauchschmerzen', 'kamillentee'},
    'it': {'aiuta', 'dormire', 'camomilla'},
    'pl': {'napar', 'pomaga', 'rumianku', 'rumianek', 'brzucha'},
    'nl': {'kamillethee', 'buikpijn', 'gedronken'},
}


def detect_language(text):
    """Writing system first, then function words. Short or mixed text stays English."""
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return 'en'
    share = lambda test: sum(map(test, letters)) / len(letters)
    if share(lambda c: 'Ͱ' <= c <= 'Ͽ' or 'ἀ' <= c <= '῿') > .3:
        return 'el'
    if share(lambda c: 'Ѐ' <= c <= 'ӿ') > .3:
        # Letters one language alone writes, then Macedonian function words ("во", "кога").
        # ъ is everyday Bulgarian ("жълт"); ы and э are Russian only. ј, љ and њ are Serbian or
        # Macedonian, never Bulgarian; Serbian writes "је", "у" and "пије", Macedonian "е", "во", "пие".
        folded = text.casefold()
        for letters, language in ((r'[ѓќѕ]', 'mk'), (r'[ђћџ]', 'sr'), (r'[іїєґ]', 'uk'), (r'[ыэ]', 'ru')):
            if re.search(letters, folded):
                return language
        if re.search(r'[јљњ]', folded) and not re.search(r'[ъщ]', folded):
            return 'sr' if re.search(r'\b(?:је|у|није|ће)\b|ије\b', folded) else 'mk'
        macedonian = sum(word in set(LANGUAGE_DATA['stopwords'].get('mk', ())) for word in re.findall(r"\w+", folded))
        return 'mk' if macedonian >= 1 and not re.search(r'[ъщ]', folded) else 'bg'
    if share(lambda c: '一' <= c <= '鿿') > .2:
        return 'zh'
    if share(lambda c: '؀' <= c <= 'ۿ') > .3:
        return 'ar'
    if share(lambda c: 'ऀ' <= c <= 'ॿ') > .3:
        return 'hi'
    words = re.findall(r"\w+", text.casefold())
    scores = {language: sum(word in set(terms) for word in words) for language, terms in LANGUAGE_DATA['stopwords'].items()}
    for language, hints in LANGUAGE_HINTS.items():
        scores[language] = scores.get(language, 0) + 2 * len(set(words) & hints)
    best = max(scores, key=scores.get)
    # Polish and Czech share "z", "na" and "do"; ł and ř do not travel. Prose that is not English
    # goes to the one language whose own letters it writes, at least twice.
    marks = {language: len(re.findall(letters, text.casefold())) for language, letters in OWN_LETTERS.items()}
    marked = [language for language, count in marks.items() if count >= 2]
    if len(marked) == 1 and (best != 'en' or scores['en'] < 2) and scores['en'] <= scores[marked[0]] + 1:
        return marked[0]
    return best if scores[best] >= 2 and scores[best] > scores['en'] else 'en'


def condition_sense(condition, original, clause):
    """Reject word senses where the condition word names something else."""
    word = original.casefold()
    if condition == 'digestive_symptoms' and word == 'stomach' and re.search(r'\b(?:over|upon|on an empty|empty|fasting)\s+(?:the\s+)?stomach\b', clause, re.I):
        return False
    if condition == 'digestive_symptoms' and word == 'wind' and not re.search(r'\b(?:expels?|dispels?|breaks?|dissolves?|helps?|for|against|voids?|ease[sd]?)\b.{0,40}\bwind\b', clause, re.I):
        return False
    if condition == 'burns' and word == 'burn' and not re.search(r'\b(?:a|the|for|any)\s+burn\b', clause, re.I):
        return False
    if condition == 'plague_infection' and word == 'plague' and not re.search(r'\b(?:the|of|from|against)\s+plague\b', clause, re.I):
        return False
    if condition == 'respiratory' and word == 'cold' and not re.search(r'\b(?:a|the|for|bad|common|of|catch\w*|with)\s+cold\b(?!\s+(?:cause|water|place|ground|climate|weather|bath|infusion|tea|and|nature|quality|stomach))', clause, re.I):
        return False
    if condition == 'wounds' and word == 'sore' and re.search(r'\bsore (?:parts?|throats?|mouths?|eyes?)\b', clause, re.I):
        return False
    if condition == 'kidney_stones' and word == 'the stone' and not re.search(r'\b(?:helps?|expels?|breaks?|against|for|cures?|dissolves?|gravel|cholic|colic|pains? of|voids?|good)\b', clause, re.I):
        return False
    if condition == 'bleeding' and word == 'bloody' and not re.search(r'\bbloody (?:flux|urine|stools?|sputum)\b', clause, re.I):
        return False
    if condition == 'pain' and word == 'griefs' and not re.search(r'griefs? (?:of|and|in|there)', clause, re.I):
        return False
    if condition == 'nervous' and word == 'nervous' and not re.search(r'\bnervous (?:affections?|disorders?|complaints?|debility|exhaustion|headaches?|troubles?|irritab\w+)\b', clause, re.I):
        return False
    if condition == 'heart' and word == 'the heart' and re.search(r'\b(?:heart of|at the heart|by heart)\b', clause, re.I):
        return False
    if condition == 'menstrual' and word == 'courses' and not re.search(r"\b(?:women['’]?s?|her|their|provok\w+|stay\w*|bring\w*|the) courses\b", clause, re.I) or (condition == 'menstrual' and re.search(r'\b(?:wisest|water|river|due) courses\b', clause, re.I)):
        return False
    if condition == 'urinary' and word == 'reins' and re.search(r'\b(?:horse|bridle|take the) reins\b', clause, re.I):
        return False
    if condition == 'cancer' and re.search(r'\b(?:Jupiter|Venus|Mars|Saturn|Mercury|Moon|Sun|sign)\b', clause):
        return False  # Culpeper's zodiac: "an herb of Jupiter, and under Cancer".
    if condition == 'fever' and re.search(r'\bhay[- ]fever\b', clause, re.I):
        return False
    return True


CAUTION = re.compile(r"\b(?:excessive use|continued use will|too (?:habitual|free|frequent|much|large|long)|caution|aggravat\w+|provoke troublesome|injurious|mischievous|fatal|paralyz\w+|paralysis|gangren\w+|(?:a )?large[r]? doses? (?:will|may|of)|has produced|have produced|symptoms? of poison\w*|may be the result|has led to the formation)\b", re.I)
EXPLICIT_USE = re.compile(r"\b(?:(?:is|are|was|were)\s+(?!not\b)(?:\w+\s+){0,2}(?:used|employed|given|applied|administered)\s+(?:[\w-]+\s+){0,5}?(?:in|for|as|to)\b|used so commonly|useful (?:wash|application|remedy|injection)|(?:wash|baths?|poultice|gargle) for\b|of (?:\w+ ){0,2}value (?:as|in|for)\b|possess\w* (?:\w+ ){0,2}value as\b)", re.I)
DOSE_EXCESS = re.compile(r"\b(?:in|by|from) (?:very |too )?(?:large|larger|excessive|over|immoderate) doses?\b|\b(?:an?|too) (?:very |too )?(?:large|larger|excessive|immoderate|full) dose\b|\btoo full doses?\b|\bover-?doses?\b", re.I)
AIMED_TERMS = '|'.join(re.escape(t) for values in CONDITIONS.values() for t in values if ' ' not in t and len(t) > 3)
AIMED = re.compile(r'\b(?:for|against|to (?:cure|ease|help|heal|relieve))\s+(?:\w+\s+){0,4}?(?:' + AIMED_TERMS + r')\b', re.I)
THERAPEUTIC = re.compile(r'\b(?:heal(?:e|es|eth|est|s|ed|ing)?|help\w*|counteract\w*|regulat\w*|(?:will )?corrects?|overcom\w*|aids?|alleviat\w*|cureth|eas(?:e|es|ed|ing)|reviv\w*|remov\w*|assuag\w*|allay\w*|mitigat\w*|expel\w*|abat\w*|drives? away|(?:take|takes|taketh|taken|taking|took) away|resolv\w*|cur(?:e|es|ed|ing|ative|atively)|remed\w*|relie\w*|benefic\w*|profitable (?:for|against|to)|use(?:d|ful|fulness)?|employ\w*|effectual|efficac\w*|medicinal\w*|medicines?\s+(?:for|against|to|in)|(?:taken|given|administered)\s+(?:(?:internally|externally)\s+)?as\s+(?:an?\s+)?medicine|sedative|laxative|astringent|cordial|comfort\w*|mollif\w*|protect\w*|prevent\w*|corrective|purifying|cleansing|cleanses?|purg(?:e|es|ed|ing|eth|est)|administer\w*|prescrib\w*|fomentation\w*|looseness of the bowels|good (?:for|to|against)|given.*for|gave.*for|appl(?:ied|y).*for|the effect is magical|stops?|stays?|stanch\w*|profit\w*|usefully|with (?:benefit|advantage)|wound[- ]herbs?|anti-?scorbutic|anti-?\w+ remedy|breaks? the stone|drieth|filleth|bindeth|cooleth|openeth|send for|obviat\w*|appeas\w*|assist\w*|act as|acts as|effected wonders|applied (?:\w+\s+){0,4}?to|eaten|chewed|voideth|helpeth|taken (?:for|in|inwardly)|strengthen\w*|provok\w*|kills?|virtues?|combat\w*|improv\w*|advis\w*|recommend\w*|promot\w*|make whole|specific (?:for|against|in)|excellent for|of (?:considerable |great |much )?service|serviceable|is good|given to those|anoint\w*|draught|tonic|antidote|dissolv\w*|opens? obstructions?|drink|drunk|drank|gargl\w*)\b', re.I)
ETYMOLOGY = re.compile(r"\b(?:technical|botanical|ordinary|latin|greek|generic|specific) name\b|\bbotanically\b|\bname(?:d)? (?:comes?|is derived|signifies|means)\b|\bcomes from the (?:greek|latin)\b|\bderived from\b|\bsignifies\b|\ba corruption of\b|\bcalled .{0,40}\bbecause\b(?!.*\b(?:employed|given)\b)", re.I)
IN_CONDITION = re.compile(r"^\W*(?:in|for)\s+(?:\w+\W+){0,5}?(?:" + AIMED_TERMS + r")\b", re.I)
DENIED = re.compile(r"\b(?:no benefit|of no avail|ineffectual|useless|no use|not of (?:any )?use|does not seem\b.*\b(?:qualit|medicinal|virtue)|has no (?:real )?(?:virtue|quality|effect))", re.I)
DESCRIPTION = re.compile(r'\b(?:rises? up|grows? (?:up|in|on|wild|by|with)|spreads?|creeps?|resembling|leaves like|flowers? (?:in|from|at) (?:june|july|august|may|the end)|stalks?\b.*\bleaves\b|gashes)\b', re.I)


def statement_role(text):
    """Conservative discourse triage; all original wording remains inspectable.

    A condition keyword alone is not a medicinal use. This is a transparent lexical
    screen, not historical or biomedical entailment. Adverse language takes priority.
    """
    adverse = re.search(r'\b(?:poison(?:ous|ing)|toxic(?:ity)?|become sick|sometimes they die|deadly to the patient|blistering|disagree(?:s)?|too freely|bad property|unquiet sleep)\b', text, re.I)
    adverse_effect = any(
        not re.search(r"(?:\b(?:not|never|without|cannot)|n['’]t)\s*$", text[max(0, match.start()-30):match.start()], re.I)
        for match in re.finditer(r'\b(?:caus(?:e|es|ed|ing)|induc(?:e|es|ed|ing)|produc(?:e|es|ed|ing))\s+(?:(?:severe|violent|great|bad|acute|chronic|unpleasant|painful|a|an|the|nervous)\s+){0,3}(?:pain|colic|stomach[- ]ache|head[- ]ache|headache|swelling|vomiting|nausea|diarrh(?:oea|ea)|sickness|convulsions|rashes|rash|blisters|redness|irritation|fainting|syncope)\b', text, re.I)
    )
    sensory_reaction = re.search(r'\b(?:faint|swoon)(?:s|ed|ing)?\s+(?:at|from|after)\s+(?:the\s+)?(?:smell|odou?r|scent)\b', text, re.I)
    causal_disease = re.search(r'\b(?:humours?|disease|condition|inflammation|swelling|winds?)\s*,?\s*(?:which|that)?\s*(?:cause|causes)\b', text, re.I)
    # "Used for paralysis" names what is treated; the word alone would read as a harm.
    # "In large doses it vomits and purges": the dose makes the action a harm, unless a condition is aimed at.
    # A sentence that first states a use ("medicinal, and in larger doses purgative") keeps it.
    dose = DOSE_EXCESS.search(text)
    excess = dose and not AIMED.search(text) and not re.search(r'\b(?:praised|commended|esteemed)\b', text[:dose.start()], re.I) and not THERAPEUTIC.search(text[:dose.start()])
    if sensory_reaction or excess or (adverse_effect and not causal_disease) or ((adverse or CAUTION.search(text)) and not EXPLICIT_USE.search(text)):
        return 'ADVERSE_EFFECT_RECORDED'
    if re.search(r'\bState poison\b|\bfood for\b|\ban excellent food\b|\bso strong a poison\b', text, re.I):
        return 'CONTEXT_ONLY_OR_UNCLEAR'
    if re.search(r'\b(?:symbolis(?:ing|e)|wounds of Christ|sculptured|physician.*famous|sleeping within mine orchard|poor silly countryman)\b', text, re.I) or ETYMOLOGY.search(text):
        return 'CONTEXT_ONLY_OR_UNCLEAR'
    aimed = AIMED.search(text)
    if DESCRIPTION.search(text) and not (aimed or re.search(r'\b(?:heal|help|eas|cur|relie|good for|remed)\w*', text, re.I)):
        return 'CONTEXT_ONLY_OR_UNCLEAR'
    return 'THERAPEUTIC_USE_RECORDED' if THERAPEUTIC.search(text) or aimed or IN_CONDITION.search(text) or EXPLICIT_USE.search(text) else 'CONTEXT_ONLY_OR_UNCLEAR'


TEA_WORDS = {normalize(word) for word in ('tea', 'thee', 'tee', 'té', 'tè', 'thé', 'chá', 'чай', 'чај', 'čaj', 'çaj', 'çay', 'τσάι', 'ceai')}
FUNCTION_EPITHETS = {'oder', 'aber', 'über', 'unter', 'hinter', 'wieder', 'immer', 'sehr', 'noch', 'schon', 'dieser', 'einer', 'eines', 'einem', 'einen', 'seiner', 'ihrer', 'unser', 'nicht', 'maar', 'voor', 'door', 'over', 'onder', 'achter', 'weer', 'zeer', 'ook', 'niet'}
OLD_PART = re.compile(r'(?:seed|roote?|leaue|leave|flowre|flower|barke|juyce|iuyce|juice|water|oyle|wine|syrupe|conserve|powder|decoction)e?s?')
MARKED_LETTER = re.compile(r'[À-ÖØ-öø-ɏ]')
MARKED_WORD = re.compile(r'\b[^\W\d_]*[À-ÖØ-öø-ɏ][^\W\d_]*\b')
CASE_LANGUAGES = {'hr', 'sr', 'sq', 'el', 'ro', 'sl', 'pl', 'cs', 'sk', 'mk', 'bg', 'uk', 'hu'}
VOWELS = 'aeiouyаеиоуъяюѐѝ'
# A short consonant-final name takes a case ending ("orah", "oraha") or a possessive adjective ("brin", "brinove").
SHORT_ENDING = re.compile(r'(?:[aeiouy]{1,2}|om|em|ov[aeiou]?|ev[aeiou]?|in[aeiou]?|от|та|то|ов[аеио]?)$')


def consonant_marks(word):
    """Casefolded, with accents on vowels removed and marks on consonants kept: "lípa" -> "lipa", "hořec" stays."""
    out = []
    for char in unicodedata.normalize('NFD', word.casefold()):
        if unicodedata.combining(char) and out and out[-1] in 'aeiouyаеиоуыэюяі':
            continue
        out.append(char)
    return unicodedata.normalize('NFC', ''.join(out))


# Romance and Germanic names change a vowel or add a plural, never a consonant: "fromage" is cheese, not "fromager".
UNINFLECTED = {'fr', 'it', 'es', 'pt', 'de', 'nl', 'la'}


def ending_only(word, key, language):
    shared = 0
    while shared < min(len(word), len(key)) and word[shared] == key[shared]:
        shared += 1
    allowed = 'aeiouyhsx' + ('n' if language in ('de', 'nl') else '')
    return all(c in allowed for c in word[shared:] + key[shared:])


ALBANIAN_DEFINITE = {'ri', 'rit', 'ut', 'ni', 'nit'}


def inflects(word, key, language):
    """Is this word an inflected form of a listed name? Endings change, the stem does not.
    "trumzë" is "trumza" and "bokvice" is "bokvica"; "soğuk" (cold) is no form of "söğüt" (willow),
    because a stem ending in a consonant only grows. Croatian "lipe" and "nane" inflect four-letter names,
    and Macedonian "пелинот" is "пелин" with its article."""
    if not 0 <= len(word) - len(key) + 2 <= 5:
        return False
    if language in UNINFLECTED and not ending_only(word, key, language):
        return False
    if len(key) >= 7:
        return word[:len(key) - 2] == key[:-2]
    if len(key) >= 5:
        return word[:len(key) - 1] == key[:-1] and (key[-1] in VOWELS or word.startswith(key))
    # Albanian three-letter names take the definite ending after the stem: "bli", "bliri", "çaji i bliut".
    if len(key) == 3 and language == 'sq':
        return word.startswith(key) and word[3:] in ALBANIAN_DEFINITE
    if len(key) != 4 or language not in CASE_LANGUAGES:
        return False
    if key[-1] in VOWELS:
        return word[:3] == key[:3] and word[3] in VOWELS and len(word) <= 6
    return word.startswith(key) and bool(SHORT_ENDING.fullmatch(word[4:]))


# German, Dutch and Hungarian join plant and part in one word: "Baldrianwurzel", "brandnetelthee", "kamillatea".
PLANT_PART = {'de': re.compile(r'(?:wurzeln?|blatter|blatt|bluten|bluthen|blute|kraut|krauter|tee|thee|rinde|samen|ol|saft|beeren|beere|fruchte|frucht|knospen)$'),
              'nl': re.compile(r'(?:thee|wortels?|bladeren|blad|bloemen|bloem|zaden|zaad|olie|bessen|bes|schors|kruid|sap)$'),
              'hu': re.compile(r'(?:tea|teat|teaja|level|levele|levelek|gyoker|gyokere|virag|viraga|olaj|mag|magja|termes|kereg|fozet)$')}
NON_PLANT_REMEDY = re.compile(r"\b(?:snails?|slugs?|egg[- ]?shells?|old eggs|oyster shells|vipers?|bees?\b.{0,30}\bkilled|bee-tea)\b", re.I)


def practice_kind(text):
    """What kind of practice the sentence reports; a filter for readers, not a judgement."""
    if NON_PLANT_REMEDY.search(text):
        return 'NON_PLANT_REMEDY'
    if re.search(r'\b(?:amulet|charm|worn (?:round|about|in|on|over)|hung|evil eye|evil spirits|anti-magical|ward(?:ing)? off|the devil|witch\w*|spell|superstiti\w*|bag over|frontlets?|protective)\b', text, re.I):
        return 'RITUAL_OR_AMULET'
    if re.search(r"\b(?:horses?|cattle|sheep|farriers?|cows?|swine|dogs?|veterinar\w*)\b(?!['’]s\b|[\s-]+(?:roses?|chestnuts?|radish|tails?|mint|parsley|parsnips?|wood|violets?|mercury|grass|fennel|berr\w+|tooth|bane|sorrel|weed|lichen|camomile|chamomile|slip)\b)", text, re.I):
        return 'VETERINARY'
    if re.search(r'\b(?:hahnemann|homoeopath\w*|homeopath\w*|provers?|law of similars|similars)\b', text, re.I):
        return 'HOMOEOPATHIC'
    return 'MEDICINAL'


def unwrap(text):
    """A line break inside a paragraph is typesetting, not a sentence end. Offsets do not move."""
    letters = list(text)
    for m in re.finditer(r'(?<=[^\n])\n(?=[^\n])', text):
        line = text[text.rfind('\n', 0, m.start()) + 1:m.start()].strip()
        following = text[m.end():m.end() + 8]
        if line.isupper() or LIST_ITEM.match(following):
            continue
        if len(line) >= WRAPPED_LINE or (len(line) >= 30 and following[0].islower()):
            letters[m.start()] = ' '
    return ''.join(letters)


GLOSS_BEFORE = re.compile(r"(?<![\w'’-])([A-Z][\w'’-]{2,} [A-Z][\w'’-]{2,}|[^\W\d_][\w'’-]{2,})(?: (?:" + '|'.join(PARTS) + r"))?(?:\s*,\s*(?:from|of|or|the|i\.\s?e\.)?\s*|\s*\(\s*|\s+(?:from|or|o|ou|oder)\s+)$")


def source_glosses(text, mentions):
    """The name a source itself gives a species: "Kurchi bark, from Holarrhena antidysenterica",
    "El estafiate (Artemisia ludoviciana)". The pairing is the author's, kept whether or not any
    name list knows the local word."""
    spans = [(m['start'], m['end']) for m in mentions]
    found = {}
    for mention in mentions:
        if 'BINOMIAL' not in mention['method']:
            continue
        match = GLOSS_BEFORE.search(text[max(0, mention['start'] - 48):mention['start']])
        if not match:
            continue
        start = mention['start'] - len(match.group(0)) + match.start(1) - match.start(0)
        word = match.group(1)
        key = word.casefold()
        # "in the Philippines (Vitex negundo)", "applied to the skin, Aloe vera": a place or an object.
        if re.search(r"\b(?:in|at|to|into|on|from|of|near|throughout|over)\s+(?:the\s+)?$", text[max(0, start - 20):start], re.I):
            continue
        if (key in NOT_A_NAME_START or key in LOWERCASE_FUNCTION or key in CUE_STOP or key in NEVER_A_PLANT or key.endswith(('aceae', 'ales', 'eae'))
                or any(s < start + len(word) and start < e for s, e in spans if (s, e) != (mention['start'], mention['end']) and 'BINOMIAL' in next(m['method'] for m in mentions if (m['start'], m['end']) == (s, e)))):
            continue
        found.setdefault(mention['id'], []).append({'name': word, 'start': start, 'end': start + len(word), 'binomial': mention['text']})
    return found


def heading_gloss(text, mentions):
    """"BONESET.\\nThe leaves and flowering tops of Eupatorium perfoliatum.": the author names the
    heading's plant in the first sentence after it. Returns (heading mention, binomial mention)."""
    if not mentions:
        return None
    head = mentions[0]
    line_end = text.find('\n', head['start'])
    # "BONESET. The leaves of ..." runs on in one line; capitals and a stop still close a heading.
    if head['text'].isupper() and text[head['end']:head['end'] + 2] == '. ' and not text[:head['start']].strip():
        line_end = head['end'] + 1
    line = text[text.rfind('\n', 0, head['start']) + 1:line_end if line_end >= 0 else len(text)]
    if 'BINOMIAL' in head['method'] or line_end < 0 or len(line.strip()) > 60 or line.strip().rstrip('.').count('.') > 1:
        return None
    first = re.search(r'[.!?](?:\s|$)', text[line_end:])
    end = line_end + (first.end() if first else len(text) - line_end)
    inside = [m for m in mentions if line_end <= m['start'] < end and 'BINOMIAL' in m['method']]
    if len(inside) == 1 and re.search(r'\b(?:variety of|cultivar of|hybrid of|derived from|related to|compared (?:with|to)|unlike|rather than|instead of|different from|not to be confused with)\b', text[line_end:inside[0]['start']], re.I):
        # The first binomial may name a relative/comparator, not the heading's
        # own plant: "garden lettuce is a variety of wild lettuce (L. virosa)".
        return None
    return (head, inside[0]) if len(inside) == 1 else None


def heading_common_names(text, mentions):
    """Literal specific names in a library entry's opening botanical subject.

    These are lookup clues, not new dictionary aliases or taxonomic facts.
    A gapped spelling is tried only when it also occurs literally elsewhere
    in the entry, so an arbitrary omitted qualifier cannot invent a name.
    """
    if not mentions or mentions[0]['method'] != 'SOURCE_HEADING_SUBJECT':
        return []
    head = mentions[0]
    line_end = text.find('\n', head['end'])
    if line_end < 0:
        return []
    first = next(sentences(text[line_end:]), None)
    if not first:
        return []
    raw = first['text']
    masked = re.sub(r'\([^()]*\)', lambda m: ' ' * len(m.group()), raw)
    verb = re.search(r'\b(?:is|was|belongs|grows|bears)\b', masked, re.I)
    if not verb:
        return []
    if verb.group().casefold() in ('is', 'was') and not re.match(r'\s+(?:found\b|native\b|an?\s+(?:\w+\s+){0,5}(?:plant|herb|flower|tree|shrub|vegetable|perennial|annual|variety)\b)', masked[verb.end():], re.I):
        return []
    subject = masked[:verb.start()].split(',', 1)[0]
    article = re.match(r'\s*(?:(?:the|our|this)\s+)?', subject, re.I)
    left = article.end()
    right = len(subject.rstrip())
    subject = subject[left:right]
    heading = normalize(head.get('heading_name') or head['text'])
    if not heading or not re.search(r'(?<!\w)' + re.escape(heading) + r'(?!\w)', normalize(subject)):
        return []
    alternative = list(re.finditer(r'\bor\s+', subject, re.I))
    if alternative:
        left += alternative[-1].end()
        subject = masked[left:right]
    elif normalize(subject) == heading:
        return []
    if not re.fullmatch(r"[\w'’-]+(?:\s+[\w'’-]+){0,5}", subject.strip()):
        return []
    left += len(subject) - len(subject.lstrip())
    subject = subject.strip()
    start = line_end + first['start'] + left
    forms = [subject]
    words = subject.split()
    if not alternative and len(words) > 2:
        normalized_text = normalize(text)
        for index in range(1, len(words) - 1):
            form = ' '.join(words[:index] + words[index + 1:])
            if re.search(r'(?<!\w)' + re.escape(normalize(form)) + r'(?!\w)', normalized_text):
                forms.append(form)
    return [{'mention_id':head['id'], 'name':subject, 'start':start, 'end':start + len(subject), 'lookup_forms':list(dict.fromkeys(forms)), 'kind':'OPENING_ALTERNATIVE_NAME' if alternative else 'OPENING_QUALIFIED_NAME'}]


def sentences(text):
    """Return sentence-like clauses with original code-point offsets, no rewritten text."""
    start = 0
    for boundary in re.finditer(r"\n|[.!?;]+(?=[\s\"”’)\]]|$)", text):
        if boundary.group().startswith('.') and ABBREVIATION.search(text[max(0, boundary.start() - 6):boundary.start()]):
            continue
        end = boundary.end()
        raw = text[start:end]
        lead = len(raw) - len(raw.lstrip())
        value = raw.strip()
        if value:
            yield {"text": value, "start": start + lead, "end": start + lead + len(value)}
        start = end
    raw = text[start:]
    value = raw.strip()
    if value:
        lead = len(raw) - len(raw.lstrip())
        yield {"text": value, "start": start + lead, "end": start + lead + len(value)}


def name_list_rows(text):
    """Names an author lists for one plant, each kept at its own place in the source."""
    rows = []
    for number, match in enumerate(m for pattern in NAME_LISTS for m in pattern.finditer(text)):
        begin = match.start('names')
        # "Dhéras or Dhénras" is two spellings; italic marks around a language tag are print, not name.
        for order, piece in enumerate(re.finditer(r"(?:(?!\s+or\s)[^,;()])+", match['names'])):
            if re.fullmatch(NAME_TAG, piece.group().strip()):
                continue
            word = piece.group().strip().strip('_*= ').lstrip('. ')
            if re.match(r"or\s", word):
                word = word[3:].strip()
            # "Manga." opens its list and is the name; "Eng." after a name says which language.
            if (order and word.endswith('.') and len(word) <= 7) or LANGUAGE_TAG.fullmatch(word) or LANGUAGE_PAIR.fullmatch(word):
                continue
            word = re.sub(r'^(?:and|or)\s+', '', word.rstrip(' .'))
            start = begin + piece.start() + piece.group().find(word)
            if 3 <= len(word) <= 40 and len(word.split()) <= 4 and word[0].isalpha() and not any(c.isdigit() for c in word):
                rows.append({'text': word, 'start': start, 'end': start + len(word), 'method': 'LOCAL_NAME_PROPOSAL', 'list_id': number})
    return rows


@lru_cache(maxsize=256)
def term_pattern(terms):
    # Longest alternative first, so "sore throat" wins over "sore" at the same position.
    return re.compile(r"(?<!\w)(?:" + "|".join(re.escape(t) for t in sorted(terms, key=len, reverse=True)) + r")(?!\w)", re.I)


def spans(text, terms):
    if not terms:
        return []
    # Word boundaries and literal punctuation; never execute retrieved instructions.
    return [{"text": m.group(), "start": m.start(), "end": m.end()} for m in term_pattern(tuple(sorted(set(terms)))).finditer(text)]


def stem_spans(text, terms):
    """Word-start stem matching for inflected languages, on accent-insensitive text."""
    folded, offsets = normalized_offsets(text)
    found = []
    for term in sorted(set(terms), key=len, reverse=True):
        key = normalize(term)
        for m in re.finditer(r"(?<!\w)" + re.escape(key) + r"\w*", folded):
            start, end = offsets[m.start()], offsets[m.end() - 1] + 1
            if not any(start < x["end"] and end > x["start"] for x in found):
                found.append({"text": text[start:end], "start": start, "end": end, "stem": len(key)})
    return sorted(found, key=lambda x: x["start"])


HEADING_LINE = re.compile(r"^(?:\[\d+\]\s*)?(?:[A-Z][A-Z'’\-]+(?:[ ,]+[A-Za-z'’\-(),]+){0,8}\.?|Of (?:the )?[A-Z][a-z]+(?: [a-z]+){0,3}\.?|[A-Z][a-z]+(?:[ -][a-z]+)?\.?)$")
# "Black Cohosh." and "Yellow Jasmine or Jessamine."; a dictionary entry is rarely a sentence.
TITLE_LINE = re.compile(r"^[A-Z][\w'’-]+(?: (?:[A-Z][\w'’-]+|of|the|or|and)){0,4}\.?$")
# "Garcinia mangostana, L." and "Cimicifuga Racemosa (L.) Nutt.": a name and its authors, no verb.
BINOMIAL_LINE = re.compile(r"^[A-Z][a-zA-Z]{2,}\s+[A-Za-z][a-zA-Z-]{2,}\b(?:[\s,.&]*(?:\([^)]*\)|[A-Z][\w.'’-]*|var\.|ex|et|and|[a-z]\.))*\s*\.?\s*$")
# "(Ind. Mo-cash)" under a heading belongs to it.
GLOSS_LINE = re.compile(r"^[(\[].*[)\]]\.?$")
# Parts of an entry, never the plant it is about.
ENTRY_PART = re.compile(r"^(?:(?:medicinal |botanical |economic )?(?:uses?|descriptions?|properties|virtues|habitat|habitat and range|history|notes?|references?|dose|doses|preparations?|constituents|composition|cultivation|collection|prices?|introduction|contents|index|preface|appendix|chapter \w+|part \w+|the plant|the root|the leaves)|other (?:common )?names|common names?|synonyms?)\.?$", re.I)
BOLD_ENTRY = re.compile(r"^[ \t]*\d+\.\s+[+=]{1,2}(?P<name>[^+=\n.][^+=]{1,80}?)\.?[+=]{1,2}", re.M)
LEADING_NAME = re.compile(r"^\s*(?:Of (?:the )?)?([A-Z][\w'’-]+(?: [a-z][\w'’-]+)?)\s*[:—–]\s+", re.M)
LATIN_BINOMIAL = re.compile(r"\b[A-Z][a-z]{2,}\s+(?:[x×]\s+)?[a-z]{3,}(?:-[a-z]+)*\b")
# Old books capitalise the epithet: "Euphorbia Tirucalli, L."; a genus or an author vouches for it.
CAPITAL_BINOMIAL = re.compile(r"\b([A-Z][a-zA-Z]{2,})\s+([A-Z][a-zA-Z]{3,}(?:-[A-Za-z]+)*)\b")
AUTHOR_AFTER = re.compile(r"\s*,?\s*\(?(?:[A-Z][a-z]*\.|Linn\b)")
# Editors' emphasis around a name; the marks are blanked so offsets into the source hold.
# Common name lists as books print them, and "American Coffee Berry" with its region set aside.
NAME_LISTS = [re.compile(r"(?:Nom\.\s*Vulg\.|(?:Other\s+)?(?:Common|Local|Native|Vernacular|Popular)\s+Names?)\s*[:.—–-]*\s*(?P<names>[^\n]+)", re.I), re.compile(r"\(\s*Ind\.\s+(?P<names>[^)\n]+)\)"), re.compile(r"\b(?:commonly |locally |popularly |generally )?(?:known|called) as\s+[\"“]?\s*(?P<names>[A-Z][\w'’-]+(?: [A-Z]?[\w'’-]+){0,3})"), re.compile(r"(?:(?:^|[.(\n])\s*)(?:American|Indian|Mexican|Chinese|Japanese|Californian|California|Canadian|Virginian)\s+(?P<names>[A-Z][\w'’-]+(?: [A-Z][\w'’-]+){0,2})")]
# "Bhindí, Rám-turáí (_Hind._), Bhéndí (_Duk._, _Punj._)": colonial works tag each name with its
# language. Two tagged runs make a list; a tag needs an abbreviation point or a language's own name.
NAME_TAG = r"_?(?:[A-Z][a-z]{1,7}\.|Malay|Hindi|Hindustani|Tamil|Telugu|Bengali|Burmese|Sinhalese|Persian|Arabic|Sanskrit|Urdu|Malayalam|Marathi|Gujarati|Kanarese|Nepali)_?"
TAGGED_NAMES = re.compile(r"(?P<names>(?:(?:(?!\n\n)[^()]){2,90}?\(\s*" + NAME_TAG + r"(?:\s*,\s*(?:and\s+)?" + NAME_TAG + r")*\s*\)[,.;]?){2,})")
NAME_LISTS.append(TAGGED_NAMES)
# "Goldthread; cankerroot; mouthroot; yellowroot.": a paragraph of nothing but names. Each still
# needs a name list or GBIF to count as a plant.
SEMICOLON_NAMES = re.compile(r"(?:^|\n[ \t]*\n)[ \t]*(?P<names>[A-Z][\w'’-]+(?:[ \t]+[\w'’-]+){0,3}(?:;\s+[\w'’-]+(?:[ \t]+[\w'’-]+){0,3}){1,12})\.[ \t]*(?=\n[ \t]*\n|\s*$)")
NAME_LISTS.append(SEMICOLON_NAMES)
LANGUAGE_TAG = re.compile(r"(?:Tag|Vis|Pam|Pamp|Iloc|Sp|Fil|Eng|Indo|Bik|Lat|Mal|Hind|Beng|Fr|Ger)(?:[.-]+(?:Tag|Vis|Pam|Fil|Eng)?)*\.?")
LANGUAGE_PAIR = re.compile(r"[A-Z][a-z]{1,5}\.? and [A-Z][a-z]{1,5}\.?")
LIST_ITEM = re.compile(r"\s{4,}|\s*(?:\d+[.)]|[-*•–])\s")
WRAPPED_LINE = 55
USE_LABEL = re.compile(r"^[ \t]*(?:(?:medicinal|medical|therapeutic)\s+)?(?:uses?|properties|virtues|action(?:\s+and\s+uses)?)\s*\.?\s*(?:--+|—|–|:)\s*(?=\S)", re.I | re.M)
EMPHASIS = re.compile(r"(?<![\w*_=])[_*=]+(?=\S)|(?<=\S)[_*=]+(?![\w*_=])")
LATIN_EPITHET = re.compile(r"(?:a|e|i|o|um|us|is|es|er|or|ur|ans|ens|ix|ex|ax|ox|ys|on)$")
NOT_EPITHET = {'will', 'shall', 'showed', 'would', 'could', 'should', 'must', 'might', 'does', 'made', 'like', 'name', 'same', 'more', 'some', 'here', 'there', 'where', 'while', 'before', 'after', 'above', 'below', 'alone', 'once', 'twice', 'whole', 'wine', 'water', 'herbe', 'leaves', 'leaf', 'root', 'roots', 'flowers', 'flower', 'seeds', 'seed', 'bark', 'oil', 'oils', 'extract', 'extracts', 'tea', 'teas', 'decoction', 'infusion', 'tincture', 'paste', 'powder', 'juice', 'syrup', 'cream', 'tablets', 'capsules', 'fruits', 'fruit', 'berries', 'herb', 'plant', 'plants', 'species', 'was', 'were', 'are', 'has', 'have', 'may', 'can', 'and', 'the', 'with', 'for', 'from', 'which', 'that', 'this', 'also', 'used', 'taken', 'given', 'applied', 'boiled', 'dried', 'preparations'}
NOT_GENUS = {'Organon', 'Paris', 'London', 'Rome', 'Athens', 'Vienna', 'Berlin', 'Victoria', 'Arabia', 'Persia', 'China', 'India', 'Egypt', 'Greece', 'Italy', 'France', 'Spain', 'Germany', 'England', 'Scotland', 'Wales', 'Ireland', 'America', 'Africa', 'Europe', 'The', 'For', 'And', 'From', 'With', 'This', 'That', 'These', 'Those', 'See', 'When', 'Which', 'After', 'Before', 'Under', 'Some', 'Its', 'Their', 'They', 'There', 'Many', 'Most', 'Other', 'Such', 'Each', 'Both', 'Several', 'Fruits', 'Leaves', 'Roots', 'Flowers', 'Seeds', 'Dioscorides', 'Gerard', 'Culpeper', 'Galen', 'Pliny', 'Aetius', 'Avicenna', 'Hippocrates', 'Parkinson', 'Mattioli', 'Sir', 'Taken', 'Applied', 'Given', 'Used', 'Boiled', 'Drunk', 'Mixed', 'Made', 'Being', 'Having', 'Your', 'Our', 'His', 'Her', 'Upon', 'Into', 'About', 'Against', 'Also', 'Another', 'Southern', 'Northern', 'Western', 'Eastern', 'Central', 'Informants', 'Local', 'Traditional', 'Recent', 'Modern', 'Ancient'}


def sections(text):
    """Heading-delimited stretches; a paste of several chapters is not one subject."""
    found = []
    lines = list(re.finditer(r"[^\n]*(?:\n|$)", text))
    for index, line in enumerate(lines):
        value = line.group().strip()
        if not value or len(value) > 70:
            continue
        opens = index == 0 or not lines[index - 1].group().strip() or (found and found[-1]['line'] == index - 1)
        following = lines[index + 1].group().strip() if index + 1 < len(lines) else ''
        after = lines[index + 2].group().strip() if index + 2 < len(lines) else ''
        closes = not following or ((GLOSS_LINE.match(following) or BINOMIAL_LINE.match(following)) and not after)
        shaped = HEADING_LINE.match(value) or TITLE_LINE.match(value) or BINOMIAL_LINE.match(value)
        if opens and closes and shaped and not ENTRY_PART.match(value) and index + 2 < len(lines):
            begin = line.start() + (len(line.group()) - len(line.group().lstrip()))
            found.append({'heading': value, 'start': begin, 'end': begin + len(value), 'line': index})
    for index, section in enumerate(found):
        section['body_end'] = found[index + 1]['start'] if index + 1 < len(found) else len(text)
    return found


# A symptom or a preparation is never a plant, whatever a vernacular database records.
NEVER_A_PLANT |= {normalize(term) for terms in CONDITIONS.values() for term in terms} | {normalize(term) for term in PREPARATIONS + PARTS} | {'balsam', 'wool'}


def albanian_forms(key):
    """Albanian lists a noun as written in the record; prose uses the other form. A feminine name
    is definite in -a and indefinite in -ë or bare ("dëllinja", "dëllinjë"; "sanëza", "sanëz")."""
    head, _, rest = key.partition(' ')
    forms = {key}
    if len(head) >= 5 and head.endswith('a'):
        forms |= {f'{head[:-1]}{ending}{" " + rest if rest else ""}' for ending in ('e', '')}
    elif len(head) >= 5 and head.endswith('e'):
        forms.add(f'{head[:-1]}a{" " + rest if rest else ""}')
    return forms


class Extractor:
    version = "gazetteer-span-0.6-short-text-safe"

    def __init__(self, taxa):
        self.taxa = taxa
        self.aliases = {}
        self.foreign_aliases = {}
        # Local names written with letters English lacks ("sanëz", "çaj mali"), found in English prose too.
        self.marked_aliases = {}
        self.foreign_written = {}
        self.genus_names = {}
        for taxon in taxa:
            gazetteer_only = taxon.get('gazetteer_only')
            for alias in taxon["aliases"]:
                language = alias.get('lang', 'en')
                if '(' in alias['name']:
                    continue
                if language not in ('en', 'la') and alias['kind'] == 'VERNACULAR':
                    self.foreign_aliases.setdefault(language, {}).setdefault(normalize(alias['name']), set()).add(taxon['id'])
                    self.foreign_written.setdefault((language, normalize(alias['name'])), set()).add(unicodedata.normalize('NFC', alias['name'].casefold()))
                    if MARKED_LETTER.search(alias['name']) and len(normalize(alias['name'])) >= 4:
                        key = normalize(alias['name'])
                        for form in albanian_forms(key) if language == 'sq' else (key,):
                            self.marked_aliases.setdefault(form.split()[0], set()).add((form, key, language))
                    continue
                key = normalize(alias['name'])
                if key in NEVER_A_PLANT or len(alias["name"]) < (3 if alias['kind'] == 'HISTORICAL_LEXICON' else 4):
                    continue
                if gazetteer_only and alias['kind'] == 'VERNACULAR' and ' ' not in key and len(key) < 5:
                    continue
                self.aliases.setdefault(alias["name"], set()).add(taxon["id"])
            if not gazetteer_only:
                self.aliases.setdefault(taxon["genus"], set()).add(taxon["id"])
            elif len(taxon['genus']) >= 5:
                self.genus_names.setdefault(taxon['genus'], set()).add(taxon['id'])
        # Orthographic transformations, not new identity assertions.
        for name, ids in list(self.aliases.items()):
            if "feverfew" in name.lower():
                self.aliases.setdefault(re.sub("feverfew", "featherfew", name, flags=re.I), set()).update(ids)
            if "chamomile" in name.lower():
                self.aliases.setdefault(re.sub("chamomile", "camomile", name, flags=re.I), set()).update(ids)
            if "john" in name.lower():
                for transformed in [name.replace("’", "'"), name.replace("'", "’")]:
                    self.aliases.setdefault(transformed, set()).update(ids)
        # Index aliases by their first normalized token. Recompiling a thousand
        # whole-document regexes per chapter scales poorly and thrashes re's cache.
        self.alias_prefixes = {}
        self.alias_taxa = {}
        for name, identifiers in self.aliases.items():
            self.alias_taxa.setdefault(normalize(name), set()).update(identifiers)
        for key in self.alias_taxa:
            if key:
                self.alias_prefixes.setdefault(key.split()[0], []).append(key)
        self.known_genera = {normalize(t['genus']) for t in taxa}
        self.foreign_exact = {}
        for language, table in self.foreign_aliases.items():
            for key in table:
                if len(key) >= 4 and key not in TEA_WORDS:
                    self.foreign_exact.setdefault(key.split()[0], []).append((key, language))
        self.single_word_vernaculars = sorted(k for k in self.alias_taxa if ' ' not in k and len(k) >= 6)

    def sense_ok(self, text, start, end, key):
        """Is this word used as a plant here? Capitalised, or next to botanical wording."""
        window = text[max(0, start - 48):min(len(text), end + 32)]
        if NON_BOTANICAL_SENSE.search(window):
            return False
        if key in SENSE_REQUIRED or key in PERSON_PLANT_NAMES:
            # A geographic role is local to this occurrence: "Orange trees in
            # Orange County" still contains one real plant mention.
            if PLACE_AFTER.match(text[end:end + 48]) or PLACE_BEFORE.search(text[max(0,start - 48):start]):
                return False
        if key in PLACE_PREFIXES:
            # Exact cross-language fallback can otherwise turn "in Santa
            # Barbara" into a catnip alias. Keep a botanical continuation such
            # as "Santa Maria leaves" rather than blacklisting the name itself.
            following = text[end:end + 72]
            named = re.match(r'\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?', following)
            if named and not CUE_AFTER.match(following[named.end():]) and (re.search(r'\b(?:in|near|from|to|within|around|across)\s*$',text[max(0,start - 32):start],re.I) or PLACE_AFTER.match(following[named.end():])):
                return False
        # A person's conversation can mention tea or pain without naming a plant.
        if key in PERSON_PLANT_NAMES:
            before, after = text[max(0, start - 56):start], text[end:end + 96]
            if person_name_context(before, after):
                return False
        if key not in SENSE_REQUIRED:
            return True
        raw = text[start:end]
        sentence_start = start == 0 or bool(re.search(r"[.!?;:\n\"“]\s*$", text[max(0, start - 3):start]))
        if raw[:1].isupper() and not sentence_start:
            return True
        before, after = text[max(0, start - 28):start], text[end:end + 32]
        return bool(CUE_BEFORE.search(before) or CUE_AFTER.match(after) or raw[:1].isupper() and VIRTUE_AFTER.match(text, end) or BOTANICAL_NEIGHBOUR.search(before + ' ' + after) or GROWING_OR_COOKING.search(before + ' ' + after))

    def same_letters(self, word, language, key):
        """An inflected guess keeps the writer's letters: "horečce" (fever) is no form of "hořec" (gentian).
        A writer who types no diacritics at all ("horecce") is matched on plain letters."""
        word = consonant_marks(word)
        if word == normalize(word):
            return True
        # Vowel length alternates ("lípa", "lipový"); a marked consonant is another letter.
        return any(inflects(word, consonant_marks(written), language) for written in self.foreign_written.get((language, key), ()) if ' ' not in written)

    def foreign_mentions(self, text, language):
        table = self.foreign_aliases.get(language, {})
        if not table:
            return []
        hits = []
        folded, offsets = normalized_offsets(text)
        if language == 'zh':
            for key in sorted(table, key=len, reverse=True):
                for m in re.finditer(re.escape(key), folded):
                    hits.append((m.start(), m.end(), key))
        else:
            by_first = {}
            for key in table:
                by_first.setdefault(key[:3], []).append(key)
            for token in re.finditer(r'\w+', folded):
                part = PLANT_PART[language].search(token.group()) if language in PLANT_PART else None
                if part and part.start() >= 4 and token.group() not in table:
                    stem = token.group()[:part.start()]
                    key = next((k for k in (stem, stem + 'e', stem[:-1], stem[:-2]) if ' ' not in k and len(k) >= 4 and k in table), None)
                    if key:
                        hits.append((token.start(), token.end(), key))
                        continue
                for key in by_first.get(token.group()[:3], []):
                    value = folded[token.start():token.start() + len(key)]
                    if value == key and (token.start() + len(key) == len(folded) or not folded[token.start() + len(key)].isalnum()):
                        hits.append((token.start(), token.start() + len(key), key))
                    # A short name may change only its last letter ("trumza", "trumzë"); "manita" is no form of "manies".
                    elif ' ' not in key and inflects(token.group(), key, language) and self.same_letters(text[offsets[token.start()]:offsets[token.end() - 1] + 1], language, key):
                        hits.append((token.start(), token.end(), key))
        rows = []
        # The word as written beats an inflected guess: "manzanilla" is chamomile, "manzanillo" the manchineel.
        for begin, finish, key in sorted(hits, key=lambda h: (-(h[1] - h[0]), folded[h[0]:h[1]] != h[2], h[0])):
            if key in TEA_WORDS:
                continue
            start, end = offsets[begin], offsets[finish - 1] + 1
            if not any(start < x['end'] and end > x['start'] for x in rows):
                rows.append({'text': text[start:end], 'start': start, 'end': end, 'lookup': key, 'method': 'MULTILINGUAL_NAME_PROPOSAL', 'language': language})
        return rows

    def marked_mentions(self, text):
        """Local names inside English prose: "women collect çaj mali". Only a word with letters English
        lacks is looked up, and only as written, so English words never turn into foreign plant names."""
        rows = []
        folded, offsets = normalized_offsets(text)
        for word in MARKED_WORD.finditer(text):
            begin = bisect.bisect_left(offsets, word.start())
            if begin >= len(offsets):
                continue
            for form, key, language in sorted(self.marked_aliases.get(normalize(word.group()), ()), key=lambda k: (-len(k[0]), k[0] != k[1])):
                finish = begin + len(form)
                if folded.startswith(form, begin) and (finish == len(folded) or not folded[finish].isalnum()):
                    start, end = offsets[begin], offsets[finish - 1] + 1
                    if not any(start < x['end'] and end > x['start'] for x in rows):
                        rows.append({'text': text[start:end], 'start': start, 'end': end, 'lookup': key, 'method': 'MULTILINGUAL_NAME_PROPOSAL', 'language': language})
                    break
        return rows

    def mentions(self, text, language='en', section_subject=False):
        normalized, offsets = normalized_offsets(text)
        hits = []
        proposals = []
        for token in re.finditer(r'\w+', normalized):
            for key in self.alias_prefixes.get(token.group(), []):
                end = token.start() + len(key)
                if normalized.startswith(key, token.start()) and (end == len(normalized) or not re.match(r'\w', normalized[end])):
                    proposals.append((token.start(), end, key))
            # An English plural still explicitly names its subject: "Raw
            # Onions" must not fall back to a chapter about garlic, leek and onion.
            # Only exact -s forms are recovered; no plural-to-species fuzzy guess.
            singular = token.group()[:-1] if language == 'en' and token.group().endswith('s') else None
            if singular and singular in self.alias_taxa and len(singular) >= 4:
                proposals.append((token.start(), token.end(), singular))
        words = list(re.finditer(r'\w+', normalized))
        for first, second in zip(words, words[1:]):
            joined = first.group() + second.group()
            if second.start() - first.end() == 1 and joined in self.alias_taxa and len(joined) >= 7:
                proposals.append((first.start(), second.end(), joined))
        for begin, finish, key in sorted(set(proposals), key=lambda x: (-(x[1]-x[0]), x[0])):
            start, end = offsets[begin], offsets[finish-1]+1
            # A known word inside an unknown hyphenated plant name is not the
            # same entity (e.g. willow-herb versus willow; wood-sage versus sage).
            compound = (end < len(text)-1 and text[end] in "-–" and text[end+1].isalpha()) or (start > 1 and text[start-1] in "-–" and text[start-2].isalpha())
            if compound and not PLANT_PART_SUFFIX.match(text[end:end + 12]):
                continue
            if not self.sense_ok(text, start, end, key):
                continue
            if not any(start < x["end"] and end > x["start"] for x in hits):
                hits.append({"text": text[start:end], "start": start, "end": end, **({'lookup': key} if ' ' not in key and key != normalize(text[start:end]) else {})})
        if language != 'en':
            for row in self.foreign_mentions(text, language):
                if not any(row['start'] < x['end'] and row['end'] > x['start'] for x in hits):
                    hits.append(row)
        else:
            for row in self.marked_mentions(text):
                if not any(row['start'] < x['end'] and row['end'] > x['start'] for x in hits):
                    hits.append(row)
        # Latin binomials can be proposed even outside the snapshot and then abstained.
        # Exact fallback has no cross-language fuzzy or inflection guessing.
        for token in words if not hits else ():
            for key, alias_language in self.foreign_exact.get(token.group(), ()):
                finish = token.start() + len(key)
                if normalized.startswith(key, token.start()) and (finish == len(normalized) or not normalized[finish].isalnum()):
                    start, end = offsets[token.start()], offsets[finish - 1] + 1
                    if self.sense_ok(text, start, end, key) and not any(start < x['end'] and end > x['start'] for x in hits):
                        hits.append({'text': text[start:end], 'start': start, 'end': end, 'lookup': key, 'method': 'CROSS_LANGUAGE_EXACT_NAME', 'language': alias_language})
        for m, candidate in self.binomials(text):
            genus, epithet = candidate.split()[0], candidate.split()[-1]
            if normalize(genus) in PERSON_PLANT_NAMES and not self.sense_ok(text, m.start(), m.start() + len(genus), normalize(genus)):
                continue
            known = normalize(genus) in self.known_genera
            plural_word = epithet.endswith('s') and not epithet.endswith(('us', 'is', 'ans', 'ens', 'ides', 'ys', 'os', 'as'))
            if genus in NOT_GENUS or epithet in NOT_EPITHET or plural_word or not LATIN_EPITHET.search(epithet):
                continue
            # "Fennell seede", "Sage leaues": an unknown genus followed by a part of a plant is English.
            if not known and OLD_PART.fullmatch(epithet.casefold()):
                continue
            # "Mio fratello", "Mijn broer": outside English a capital opening a sentence is no genus,
            # and German capitalises every noun ("Morgen zur Schule"): an unknown epithet needs four letters.
            if not known and language != 'en' and (re.search(r'(?:^|[.!?;:]\s*)$', text[:m.start()]) or len(epithet) < 4 or epithet.casefold() in FUNCTION_EPITHETS):
                continue
            # A recognised genus must not swallow an unknown full binomial.
            contained = [x for x in hits if m.start() <= x['start'] and x['end'] <= m.end()]
            if contained and any(x['start'] < m.start() or x['end'] > m.end() for x in hits if m.start() < x['end'] and m.end() > x['start']):
                continue
            # "Listovi bokvice" (plantain leaves) and "Horehound drunke" have a binomial's shape; an unknown genus keeps the known name.
            if not known and (contained or normalize(epithet) in self.known_genera):
                continue
            hits = [x for x in hits if x not in contained]
            if not any(m.start() < x['end'] and m.end() > x['start'] for x in hits):
                hits.append({'text': m.group(), 'start': m.start(), 'end': m.end(), 'method': 'SCIENTIFIC_BINOMIAL_PROPOSAL' if known else 'UNVERIFIED_BINOMIAL_PROPOSAL', **({'lookup': candidate} if candidate != m.group() else {})})
        # Genus spelling is case-insensitive; a lower-case genus also needs
        # botanical context. It proposes the group and does not settle a species.
        genera = {normalize(name): name for name in self.genus_names}
        for m in re.finditer(r"\b[A-Za-z]{5,}\b", text):
            key = normalize(m.group())
            if key in genera and genera[key] not in NOT_GENUS and (m.group()[0].isupper() or BOTANICAL_NEIGHBOUR.search(text[max(0, m.start()-40):m.end()+32])) and self.sense_ok(text, m.start(), m.end(), key) and not any(m.start() < x['end'] and m.end() > x['start'] for x in hits):
                hits.append({'text': m.group(), 'start': m.start(), 'end': m.end(), 'lookup': genera[key], 'method': 'GENUS_NAME_PROPOSAL'})
        # Abbreviated genus must be resolved against candidate genera, never silently expanded.
        for m in re.finditer(r"\b[A-Z]\.\s+[a-z]{3,}\b", text):
            if m.group().split()[-1] not in NOT_EPITHET and not any(m.start() < x["end"] and m.end() > x["start"] for x in hits):
                hits.append({"text": m.group(), "start": m.start(), "end": m.end()})
        # Propose parenthesised Latin-looking binomials outside the 24-taxon list.
        # They undergo exact reconciliation only, never fuzzy identity assignment.
        for m in re.finditer(r"\(\s*([A-Z][a-z]{2,}\s+(?:[x×]\s+)?[a-z]{3,}(?:-[a-z]+)*)\s*\)", text):
            start, end = m.span(1)
            if m[1].split()[0] in NOT_GENUS:
                continue
            if not any(start < h['end'] and end > h['start'] for h in hits):
                hits.append({'text': m[1], 'start': start, 'end': end, 'method': 'PARENTHETICAL_BINOMIAL_PROPOSAL'})
        # "Чай от лайка", "chá de erva-cidreira", "Der Thee von Pfefferminze": the drink, made of the other plant.
        drinks = [x for x in hits if normalize(x['text']) in TEA_WORDS]
        for drink in drinks:
            if not re.match(r'\s+(?:plant|bush|shrub|tree)\b', text[drink['end']:], re.I):
                hits.remove(drink)
        # "Brinove jagode" is juniper berries: after a plant's possessive adjective the noun is its part.
        if language in CASE_LANGUAGES:
            adjectives = [x for x in hits if x.get('method') == 'MULTILINGUAL_NAME_PROPOSAL' and re.search(r'(?:ov|ev|in)[aeiou]?$', normalize(x['text']))]
            hits = [x for x in hits if not (x.get('method') == 'MULTILINGUAL_NAME_PROPOSAL' and any(a is not x and a['end'] < x['start'] and not text[a['end']:x['start']].strip() for a in adjectives))]
        hits += self.spelling_proposals(text, hits) if language == 'en' else []
        hits += self.position_proposals(text, hits) if language == 'en' and not section_subject else []
        hits += self.list_proposals(text, hits) if not section_subject else []
        # Proposal routes obey the same sense rules as the main gazetteer.
        # Otherwise a rejected person name can reappear via spelling recovery.
        hits = [x for x in hits if normalize(x['text']) not in {'herbs', 'plants', 'flowers', 'trees'} and self.sense_ok(text, x['start'], x['end'], normalize(x.get('lookup') or x['text'])) and (normalize(x['text']) not in TEA_WORDS or re.match(r'\s+(?:plant|bush|shrub|tree)\b', text[x['end']:], re.I))]
        return [{"id": f"mention-{i}", "method": x.get('method', self.version), **{k: v for k, v in x.items() if k != 'method'}, "normalized": normalize(x.get('lookup') or x["text"])} for i, x in enumerate(sorted(hits, key=lambda x: x["start"]))]

    def binomials(self, text):
        for m in LATIN_BINOMIAL.finditer(text):
            yield m, m.group()
        for m in CAPITAL_BINOMIAL.finditer(text):
            alone = re.fullmatch(r'[ \t]*', text[text.rfind('\n', 0, m.start()) + 1:m.start()]) and re.match(r'[ \t]*\.?[ \t]*(?:\n|$)', text[m.end():])
            if normalize(m[1]) in self.known_genera or alone or AUTHOR_AFTER.match(text, m.end()):
                yield m, f'{m[1].capitalize()} {m[2].lower()}'

    def list_proposals(self, text, hits):
        """Listed names that no known name already covers."""
        rows = []
        for row in sorted(name_list_rows(text), key=lambda r: r['start']):
            same = next((x for x in hits if (x['start'], x['end']) == (row['start'], row['end'])), None)
            if same is not None:
                # A known name inside a list still belongs to that entry when the reader is shown it.
                same.setdefault('listed_in', row['list_id'])
            if not any(row['start'] < x['end'] and row['end'] > x['start'] for x in hits + rows):
                rows.append(row)
        return rows

    def labelled_entries(self, text, mentions, blocks):
        """A "Uses.--" paragraph speaks of the plant the entry opened with."""
        found = []
        floor = 0
        for label in USE_LABEL.finditer(text):
            if any(b['start'] <= label.start() < b['body_end'] for b in blocks):
                continue
            head = text.rfind('\n\n', floor, max(label.start() - 1, 0))
            head = max(text.rfind('\n\n', floor, head) if head > floor else head, floor)
            names = [m for m in mentions if head <= m['start'] < label.start()]
            # The first Latin name is the entry; those after it are the author's synonyms.
            first = next((m for m in names if 'BINOMIAL' in m['method']), None)
            subjects = ([first] if first else []) + [m for m in names if 'BINOMIAL' not in m['method']]
            floor = text.find('\n\n', label.end())
            floor = len(text) if floor < 0 else floor
            if subjects:
                found.append({'heading': subjects[0]['text'], 'start': subjects[0]['start'], 'end': subjects[0]['end'], 'subjects': subjects, 'labelled': True, 'names': {m['normalized'] for m in subjects}, 'taxa': set().union(set(), *(self.alias_taxa.get(normalize(f), set()) for m in subjects for f in m.get('forms', [m['normalized']])))})
        for index, block in enumerate(found):
            block['body_end'] = found[index + 1]['start'] if index + 1 < len(found) else len(text)
        return found

    def position_proposals(self, text, hits):
        """Unknown words in a plant position; only GBIF can turn one into a candidate."""
        rows = []
        for pattern in CUE_NAME:
            for m in pattern.finditer(text):
                word = m.group(1)
                key = word.casefold()
                last = key.split()[-1]
                if key in CUE_STOP or last in CUE_STOP or key in NEVER_A_PLANT or last in NEVER_A_PLANT or key in SENSE_REQUIRED or word in NOT_GENUS or key in LOWERCASE_FUNCTION or key.endswith(('ing', 'ed', 'ly')) or key.split()[0] in NOT_A_NAME_START:
                    continue
                if not any(m.start(1) < x['end'] and m.end(1) > x['start'] for x in hits + rows):
                    rows.append({'text': word, 'start': m.start(1), 'end': m.end(1), 'method': 'PLANT_POSITION_PROPOSAL'})
        return rows

    def spelling_proposals(self, text, hits):
        """Early-modern spelling: only a word in a plant position may be matched approximately."""
        rows = []
        for m in re.finditer(r"\b[A-Za-z]{5,}\b", text):
            if any(m.start() < x['end'] and m.end() > x['start'] for x in hits + rows):
                continue
            before, after = text[max(0, m.start() - 26):m.start()], text[m.end():m.end() + 16]
            capitalised = m.group()[0].isupper() and not re.search(r"(?:^|[.!?;:\n\"“]\s*)$", before)
            if not (CUE_BEFORE.search(before) or CUE_AFTER.match(after) or capitalised):
                continue
            key = normalize(m.group())
            if key in CUE_STOP or key in LOWERCASE_FUNCTION or key in NEVER_A_PLANT or key in SENSE_REQUIRED or m.group() in NOT_GENUS or key.endswith(('ed', 'ing')):
                continue
            match = process.extractOne(key, self.single_word_vernaculars, scorer=fuzz.ratio, score_cutoff=84)
            if match and match[0][0] == key[0]:
                rows.append({'text': m.group(), 'start': m.start(), 'end': m.end(), 'lookup': match[0], 'method': 'APPROXIMATE_SPELLING_PROPOSAL'})
        return rows

    def _taxa(self):
        # Supplied by Pipeline after construction; kept explicitly for unknown-binomial proposals.
        return getattr(self, "taxa", [])

    def heading_mentions(self, text, section):
        """Plant names a heading announces, each spanning its own heading wording."""
        rows = []
        line = text[section['start']:section['end']]
        names = heading_names(line)
        for name in names:
            specific = any(other is not name and len(other['name'].split()) > len(name['name'].split()) and other['name'].casefold().endswith(name['name'].casefold()) for other in names)
            if specific:
                continue
            start = section['start'] + max(name['start'], 0)
            end = min(section['end'], start + len(name['name']))
            if not text[start:end].strip() or any(start < r['end'] and end > r['start'] for r in rows):
                free = next(((m.start() + section['start'], m.end() + section['start']) for m in re.finditer(r'[^\s,().]+', line) if not any(m.start() + section['start'] < r['end'] and m.end() + section['start'] > r['start'] for r in rows)), None)
                if not free:
                    continue
                start, end = free
            rows.append({'text': text[start:end], 'start': start, 'end': end, 'normalized': normalize(name['name']), 'heading_name': name['name'], 'forms': name['forms'], 'method': 'SOURCE_HEADING_SUBJECT'})
        return rows

    def condition_rows(self, clause, language, fallback_languages=()):
        rows = []
        if language == 'en':
            for condition, terms in CONDITIONS.items():
                for span in spans(clause["text"], terms):
                    if condition_sense(condition, span['text'], clause['text']):
                        rows.append((condition, span))
        else:
            found = [(condition, span) for condition, table in LANGUAGE_DATA['conditions'].items() for span in stem_spans(clause["text"], table.get(language, []))]
            # "Sore throat" also starts with the word for pain; the longer wording decides, then the
            # longer stem: "πονοκέφαλο" is a headache before it is a "πόνο".
            for condition, span in sorted(found, key=lambda row: (row[1]['start'] - row[1]['end'], -row[1]['stem'])):
                if not any(span['start'] < other['end'] and span['end'] > other['start'] for _, other in rows):
                    rows.append((condition, span))
        if not rows:
            for fallback in dict.fromkeys(fallback_languages):
                if fallback != language:
                    found = self.condition_rows(clause, fallback)
                    if found:
                        return found
        return [{"id": f"condition:{condition}", "label": condition.replace("_", " "), "mapping_status": "LEXICAL_RETRIEVAL_AID_NOT_DIAGNOSTIC_EQUIVALENCE", "original": span["text"], "start": span["start"] + clause["start"], "end": span["end"] + clause["start"]} for condition, span in rows]

    def extract(self, text, **options):
        result = self.read_text(unwrap(EMPHASIS.sub(lambda m: ' ' * len(m.group()), text)), **options)
        for claim in result['historical_claims']:
            claim['support'] = {**claim['support'], 'text': text[claim['support']['start']:claim['support']['end']]}
        return result

    def read_text(self, text, *, section_subject=False, requested_name=None, language=None):
        language = language or detect_language(text)
        mentions = self.mentions(text, language, section_subject)
        if section_subject:
            # Without GBIF at hand a Latin-looking pair needs a known genus or the author's brackets.
            mentions = [m for m in mentions if m['method'] != 'UNVERIFIED_BINOMIAL_PROPOSAL']
        if requested_name is not None:
            requested_name = requested_name.strip()
            if not 2 <= len(requested_name) <= 120:
                raise ValueError('Choose a name of 2–120 characters from the source')
            matches = list(re.finditer(r'(?<!\w)' + re.escape(requested_name) + r'(?!\w)', text, re.I))
            if not matches:
                raise ValueError('This name does not occur in the source. Enter the original spelling, including spaces and punctuation.')
            # User-selected source wording is explicit provenance, not an alias
            # learned by the extractor or a verified botanical identification.
            mentions = [m for m in mentions if not any(hit.start() < m['end'] and hit.end() > m['start'] for hit in matches)]
            mentions += [{'text': hit.group(), 'start': hit.start(), 'end': hit.end(), 'normalized': normalize(hit.group()), 'method': 'RESEARCHER_SELECTED_NAME'} for hit in matches]
        heading_end = text.find('\n')
        if section_subject:
            blocks = [{'heading': text[:heading_end], 'start': 0, 'end': heading_end, 'body_end': len(text)}] if heading_end > 0 else []
        else:
            blocks = sections(text)
            # "Chamaemelum: the flowers are heating" announces its subject inline.
            for match in LEADING_NAME.finditer(text):
                if match[1].split()[0] not in NOT_GENUS:
                    blocks.append({'heading': match[1], 'start': match.start(1), 'end': match.end(1), 'inline': True})
            # "258. +Ním Tree or Margosa.+ The leaves...": a numbered entry opens with its name in bold.
            for match in BOLD_ENTRY.finditer(text):
                if not any(b['start'] <= match.start('name') < b['end'] for b in blocks):
                    blocks.append({'heading': match['name'], 'start': match.start('name'), 'end': match.end('name'), 'inline': True})
            blocks.sort(key=lambda b: b['start'])
            for index, block in enumerate(blocks):
                block['body_end'] = blocks[index + 1]['start'] if index + 1 < len(blocks) else len(text)
        for block in blocks:
            announced = self.heading_mentions(text, block)
            if not section_subject:
                # An inferred heading keeps recognised names; unknown words are not promoted.
                inside = [m for m in mentions if block['start'] <= m['start'] < block['end']]
                known = [m for m in announced if any(normalize(f) in self.alias_taxa for f in m['forms'])]
                if BINOMIAL_LINE.match(text[block['start']:block['end']]) and any('BINOMIAL' in m['method'] for m in inside):
                    announced = inside
                elif known:
                    announced = known
                else:
                    # "May-Apple." may only be known to GBIF; there a rejected word leaves no trace.
                    wording = text[block['start']:block['end']].rstrip(' .,')
                    whole = [] if block.get('inline') or wording.casefold() in CUE_STOP or any(m['start'] == block['start'] and m['end'] >= block['start'] + len(wording) for m in inside) else [{'id': 'heading', 'text': wording, 'start': block['start'], 'end': block['start'] + len(wording), 'normalized': normalize(wording), 'method': 'PLANT_POSITION_PROPOSAL', 'heading_line': True}]
                    announced = whole + inside
            mentions = [m for m in mentions if not (block['start'] <= m['start'] < block['end'])] + announced
        mentions = [{**m, 'id': f'mention-{i}'} for i, m in enumerate(sorted(mentions, key=lambda m: m['start']))]
        for index, block in enumerate(blocks):
            block['subjects'] = [m for m in mentions if block['start'] <= m['start'] < block['end']]
            # A common name, then its Latin name on the next line: one entry, one subject.
            if index and not text[blocks[index - 1]['end']:block['start']].strip():
                block['subjects'] = blocks[index - 1]['subjects'] + block['subjects']
            block['names'] = {m['normalized'] for m in block['subjects']}
            block['taxa'] = set().union(set(), *(self.alias_taxa.get(normalize(f), set()) for m in block['subjects'] for f in m.get('forms', [m['normalized']])))
        use_paragraphs = []
        if not section_subject:
            blocks = sorted(blocks + self.labelled_entries(text, mentions, blocks), key=lambda b: b['start'])
            # Under an author's own "Uses" label a topic word is a use, whatever the verb.
            use_paragraphs = [(m.start(), (text.find(chr(10) * 2, m.end()) + 1 or len(text) + 1) - 1) for m in USE_LABEL.finditer(text)]
        paragraphs, begin = [], 0
        for boundary in list(re.finditer(r'\n\s*\n', text)) + [None]:
            end = boundary.start() if boundary else len(text)
            paragraphs.append((begin, end))
            begin = boundary.end() if boundary else len(text)
        # "Bhindí, Rám-turáí (_Hind._) …" on its own, then a paragraph of uses that never repeats
        # the name: a short list that records no use is the entry the next paragraph describes.
        listed = {}
        for before, after in zip(paragraphs, paragraphs[1:]):
            names = [m for m in mentions if before[0] <= m['start'] < before[1]]
            residue = list(text[before[0]:before[1]])
            for m in names:
                residue[m['start'] - before[0]:m['end'] - before[0]] = ' ' * (m['end'] - m['start'])
            # Only names, language tags and punctuation: "Sage grows in every garden" is not a list.
            residue = re.sub(r'_[^_]{1,12}_|\([^)]{0,30}\)|\b(?:or|and)\b', ' ', ''.join(residue))
            if names and before[1] - before[0] <= 400 and len(re.findall(r'\w{3,}', residue)) <= 2 * len(names) \
                    and not re.search(r'\b(?:the|an?|is|are|was|were|be|in|of|for|with|by|to|at|on|it|this|that|which|from|grows?|grown|used|called|known)\b', residue, re.I) \
                    and not any(after[0] <= m['start'] < after[1] for m in mentions):
                listed[after] = names
        result, recent = [], []
        for clause in sentences(text):
            block = next((b for b in reversed(blocks) if b['start'] <= clause['start'] < b['body_end']), None)
            subject = block['subjects'] if block else []
            paragraph = next((p for p in paragraphs if p[0] <= clause['start'] <= p[1]), None)
            nearby = [m for m in mentions if m["start"] < clause["end"] and m["end"] > clause["start"]]
            named = [m for m in nearby if m['method'] != 'SOURCE_HEADING_SUBJECT']
            explicit_recent = [m for start, group in recent if paragraph and start >= paragraph[0] for m in group][-4:]
            conditions = self.condition_rows(clause, language, [m['language'] for m in mentions if m.get('language') and m['start'] < clause['end'] and m['end'] > clause['start']])
            if named:
                recent = (recent + [(clause['start'], named)])[-2:]
            if not conditions:
                continue
            scope = "SENTENCE"
            possible = []
            if not nearby and subject:
                # Coreference window: only a plant named in the last two sentences of this
                # paragraph competes with the chapter subject. A distant mention does not.
                rival = [m for m in explicit_recent if m['normalized'] not in block['names'] and not (self.alias_taxa.get(m['normalized'], set()) & block['taxa'])]
                nearby = subject
                scope = "PARAGRAPH_CONTEXT_UNCERTAIN_RELATION" if rival else "SOURCE_SECTION_HEADING"
                possible = sorted({m['text'] for m in rival})
            elif subject and nearby and not any(m in subject for m in nearby) and all(INGREDIENT_POSITION.search(text[max(0, m['start'] - 30):m['start']]) for m in nearby):
                nearby = subject + nearby
                scope = "MULTI_PLANT_CLAUSE_UNCERTAIN_RELATION"
            elif not nearby and explicit_recent:
                nearby = explicit_recent[-1:]
                scope = "PRECEDING_SENTENCE_SUBJECT"
            elif not nearby and paragraph in listed:
                nearby = listed[paragraph]
                scope = "PRECEDING_NAME_LIST"
            if not nearby:
                continue
            # Explicitly retain multi-plant ambiguity instead of attaching the whole clause to all.
            if scope == "SENTENCE" and len({m["normalized"] for m in nearby}) > 1:
                scope = "MULTI_PLANT_CLAUSE_UNCERTAIN_RELATION"
            fields = {}
            preparation_terms = PREPARATIONS if language == 'en' else LANGUAGE_DATA['preparations'].get(language, [])
            for field, terms in [("part", PARTS if language == 'en' else []), ("preparation", preparation_terms), ("route", ROUTES if language == 'en' else [])]:
                values = spans(clause["text"], terms) if language == 'en' else stem_spans(clause["text"], terms)
                fields[field] = [{"text": v["text"], "start": v["start"] + clause["start"], "end": v["end"] + clause["start"]} for v in values]
            dosage = []
            for m in re.finditer(r"\b(?:half|one|two|three|four|five|six|ten|twenty|thirty|\d+)\s+(?:to\s+\w+\s+)?(?:drams?|drachms?|ounces?|grains?|drops?|spoonfuls?|pints?|teaspoonfuls?|tablespoonfuls?)\b", clause["text"], re.I):
                dosage.append({"text": m.group(), "start": clause["start"] + m.start(), "end": clause["start"] + m.end()})
            role = statement_role(clause['text']) if language == 'en' else 'THERAPEUTIC_USE_RECORDED'
            if role == 'CONTEXT_ONLY_OR_UNCLEAR' and any(begin <= clause['start'] < end for begin, end in use_paragraphs):
                role = 'THERAPEUTIC_USE_RECORDED'
            if language == 'en' and role == 'CONTEXT_ONLY_OR_UNCLEAR' and CONTINUATION.match(clause['text']) and result and result[-1]['statement_role'] == 'THERAPEUTIC_USE_RECORDED' and clause['start'] - result[-1]['support']['end'] < 4:
                role = 'THERAPEUTIC_USE_RECORDED'
            result.append({"id": f"historical-claim-{len(result)}", "type": "HISTORICAL_ATTESTATION", "statement_role": role, "role_method": "LEXICAL_DISCOURSE_SCREEN_NOT_ENTAILMENT" if language == 'en' else "LANGUAGE_LEXICON_SCREEN_NOT_ENTAILMENT", "practice": practice_kind(clause['text']) if language == 'en' else 'MEDICINAL', "mention_ids": [m["id"] for m in nearby], "relation_scope": scope, "possible_subjects": possible, "support": clause, "conditions": conditions, **fields, "dosage_expressions": dosage, "negated": bool(DENIED.search(clause["text"])), "human_reviewed": False})
        return {"mentions": mentions, "historical_claims": result, "language": language}

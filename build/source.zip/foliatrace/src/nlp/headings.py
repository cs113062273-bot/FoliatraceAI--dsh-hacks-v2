"""Split a herbal chapter heading into the plant names it actually announces.

Headings pack several shapes into one line: page markers, botanical family glosses,
synonyms, qualifiers and several plants. Every returned name keeps the span of the
heading wording it came from, so a resolved name never loses its source position.
"""
from __future__ import annotations

import re

QUALIFIERS = {'white', 'black', 'greater', 'lesser', 'great', 'little', 'small', 'horse', 'sweet', 'meadow', 'cultivated', 'common', 'wood', 'wild', 'ground', 'garden', 'field', 'marsh', 'water', 'sea', 'red', 'yellow', 'deadly', 'english', 'dwarf', 'stinking', 'bitter', 'true', 'dog', "dog's"}
NOT_PLANT = {'other', 'the', 'and', 'or', 'also', 'called', 'see', 'a', 'an', 'of', 'tree', 'plants', 'flowers', 'root', 'radix', 'herb', 'herbs', 'sea', 'water'}
DROP_GLOSS = re.compile(r'^(?:[a-z]+(?:aceoe|aceae|iferae|iferoe|ceoe|acoe)|leguminous|labiatoe|compositoe|umbelliferoe|radix.*|a root|see also.*|the|other)$', re.I)
NOT_A_PLANT_NAME = re.compile(r'^(?:flowers? of|sea plants|sea weeds|water plants)$', re.I)


def singular(word):
    lower = word.casefold()
    if lower.endswith('ies') and len(lower) > 5:
        return word[:-3] + 'y'
    if lower.endswith(('ches', 'shes', 'sses', 'xes')) and len(lower) > 5:
        return word[:-2]
    if lower.endswith('s') and not lower.endswith(('ss', 'us', 'is')) and len(lower) > 4:
        return word[:-1]
    return word


def forms(name):
    """Orthographic lookup variants; none of them asserts an identity."""
    clean = ' '.join(name.replace('’', "'").split())
    out = [clean, clean.replace('-', ' '), clean.replace('-', ''), clean.replace(' ', ''), re.sub(r"^(?:the|a|an)\s+", '', clean, flags=re.I)]
    words = clean.split()
    out.append(' '.join(words[:-1] + [singular(words[-1])]))
    out.append(' '.join(out[-1].split()).replace('-', ' '))
    out.append(re.sub(r"\s+tree$", '', clean, flags=re.I))
    out.append(re.sub(r"^st\.?\s+", "st. ", clean, flags=re.I))
    if re.match(r"john'?s wort", clean, re.I):
        out += ["st. john's wort", "st john's wort"]
    seen, unique = set(), []
    for value in out:
        key = value.casefold().strip()
        if key and key not in seen:
            seen.add(key)
            unique.append(value.strip())
    return unique


def _add(found, text, start, name):
    name = re.sub(r"^(?:the|a|an)\s+", '', ' '.join(name.split()), flags=re.I).strip(" ,.;:—-")
    name = re.sub(r"^other\s+", '', name, flags=re.I)
    if len(name) < 3 or name.casefold() in NOT_PLANT or NOT_A_PLANT_NAME.fullmatch(name):
        return
    if any(name.casefold() == row['name'].casefold() for row in found):
        return
    found.append({'name': name, 'start': start, 'end': min(len(text), start + len(name)), 'forms': forms(name)})


def heading_names(heading):
    """Return plant names announced by a heading, in reading order."""
    text = heading
    line = re.sub(r'\[\d+\]', lambda m: ' ' * len(m.group()), heading).rstrip()
    line = line.rstrip('. ')
    found = []
    groups = list(re.finditer(r'\(([^)]*)\)', line))
    base = re.sub(r'\([^)]*\)', lambda m: ' ' * len(m.group()), line)
    head_offset = len(base) - len(base.lstrip())
    base_clean = base.strip().rstrip(' .,—-')
    parts = [p for p in re.split(r'\s*(?:,|—|\band\b|\bAND\b|\bor\b|\bOR\b|\bcalled\b|\bCALLED\b)\s*', base_clean) if p.strip()]
    # "NIGHT SHADE, DEADLY" and "IVY, Common": a trailing qualifier belongs to the plant before it.
    qualified = []
    for part in parts:
        part = re.sub(r'^the\s+', '', part, flags=re.I)
        if qualified and part.casefold().split()[-1] in QUALIFIERS and len(part.split()) == 1:
            qualified[-1] = f'{part} {qualified[-1]}'
        else:
            qualified.append(part)
    # "MERCURY-DOG'S" inverts the plant and its qualifier.
    inverted = []
    for part in qualified:
        match = re.fullmatch(r"([A-Za-z]+)-([A-Za-z]+'[sS])", part)
        inverted.append(f'{match[2]} {match[1]}' if match else part)
    head = inverted[0] if inverted else ''
    for part in inverted:
        index = text.casefold().find(part.split()[-1].casefold())
        _add(found, text, max(index, head_offset), part)
    for group in groups:
        items = [p.strip() for p in re.split(r'\s*(?:,|\band\b|\bor\b|\bAND\b|\bOR\b)\s*', group[1]) if p.strip()]
        for item in items:
            item = re.sub(r'^(?:also called|called|the|The)\s+', '', item).strip(' .')
            if not item or DROP_GLOSS.fullmatch(item):
                continue
            start = text.find(item)
            words = item.casefold().split()
            if len(words) == 1 and words[0] in QUALIFIERS:
                for row in list(found):
                    if len(row['name'].split()) == 1:
                        _add(found, text, max(start, 0), f"{item} {row['name']}")
                        # A qualified entry is more specific than its bare head.
                continue
            _add(found, text, max(start, 0), item)
    return found

"""Reusable knowledge records mined from historical prose, retaining exact spans."""
from collections import Counter
from src.common import now


def mine_corpus(pipeline, previous=None):
    rows, collections = [], Counter()
    withdrawn = pipeline.withdrawn()
    for passage in pipeline.passages + pipeline.extra_passages:
        if passage['id'] in withdrawn or passage['source_id'] in withdrawn:
            continue
        text = passage['title'] + '\n\n' + passage['text']
        extracted = pipeline.extractor.extract(text, section_subject=True, language='en')
        mentions = {m['id']: m for m in extracted['mentions']}
        collection = passage.get('collection') or 'Culpeper 1850'
        collections[collection] += 1
        for claim in extracted['historical_claims']:
            names = [mentions[m] for m in claim['mention_ids']]
            rows.append({'id': passage['id'] + ':' + claim['id'], 'source_id': passage['id'], 'collection': collection, 'source_title': passage['title'], 'date': passage['date'], 'url': passage['url'], 'licence': passage['licence'], 'statement': claim['support'], 'names': [{'text': m.get('heading_name') or m['text'], 'method': m['method'], 'start': m['start'], 'end': m['end']} for m in names], 'conditions': claim['conditions'], 'parts': claim['part'], 'preparations': claim['preparation'], 'routes': claim['route'], 'scope': claim['relation_scope'], 'negated': claim['negated'], 'human_reviewed': False})
            rows[-1]['statement_role'] = claim['statement_role']
            rows[-1]['role_method'] = claim['role_method']
            rows[-1]['dosage_expressions'] = claim['dosage_expressions']
            rows[-1]['practice'] = claim['practice']
            rows[-1]['possible_subjects'] = claim['possible_subjects']
    migrations = {}
    if previous:
        def anchor(row):
            return (row['source_id'], row['collection'], row['date'], row['url'], row['statement']['start'], row['statement']['end'], row['statement']['text'])
        active = {anchor(row): row['id'] for row in rows}
        id_map = {row['id']: active[anchor(row)] for row in previous['records'] if anchor(row) in active}
        migrations[previous['snapshot_sha256']] = id_map
        for migration in previous.get('reading_migrations', []):
            migrations[migration['snapshot_sha256']] = {old_id: id_map[prior_id] for old_id, prior_id in migration['id_map'].items() if prior_id in id_map}
    return {'created_at': now(), 'snapshot_sha256': pipeline.snapshot, 'code_fingerprint': pipeline.code_fingerprint, 'scope': 'Automatically extracted historical statements, including uses, adverse effects and context. Condition mappings are lexical research aids, not diagnostic equivalence. Counts do not establish extraction accuracy, efficacy or historical botanical identity.', 'collections': dict(collections), 'records': rows, 'conditions': dict(Counter(c['id'] for r in rows for c in r['conditions'])), 'roles': dict(Counter(r['statement_role'] for r in rows)), 'extraction_method': pipeline.extractor.version, 'reading_migrations': [{'snapshot_sha256': snapshot, 'id_map': mapping} for snapshot, mapping in migrations.items()]}

from __future__ import annotations

import math
import re
from collections import Counter
from pathlib import Path

import numpy as np
from src.common import ROOT, read_json
from src.nlp.extract import SENSE_REQUIRED, normalize, topic_pattern, research_terms
from src.retrieval.reranker import LocalReranker


def tokens(text):
    return re.findall(r"[a-z]{2,}", normalize(text))


def design_rank(paper):
    types = set(paper.get("publication_types", []))
    title = paper["title"].casefold()
    if types & {"Meta-Analysis", "Systematic Review"} or "meta-analysis" in title or "systematic review" in title:
        return 0
    if types & {"Randomized Controlled Trial", "Controlled Clinical Trial"} or "randomized" in title or "randomised" in title:
        return 1
    if any(t.startswith("Clinical Trial") for t in types) or "clinical trial" in title:
        return 2
    if "Review" in types or re.search(r"\breview\b", title):
        return 3
    return 4


class LocalEncoder:
    """Pinned MiniLM ONNX encoder. Absence is explicit, never silently substituted."""
    def __init__(self, model_dir=None):
        self.path = model_dir or ROOT / "models" / "minilm"
        self.available = (self.path / "model.onnx").exists() and (self.path / "tokenizer.json").exists()
        self.session = None

    def encode(self, texts):
        if not self.available:
            raise RuntimeError("Local encoder is not installed. Run scripts/setup_model.py, or select bm25 explicitly.")
        if self.session is None:
            from src.common import digest
            lock = read_json(ROOT / "data" / "models.lock.json")
            for entry in lock["files"]:
                if digest((self.path / entry["local"]).read_bytes()) != entry["sha256"]:
                    raise ValueError("Local encoder artifact checksum differs from pinned manifest")
            import onnxruntime as ort
            from tokenizers import Tokenizer
            options = ort.SessionOptions()
            options.intra_op_num_threads = 4
            self.session = ort.InferenceSession(str(self.path / "model.onnx"), sess_options=options, providers=["CPUExecutionProvider"])
            self.tokenizer = Tokenizer.from_file(str(self.path / "tokenizer.json"))
            self.tokenizer.enable_truncation(max_length=256)
            self.tokenizer.enable_padding()
        outputs = []
        for start in range(0, len(texts), 16):
            encodings = self.tokenizer.encode_batch(texts[start:start + 16])
            ids = np.asarray([e.ids for e in encodings], dtype=np.int64)
            mask = np.asarray([e.attention_mask for e in encodings], dtype=np.int64)
            feed = {"input_ids": ids, "attention_mask": mask, "token_type_ids": np.zeros_like(ids)}
            values = self.session.run(None, {x.name: feed[x.name] for x in self.session.get_inputs()})[0]
            if values.ndim == 3:
                weights = mask[..., None].astype(np.float32)
                values = (values * weights).sum(axis=1) / np.maximum(weights.sum(axis=1), 1)
            values = values / np.maximum(np.linalg.norm(values, axis=1, keepdims=True), 1e-12)
            outputs.append(values)
        return np.concatenate(outputs) if outputs else np.empty((0, 384))


class LiteratureIndex:
    def __init__(self, papers, taxa, *, encoder=None):
        self.papers, self.taxa = [], taxa
        self.docs, self.counts, self.texts, self.lengths = [], [], [], []
        self.postings = {}
        self.encoder = encoder or LocalEncoder()
        self.reranker = LocalReranker()
        self.embeddings = None
        self.naming_cache = {}
        self.add(papers)

    def add(self, papers):
        """Incremental: a plant looked up on demand joins the index without rebuilding it."""
        for paper in papers:
            index = len(self.papers)
            self.papers.append(paper)
            document = tokens(paper["title"] + " " + paper["abstract"])
            counts = Counter(document)
            self.docs.append(document)
            self.counts.append(counts)
            self.lengths.append(len(document))
            self.texts.append(normalize(paper["title"] + " " + paper["abstract"]))
            for word, count in counts.items():
                self.postings.setdefault(word, []).append((index, count))
        self.df = {word: len(rows) for word, rows in self.postings.items()}
        self.avg_len = sum(self.lengths) / max(len(self.lengths), 1)
        # Encoding nine thousand abstracts takes minutes; a looked-up plant's papers are appended instead.
        if self.embeddings is not None and papers:
            self.embeddings = np.concatenate([self.embeddings, self.encoder.encode([p["title"] + " " + p["abstract"] for p in papers])])

    def bm25(self, query):
        scores = np.zeros(len(self.papers))
        total = len(self.docs)
        for word in set(tokens(query)):
            rows = self.postings.get(word)
            if not rows:
                continue
            df = len(rows)
            idf = math.log(1 + (total - df + .5) / (df + .5))
            for i, tf in rows:
                scores[i] += idf * tf * 2.5 / (tf + 1.5 * (.25 + .75 * self.lengths[i] / max(self.avg_len, 1)))
        return scores

    def documents_naming(self, taxon):
        """Papers whose text carries a scientific name or a usable common name of this taxon."""
        key = (taxon["id"], len(self.papers))
        if key not in self.naming_cache:
            self.naming_cache[key] = self.find_naming(taxon)
        return self.naming_cache[key]

    def find_naming(self, taxon):
        scientific = [taxon["name"]] + [a["name"] for a in taxon["aliases"] if a["kind"] in ("SYNONYM", "INPUT_SYNONYM_MATCH")]
        common = [a["name"] for a in taxon["aliases"] if a["kind"] in ("VERNACULAR", "HISTORICAL_LEXICON") and a.get('lang', 'en') == 'en' and len(a["name"]) >= 5 and normalize(a["name"]) not in SENSE_REQUIRED]
        found = {}
        common += taxon.get('drug_names', [])
        for names, label in ((scientific, "SCIENTIFIC_NAME"), (common, "COMMON_NAME_ONLY_IDENTITY_UNCERTAIN")):
            for name in names:
                key = normalize(name)
                parts = tokens(name)
                if not parts:
                    continue
                pattern = re.compile(r"\b" + re.escape(key) + r"\b")
                for i, _ in self.postings.get(min(parts, key=lambda w: self.df.get(w, 0)), ()):
                    if i not in found and pattern.search(self.texts[i]):
                        found[i] = label
        return found

    def matching(self, taxon, condition, *, scores=None, method="DIRECT_LOOKUP", genus=False):
        """Every paper naming the plant and the topic, unranked; the digest reads all of them.

        With genus=True, papers naming only the genus are included as identity-uncertain rows.
        """
        pattern = topic_pattern(tuple(research_terms(condition)))
        results = []
        named = dict(self.documents_naming(taxon))
        if genus:
            for i, _ in self.postings.get(normalize(taxon["name"].split()[0]), ()):
                named.setdefault(i, "COMMON_NAME_ONLY_IDENTITY_UNCERTAIN")
        for i, label in named.items():
            if not pattern.search(self.texts[i]):
                continue
            paper = self.papers[i]
            results.append({"paper": paper, "retrieval_score": round(float(scores[i]), 5) if scores is not None else 0, "retrieval_method": method, "taxon_match": label, "condition_match": True, "branch_taxon_id": taxon["id"], "design_rank": design_rank(paper), "topic_in_title": bool(pattern.search(normalize(paper["title"])))})
        return results

    def search(self, taxon, condition, *, method="hybrid", limit=6):
        terms = research_terms(condition)
        query = taxon["name"] + " " + " ".join(terms)
        lexical = self.bm25(query)
        semantic = None
        if method in ("embedding", "hybrid", "rerank"):
            if not self.encoder.available:
                if method == "embedding":
                    raise RuntimeError("Embedding retrieval requested but local model is absent")
                effective = "BM25_ONLY_ENCODER_NOT_INSTALLED"
            else:
                if self.embeddings is None:
                    self.embeddings = self.encoder.encode([p["title"] + " " + p["abstract"] for p in self.papers])
                semantic = self.embeddings @ self.encoder.encode([query])[0]
                effective = method.upper()
        else:
            effective = "BM25"
        if method == "embedding" and semantic is not None:
            scores = semantic
        elif semantic is not None:
            scores = np.zeros(len(self.papers))
            for component in [lexical, semantic]:
                for rank, i in enumerate(np.argsort(-component)):
                    scores[i] += 1 / (60 + rank + 1)
        else:
            scores = lexical
        results = self.matching(taxon, condition, scores=scores, method=effective)
        # Human evidence first: a reader of one source statement should not meet cell assays
        # before the trial that tests the plant. Ties keep the retrieval order.
        results.sort(key=lambda r: (r["taxon_match"] != "SCIENTIFIC_NAME", not r["topic_in_title"], r["design_rank"], -r["retrieval_score"]))
        results = results[:40 if method == 'rerank' else limit]
        if method == 'rerank' and results:
            reranked = self.reranker.score(query, [r['paper']['title'] + ' ' + r['paper']['abstract'] for r in results])
            for row, score in zip(results, reranked):
                row['retrieval_score'] = round(float(score), 5)
                row['retrieval_method'] = 'RERANK_CROSS_ENCODER_AFTER_IDENTITY_CONDITION_FILTER'
            results.sort(key=lambda r: (r["design_rank"], -r['retrieval_score']))
            results = results[:limit]
        return results

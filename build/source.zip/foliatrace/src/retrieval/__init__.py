"""Lexical, local neural and hybrid branch-specific retrieval."""

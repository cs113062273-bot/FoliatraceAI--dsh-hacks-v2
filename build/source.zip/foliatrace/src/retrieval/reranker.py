"""Pinned query-document cross-encoder. Scores are relevance logits, not evidence."""
import threading
import numpy as np
from src.common import ROOT, read_json, digest


class LocalReranker:
    def __init__(self, model_dir=None):
        self.path = model_dir or ROOT / 'models/reranker'
        self.available = all((self.path / f).exists() for f in ('model.onnx', 'tokenizer.json'))
        self.session = None
        self.lock = threading.RLock()

    def score(self, query, documents):
        if not self.available:
            raise RuntimeError('Install the pinned local reranker with scripts/setup_reranker.py; no silent ranking fallback')
        if not documents:
            return np.empty(0)
        with self.lock:
            if self.session is None:
                import onnxruntime as ort
                from tokenizers import Tokenizer
                manifest = read_json(ROOT / 'data/reranker.lock.json')
                for artifact in manifest['files']:
                    if digest((self.path / artifact['local']).read_bytes()) != artifact['sha256']:
                        raise ValueError('Reranker artifact differs from pinned checksum')
                options = ort.SessionOptions()
                options.intra_op_num_threads = 4
                self.session = ort.InferenceSession(str(self.path / 'model.onnx'), sess_options=options, providers=['CPUExecutionProvider'])
                self.tokenizer = Tokenizer.from_file(str(self.path / 'tokenizer.json'))
                self.tokenizer.enable_truncation(max_length=384, strategy='longest_first')
                self.tokenizer.enable_padding()
            values = []
            for start in range(0, len(documents), 8):
                batch = self.tokenizer.encode_batch([(query, text) for text in documents[start:start+8]])
                feed = {'input_ids': np.array([b.ids for b in batch], dtype=np.int64), 'attention_mask': np.array([b.attention_mask for b in batch], dtype=np.int64), 'token_type_ids': np.array([b.type_ids for b in batch], dtype=np.int64)}
                logits = self.session.run(None, {f.name: feed[f.name] for f in self.session.get_inputs()})[0]
                values.extend(logits.reshape(-1).tolist())
            scores = np.asarray(values)
            if scores.shape != (len(documents),) or not np.isfinite(scores).all():
                raise ValueError('Invalid query-document ranking output')
            return scores

"""Local semantic search over source-attested use records, not answer generation."""
import re
import tempfile
import numpy as np
from src.retrieval.index import LocalEncoder, tokens
from collections import Counter
from src.common import ROOT, digest
from src.retrieval.reranker import LocalReranker


class TextIndex:
    """Shared ranking implementation used by the app and external retrieval evaluation."""
    def __init__(self, texts, *, cache_dir=None):
        self.texts = texts
        self.encoder = LocalEncoder()
        self.reranker = LocalReranker()
        self.embeddings = None
        self.cache_dir = cache_dir or ROOT / '.cache/knowledge-index'
        self.cache_key = digest('text-index-v1-384-rerank-40' + '\n'.join(self.texts))
        self.documents = [Counter(tokens(t)) for t in self.texts]
        self.df = Counter(word for doc in self.documents for word in doc)
        self.avg_length = sum(sum(d.values()) for d in self.documents) / max(len(self.documents), 1)

    def lexical(self, query):
        scores = np.zeros(len(self.texts))
        for term in set(tokens(query)):
            df = self.df[term]
            idf = np.log(1 + (len(self.texts) - df + .5) / (df + .5))
            for i, doc in enumerate(self.documents):
                tf = doc[term]
                if tf:
                    scores[i] += idf * tf * 2.2 / (tf + 1.2 * (.25 + .75 * sum(doc.values()) / max(self.avg_length, 1)))
        return scores

    def rank(self, query, *, method='bm25', limit=20, allowed=None):
        if method not in ('bm25', 'embedding', 'hybrid', 'rerank'):
            raise ValueError('Unknown knowledge search method')
        if not query.strip() or allowed == set():
            return []
        lexical = self.lexical(query)
        if method == 'bm25':
            scores = lexical
        else:
            if not self.encoder.available:
                raise RuntimeError('Install the pinned local encoder with scripts/setup_model.py; semantic search has no silent keyword fallback')
            if self.embeddings is None:
                self.cache_dir.mkdir(parents=True, exist_ok=True)
                path = self.cache_dir / (self.cache_key + '.npy')
                if path.exists():
                    values = np.load(path, allow_pickle=False)
                    if values.shape != (len(self.texts), 384) or not np.isfinite(values).all():
                        raise ValueError('Invalid local knowledge embeddings; rebuild this cache')
                    self.embeddings = values
                else:
                    self.embeddings = self.encoder.encode(self.texts)
                    with tempfile.NamedTemporaryFile(dir=self.cache_dir, suffix='.npy', delete=False) as temp:
                        temporary = type(path)(temp.name)
                        np.save(temp, self.embeddings, allow_pickle=False)
                    try:
                        temporary.replace(path)
                    finally:
                        temporary.unlink(missing_ok=True)
            semantic = self.embeddings @ self.encoder.encode([query])[0]
            if method == 'embedding':
                scores = semantic
            else:
                scores = np.zeros(len(self.texts))
                for component in (lexical, semantic):
                    for rank, i in enumerate(np.argsort(-component, kind='stable')):
                        if component is lexical and component[i] <= 0:
                            continue
                        scores[i] += 1 / (60 + rank + 1)
        order = np.argsort(-scores, kind='stable')
        if allowed is not None:
            order = np.asarray([i for i in order if int(i) in allowed], dtype=int)
        if method == 'rerank':
            pool = order[:max(40, limit)]
            reranked = self.reranker.score(query, [self.texts[int(i)] for i in pool])
            return [(int(pool[i]), float(reranked[i])) for i in np.argsort(-reranked, kind='stable')[:limit]]
        return [(int(i), float(scores[i])) for i in order[:limit] if method != 'bm25' or scores[i] > 0]


class KnowledgeIndex(TextIndex):
    def __init__(self, corpus, *, cache_dir=None):
        self.rows = corpus['records']
        texts = [' '.join([r['source_title'], r['statement']['text'], ' '.join(n['text'] for n in r['names'])]) for r in self.rows]
        super().__init__(texts, cache_dir=cache_dir)

    def search(self, query, *, method='bm25', limit=20, collection=None, condition=None, role=None):
        allowed = None
        if collection or condition or role:
            allowed = {i for i, r in enumerate(self.rows) if (not collection or r['collection'] == collection) and (not condition or any(c['id'] == condition for c in r['conditions'])) and (not role or r.get('statement_role') == role)}
        return [{'record': self.rows[i], 'score': round(score, 6), 'score_meaning': 'RETRIEVAL_RANKING_NOT_PROBABILITY', 'method': method} for i, score in self.rank(query, method=method, limit=limit, allowed=allowed)]

from __future__ import annotations

import csv
import io
import json
import re
from threading import Lock
from functools import lru_cache
from collections import Counter
from typing import Literal
from urllib.parse import urlencode
from urllib.parse import quote

from fastapi import FastAPI, HTTPException, Query, UploadFile, File
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field
from starlette.middleware.trustedhost import TrustedHostMiddleware

from src import __version__
from src.common import DATA, ROOT, read_json, write_json, now
from src.nlp.corpus import mine_corpus
from src.pipeline import Pipeline
from src.ingestion.client import ScientificClient
from src.ingestion.pubmed import fetch_records
from src.api.contracts import AnalysisRecord
from src.evidence.classify import conflict_groups
from src.evidence.comparability import not_assessed, summarize
from src.evidence.counterfactual import counterfactuals
from src.evidence.brief import research_brief, brief_markdown
from src.evidence.readings import active_reading_sets
from src.evidence.chemistry import assay_leads
from src.evidence.outcome_model import OutcomeModel
from src.evidence.handoff import HandoffRequest, HandoffPacket, HandoffStore, build_handoff, canonical, handoff_markdown
from src.evidence.question_review import ResearchQuestion, ReadingDecision, QuestionStore, run_question, validate_packet, review_markdown
from src.evidence.question_review import canonical as question_canonical
from src.evidence.consultation import ConsultationInput, ConsultationStore, prepare_consultation, validate_consultation, consultation_markdown
from src.evidence.consultation_summary import summary_markdown, summary_html
from src.evidence.care_workspace import ClarificationAnswer, ShareSelection, add_clarification, review_context, study_bridge, share_preview
from src.evidence.product_labels import LabelSnapshot, search_labels, read_label, label_wording, ingredient_source, compare_labels, summarize as summarize_label, ingredients as label_ingredients
from pydantic import ValidationError
import hashlib
from src.retrieval.knowledge import KnowledgeIndex
from src.nlp.extract import normalize

app = FastAPI(title="FoliaTrace consultation and evidence API", version=__version__, description="Prepare herbal-product information and source-linked professional evidence reading for a pharmacist conversation.")
app.add_middleware(TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "testserver"])
_corpus_lock = Lock()


@lru_cache(maxsize=1)
def pipeline():
    return Pipeline()


@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    if request.url.path.startswith("/check"):
        # Browser checker: on-device WASM (OCR, reranker), its own workers, blob downloads, and NIH label search only.
        response.headers.setdefault("Content-Security-Policy", CHECKER_CSP + "; frame-ancestors 'none'")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
    return response


CHECKER_CSP = ("default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; worker-src 'self' blob:; "
               "connect-src 'self' blob: data: https://api.ods.od.nih.gov; img-src 'self' data: blob:; style-src 'self'; "
               "object-src 'none'; base-uri 'none'; form-action 'none'")


class AnalysisRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    text: str | None = Field(None, min_length=1, max_length=50000)
    passage_id: str | None = Field(None, max_length=100)
    source_title: str = Field("Researcher-provided text", max_length=200)
    retrieval: Literal["bm25", "embedding", "hybrid", "rerank"] = "bm25"
    name_to_inspect: str | None = Field(None, min_length=2, max_length=120)


@app.get("/api/health")
def health():
    p = pipeline()
    abstracts = sum(bool(paper.get('abstract')) for paper in p.papers)
    return {"status": "ok", "version": __version__, "snapshot": p.snapshot, "taxa": len(p.taxa), "papers": len(p.papers), "abstracts_available": abstracts, "literature_coverage": "FULL_LOCAL_ABSTRACT_CACHE" if abstracts == len(p.papers) else "PARTIAL_ABSTRACT_COVERAGE", "offline": p.client.offline, "passages": len(p.passages) + len(p.extra_passages), "collections": 1 + bool(p.extra_passages), "chembl_assays": len(p.mechanism_records), "outcome_model_trained": (ROOT / '.cache/outcome_model.joblib').exists(), "encoder_installed": p.index.encoder.available, "reranker_installed": p.index.reranker.available, "study_model_trained": p.study_model.model is not None, "mode": "LOCAL_LIVE_PIPELINE", "network_required_for_cached_analysis": False}


@app.get("/api/passages")
def passages():
    withdrawn=pipeline().withdrawn()
    return [{k: p.get(k) for k in ("id", "title", "text", "source_id", "licence", "context", "url", "date", "community", "collection")} for p in pipeline().passages + pipeline().extra_passages if p['id'] not in withdrawn and p['source_id'] not in withdrawn]


@app.get("/api/search")
def search(q: str = Query(min_length=2, max_length=150), kind: str | None = None):
    return {"results": pipeline().search(q, kind)}


@app.post("/api/analyses", response_model=AnalysisRecord)
def analyze(request: AnalysisRequest):
    p = pipeline()
    source = None
    if request.passage_id:
        source = next((row for row in p.passages + p.extra_passages if row["id"] == request.passage_id), None)
        if not source:
            raise HTTPException(404, "Historical passage not found")
        text = source["title"] + "\n\n" + source["text"]
        source = {k: v for k, v in source.items() if k != "text"}
    else:
        text = request.text or ""
        source = {"id": "user-provided", "title": request.source_title, "url": None, "licence": "USER_RIGHTS_UNVERIFIED", "context": "Researcher input, not independently verified historical provenance", "community": None}
    if not text.strip():
        raise HTTPException(422, "Supply a passage_id or nonempty text")
    try:
        result = p.analyze(text, source=source, method=request.retrieval, name_to_inspect=request.name_to_inspect)
        result = {**result, "researcher_reviews": p.store.reviews(result["run_id"], result)}
        result["research_brief"] = research_brief(result)
        return result
    except (ValueError, RuntimeError) as error:
        raise HTTPException(422, str(error)) from error


@app.post("/api/uploads/text")
async def upload_text(file: UploadFile = File()):
    body = await file.read(200001)
    if len(body) > 200000:
        raise HTTPException(413, "Text upload exceeds 200KB")
    if not (file.filename or "").lower().endswith(".txt"):
        raise HTTPException(415, "Only UTF-8 .txt files are accepted; no PDF/OCR is claimed")
    try:
        text = body.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise HTTPException(422, "Expected UTF-8 text") from error
    if len(text) > 50000:
        raise HTTPException(413, "Passage exceeds 50,000 characters")
    return analyze(AnalysisRequest(text=text, source_title=(file.filename or "Uploaded text")[:200]))


def upgrade_legacy(result):
    """Analyses stored before comparability screening and counterfactuals existed are marked
    as not screened, never silently re-scored with today's rules."""
    for e in result['evidence']:
        e.setdefault('comparability', not_assessed())
        if 'screening' not in e['comparability']:
            # Summary fields added later are derived from the stored checks, not recomputed checks.
            e['comparability'] = summarize(e['comparability']['checks'])
    if 'identity_counterfactuals' not in result:
        result['identity_counterfactuals'] = counterfactuals(result)


def get_run(run_id):
    if not re.fullmatch(r"[0-9a-f]{24}", run_id):
        raise HTTPException(404, "Analysis not found")
    result = pipeline().store.get(run_id)
    if not result:
        raise HTTPException(404, "Analysis not found")
    upgrade_legacy(result)
    p=pipeline();withdrawn=p.withdrawn()
    for key, references in result.get('historical_identity_references', {}).items():
        result['historical_identity_references'][key] = [reference for reference in references if not {reference['source']['id'], reference['source'].get('source_id')} & withdrawn]
        for reference in result['historical_identity_references'][key]:
            for excerpt in reference['excerpts']:
                excerpt['names'] = [name for name in excerpt['names'] if name['candidate_id'] not in withdrawn]
            reference['excerpts'] = [excerpt for excerpt in reference['excerpts'] if excerpt['names']]
    if result['source']['id'] in withdrawn or result['source'].get('source_id') in withdrawn:
        raise HTTPException(410,'Historical source withdrawn from active views')
    removed_taxa={c['taxon_id'] for r in result['resolutions'] for c in r['candidates'] if c['taxon_id'] in withdrawn}
    if removed_taxa or any(e['paper']['id'] in withdrawn for e in result['evidence']) or 'chembl' in withdrawn or any(a['id'] in withdrawn or a['molecule_chembl_id'] in withdrawn or a['target']['target_chembl_id'] in withdrawn for a in result.get('compound_assay_leads', [])):
        for resolution in result['resolutions']:
            resolution['candidates']=[c for c in resolution['candidates'] if c['taxon_id'] not in withdrawn]
            if not resolution['candidates']:resolution['status']='UNRESOLVED'
        result['evidence']=[e for e in result['evidence'] if e['paper']['id'] not in withdrawn and e['taxon_id'] not in withdrawn]
        result['compound_assay_leads']=assay_leads(result['evidence'], p.mechanism_records, withdrawn)
        result['graph']=p.make_graph(result)
        result['conflicts']=conflict_groups(result['evidence'])
        result['identity_counterfactuals']=counterfactuals(result)
    result['study_reading_sets'] = active_reading_sets(result.get('study_reading_sets', []), [c['taxon_id'] for r in result['resolutions'] for c in r['candidates']], [c['id'] for c in result['conditions']], withdrawn)
    result['researcher_reviews']=p.store.reviews(run_id, result)
    result['research_brief']=research_brief(result)
    return result


class ReviewRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target_kind: Literal["identity", "evidence"]
    target_id: str = Field(min_length=1, max_length=200)
    decision: Literal["ACCEPT", "REJECT", "INSUFFICIENT_INFORMATION"]
    reason: str = Field(min_length=3, max_length=1000)
    reviewer: str = Field("Local researcher", min_length=1, max_length=80)


def review_targets(result):
    identities = {f"{c['key']}::{b['taxon_id']}" for c in result.get("identity_counterfactuals", []) for b in c["branches"]}
    return {"identity": identities, "evidence": {e["id"] for e in result["evidence"]}}


@app.get("/api/analyses/{run_id}", response_model=AnalysisRecord)
def analysis(run_id: str):
    return get_run(run_id)


@app.get("/api/analyses/{run_id}/reviews")
def list_reviews(run_id: str):
    return {"reviews": get_run(run_id)["researcher_reviews"]}


@app.put("/api/analyses/{run_id}/reviews")
def save_review(run_id: str, review: ReviewRequest):
    result = get_run(run_id)
    if review.target_id not in review_targets(result)[review.target_kind]:
        raise HTTPException(404, "Review target is not part of this analysis")
    pipeline().store.put_review(run_id, review.model_dump())
    active = get_run(run_id)
    return {"reviews": active["researcher_reviews"], "research_brief": active["research_brief"]}


@app.delete("/api/analyses/{run_id}/reviews/{target_kind}/{target_id:path}")
def delete_review(run_id: str, target_kind: Literal["identity", "evidence"], target_id: str):
    get_run(run_id)
    pipeline().store.delete_review(run_id, target_kind, target_id)
    active = get_run(run_id)
    return {"reviews": active["researcher_reviews"], "research_brief": active["research_brief"]}


@app.get("/api/graph/{run_id}")
def graph(run_id: str, focus: str | None = None, predicate: str | None = None, source_id: str | None = None, limit: int = Query(100, ge=1, le=300)):
    result=get_run(run_id)
    if pipeline().withdrawn():
        edges=[e for e in result['graph']['edges'] if (not focus or e['subject']==focus or e['object']==focus) and (not predicate or e['predicate']==predicate) and (not source_id or e['provenance']['source_id']==source_id)][:limit]
        ids={e[k] for e in edges for k in ('subject','object')}
        return {'edges':edges,'nodes':[n for n in result['graph']['nodes'] if n['id'] in ids]}
    return pipeline().store.neighborhood(run_id, focus, predicate, source_id, limit)


@app.get("/api/sources/{source_id}")
def source(source_id: str):
    p = pipeline()
    if source_id in p.withdrawn():raise HTTPException(410,'Source withdrawn from active views')
    if source_id in p.papermap:
        return p.papermap[source_id]
    if source_id in p.taxmap:
        return p.taxmap[source_id]
    record = next((x for x in p.passages + p.extra_passages if x["id"] == source_id), None)
    if record:
        if record.get('source_id') in p.withdrawn():raise HTTPException(410,'Source withdrawn from active views')
        return record
    raise HTTPException(404, "Source not in approved local snapshot")


@app.get("/api/benchmarks")
def benchmark_results():
    path = ROOT / "reports" / "benchmark" / "metrics.json"
    result = read_json(path) if path.exists() else {"status": "NOT_RUN"}
    learned = ROOT / 'reports/outcome_model.json'
    if learned.exists():
        result['outcome_model'] = read_json(learned)
    for name in ('retrieval_external', 'use_role_audit', 'product_coverage', 'product_evaluation', 'known_answers', 'unseen_books', 'independent_records', 'expert_review', 'regulator_agreement', 'folklore_blind', 'lead_foresight', 'free_text_blind', 'free_text_blind_round9', 'free_text_blind_round10'):
        path = ROOT / 'reports' / (name + '.json')
        if path.exists():
            result[name] = read_json(path)
    audit = ROOT / 'benchmark/gold/book_statement_audit.json'
    if audit.exists():
        result['book_statement_audit'] = {k: v for k, v in read_json(audit).items() if k != 'items'}
    return result


@app.get('/api/research/chemistry')
def chemical_snapshot():
    p = pipeline()
    path = p.data_dir / 'mechanisms.json'
    if not path.exists():
        return {'records': [], 'mappings': [], 'failures': [], 'publications': {}, 'status': 'NOT_INSTALLED'}
    result = read_json(path)
    withdrawn = p.withdrawn()
    if 'chembl' in withdrawn:
        raise HTTPException(410, 'ChEMBL records withdrawn from active views')
    result['records'] = [r for r in result['records'] if not {r['id'], r['molecule_chembl_id'], r['target']['target_chembl_id']} & withdrawn]
    result['publications'] = {}
    for c in p.compounds:
        publications = []
        for paper in p.papers:
            if paper['id'] in withdrawn:
                continue
            if match := re.search(r'\b' + re.escape(c['name']) + r'\b', paper['abstract'], re.I):
                publications.append({'paper_id': paper['id'], 'title': paper['title'], 'url': paper['url'], 'licence': paper['licence'], 'supporting_text': paper['abstract'][max(0, match.start()-100):min(len(paper['abstract']), match.end()+140)], 'scope': 'Text co-mention only. No verified plant-constituent or therapeutic relation.'})
        result['publications'][str(c['cid'])] = publications
    return result


@app.get('/api/research/corpus')
def historical_corpus(format: Literal['json', 'csv'] = 'json'):
    p = pipeline()
    path = ROOT / 'reports/corpus_mining.json'
    # Local extraction is bounded and offline. Rebuild under one lock, publish
    # atomically, and keep statement-anchor migrations from the previous build.
    with _corpus_lock:
        result = read_json(path) if path.exists() else None
        if result is None or result.get('snapshot_sha256') != p.snapshot or result.get('code_fingerprint') != p.code_fingerprint:
            result = mine_corpus(p, previous=result)
            write_json(path, result)
    result['build_status'] = 'CURRENT'
    withdrawn = p.withdrawn()
    hidden = {s['id'] for s in p.passages + p.extra_passages if s['source_id'] in withdrawn}
    result['records'] = [r for r in result['records'] if r['source_id'] not in withdrawn | hidden]
    result['collections'] = dict(Counter(s.get('collection') or 'Culpeper 1850' for s in p.passages + p.extra_passages if s['id'] not in withdrawn | hidden))
    result['conditions'] = dict(Counter(c['id'] for r in result['records'] for c in r['conditions']))
    result['roles'] = dict(Counter(r.get('statement_role', 'LEGACY_ROLE_NOT_SCREENED') for r in result['records']))
    if format == 'csv':
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['source_id', 'collection', 'edition', 'plant_wording', 'historical_statement', 'span_start', 'span_end', 'condition_retrieval_aids', 'parts', 'preparations', 'relation_scope', 'negation_flag', 'source_url', 'source_licence', 'human_reviewed', 'statement_role'])
        for r in result['records']:
            values = [r['source_id'], r['collection'], r['date'], '; '.join(n['text'] for n in r['names']), r['statement']['text'], r['statement']['start'], r['statement']['end'], '; '.join(c['id'] for c in r['conditions']), '; '.join(p['text'] for p in r['parts']), '; '.join(p['text'] for p in r['preparations']), r['scope'], r['negated'], r['url'], r['licence'], False, r.get('statement_role', 'LEGACY_ROLE_NOT_SCREENED')]
            writer.writerow(["'" + str(v) if str(v).lstrip().startswith(('=', '+', '-', '@')) else str(v) for v in values])
        return Response(output.getvalue(), media_type='text/csv', headers={'Content-Disposition': 'attachment; filename="foliatrace-traditional-uses.csv"'})
    return result


@app.get('/api/research/evidence-map')
def evidence_map(format: Literal['json', 'csv'] = 'json'):
    path = ROOT / 'reports/evidence_map.json'
    if not path.exists():
        raise HTTPException(503, 'Build the research map with scripts/build_evidence_map.py')
    result = read_json(path)
    p = pipeline()
    result['build_status'] = 'CURRENT' if result.get('snapshot_sha256') == p.snapshot and result.get('code_fingerprint') == p.code_fingerprint else 'PREVIOUS_BUILD'
    if result['build_status'] == 'PREVIOUS_BUILD':
        result['build_warning'] = 'This map was generated by an earlier build. Its study summaries may differ from a new analysis. Rebuild with scripts/build_evidence_map.py.'
    if format == 'csv':
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['plant', 'topic', 'historical_statements', 'books', 'modern_research_state', 'human_studies', 'syntheses', 'laboratory_studies', 'favourable', 'no_benefit', 'independent_records', 'independent_places', 'recorded_poisonous', 'lead_score', 'key_study', 'key_study_url', 'eligible_source_statements', 'uncertain_source_links', 'priority_components', 'source_statement_ids', 'isolated_plant_studies', 'summary_basis', 'summary_source_ids'])
        for r in result['rows']:
            best = r.get('best_study') or {}
            values = [r['taxon'], r['topic'], r['historical_statements'], '; '.join(r['books']), r['state'], r['human_studies'], r['syntheses'], r['preclinical_studies'], r['favourable'], r['no_benefit'], (r.get('independent_use') or {}).get('records', 0), (r.get('independent_use') or {}).get('places', 0), bool(r.get('recorded_poisonous')), r['lead_score'], best.get('title', ''), best.get('url', ''), r.get('direct_statements', ''), r.get('uncertain_statements', ''), json.dumps(r.get('priority_components', {})), '; '.join(s['source_id'] + ':' + s['claim_id'] for s in r.get('statements', []))]
            values.extend([r.get('isolated_plant_studies', ''), (r.get('assessment_basis') or {}).get('kind', ''), '; '.join((r.get('assessment_basis') or {}).get('paper_ids', []))])
            writer.writerow(["'" + str(v) if str(v).lstrip().startswith(('=', '+', '-', '@')) else str(v) for v in values])
        return Response(output.getvalue(), media_type='text/csv', headers={'Content-Disposition': 'attachment; filename="foliatrace-research-map.csv"'})
    foresight = ROOT / 'reports/lead_foresight.json'
    if foresight.exists():
        # The time-split check of this ranking travels with it, so the order is read with its record.
        result['foresight'] = read_json(foresight)['cutoffs'].get('2010')
    return result


@lru_cache(maxsize=1)
def outcome_model():
    metadata = ROOT / 'reports/outcome_model.json'
    return OutcomeModel.load(ROOT / '.cache/outcome_model.joblib', read_json(metadata) if metadata.exists() else {})


@lru_cache(maxsize=2)
def knowledge_index(snapshot, code_fingerprint, withdrawal_ids):
    return KnowledgeIndex(historical_corpus())


@app.get('/api/research/knowledge-search')
def knowledge_search(q: str = Query(min_length=2, max_length=200), method: Literal['bm25', 'embedding', 'hybrid', 'rerank'] = 'bm25', limit: int = Query(20, ge=1, le=50), collection: str | None = Query(None, max_length=80), condition: str | None = Query(None, max_length=80), role: str | None = Query(None, max_length=80)):
    p = pipeline()
    index = knowledge_index(p.snapshot, p.code_fingerprint, tuple(sorted(p.withdrawn())))
    try:
        return {'query': q, 'method': method, 'results': index.search(q, method=method, limit=limit, collection=collection, condition=condition, role=role), 'scope': 'Ranked historical statements, not answers or evidence of therapeutic benefit. Collection, condition and role filters apply before candidate selection and ranking. Similar wording does not establish medical equivalence.'}
    except (ValueError, RuntimeError) as error:
        raise HTTPException(422, str(error)) from error


class OutcomeRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    run_id: str = Field(pattern=r'^[a-f0-9]{24}$')
    paper_id: str = Field(min_length=1, max_length=60)
    evidence: str = Field(min_length=15, max_length=12000)
    outcome: str = Field(min_length=2, max_length=500)
    intervention: str = Field(min_length=2, max_length=500)
    comparator: str = Field(min_length=2, max_length=500)


class ComparisonRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    passage_ids: list[str] = Field(min_length=2, max_length=4)


@app.post('/api/research/compare-sources')
def compare_sources(request: ComparisonRequest):
    if len(set(request.passage_ids)) != len(request.passage_ids):
        raise HTTPException(422, 'Choose different historical passages')
    results = [analyze(AnalysisRequest(passage_id=id, retrieval='bm25')) for id in request.passage_ids]
    taxa = {}
    for result in results:
        for group in result['identity_counterfactuals']:
            for b in group['branches']:
                taxa.setdefault(b['taxon_id'], {'id': b['taxon_id'], 'name': b['name'], 'sources': []})['sources'].append({'source_id': result['source']['id'], 'historical_name': group['label'], 'status': group['status']})
    return {'scope': 'Comparison of recorded uses and candidate branches. Shared candidates or condition terms are research links, not proof of a shared historical identity or effective treatment.', 'sources': [{'source': r['source'], 'run_id': r['run_id'], 'claims': r['historical_claims'], 'names': r['identity_counterfactuals'], 'evidence_records': len(r['evidence']), 'abstracts': len({e['paper']['id'] for e in r['evidence']}), 'conditions': r['conditions']} for r in results], 'candidate_links': list(taxa.values()), 'shared_candidate_ids': [id for id, t in taxa.items() if len({s['source_id'] for s in t['sources']}) > 1], 'snapshot_sha256': results[0]['snapshot_sha256'], 'code_fingerprint': results[0]['code_fingerprint']}


@app.post('/api/research/outcome-direction')
def predict_outcome(request: OutcomeRequest):
    result = get_run(request.run_id)
    paper = next((e['paper'] for e in result['evidence'] if e['paper']['id'] == request.paper_id), None)
    if not paper:
        raise HTTPException(404, 'Publication is not part of this active analysis')
    if request.evidence not in paper['abstract']:
        raise HTTPException(422, 'Select an exact passage from this publication abstract')
    # A valid quotation does not establish an arbitrary user-entered comparison.
    # Lexical context is a conservative gate, not semantic PICO verification.
    words = set(normalize(paper['abstract']).split())
    stop = {'the', 'and', 'with', 'versus', 'compared', 'to', 'of', 'in', 'a', 'an', 'for', 'group'}
    checks = {}
    for field in ('outcome', 'intervention', 'comparator'):
        terms = {w for w in normalize(getattr(request, field)).split() if len(w) > 2 and w not in stop}
        checks[field] = 'LEXICAL_CONTEXT_PRESENT_NOT_SEMANTICALLY_VERIFIED' if terms and terms & words else 'NOT_ESTABLISHED_IN_ABSTRACT'
    if any(v == 'NOT_ESTABLISHED_IN_ABSTRACT' for v in checks.values()):
        prediction = {'status': 'QUESTION_CONTEXT_NOT_ESTABLISHED', 'direction': None, 'scope': 'The supplied intervention, comparator or outcome could not be linked lexically to this abstract. Check the actual study comparison or consult the full text; no direction is proposed.'}
    else:
        prediction = outcome_model().predict(request.evidence, request.outcome, request.intervention, request.comparator)
    prediction['question_context_checks'] = checks
    return {**prediction, 'paper_id': paper['id'], 'supporting_text': request.evidence, 'question': {k: getattr(request, k) for k in ('outcome', 'intervention', 'comparator')}, 'provenance': paper['provenance'], 'licence': paper['licence'], 'stored_as_scientific_fact': False}


@app.get("/api/taxonomy/live")
def taxonomy_live(name: str = Query(min_length=3, max_length=120)):
    try:
        result, provenance = ScientificClient().json("https://api.gbif.org/v1/species/match?" + urlencode({"name": name, "kingdom": "Plantae", "verbose": "true"}))
        return {"result": result, "provenance": provenance, "limitation": "Service match confidence is not historical identity probability; not automatically inserted into local graph."}
    except Exception as error:
        raise HTTPException(502, f"Public taxonomy service unavailable: {type(error).__name__}") from error


@app.get('/api/taxonomy/verify-scientific')
def verify_scientific(name: str = Query(min_length=3, max_length=120)):
    try:
        response, provenance = ScientificClient().json('https://verifier.globalnames.org/api/v1/verifications/' + quote(name, safe=''))
        names = response.get('names', []) if isinstance(response, dict) else response
        row = names[0] if names else {}
        candidates = ([row['bestResult']] if row.get('bestResult') else []) + row.get('bestResults', [])
        return {'query': name, 'match_type': row.get('matchType'), 'results': [{k: c.get(k) for k in ('dataSourceTitleShort', 'matchedName', 'currentCanonicalSimple', 'taxonomicStatus', 'recordId', 'outlink')} for c in candidates], 'provenance': provenance, 'scope': 'External scientific-name verification, not historical vernacular interpretation. No result is automatically attached to the passage or inserted into the local knowledge graph.'}
    except Exception as error:
        raise HTTPException(502, 'GNverifier unavailable: ' + type(error).__name__) from error


@app.get("/api/citations/{paper_id}/verify-live")
def verify_live(paper_id: str):
    p = pipeline()
    paper = p.papermap.get(paper_id)
    if not paper:
        raise HTTPException(404, "Citation not registered in snapshot")
    try:
        if paper_id.startswith('PMID'):
            row = next(iter(fetch_records(ScientificClient(), [paper['pmid']])), {})
            checks = {"pmid": row.get("pmid") == paper.get("pmid"), "title": row.get("title") == paper["title"], "doi": row.get("doi") == paper.get("doi"), "not_retracted": row.get("retracted") is False}
            return {"checks": checks, "metadata_match": all(checks.values()), "provenance": paper["provenance"], "entailment": "NOT_ESTABLISHED_BY_METADATA_LOOKUP"}
        result, provenance = ScientificClient().json("https://www.ebi.ac.uk/europepmc/webservices/rest/search?" + urlencode({"query": f"PMCID:{paper_id}", "format": "json", "resultType": "core", "pageSize": 1}))
        rows = result.get("resultList", {}).get("result", [])
        row = rows[0] if rows else {}
        checks = {"pmcid": row.get("pmcid") == paper_id, "title": row.get("title") == paper.get("original_title",paper["title"]), "doi": row.get("doi") == paper.get("doi"), "pmid": row.get("pmid") == paper.get("pmid")}
        return {"checks": checks, "metadata_match": all(checks.values()), "provenance": provenance, "entailment": "NOT_ESTABLISHED_BY_METADATA_LOOKUP"}
    except Exception as error:
        raise HTTPException(502, f"Citation service unavailable: {type(error).__name__}") from error


@app.get("/api/exports/{run_id}")
def export(run_id: str, format: Literal["json", "csv", "bibtex", "graph", "brief"] = "json"):
    result = get_run(run_id)
    if format == "brief":
        return Response(brief_markdown(result['research_brief']), media_type="text/markdown", headers={"Content-Disposition": f'attachment; filename="foliatrace-{run_id}-brief.md"'})
    if format in ("json", "graph"):
        value = result if format == "json" else {"graph": result["graph"], "source": result["source"], "researcher_reviews": result["researcher_reviews"], "limitations": result["limitations"]}
        return Response(json.dumps(value, ensure_ascii=False, indent=2), media_type="application/json", headers={"Content-Disposition": f'attachment; filename="foliatrace-{run_id}-{format}.json"'})
    unique = {e["paper"]["id"]: e["paper"] for e in result["evidence"]}
    if format == "bibtex":
        def escape(value):
            return str(value or "").replace("\\", " ").replace("{", "(").replace("}", ")")
        text = "\n\n".join("@article{" + p["id"] + ",\n" + ",\n".join(f"  {k} = {{{escape(v)}}}" for k, v in [("title", p["title"]), ("author", p["authors"]), ("year", p["year"]), ("doi", p.get("doi")), ("url", p["url"]), ("note", "License: " + p["licence"])]) + "\n}" for p in unique.values())
        return Response(text, media_type="text/plain", headers={"Content-Disposition": f'attachment; filename="foliatrace-{run_id}.bib"'})
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["taxon_id", "condition", "identity_qualifier", "identity_review", "paper_id", "title", "evidence_types", "relation", "reported_finding", "first_blocking_check", "comparability_screening", "supporting_text", "url", "licence", "evidence_review", "review_reason", "source_rights", "source_id", "source_title", "source_url", "source_date", "reviewer", "review_created_at", "review_origin_analysis", "review_retained", "identity_review_notes", "historical_statement_comparisons", "candidate_preparation_wording", "study_methods_sources", "author_reported_results", "automated_endpoint_statements", "candidate_result_scope"])
    def safe(value):
        value = str('' if value is None else value)
        return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value
    reviews = {(r["target_kind"], r["target_id"]): r for r in result["researcher_reviews"]}
    identity_reviews = {}
    identity_notes = {}
    for (kind, target), r in reviews.items():
        if kind == "identity":
            identity_reviews.setdefault(target.split("::")[-1], []).append(r["decision"] + " (" + target.split("::")[0] + ")")
            identity_notes.setdefault(target.split('::')[-1], []).append({k: r.get(k) for k in ('target_id', 'decision', 'reason', 'reviewer', 'created_at', 'origin_run_id', 'carried_forward')})
    for e in result["evidence"]:
        review = reviews.get(("evidence", e["id"]))
        values = [e['taxon_id'], e['condition_id'], e['identity_qualifier'],
                  '; '.join(identity_reviews.get(e['taxon_id'], [])) or 'UNREVIEWED',
                  e['paper']['id'], e['paper']['title'], ';'.join(e['study']['types']),
                  e['relation']['relation'], (e['relation'].get('reported_finding') or {}).get('direction'),
                  (e.get('comparability') or {}).get('first_blocking_check') or 'NONE',
                  (e.get('comparability') or {}).get('screening'), e['relation']['supporting_text'],
                  e['paper']['url'], e['paper']['licence'], review['decision'] if review else 'UNREVIEWED',
                  review['reason'] if review else '', result['source']['licence']]
        values += [result['source'].get(k) for k in ('id', 'title', 'url', 'date')]
        values += [(review or {}).get(k, '') for k in ('reviewer', 'created_at', 'origin_run_id', 'carried_forward')]
        values.append(json.dumps(identity_notes.get(e['taxon_id'], []), ensure_ascii=False))
        values.append(json.dumps(e.get('historical_contexts', []), ensure_ascii=False))
        values.append(json.dumps(e['study'].get('preparation_attribution'), ensure_ascii=False))
        values.append(json.dumps(e['paper'].get('methods_contexts', []), ensure_ascii=False))
        values.append(json.dumps(e['paper'].get('reported_results', []), ensure_ascii=False))
        values.append(json.dumps((e['relation'].get('reported_finding') or {}).get('statements', []), ensure_ascii=False))
        values.append(json.dumps({k:v for k,v in (e['relation'].get('reported_finding') or {}).items() if k in ('candidate_scope_note','unassigned_statements')}, ensure_ascii=False))
        writer.writerow([safe(value) for value in values])
    return Response(output.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="foliatrace-{run_id}.csv"'})


def handoff_store():
    return HandoffStore(pipeline().store.path)


def active_handoff(identifier):
    record = handoff_store().get(identifier)
    if not record:
        raise HTTPException(404, 'Evidence handoff not found')
    packet = record['packet']
    withdrawn = pipeline().withdrawn()
    source = packet['source']
    references = {source.get('id'), source.get('source_id')} | {s['paper']['id'] for s in packet['studies']} | {c['taxon_id'] for c in packet['candidates']}
    if references & withdrawn:
        raise HTTPException(410, 'A handoff source has been withdrawn; create a new reading from current sources')
    return record


@app.get('/api/handoffs')
def list_handoffs():
    rows = []
    for row in handoff_store().list():
        try:
            active_handoff(row['id'])
            rows.append(row)
        except HTTPException as error:
            if error.status_code != 410:
                raise
    return {'handoffs': rows, 'limit': 100}


@app.post('/api/analyses/{run_id}/handoffs', status_code=201)
def save_handoff(run_id: str, request: HandoffRequest):
    try:
        return handoff_store().put(build_handoff(get_run(run_id), request))
    except (ValueError, KeyError) as error:
        raise HTTPException(422, str(error)) from error


@app.post('/api/handoffs/import', status_code=201)
async def import_handoff(file: UploadFile = File()):
    body = await file.read(20_000_001)
    if len(body) > 20_000_000:
        raise HTTPException(413, 'Handoff exceeds 20 MB')
    try:
        envelope = json.loads(body.decode('utf-8-sig'))
        packet = HandoffPacket.model_validate(envelope['packet']).model_dump()
        if hashlib.sha256(canonical(packet)).hexdigest() != envelope['sha256']:
            raise ValueError('Handoff checksum mismatch; checksum is integrity checking, not authenticity')
        source = packet['source']
        ids = {source.get('id'), source.get('source_id')} | {s['paper']['id'] for s in packet['studies']} | {c['taxon_id'] for c in packet['candidates']}
        if ids & pipeline().withdrawn():
            raise ValueError('Handoff contains withdrawn sources')
    except (UnicodeDecodeError, ValueError, KeyError, TypeError, ValidationError) as error:
        raise HTTPException(422, 'Invalid handoff: '+str(error)) from error
    # Imported packets are separate immutable records, never model output or overwritten notes.
    return handoff_store().put(packet, origin='IMPORTED_UNVERIFIED_RECORD')


@app.get('/api/handoffs/{identifier}')
def read_handoff(identifier: str, format: Literal['json', 'markdown'] = 'json'):
    record = active_handoff(identifier)
    if format == 'markdown':
        prefix = ('Imported record; author and scientific claims are unverified.\n\n' if record['origin'] == 'IMPORTED_UNVERIFIED_RECORD' else '')
        return Response(prefix+handoff_markdown(record['packet']), media_type='text/markdown', headers={'Content-Disposition': f'attachment; filename="foliatrace-handoff-{record["id"]}.md"'})
    return record


def question_store():
    return QuestionStore(pipeline().store.path)


def active_question(identifier):
    record = question_store().get(identifier)
    if record is None:
        raise HTTPException(404, 'Research question not found')
    withdrawn = pipeline().withdrawn()
    if any(b['taxon_id'] in withdrawn or any(r['paper']['id'] in withdrawn for r in b['records']) for b in record['packet']['branches']):
        raise HTTPException(410, 'A source in this review was withdrawn; rerun the question with current sources')
    return record


@app.get('/api/research/question-options')
def question_options():
    from src.nlp.extract import CONDITIONS
    return {'topics': [{'id': key, 'label': key.replace('_', ' ')} for key in CONDITIONS],
            'code_fingerprint':pipeline().code_fingerprint,
            'coverage': 'Question-first local search; optional bounded Europe PMC lookup uses public plant names and endpoint phrases only. Specific endpoint wording is a reading check, not diagnostic equivalence.'}


@app.post('/api/research/public-search-plan')
def public_search_plan(protocol:ResearchQuestion):
    from src.evidence.question_search import search_plan
    p=pipeline();resolution=p.resolver.resolve(protocol.plant_name)
    candidates=resolution['candidates'];known={c['taxon_id'] for c in candidates}
    if not set(protocol.candidate_ids)<=known:raise HTTPException(422,'Selected identity is not a candidate for this wording')
    taxa=[p.taxmap[c['taxon_id']] for c in candidates if (not protocol.candidate_ids or c['taxon_id'] in protocol.candidate_ids) and c['taxon_id'] not in p.withdrawn()]
    try:
        return {'queries':search_plan(taxa,protocol.outcome_terms,p.index,protocol.reference_pmids),
                'scope':'Up to 20 PubMed-indexed records per candidate from Europe PMC, plus up to ten supplied reference IDs. No free-text question, product wording or consultation details sent.',
                'offline':p.client.offline,'network_used':False}
    except ValueError as error:
        raise HTTPException(422,str(error)) from error


@app.get('/api/research/questions')
def list_questions():
    # Stored packets were validated on creation/import. With no withdrawals,
    # listing titles need not deserialize every complete literature review.
    if not pipeline().withdrawn():
        return {'reviews':question_store().list(),'limit':100}
    result = []
    for item in question_store().list():
        try:
            active_question(item['id'])
            result.append(item)
        except HTTPException as error:
            if error.status_code != 410:
                raise
    return {'reviews': result, 'limit': 100}


@app.post('/api/research/questions', status_code=201)
def create_question(protocol: ResearchQuestion):
    try:
        return question_store().put(run_question(pipeline(), protocol))
    except (ValueError, RuntimeError) as error:
        raise HTTPException(422, str(error)) from error


@app.post('/api/research/questions/import', status_code=201)
async def import_question(file: UploadFile = File()):
    raw = await file.read(20_000_001)
    if len(raw) > 20_000_000:
        raise HTTPException(413, 'Research review exceeds 20 MB')
    try:
        record = json.loads(raw.decode('utf-8-sig'))
        payload = {'packet': record['packet'], 'decision_history': record['decision_history']}
        if hashlib.sha256(question_canonical(payload)).hexdigest() != record['sha256']:
            raise ValueError('Research review checksum mismatch')
        validate_packet(record['packet'])
        withdrawn = pipeline().withdrawn()
        if any(b['taxon_id'] in withdrawn or any(r['paper']['id'] in withdrawn for r in b['records']) for b in record['packet']['branches']):
            raise ValueError('Review contains withdrawn sources')
        return question_store().put(record['packet'], origin='IMPORTED_UNVERIFIED_REVIEW', decisions=record['decision_history'])
    except (ValueError, KeyError, TypeError, UnicodeDecodeError) as error:
        raise HTTPException(422, 'Invalid research review: '+str(error)) from error


@app.get('/api/research/questions/{identifier}')
def read_question(identifier: str, format: Literal['json', 'markdown', 'csv'] = 'json'):
    record = active_question(identifier)
    if format == 'markdown':
        return Response(review_markdown(record), media_type='text/markdown', headers={'Content-Disposition': f'attachment; filename="foliatrace-question-{record["id"]}.md"'})
    if format == 'csv':
        output = io.StringIO();writer = csv.writer(output)
        writer.writerow(['question', 'plant_wording', 'candidate', 'paper_id', 'title', 'url', 'rights', 'screening', 'checks', 'review_decision', 'review_reason'])
        decisions = {d['record_id']:d for d in record['decision_history']}
        for branch in record['packet']['branches']:
            for row in branch['records']:
                decision = decisions.get(row['id'], {})
                values = [record['packet']['protocol']['question'], record['packet']['protocol']['plant_name'], branch['name'], row['paper']['id'], row['paper']['title'], row['paper']['url'], row['paper']['licence'], row['screening']['state'], json.dumps(row['screening']['checks'], ensure_ascii=False), decision.get('decision', ''), decision.get('reason', '')]
                writer.writerow(["'"+v if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')) else v for v in values])
        return Response(output.getvalue(), media_type='text/csv', headers={'Content-Disposition': f'attachment; filename="foliatrace-question-{record["id"]}.csv"'})
    return record


@app.put('/api/research/questions/{identifier}/decisions')
def decide_question(identifier: str, decision: ReadingDecision):
    active_question(identifier)
    try:
        return question_store().decide(identifier, decision)
    except ValueError as error:
        raise HTTPException(422, str(error)) from error


@app.get('/api/product-labels')
def find_product_labels(q:str=Query(min_length=2,max_length=120),mode:Literal['reference','live']='reference',offset:int=Query(default=0,ge=0,le=200),market:Literal['all','on','off']='all'):
    if len(q.strip())<2:raise HTTPException(422,'Enter a product name, brand or barcode')
    try:
        return search_labels(pipeline().client,q.strip(),mode,offset,market)
    except (ValueError,RuntimeError,OSError) as error:
        raise HTTPException(503,'Label search unavailable: '+str(error)) from error


class LabelComparison(BaseModel):
    model_config=ConfigDict(extra='forbid')
    left:LabelSnapshot
    right:LabelSnapshot


@app.post('/api/product-labels/compare')
def compare_product_labels(request:LabelComparison):
    return compare_labels(request.left.model_dump(),request.right.model_dump())


@app.get('/api/product-labels/{identifier}')
def get_product_label(identifier:int,mode:Literal['reference','live']='reference'):
    if identifier<=0:raise HTTPException(422,'A positive NIH label identifier is required')
    try:
        snap=read_label(pipeline().client,identifier,mode)
        return {'snapshot':snap,'summary':summarize_label(snap['raw']),
                'ingredients':label_ingredients(snap['raw']),'source_text':label_wording(snap['raw'])}
    except (ValueError,RuntimeError,OSError,KeyError,TypeError) as error:
        raise HTTPException(503,'Label record unavailable: '+str(error)) from error


def consultation_store():
    return ConsultationStore(pipeline().store.path)


def active_consultation(identifier):
    record = consultation_store().get(identifier)
    if record is None:
        raise HTTPException(404, 'Consultation preparation not found')
    withdrawn = pipeline().withdrawn()
    for item in record['packet']['products']:
        if any(c['taxon_id'] in withdrawn for c in item['candidates']):
            raise HTTPException(410, 'A name source was withdrawn; prepare a new record')
    for link in record['packet']['linked_evidence']:
        if any(b['taxon_id'] in withdrawn or any(r['paper']['id'] in withdrawn for r in b['records']) for b in link['review']['packet']['branches']):
            raise HTTPException(410, 'A linked evidence source was withdrawn; review current sources')
    return record


@app.get('/api/consultations')
def list_consultations():
    if not pipeline().withdrawn():
        return {'preparations':consultation_store().list(),'limit':100}
    result=[]
    for item in consultation_store().list():
        try:
            active_consultation(item['id']);result.append(item)
        except HTTPException as error:
            if error.status_code != 410:raise
    return {'preparations':result,'limit':100}


@app.post('/api/consultations',status_code=201)
def create_consultation(request:ConsultationInput):
    try:
        return consultation_store().put(prepare_consultation(pipeline(),request))
    except ValueError as error:
        raise HTTPException(422,str(error)) from error


@app.post('/api/consultations/import',status_code=201)
async def import_consultation(file:UploadFile=File()):
    body=await file.read(20_000_001)
    if len(body)>20_000_000:raise HTTPException(413,'Consultation preparation exceeds 20 MB')
    try:
        record=json.loads(body.decode('utf-8-sig'));packet=record['packet']
        if hashlib.sha256(question_canonical(packet)).hexdigest()!=record['sha256']:raise ValueError('File integrity checksum mismatch')
        validate_consultation(packet)
        withdrawn=pipeline().withdrawn()
        if any(c['taxon_id'] in withdrawn for item in packet['products'] for c in item['candidates']):raise ValueError('A source was withdrawn')
        for link in packet['linked_evidence']:
            if any(b['taxon_id'] in withdrawn or any(r['paper']['id'] in withdrawn for r in b['records']) for b in link['review']['packet']['branches']):raise ValueError('A linked evidence source was withdrawn')
        return consultation_store().put(packet,origin='IMPORTED_UNVERIFIED_PREPARATION')
    except (ValueError,KeyError,TypeError,UnicodeDecodeError) as error:
        raise HTTPException(422,'Invalid consultation preparation: '+str(error)) from error


class ConsultationEvidenceLink(BaseModel):
    model_config=ConfigDict(extra='forbid')
    item_id:str=Field(pattern=r'^[a-f0-9]{12,32}$')
    review_id:str=Field(pattern=r'^[a-f0-9]{32}$')
    ingredient_key:str|None=Field(default=None,max_length=300)


@app.post('/api/consultations/{identifier}/evidence',status_code=201)
def link_consultation_evidence(identifier:str,request:ConsultationEvidenceLink):
    import copy
    record=active_consultation(identifier);review=active_question(request.review_id)
    try:
        item,ingredient = review_context(record, review, request.item_id, request.ingredient_key)
    except ValueError as error:
        raise HTTPException(422,str(error)) from error
    packet=copy.deepcopy(record['packet'])
    label=item['reported'].get('label_snapshot')
    packet['linked_evidence']=[v for v in packet['linked_evidence'] if not (v['item_id']==request.item_id and v['review']['id']==request.review_id)]
    packet['linked_evidence'].append({'item_id':request.item_id,'source_item_sha256':item['item_sha256'],'review':review,
                                      **({'ingredient_key':request.ingredient_key,'source_label_sha256':label['sha256']} if label else {}),
                                      'scope':'PROFESSIONAL_READING_NOT_PRODUCT_SAFETY_VERIFICATION'})
    packet['created_at']=now()
    return consultation_store().put(packet)


@app.post('/api/consultations/{identifier}/clarifications',status_code=201)
def answer_consultation_clarification(identifier:str,request:ClarificationAnswer):
    try:
        return consultation_store().put(add_clarification(active_consultation(identifier),request))
    except ValueError as error:
        raise HTTPException(422,str(error)) from error


@app.get('/api/consultations/{identifier}/study-bridge')
def compare_consultation_study(identifier:str,review_id:str=Query(pattern=r'^[a-f0-9]{32}$'),
                               item_id:str=Query(pattern=r'^[a-f0-9]{12,32}$'),
                               record_id:str=Query(pattern=r'^[a-f0-9]{24}$'),
                               ingredient_key:str|None=Query(default=None,max_length=300)):
    try:
        return study_bridge(active_consultation(identifier),active_question(review_id),item_id,record_id,ingredient_key)
    except ValueError as error:
        raise HTTPException(422,str(error)) from error


@app.post('/api/consultations/{identifier}/share-preview')
def preview_consultation_share(identifier:str,request:ShareSelection):
    try:
        return share_preview(active_consultation(identifier),request)
    except ValueError as error:
        raise HTTPException(422,str(error)) from error


@app.get('/api/consultations/{identifier}')
def read_consultation(identifier:str,format:Literal['json','markdown','summary','html']='json'):
    record=active_consultation(identifier)
    if format=='markdown':
        return Response(consultation_markdown(record),media_type='text/markdown',headers={'Content-Disposition':f'attachment; filename="foliatrace-consultation-{record["id"]}.md"'})
    if format=='summary':
        return Response(summary_markdown(record),media_type='text/markdown',headers={'Content-Disposition':f'attachment; filename="foliatrace-conversation-{record["id"]}.md"'})
    if format=='html':
        return Response(summary_html(record),media_type='text/html',headers={
            'Content-Disposition':f'inline; filename="foliatrace-conversation-{record["id"]}.html"',
            'Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"})
    return record


@app.get("/")
@app.get("/research")
def home():
    return FileResponse(ROOT / "frontend" / "index.html")


app.mount("/assets", StaticFiles(directory=ROOT / "frontend"), name="assets")

# The browser checker (NIH statements x medicines, OCR, pharmacist QR) is the same static app as the
# public demo. Build it with scripts/sync_public_demo.py (and build_care_demo.py for recorded cases).
_CHECKER = ROOT / "sites" / "foliatrace-research" / "build"
if (_CHECKER / "index.html").exists():
    app.mount("/check", StaticFiles(directory=_CHECKER, html=True), name="checker")

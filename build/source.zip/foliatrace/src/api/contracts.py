from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator


class Span(BaseModel):
    text: str
    start: int = Field(ge=0)
    end: int = Field(gt=0)

    @model_validator(mode='after')
    def ordered(self):
        if self.end <= self.start:raise ValueError('Invalid half-open source span')
        return self


class Mention(Span):
    id: str
    normalized: str
    method: str


class Relation(BaseModel):
    relation: Literal['SUPPORTS','CONTRADICTS','MIXED','IRRELEVANT','INSUFFICIENT']
    supporting_text: str | None
    rationale: str
    directness: str
    mechanistic_relation: str | None = None
    reported_relation: str | None = None


class AnalysisRecord(BaseModel):
    model_config=ConfigDict(extra='forbid')
    run_id: str = Field(pattern=r'^[a-f0-9]{24}$')
    created_at: str
    pipeline_version: str
    snapshot_sha256: str = Field(pattern=r'^[a-f0-9]{64}$')
    knowledge_sha256: str | None = Field(default=None, pattern=r'^[a-f0-9]{64}$')
    code_fingerprint: str
    model_fingerprint: str
    source: dict
    input: str
    mentions: list[Mention]
    historical_claims: list[dict]
    local_names_not_in_any_list: list[str] = []
    resolutions: list[dict]
    conditions: list[dict]
    evidence: list[dict]
    conflicts: list[dict]
    blocked_citations: list[dict]
    cache_hit: bool
    limitations: list[str]
    configuration: dict
    models: dict
    graph: dict
    performance: dict
    identity_counterfactuals: list[dict] = []
    historical_identity_references: dict[str, list[dict]] = {}
    researcher_reviews: list[dict] = []
    research_brief: dict = {}
    compound_assay_leads: list[dict] = []
    study_reading_sets: list[dict] = []
    language: str = 'en'
    literature_access: dict = {}
    research_digest: list[dict] = []
    plant_literature: dict = {}

    @model_validator(mode='after')
    def integrity(self):
        for mention in self.mentions:
            if self.input[mention.start:mention.end]!=mention.text:raise ValueError('Mention/source span mismatch')
        for evidence in self.evidence:
            Relation.model_validate(evidence['relation'])
            if evidence['identity_qualifier']!='CONDITIONAL_ON_CANDIDATE_IDENTITY':raise ValueError('Identity uncertainty was lost')
            support=evidence['relation']['supporting_text']
            if support and support not in evidence['paper']['abstract']:raise ValueError('Unsupported output span')
            finding = evidence['relation'].get('reported_finding') or {}
            for statement in finding.get('statements', []) + finding.get('unassigned_statements', []):
                start, end = statement['start'], statement['end']
                if not 0 <= start < end <= len(evidence['paper']['abstract']) or evidence['paper']['abstract'][start:end] != statement['supporting_text']:
                    raise ValueError('Endpoint finding/abstract span mismatch')
            if evidence['citation']['status']=='REJECTED':raise ValueError('Rejected citation cannot enter an API response')
            for context in evidence.get('historical_contexts', []):
                span = context['support']
                if self.input[span['start']:span['end']] != span['text']:
                    raise ValueError('Historical statement comparison/source span mismatch')
            attribution = evidence['study'].get('preparation_attribution') or {}
            methods = {c['id']: c for c in evidence['paper'].get('methods_contexts', [])}
            for form in attribution.get('forms', []) + attribution.get('other_preparation_wording', []):
                if form.get('source_kind') == 'FULL_TEXT_METHODS_TABLE':
                    source = methods.get(form.get('source_id'))
                    if not source or source.get('source_kind') != 'FULL_TEXT_METHODS_TABLE' or source['paper_id'] != evidence['paper']['id']:
                        raise ValueError('Preparation table source mismatch')
                    for span in (form, form['name_span'], form['context']):
                        if span.get('source_id') != source['id'] or source['text'][span['start']:span['end']] != span['text']:
                            raise ValueError('Preparation/table transcription span mismatch')
                elif evidence['paper']['abstract'][form['start']:form['end']] != form['text']:
                    raise ValueError('Preparation wording/abstract span mismatch')
            for check in (evidence.get('comparability') or {}).get('checks', []):
                span = check.get('span') or {}
                if span.get('source_kind', '').startswith('FULL_TEXT_METHODS'):
                    context = methods.get(span.get('source_id'))
                    if not context or context.get('source_kind') != span['source_kind'] or context['paper_id'] != evidence['paper']['id'] or context['text'][span['start']:span['end']] != span['text']:
                        raise ValueError('Methods check/source span mismatch')
        ids={n['id'] for n in self.graph['nodes']}
        for references in self.historical_identity_references.values():
            for reference in references:
                text = reference['input']
                for excerpt in reference['excerpts']:
                    if text[excerpt['start']:excerpt['end']] != excerpt['text']:
                        raise ValueError('Historical name reference/source span mismatch')
                    for name in excerpt['names']:
                        if not (excerpt['start'] <= name['start'] < name['end'] <= excerpt['end']) or text[name['start']:name['end']] != name['text']:
                            raise ValueError('Historical name reference/name span mismatch')
        if any(e['subject'] not in ids or e['object'] not in ids or not e.get('provenance') for e in self.graph['edges']):raise ValueError('Graph integrity failure')
        return self

"""Research API and local product frontend."""

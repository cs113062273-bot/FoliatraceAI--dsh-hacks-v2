import test from 'node:test';
import assert from 'node:assert/strict';
import {sourceContext, researchQueries, excludedFromPatientLeads} from '../frontend/demo/research-evidence.js';
test('multiple patient goals remain separate research questions',()=>{
  const queries=researchQueries('Turmeric','memory and joint pain');
  assert.deepEqual(queries.map(q=>q.goal),['memory','joint pain']);
  assert.ok(queries.every(q=>q.query.includes('in people')));
});
test('abstract excerpts preserve exact source characters and absent dimensions stay empty',()=>{
  const abstract='Background: A small study. Forty adult participants received extract 500 mg daily. The trial was randomized against placebo.';
  const rows=sourceContext({abstract});
  for(const row of rows){assert.ok(row.span);assert.equal(abstract.slice(row.span.start,row.span.end),row.span.text)}
  assert.ok(sourceContext({abstract:'No relevant information provided.'}).every(r=>r.span===null));
});
test('obvious nonclinical and protocol titles stay out of patient research leads',()=>{
  for(const title of ['Valerian stress in Japanese quails','Goldenseal in a rat burn wound model','Foliar application during drought','Curcumin trial protocol','Lipids in HepG2 cells'])assert.equal(excludedFromPatientLeads({title}),true);
  assert.equal(excludedFromPatientLeads({title:'Turmeric for knee osteoarthritis: a randomized trial'}),false);
});

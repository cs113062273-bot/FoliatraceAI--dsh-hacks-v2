// node --test tests/safety_engine.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, existsSync} from 'node:fs';
import {indexKnowledge, parseLabelText, fromDsldLabel, analyze, resolveMedicines, identify} from '../frontend/demo/safety-engine.js';
import {EXAMPLES} from '../frontend/demo/safety-examples.js';

const kb = JSON.parse(readFileSync(new URL('../frontend/demo/safety-knowledge.json', import.meta.url)));
const idx = indexKnowledge(kb);
const Q = f => f.quotes.map(q => q.text + ' ' + q.items.join(' ')).join(' ');
// What the on-device AI returns for the examples' everyday phrases (see reports/ai_medicine_understanding_*.json).
const AI_REPORT = JSON.parse(readFileSync(new URL('../reports/ai_medicine_understanding_v2_2026-11-12.json', import.meta.url)));
const AI_FIXTURE = Object.fromEntries(AI_REPORT.development.rows.filter(r=>r.predicted).map(r=>[r.text,{group:r.predicted,score:r.similarity}]));
const run = ex => analyze({products: ex.products.map(p => parseLabelText(p.text, p.name)), medicines: ex.medicines, conditions: ex.conditions, aiMedicines: AI_FIXTURE}, idx);
// Page text cache written by `python scripts/build_safety_knowledge.py` (downloads the NIH pages).
const pagesUrl = new URL('../.runtime/nccih/pages.json', import.meta.url);
const pages = existsSync(pagesUrl) ? JSON.parse(readFileSync(pagesUrl, 'utf8')) : null;
const clean = s => s.normalize('NFKD').replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/[–—]/g, '-').replace(/\s+/g, ' ');

test('Mei: ginkgo and garlic are flagged against warfarin, with NIH quotes', () => {
  const r = run(EXAMPLES[0]);
  const discuss = r.findings.filter(f => f.level === 'discuss' && !f.conditional);
  assert.ok(discuss.some(f => f.herb === 'ginkgo' && f.medicines.some(m => m.name === 'warfarin')));
  assert.ok(discuss.some(f => f.herb === 'garlic' && f.medicines.some(m => m.name === 'warfarin')));
  assert.ok(r.findings.some(f => f.herb === 'turmeric' && f.because === 'variant'), 'BioPerine marks a bioavailable curcumin formulation');
  assert.ok(r.gaps.some(g => g.type === 'identity' && g.term === 'ginseng'), 'bare ginseng stays ambiguous');
  assert.ok(r.gaps.some(g => g.type === 'blend' && g.ingredients.some(i => /garlic/i.test(i)) && g.blend === 'Proprietary Wellness Blend'), 'blend amounts flagged');
  assert.ok(r.findings.every(f => f.source.url.startsWith('https://www.nccih.nih.gov/health/')));
  assert.ok(!r.findings.some(f => f.herb === 'ginger' && f.level !== 'note'), 'no invented ginger interaction');
});

test('Sam: St. John\'s wort flags sertraline (serotonin) and birth control (weakened effect)', () => {
  const r = run(EXAMPLES[1]);
  const sjw = r.findings.filter(f => f.herb === 'st-johns-wort' && f.because === 'medicine');
  assert.ok(sjw.some(f => f.medicines.some(m => m.name === 'sertraline') && /serotonin/.test(Q(f))));
  assert.ok(sjw.some(f => f.medicines.some(m => m.name === 'birth control pill') && /weaken/.test(Q(f)) && /Birth control pills/.test(Q(f))));
  assert.ok(r.gaps.some(g => g.type === 'identity' && g.term === 'chamomile'), 'chamomile species unspecified');
  const cham = r.gaps.find(g => g.type === 'identity' && g.term === 'chamomile');
  assert.ok(cham.candidates.find(c => c.herb === 'chamomile').findings.some(f => f.medicines.some(m => m.name === 'birth control pill')), 'German chamomile statement is nested under the identity question');
  assert.ok(!r.findings.some(f => f.herb === 'chamomile'), 'not promoted to the main list');
});

test('Ray: inferred statin triggers the NIH red yeast rice quote; goldenseal vs metformin; duplicate green tea', () => {
  const r = run(EXAMPLES[2]);
  assert.ok(r.findings.some(f => f.herb === 'red-yeast-rice' && /lovastatin/.test(Q(f)) && f.medicines.some(m => m.input === 'my cholesterol pill' && m.inferred)), 'AI-understood statin triggers the red yeast rice statement');
  assert.ok(!r.findings.some(f => f.herb === 'green-tea' && /atorvastatin/.test(Q(f))), 'an atorvastatin-specific sentence is not applied to an unnamed statin');
  assert.ok(r.findings.some(f => f.herb === 'goldenseal' && f.medicines.some(m => m.name === 'metformin')));
  assert.ok(r.gaps.some(g => g.type === 'duplicate' && g.herb === 'green-tea'));
  const ginseng = r.gaps.find(g => g.type === 'identity' && g.term === 'ginseng');
  assert.ok(ginseng && ginseng.candidates.find(c => c.herb === 'asian-ginseng').flagged, 'diabetes caution only for the Asian ginseng candidate');
  assert.ok(!r.findings.some(f => f.herb === 'asian-ginseng'), 'Asian ginseng statements stay conditional');
  assert.ok(r.gaps.some(g => g.type === 'duplicate' && g.herb === 'green-tea' && g.products.length === 2), 'green tea flagged across both products');
  assert.equal(r.findings.find(f => f.herb === 'red-yeast-rice' && f.because === 'medicine').quotes.length, 2, 'two statin statements in one card');
});

test('Siberian ginseng is not treated as Asian ginseng', () => {
  const p = parseLabelText('Siberian ginseng (Eleutherococcus senticosus) root 500 mg', 'X');
  const f = identify(p, idx);
  assert.ok(!f.some(x => x.herb === 'asian-ginseng'));
  assert.ok(f.some(x => x.unverified));
});

test('medicine resolution: brands, doses, typos and unknowns', () => {
  const r = resolveMedicines(['Coumadin 5mg', 'warfrin', 'Zoloft 50 mg daily', 'Synthroid', 'mystery pill'], idx);
  assert.equal(r[0].name, 'warfarin'); assert.equal(r[1].name, 'warfarin'); assert.ok(r[1].corrected);
  assert.equal(r[2].name, 'sertraline'); assert.equal(r[3].name, 'levothyroxine'); assert.equal(r[4].known, false);
});

test('no medicines and no conditions: no medicine-specific flag is invented', () => {
  const r = analyze({products: [parseLabelText('Ginkgo biloba 120 mg', 'G')], medicines: [], conditions: []}, idx);
  assert.equal(r.findings.filter(f => f.because === 'medicine').length, 0);
  assert.equal(r.checked.length, 1);
});

test('OCR noise: fuzzy matching recovers misspelt herb names only in OCR mode', () => {
  const p = {...parseLabelText('Gink9o biloba 120 mg\nValerlan root 200 mg', 'OCR'), source: 'ocr'};
  const r = analyze({products: [p], medicines: ['zolpidem'], conditions: []}, idx);
  assert.ok(r.checked.some(c => c.herb === 'valerian' && c.basis === 'fuzzy'));
  assert.ok(r.findings.some(f => f.herb === 'valerian' && f.medicines.some(m => m.name === 'zolpidem')));
  const strict = analyze({products: [parseLabelText('Valerlan root 200 mg', 'T')], medicines: [], conditions: []}, idx);
  assert.equal(strict.checked.length, 0);
});

test('DSLD record: declared genus/species resolves identity; blends propagate', () => {
  const label = {id: 1, fullName: 'Test', brandName: 'B', ingredientRows: [
    {name: 'Ginseng', notes: 'PlantPart: root Genus: Panax Species: ginseng', category: 'botanical', quantity: [{quantity: 100, unit: 'mg'}]},
    {name: 'Herbal Blend', category: 'blend', quantity: [{quantity: 400, unit: 'mg'}], nestedRows: [
      {name: 'Ginkgo', notes: 'Genus: Ginkgo Species: biloba', category: 'botanical', quantity: []},
      {name: 'Astragalus', notes: 'Genus: Astragalus Species: membranaceus', category: 'botanical', quantity: []}]}]};
  const p = fromDsldLabel(label);
  const r = analyze({products: [p], medicines: ['warfarin'], conditions: []}, idx);
  assert.ok(r.checked.some(c => c.herb === 'asian-ginseng' && c.basis === 'label_species'));
  assert.ok(!r.gaps.some(g => g.type === 'identity'), 'label species removes the ambiguity');
  assert.ok(r.gaps.some(g => g.type === 'blend' && g.ingredients.includes('Ginkgo') && g.ingredients.includes('Astragalus') && g.total === '400 mg'));
  assert.ok(r.gaps.some(g => g.type === 'unverified' && /Astragalus/.test(g.name)));
  assert.ok(r.findings.some(f => f.herb === 'ginkgo' && f.level === 'discuss'));
});

test('every quote in the knowledge base occurs verbatim in the cached NIH page', {skip: pages ? false : 'run `python scripts/build_safety_knowledge.py` first to download the NIH pages'}, () => {
  let n = 0;
  for (const h of kb.herbs) {
    const text = clean(pages[h.source].text);
    for (const q of [...h.rules.map(r => r.quote), ...(h.variants || []).map(v => v.quote)]) { n++; assert.ok(text.includes(clean(q)), h.id + ': ' + q.slice(0, 60)); }
  }
  assert.ok(n >= 60);
});

test('regression: a qualified non-covered species is reported, never silently dropped', () => {
  const r = analyze({products: [parseLabelText('Ginseng (Panax quinquefolius) root 200 mg\nVitamin C 500 mg', 'X')], medicines: ['warfarin'], conditions: []}, idx);
  assert.ok(r.gaps.some(g => g.type === 'unverified' && /quinquefolius/.test(g.name)));
  assert.ok(r.unmatched.some(u => /Vitamin C/.test(u.ingredient)), 'non-herb lines are listed as not checked');
  assert.ok(!r.findings.some(f => f.herb === 'asian-ginseng'));
});

test('regression: a condition-specific caution is not repeated as a general caution', () => {
  const r = analyze({products: [parseLabelText('Kava root 100 mg', 'K')], medicines: [], conditions: ['liver']}, idx);
  const liver = r.findings.filter(f => f.herb === 'kava' && f.quotes.some(q => /liver injury/.test(q.text)));
  assert.equal(liver.length, 1);
  assert.equal(liver[0].because, 'condition');
});

test('AI-understood medicine: a lay phrase triggers the same NIH statement, marked as inferred', () => {
  const phrase = 'the clot medicine after my stroke';
  const products = [parseLabelText('Ginkgo biloba leaf extract 120 mg', 'G')];
  const withAi = analyze({products, medicines: [phrase], conditions: [], aiMedicines: {[phrase]: {group: 'blood_thinner', score: 0.62}}}, idx);
  const f = withAi.findings.find(x => x.herb === 'ginkgo' && x.because === 'medicine');
  assert.ok(f && f.medicines[0].inferred && f.medicines[0].label === 'a blood thinner (anticoagulant)');
  assert.ok(/which I think is a blood thinner/.test(f.question) && /exactly/.test(f.question));
  assert.ok(withAi.gaps.some(g => g.type === 'inferred_medicine' && g.input === phrase));
  assert.ok(!withAi.gaps.some(g => g.type === 'unknown_medicine'));
  const noAi = analyze({products, medicines: [phrase], conditions: []}, idx);
  assert.ok(!noAi.findings.some(x => x.because === 'medicine') && noAi.gaps.some(g => g.type === 'unknown_medicine'));
  const unsure = analyze({products, medicines: [phrase], conditions: [], aiMedicines: {[phrase]: {group: null, best: 'blood_thinner', score: 0.44}}}, idx);
  assert.ok(!unsure.findings.some(x => x.because === 'medicine'), 'below the threshold nothing is inferred');
});

test('dictionary beats AI: a known medicine name is never overridden by an AI reading', () => {
  const r = resolveMedicines(['warfarin'], idx, {warfarin: {group: 'cholesterol', score: 0.9}});
  assert.equal(r[0].name, 'warfarin'); assert.ok(!r[0].inferred);
});

test('negated and historical names never become current medicine matches, even with supplied AI metadata', () => {
  const phrases = ['I stopped taking warfarin', 'not taking my statin', 'herbal sleeping tea'];
  const r = analyze({products:[parseLabelText('Ginkgo biloba 120 mg\nRed yeast rice 100 mg\nValerian 200 mg','X')],medicines:phrases,
    aiMedicines:Object.fromEntries(phrases.map(t=>[t,{group:'blood_thinner',score:.99}]))},idx);
  assert.equal(r.findings.filter(f=>f.because==='medicine').length,0);
  assert.equal(r.gaps.filter(g=>g.type==='unknown_medicine').length,phrases.length);
});

test('persisted or shared AI metadata below the active threshold cannot trigger a warning', () => {
  const phrase='my cholesterol pill';
  for(const score of [.54,NaN,Infinity,undefined]) {
    const r=analyze({products:[parseLabelText('Red yeast rice 1200 mg','X')],medicines:[phrase],aiMedicines:{[phrase]:{group:'cholesterol',score}}},idx);
    assert.ok(!r.findings.some(f=>f.because==='medicine'));
  }
});
